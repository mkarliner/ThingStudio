// SPDX-License-Identifier: Apache-2.0
// editor/src/app/main.ts
//
// Bare-minimum editor app shell: canvas (Rete, five real node types via
// rete/nodes.ts) -> real compiler (compiler/compile.ts, the same one the
// off-device tests exercise) -> real mpy-cross WASM cross-compile
// (vendored from mpy-cross-wasm/, see editor/public/vendor/mpy-cross) ->
// real §13 DEPLOY over WebSerial (protocol/transport.ts). Save/load
// (flow-file/), the HELLO/version gate (version.ts), and node highlighting
// are all wired in below.
//
// Canvas layer rewritten Rete migration Phase 3
// (docs/working-notes/rete-migration-decision.md's scoped task list, items
// 1 and 10-13). app/nodes.ts (Litegraph) is deliberately no longer
// imported from this file -- not deleted (Phase 4 step 17, after the
// hardware round-trip). Per the decision doc's own framing, "the existing
// Litegraph editor stays runnable" now means reversible via git, not
// simultaneously live in this browser tab alongside Rete -- Litegraph and
// Rete both want to own the same canvas element and pointer events, so
// there is no dual-canvas mode. Confirmed with Mike before this rewrite
// started, same as the decision doc asked.
//
// Vue-mounting judgment call (index.html's own open question, decision doc
// item 2): this migration mounts two small standalone Vue apps
// (PaletteSidebar.vue, PropertyPanel.vue) via createApp(...).mount(...)
// into two designated containers, rather than folding the whole app shell
// into one Vue tree. The canvas region's own rendering is already Vue
// internally (rete-vue-plugin, via createThingstudioEditor()) without this
// file mounting anything itself. Toolbar, source-preview, console, and the
// WebSerial connect/deploy flow all stay exactly the vanilla-DOM
// addEventListener style they always were. This is the smaller-blast-
// radius reading of the two options: the canvas-agnostic two-thirds of
// this file (mpy-cross loader, device console, HELLO/version gate,
// Deploy handler) must survive verbatim per the decision doc's stop
// conditions, and a single-Vue-tree rewrite would touch all of it for no
// benefit this migration is scoped to deliver.
//
// Config nodes (config-node-and-palette-implementation-briefing.md):
// rete/store.ts's `configs` map is the single source of truth for a
// flow's config nodes, same role it already plays for `selectedNode`/
// `propertyVersion`. This file folds that store into save (buildFlowFile),
// load (applyFlowFile -> replaceAllConfigs), compile (toGraphData), and
// canvas-clear (clearConfigs) -- the "genuinely new plumbing" the briefing
// calls out, not a couple of extra fields on something that already walks
// the canvas.
//
// Custom node authoring (docs/working-notes/custom-node-authoring-
// scoping.md, 2026-08-20): a loaded custom node type (rete/custom-nodes-
// store.ts) is session-scoped, not flow-scoped -- unlike configs, it is
// NOT cleared by "clear canvas" and is not part of applyFlowFile()'s
// clear-then-repopulate cycle. What IS new here: addCustomNodeOfType()
// (this file's equivalent of addNodeOfKind() for a loaded custom type),
// the drop handler's second MIME check, applyFlowFile()'s per-node branch
// (a saved node whose type matches a *currently loaded* custom package
// constructs via CustomNode instead of NODE_FACTORIES -- one not
// currently loaded already falls through to the pre-existing "unknown
// type, skip + log" path unchanged, no special-casing needed there), and
// currentSource()'s registry merge (custom-node.ts's
// mergeCustomNodeRegistry(), rebuilt fresh each compile since custom
// nodes can be loaded mid-session).

import { createApp, watch } from "vue";
import { compile } from "../compiler/compile.js";
import type { NodeLineRange } from "../compiler/compile.js";
import { buildRegistry } from "../node-library/registry.js";
import { mergeCustomNodeRegistry } from "../node-library/custom-node.js";
import { WebSerialTransport, type WebSerialPort } from "../protocol/transport.js";
import type { Message, ProtocolVersion } from "../protocol/messages.js";
import { decideDeploy } from "../protocol/version.js";
import { createThingstudioEditor, type ThingstudioEditor } from "./rete/editor-setup.js";
import { NODE_FACTORIES, CustomNode, type AnyThingstudioNode } from "./rete/nodes.js";
import { DRAG_MIME, CUSTOM_DRAG_MIME, type NodeKind } from "./rete/palette.js";
import { toGraphData, socketIndex } from "./rete/graph-adapter.js";
import {
  propertyVersion,
  configs as configsStore,
  replaceAllConfigs,
  clearConfigs,
  deviceConnected,
  flowDeployed,
  fireNodeImpl,
  type FireResult,
} from "./rete/store.js";
import { getCustomNodePackage, listCustomNodeDefinitions } from "./rete/custom-nodes-store.js";
import PaletteSidebar from "./rete/PaletteSidebar.vue";
import PropertyPanel from "./rete/PropertyPanel.vue";
import {
  buildFlowFile,
  parseFlowFile,
  serializeFlowFileText,
  FlowFileError,
  type FlowFile,
  type FlowFileEdge,
  type FlowFileConfig,
  type CanvasNodeSnapshot,
} from "../flow-file/flow-file.js";
import { saveFlowFileToDisk, openFlowFileFromDisk } from "../flow-file/file-io.js";

const el = <T extends HTMLElement = HTMLElement>(id: string): T => document.getElementById(id) as T;

// ---------------------------------------------------------------------
// Canvas
// ---------------------------------------------------------------------
// Top-level await, not an async IIFE: createThingstudioEditor() does no
// network/disk I/O (just plugin/DOM setup), so everything below this
// block starts running a single microtask later in practice -- simpler
// than threading an "editor not ready yet" guard through every function
// below that touches reteEditor/reteArea.
const canvasContainer = el("rete-canvas");
const reteHandle: ThingstudioEditor = await createThingstudioEditor(canvasContainer);
const reteEditor = reteHandle.editor;
const reteArea = reteHandle.area;

let placeCount = 0;
function nextGridPosition(): { x: number; y: number } {
  const col = placeCount % 3;
  const row = Math.floor(placeCount / 3);
  placeCount++;
  return { x: 80 + col * 220, y: 80 + row * 160 };
}

async function addNodeOfKind(kind: NodeKind, position?: { x: number; y: number }): Promise<AnyThingstudioNode> {
  const node = NODE_FACTORIES[kind]();
  await reteHandle.addNode(node, position ?? nextGridPosition());
  return node;
}

/** Custom-node counterpart to addNodeOfKind() above -- `type` must name a
 * package already loaded this session (rete/custom-nodes-store.ts); a
 * stale drag/click referencing a type that's since... never happens today
 * (nothing unloads a custom type once loaded), but a stale flow file
 * reference is real (applyFlowFile() below), so this stays a fallible
 * lookup rather than an assert. */
async function addCustomNodeOfType(type: string, position?: { x: number; y: number }): Promise<AnyThingstudioNode | null> {
  const pkg = getCustomNodePackage(type);
  if (!pkg) {
    logLine(`[custom node "${type}" is not loaded this session -- use "Load custom node..." first]`, "err");
    return null;
  }
  const node = new CustomNode(pkg.descriptor);
  await reteHandle.addNode(node, position ?? nextGridPosition());
  return node;
}

el("clear-canvas").addEventListener("click", async () => {
  await reteHandle.clear();
  placeCount = 0;
  // Configs are flow-scoped, not canvas-node-scoped (they never appear as
  // boxes -- graph.ts's GraphConfigNode header), but "clear canvas" means
  // "start a new empty flow" from the user's point of view, so they reset
  // together rather than leaving orphaned configs no visible node
  // references anymore. Loaded custom node *types* are session-scoped, not
  // flow-scoped (this file's header comment) -- deliberately NOT reset
  // here.
  clearConfigs();
});

// Palette (left) -- click-to-add via the `add`/`addCustom` emits, plus the
// two custom-node-load outcome emits routed to the same device console
// every other status line already uses. Vue's programmatic mount treats
// an `onX` prop as a listener for an emitted `x` event, same as if this
// were a child component in a template (PaletteSidebar.vue's own
// `defineEmits<...>()`).
createApp(PaletteSidebar, {
  onAdd: (kind: NodeKind) => {
    void addNodeOfKind(kind);
  },
  onAddCustom: (type: string) => {
    void addCustomNodeOfType(type);
  },
  onCustomNodeLoaded: (type: string) => {
    logLine(`[custom node loaded: ${type}]`, "ok");
  },
  onCustomNodeLoadError: (message: string) => {
    logLine(`[custom node load failed] ${message}`, "err");
  },
}).mount(el("palette-mount"));

// Property panel (right) -- reads/writes the selected node via store.ts;
// editor-setup.ts's nodepicked pipe (Phase 3 item 13) keeps `selectedNode`
// in sync with canvas clicks.
createApp(PropertyPanel).mount(el("property-panel-mount"));

// Drag-and-drop from the palette onto the canvas -- ported from poc-rete's
// App.vue onDrop(), same graph-space coordinate math: a screen point maps
// back to graph space by subtracting the canvas's own on-screen offset and
// current pan, then dividing by zoom (the inverse of how the canvas
// positions/scales its content layer). PaletteSidebar.vue's own dragstart
// sets DRAG_MIME (built-in kinds) or CUSTOM_DRAG_MIME (loaded custom
// types, checked first below since a custom type is never also a NodeKind
// literal -- the two MIME types are mutually exclusive per drag, not a
// fallback chain); this is the drop-target half, a plain DOM listener
// rather than part of either mounted Vue app since the gesture crosses a
// real DOM boundary between them.
canvasContainer.addEventListener("dragover", (e) => e.preventDefault());
canvasContainer.addEventListener("drop", (e) => {
  e.preventDefault();
  const rect = canvasContainer.getBoundingClientRect();
  const { x: panX, y: panY, k: zoom } = reteArea.area.transform;
  const graphX = (e.clientX - rect.left - panX) / zoom;
  const graphY = (e.clientY - rect.top - panY) / zoom;

  const customType = e.dataTransfer?.getData(CUSTOM_DRAG_MIME);
  if (customType) {
    void addCustomNodeOfType(customType, { x: graphX, y: graphY });
    return;
  }
  const kind = e.dataTransfer?.getData(DRAG_MIME) as NodeKind | "";
  if (!kind) return;
  void addNodeOfKind(kind, { x: graphX, y: graphY });
});

// ---------------------------------------------------------------------
// Flow save/load (flow-file/) -- the canvas-coupled half. flow-file.ts
// owns the actual format (pure, off-device testable); this is just the
// glue reading/writing a live Rete graph, same split transport.ts
// (protocol machinery) vs. main.ts's Connect handler (the raw
// requestPort() call) already uses.
// ---------------------------------------------------------------------
function extractCanvasSnapshot(): { nodes: CanvasNodeSnapshot[]; edges: FlowFileEdge[] } {
  const nodes = reteEditor.getNodes() as AnyThingstudioNode[];
  // Rete node IDs are string UUIDs (ClassicPreset.Node's own constructor,
  // crypto.randomUUID()) -- flow-file.ts's format wants plain integers
  // (Node-RED-cautionary-tale-driven determinism, that module's own
  // header), so this assigns fresh sequential IDs for the save, same
  // "recomputed fresh, no persistent numbering" approach graph-adapter.ts
  // takes for the compiler-facing path (1-indexed, matching that file's
  // own convention).
  const fileIdByReteId = new Map<string, number>();
  nodes.forEach((n, i) => fileIdByReteId.set(n.id, i + 1));

  const snapshot: CanvasNodeSnapshot[] = nodes.map((n) => {
    const view = reteArea.nodeViews.get(n.id);
    // A missing NodeView would mean the node exists in the editor's data
    // model but was never actually rendered -- shouldn't happen
    // (reteHandle.addNode() always area.translate()s a node right after
    // adding it), but falls back to (0, 0) rather than crashing the save,
    // same "a partially-bad state should still save what it can" reasoning
    // applyFlowFile's load side below uses.
    const pos: [number, number] = view ? [view.position.x, view.position.y] : [0, 0];
    return {
      id: fileIdByReteId.get(n.id)!,
      // n.nodeType is each node's own real compiler type string (nodes.ts)
      // -- "thingstudio/xxx" for a first-party kind, or a custom type's own
      // namespaced id verbatim (e.g. "custom/dht22") -- read directly
      // instead of computing `` `thingstudio/${n.kind}` ``, which assumed
      // every node lives in the "thingstudio/" namespace (docs/working-
      // notes/custom-node-authoring-scoping.md, 2026-08-20).
      type: n.nodeType,
      properties: n.properties,
      pos,
      size: [n.width, n.height],
    };
  });

  const edges: FlowFileEdge[] = reteEditor.getConnections().map((c) => {
    const sourceNode = reteEditor.getNode(c.source) as AnyThingstudioNode;
    const targetNode = reteEditor.getNode(c.target) as AnyThingstudioNode;
    const originSlot = socketIndex(Object.keys(sourceNode.outputs), c.sourceOutput);
    const targetSlot = socketIndex(Object.keys(targetNode.inputs), c.targetInput);
    return [fileIdByReteId.get(c.source)!, originSlot, fileIdByReteId.get(c.target)!, targetSlot];
  });

  return { nodes: snapshot, edges };
}

/** rete/store.ts's `configs` map, snapshotted into flow-file.ts's own
 * {id, type, properties} shape -- already agrees field-for-field
 * (store.ts's ConfigEntry header), so this is a plain copy, not a
 * translation. */
function extractConfigsSnapshot(): FlowFileConfig[] {
  return [...configsStore.value.values()].map((c) => ({ id: c.id, type: c.type, properties: c.properties }));
}

/**
 * Reconstructs the canvas from a parsed flow file. Rete rewrite of the
 * Litegraph version -- rete has no widget layer to sync (no
 * per-node `configure()` call doing double duty the way Litegraph's did),
 * which makes this simpler, not harder: construct each node via
 * NODE_FACTORIES (or, for a custom type, `new CustomNode(descriptor)` --
 * see below), assign its saved properties directly, and place it via
 * reteHandle.addNode(). The fault-handling contract this replaces is not
 * negotiable and is unchanged: a referenced node type that isn't
 * registered (a newer/unknown type, a typo from hand-editing the file, or
 * -- new with custom nodes -- a custom type this session hasn't loaded
 * yet) is reported and skipped, along with any edge touching it, rather
 * than aborting the whole load -- CLAUDE.md's fault-handling priority
 * applied to file I/O: a partially-bad file should still load what it
 * can. An edge naming a valid slot index that doesn't resolve to a real
 * socket key, or a connection Rete's own validation pipe rejects, is
 * reported and skipped the same way rather than treated as fatal.
 */
async function applyFlowFile(file: FlowFile): Promise<void> {
  await reteHandle.clear();
  placeCount = 0;
  // Configs load before nodes: a node's own ConfigRefField (PropertyPanel.vue)
  // looks its bound wifiConfigId up in this store to render the dropdown's
  // current selection, so the store needs to already hold the file's
  // configs by the time any node using one gets constructed/selected below.
  replaceAllConfigs(file.configs.map((c) => ({ id: c.id, type: c.type, properties: c.properties })));
  const skippedFileIds = new Set<number>();
  const nodeByFileId = new Map<number, AnyThingstudioNode>();

  for (const n of file.nodes) {
    // Custom node types are checked first -- a loaded custom package's
    // `type` never starts with "thingstudio/" (validateCustomNodeDescriptor
    // enforces the reserved namespace), so there's no ambiguity between
    // the two lookups. A custom type this session simply hasn't loaded
    // yet falls straight through to the existing built-in lookup below,
    // which correctly reports it as unknown (custom-node-authoring-
    // scoping.md's Decision 4: session-scoped loading, no auto-restore).
    const customPkg = getCustomNodePackage(n.type);
    let node: AnyThingstudioNode;
    if (customPkg) {
      node = new CustomNode(customPkg.descriptor);
    } else {
      const kind = n.type.replace(/^thingstudio\//, "") as NodeKind;
      const factory = NODE_FACTORIES[kind];
      if (!factory) {
        skippedFileIds.add(n.id);
        logLine(`[load: skipped node ${n.id}, unknown type "${n.type}"]`, "err");
        continue;
      }
      node = factory();
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    Object.assign(node.properties as any, n.properties);
    const layoutEntry = file.layout[String(n.id)];
    const position = layoutEntry ? { x: layoutEntry.pos[0], y: layoutEntry.pos[1] } : { x: 0, y: 0 };
    await reteHandle.addNode(node, position);
    nodeByFileId.set(n.id, node);
  }

  for (const [originId, originSlot, targetId, targetSlot] of file.edges) {
    if (skippedFileIds.has(originId) || skippedFileIds.has(targetId)) continue; // already reported above
    const originNode = nodeByFileId.get(originId);
    const targetNode = nodeByFileId.get(targetId);
    if (!originNode || !targetNode) {
      logLine(`[load: skipped edge from missing node ${!originNode ? originId : targetId}]`, "err");
      continue;
    }
    const sourceKey = Object.keys(originNode.outputs)[originSlot];
    const targetKey = Object.keys(targetNode.inputs)[targetSlot];
    if (sourceKey === undefined || targetKey === undefined || !(await reteHandle.connectNodes(originNode, sourceKey, targetNode, targetKey))) {
      logLine(`[load: failed to connect node ${originId} slot ${originSlot} -> node ${targetId} slot ${targetSlot}]`, "err");
    }
  }

  placeCount = file.nodes.length;
}

el("btnSaveFlow").addEventListener("click", async () => {
  try {
    const { nodes, edges } = extractCanvasSnapshot();
    const text = serializeFlowFileText(buildFlowFile(nodes, edges, extractConfigsSnapshot()));
    const saved = await saveFlowFileToDisk(text, "flow.flow.json");
    if (saved) logLine("[flow saved]", "ok");
  } catch (err) {
    logLine(`[save failed] ${err instanceof Error ? err.message : String(err)}`, "err");
  }
});

el("btnOpenFlow").addEventListener("click", async () => {
  try {
    const text = await openFlowFileFromDisk();
    if (text === null) return; // user cancelled the picker
    const file = parseFlowFile(text);
    await applyFlowFile(file);
    logLine(`[flow loaded -- ${file.nodes.length} node(s)]`, "ok");
    refreshPreview();
  } catch (err) {
    const message = err instanceof FlowFileError ? `invalid flow file: ${err.message}` : err instanceof Error ? err.message : String(err);
    logLine(`[load failed] ${message}`, "err");
  }
});

// ---------------------------------------------------------------------
// Console
// ---------------------------------------------------------------------
const consoleEl = el("console");
function logLine(text: string, cls?: "ok" | "err" | ""): void {
  const row = document.createElement("div");
  const now = new Date();
  const ts = now.toLocaleTimeString(undefined, { hour12: false }) + "." + String(now.getMilliseconds()).padStart(3, "0");
  row.innerHTML = `<span class="t">[${ts}] </span><span class="${cls ?? ""}"></span>`;
  row.querySelector("span:last-child")!.textContent = text;
  consoleEl.appendChild(row);
  consoleEl.scrollTop = consoleEl.scrollHeight;
}
el("btnClear").addEventListener("click", () => (consoleEl.innerHTML = ""));

// ---------------------------------------------------------------------
// mpy-cross WASM (vendored -- see editor/public/vendor/mpy-cross, copied
// byte-for-byte from mpy-cross-wasm/, hashes verified at copy time).
//
// NOT imported from this source file -- a first attempt at a dynamic
// `import()` of the public-dir URL hit Vite's own guard against exactly
// that ("This file is in /public ... should not be imported from source
// code. It can only be referenced via HTML tags."). So instead,
// index.html loads a tiny bridge script
// (public/vendor/mpy-cross/load.mjs) via a real HTML `<script
// type="module">` tag -- outside Vite's module graph entirely, the same
// unbundled way pocs/poc-d/app.js loaded this exact file -- which
// imports the real mpy-cross.mjs and publishes its factory on
// `window.__thingstudioCreateMpyCross`. This file just waits for that
// global to show up.
// ---------------------------------------------------------------------
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let MpyModule: any = null;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type CreateMpyCross = (opts: { print: (t: string) => void; printErr: (t: string) => void }) => Promise<any>;

async function waitForMpyCrossFactory(timeoutMs: number): Promise<CreateMpyCross> {
  const w = window as unknown as { __thingstudioCreateMpyCross?: CreateMpyCross };
  const deadline = Date.now() + timeoutMs;
  while (!w.__thingstudioCreateMpyCross) {
    if (Date.now() > deadline) {
      throw new Error("mpy-cross loader (public/vendor/mpy-cross/load.mjs) never populated window.__thingstudioCreateMpyCross -- check the browser console for a script-load error");
    }
    await new Promise((r) => setTimeout(r, 20));
  }
  return w.__thingstudioCreateMpyCross;
}

// Captured alongside the printErr logging below so a failed compile can be
// parsed for a "line N" attribution (see highlightNodeFromMpyError) without
// re-running mpy-cross or scraping the console DOM -- reset per compile
// attempt in compileToMpy, read back in the Deploy handler's catch block.
let mpyStderrLines: string[] = [];

const mpyReadyPromise: Promise<void> = (async () => {
  const createMpyCross = await waitForMpyCrossFactory(10000);
  MpyModule = await createMpyCross({
    print: (t: string) => logLine("[mpy-cross] " + t, ""),
    printErr: (t: string) => {
      mpyStderrLines.push(t);
      logLine("[mpy-cross] " + t, "err");
    },
  });
  logLine("[mpy-cross WASM ready]", "ok");
})().catch((err) => {
  logLine(`[mpy-cross load error] ${err instanceof Error ? err.message : String(err)}`, "err");
});

function compileToMpy(source: string): Uint8Array {
  if (!MpyModule) throw new Error("mpy-cross not ready yet");
  mpyStderrLines = [];
  MpyModule.FS.writeFile("/in.py", source);
  try {
    MpyModule.FS.unlink("/out.mpy");
  } catch {
    // no previous output to remove -- fine
  }
  const exitCode = MpyModule.callMain(["-o", "/out.mpy", "/in.py"]);
  if (exitCode !== 0) {
    throw new Error(`mpy-cross exited ${exitCode} (see console log above for stderr)`);
  }
  return MpyModule.FS.readFile("/out.mpy") as Uint8Array;
}

// ---------------------------------------------------------------------
// Compile (source preview -- runs the real compiler, no device needed)
// ---------------------------------------------------------------------
// Base registry, built once -- every compile merges the loaded custom
// node definitions (rete/custom-nodes-store.ts) on top of this fresh
// (custom-node.ts's mergeCustomNodeRegistry(), see currentSource() below),
// since which custom types are loaded can change mid-session. Renamed
// from the old bare `registry` (docs/working-notes/custom-node-
// authoring-scoping.md, 2026-08-20) so it's unambiguous this is the
// built-in-only base, not the registry actually passed to compile().
const builtInRegistry = buildRegistry();

// Node-ID line ranges from the most recent successful compile -- stashed
// here rather than threaded through refreshPreview()'s return value so the
// Deploy handler's mpy-cross error path (which runs after Deploy's own
// re-compile, see currentSource()'s call sites) can look a line number up
// without re-plumbing it through another layer.
let lastNodeLineRanges: NodeLineRange[] = [];

function currentSource(): string {
  const { graphData } = toGraphData(reteEditor, [...configsStore.value.values()]);
  // mergeCustomNodeRegistry throws (CustomNodeDescriptorError) if two
  // loaded custom packages collide on the same type id -- allowed to
  // propagate out to refreshPreview()'s existing catch below, which
  // already turns any thrown Error from this function into a visible
  // "COMPILE ERROR: ..." in the source preview panel; no special-casing
  // needed here for that to be comprehensible.
  const registry = mergeCustomNodeRegistry(builtInRegistry, listCustomNodeDefinitions());
  const { source, nodeLineRanges } = compile(graphData, registry);
  lastNodeLineRanges = nodeLineRanges;
  return source;
}

function refreshPreview(): { source: string } | { error: string } {
  try {
    const source = currentSource();
    el("source-preview").textContent = source;
    return { source };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    el("source-preview").textContent = "COMPILE ERROR: " + message;
    return { error: message };
  }
}

// ---------------------------------------------------------------------
// Error node attribution -- two distinct error sources, both flagging the
// same way (the node goes red on the canvas):
//
//  1. Compile-time: mpy-cross's SyntaxError only carries a raw line number
//     in the generated source; map it back to whichever node's generated
//     function that line falls inside via lastNodeLineRanges (computed by
//     compile.ts from the exact same text it emits, not re-derived here).
//     Only meaningful for function-node syntax errors in practice -- every
//     other node type's generated body is fixed, known-good text.
//  2. Runtime: a real §13 NODE_ERROR from the device (design doc §5's
//     fault isolation) -- this one's easier, the device already tells us
//     the exact node ID directly, no line-number math needed at all. The
//     msg22/NameError case that motivated adding this: syntactically
//     valid Python, so mpy-cross never rejects it -- it only fails once
//     actually executed on-device, which is exactly case 2, not case 1.
//     A custom node's own NameError (e.g. its `.node.py` doesn't actually
//     define `run`/`emit`, custom-node.ts's own header) is exactly this
//     case too -- syntactically valid Python, fails only once imported.
//
// Both cases' own logic is unchanged from the Litegraph version (Phase 3
// item 12) -- only the mechanism that turns a node red changed, from
// node.color/node.bgcolor mutation + canvas.setDirty(true, true) to
// reactive component state (nodes.ts's `highlighted` field, mutated here
// and pushed to the DOM via area.update("node", id) since Rete nodes
// aren't Vue-reactive on their own).
// ---------------------------------------------------------------------
function clearNodeHighlights(): void {
  for (const node of reteEditor.getNodes() as AnyThingstudioNode[]) {
    if (node.highlighted) {
      node.highlighted = false;
      void reteArea.update("node", node.id);
    }
  }
}

// Compiler-facing node IDs are now each node's own stable Rete-assigned
// UUID (graph.ts's own header, docs/working-notes/inject-node-live-fire-
// and-startup-node.md) -- no separate numeric<->UUID mapping to look up
// or keep fresh any more, this is just a direct editor.getNode() call.
// `null` genuinely means "this node no longer exists" (deleted since
// whatever compile/deploy produced this ID), not "the ID space has been
// renumbered out from under us" the way it used to.
function highlightNode(nodeId: string): AnyThingstudioNode | null {
  const node = reteEditor.getNode(nodeId) as AnyThingstudioNode | undefined;
  if (!node) return null;
  node.highlighted = true;
  void reteArea.update("node", node.id);
  return node;
}

function highlightNodeFromMpyError(stderrText: string): void {
  const match = stderrText.match(/line (\d+)/);
  if (!match) return; // not every mpy-cross failure names a line (e.g. a generic exit code) -- nothing to attribute
  const lineNo = Number(match[1]);
  const range = lastNodeLineRanges.find((r) => lineNo >= r.startLine && lineNo <= r.endLine);
  if (!range) return; // line falls outside any single node's function (compiler scaffolding) -- can't attribute more precisely than "somewhere in the flow"
  const node = highlightNode(range.nodeId);
  if (!node) return;
  // node.nodeType (nodes.ts) rather than node.kind here -- kind is just
  // "custom" for every loaded custom node type, nodeType is the real,
  // specific type id regardless of first-party or custom (docs/working-
  // notes/custom-node-authoring-scoping.md, 2026-08-20).
  logLine(`[compile error attributed to node ${range.nodeId} (${node.nodeType}), source line ${lineNo}]`, "err");
}

function highlightNodeFromNodeError(nodeId: string): void {
  // §13's NODE_ERROR.nodeId and the compiler-facing node ID space are now
  // the same string-UUID space (graph.ts's own header) -- no numeric
  // parsing/validation step needed any more. The device is still
  // untrusted input (CLAUDE.md's fault-handling priority): an ID naming
  // no current canvas node -- garbled, or from a flow that's since been
  // edited or replaced -- is handled by highlightNode() returning null
  // below, not by rejecting the string shape up front.
  const node = highlightNode(nodeId);
  if (!node) return;
  logLine(`[runtime error attributed to node ${nodeId} (${node.nodeType})]`, "err");
}

// Rete's editor.addPipe sees every graph mutation (nodes/connections
// added, removed, or cleared) -- replaces the 1s poll this section used to
// need for Litegraph, whose own "no reliable 'graph changed' callback"
// gap (this file's previous header comment) doesn't exist here. Property-
// only edits (PropertyPanel.vue's v-model bindings) don't go through an
// editor pipe at all -- they mutate `node.properties` directly, the same
// off-Vue-reactivity mutation store.ts's `propertyVersion` bump exists to
// signal -- so this also re-runs on every propertyVersion bump, which
// PropertyPanel.vue's `touch()` already fires on every field edit. Between
// the two, every user action that could change the compiled source
// triggers a refresh; as before, Deploy always re-compiles from the live
// graph right before sending regardless of when this last ran, so nothing
// here is ever the source of truth for what gets deployed.
reteEditor.addPipe((context) => {
  if (context.type === "nodecreated" || context.type === "noderemoved" || context.type === "connectioncreated" || context.type === "connectionremoved" || context.type === "cleared") {
    refreshPreview();
  }
  return context;
});
watch(propertyVersion, () => refreshPreview());
refreshPreview();

// ---------------------------------------------------------------------
// WebSerial connect / deploy -- real §13 protocol via transport.ts, no
// hand-rolled framing here (that's exactly what transport.ts exists to
// own). HELLO/version-gate check (version.ts) wired in below.
//
// Real constraint this wiring has to live with, not a hypothetical:
// device-runtime/src/listener.py sends HELLO exactly once, from a task
// spawned in main() at listener *boot* -- there's no periodic resend and
// nothing re-triggers it on a new client connection, because opening a
// WebSerial port is silent to the device (no DTR-style reset the way
// esptool's own best-effort reset trick, already used elsewhere in this
// app, exploits when it works at all). So a device that was already
// running before Connect was clicked -- the normal case, since a
// deployed flow persists across power cycles per §5 -- has no fresh
// HELLO for this connection to see; only a physical reset (the console
// already hints at this today) produces one. Blocking Deploy outright
// whenever no HELLO has arrived would make Deploy unusable in that
// ordinary case, so the gate is soft on absence and hard on mismatch:
// no HELLO yet -> allow Deploy with a visible "unverified" warning, a
// real HELLO reporting an incompatible major version -> block, per §5's
// "a version-checked editor refusing to send a DEPLOY the device can't
// parse prevents this specific trigger before it starts." Fixing the
// underlying gap for real (an explicit HELLO_REQUEST the editor can send
// on connect instead of waiting on a maybe-reset) is a device-runtime
// protocol change, out of scope here -- flagged, not silently worked
// around forever.
// ---------------------------------------------------------------------
let waiters: { match: (m: Message) => boolean; resolve: (m: Message) => void; timer: ReturnType<typeof setTimeout> }[] = [];

function waitForMessage(match: (m: Message) => boolean, timeoutMs: number): Promise<Message> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      waiters = waiters.filter((w) => w.timer !== timer);
      reject(new Error("timeout waiting for device response"));
    }, timeoutMs);
    waiters.push({ match, resolve, timer });
  });
}

// The runtime version this editor's compiler/codegen currently targets
// (version.ts's `editorTarget`). Has to be mirrored by hand against
// device-runtime/src/listener.py's `_RUNTIME_VERSION` -- no shared
// config file between the two projects/languages, same "has to be
// mirrored, flagged rather than silently duplicated" reasoning
// messages.ts's own header already applies to the MessageType table.
const EDITOR_TARGET_VERSION: ProtocolVersion = { major: 0, minor: 1, patch: 0 };

const HELLO_WAIT_MS = 3000; // generous over a real boot's timing; only gates the "unverified" warning below, never blocks Connect itself

// Set from the most recent HELLO this connection has seen; null means
// "no HELLO yet this connection" (either still waiting, or the device
// was already running and none is coming -- see the constraint above).
// Reset on every fresh Connect and on disconnect so a stale version from
// a previous device never silently carries over to a new one.
let lastHelloVersion: ProtocolVersion | null = null;

const transport = new WebSerialTransport({
  onMessage(message) {
    logLine(`[${message.type}] ${JSON.stringify(message, (_k, v) => (v instanceof Uint8Array ? `<${v.length} bytes>` : v))}`, "ok");
    if (message.type === "NODE_ERROR") highlightNodeFromNodeError(message.nodeId);
    if (message.type === "HELLO") {
      lastHelloVersion = message.runtimeVersion;
      const decision = decideDeploy(message.runtimeVersion, EDITOR_TARGET_VERSION);
      logLine(`[version check] ${decision.reason}`, decision.allowed ? "ok" : "err");
    }
    waiters = waiters.filter((w) => {
      if (w.match(message)) {
        clearTimeout(w.timer);
        w.resolve(message);
        return false;
      }
      return true;
    });
  },
  onProtocolError(error) {
    logLine(`[protocol error] ${String(error)}`, "err");
  },
  onDebugLine(line) {
    logLine(line, "");
  },
  onDisconnect(reason) {
    logLine(`[disconnected] ${reason ? String(reason) : "(clean)"}`, "");
    lastHelloVersion = null;
    setConnectedUi(false);
  },
});

function setConnectedUi(connected: boolean): void {
  el("pill").textContent = connected ? "connected" : "disconnected";
  el("pill").className = connected ? "pill connected" : "pill disconnected";
  el<HTMLButtonElement>("btnConnect").disabled = connected;
  el<HTMLButtonElement>("btnDisconnect").disabled = !connected;
  el<HTMLButtonElement>("btnDeploy").disabled = !connected;
  deviceConnected.value = connected;
  // A fresh (dis)connection has no evidence the device's own currently-
  // running flow (if any) matches what's open here -- store.ts's
  // flowDeployed doc comment.
  if (!connected) flowDeployed.value = false;
}

el("btnConnect").addEventListener("click", async () => {
  const nav = navigator as unknown as { serial?: { requestPort(): Promise<WebSerialPort> } };
  if (!nav.serial) {
    logLine("[Web Serial API not available -- use Chrome or Edge, served over http(s)://]", "err");
    return;
  }
  lastHelloVersion = null;
  try {
    const port = await nav.serial.requestPort();
    await transport.connect(port);
  } catch (err) {
    logLine(`[connect failed] ${err instanceof Error ? err.message : String(err)}`, "err");
    return;
  }
  setConnectedUi(true);
  logLine("[connected @ 115200 baud -- opening the port does not reset the board]", "");
  logLine("[if nothing appears below, the board's listener may not be running -- press its physical reset button]", "");

  // Only gates the warning below -- transport.onMessage already handles
  // (and logs) a HELLO whenever it actually arrives, on its own schedule,
  // independent of this wait. See this section's header comment for why
  // a timeout here is expected and not itself an error.
  try {
    await waitForMessage((m) => m.type === "HELLO", HELLO_WAIT_MS);
  } catch {
    logLine(
      "[no HELLO received yet -- version compatibility is unverified; Deploy will proceed without the check until one arrives (reset the board to get one now)]",
      "",
    );
  }
});

el("btnDisconnect").addEventListener("click", async () => {
  await transport.disconnect();
  setConnectedUi(false);
});

const DEPLOY_TIMEOUT_MS = 30000; // comfortably exceeds listener.py's own READ_TIMEOUT_S=8 across a few internal phases

el("btnDeploy").addEventListener("click", async () => {
  const btn = el<HTMLButtonElement>("btnDeploy");
  btn.disabled = true;
  clearNodeHighlights(); // stale red from a previous failed attempt shouldn't linger past a new one
  // False for the whole attempt until (if) a DEPLOY_ACK actually arrives
  // below -- store.ts's flowDeployed doc comment on why this isn't set
  // back to whatever it was before on failure.
  flowDeployed.value = false;
  try {
    // Gate the attempt itself, before any compile work -- §5's own
    // framing for why this check exists. Soft on absence (no HELLO seen
    // this connection -- proceed, warned), hard on a real mismatch (a
    // HELLO reporting an incompatible major version -- refuse outright).
    // See the "WebSerial connect / deploy" section header for why
    // absence is common and not itself a red flag.
    if (lastHelloVersion) {
      const decision = decideDeploy(lastHelloVersion, EDITOR_TARGET_VERSION);
      if (!decision.allowed) {
        logLine(`[deploy blocked -- version mismatch] ${decision.reason}`, "err");
        return;
      }
    } else {
      logLine("[deploying without a version check -- no HELLO received this connection]", "");
    }

    const preview = refreshPreview();
    if ("error" in preview) {
      logLine(`[compile error] ${preview.error}`, "err");
      return;
    }

    await mpyReadyPromise;

    let mpyBytes: Uint8Array;
    try {
      mpyBytes = compileToMpy(preview.source);
    } catch (err) {
      logLine(`[mpy-cross error] ${err instanceof Error ? err.message : String(err)}`, "err");
      highlightNodeFromMpyError(mpyStderrLines.join("\n"));
      return;
    }
    logLine(`[compiled -- ${mpyBytes.length} bytes of bytecode]`, "");

    const ackP = waitForMessage((m) => m.type === "DEPLOY_ACK" || m.type === "DEPLOY_ERROR", DEPLOY_TIMEOUT_MS);
    await transport.send({ type: "DEPLOY", bytecode: mpyBytes, staticData: new Uint8Array(0) });
    try {
      const result = await ackP;
      if (result.type === "DEPLOY_ERROR") {
        logLine(`[deploy failed] ${result.code}: ${result.message}`, "err");
      } else {
        logLine("[deploy OK -- flow is running on the device]", "ok");
        flowDeployed.value = true;
      }
    } catch {
      logLine(`[deploy timeout] no DEPLOY_ACK/DEPLOY_ERROR within ${DEPLOY_TIMEOUT_MS}ms`, "err");
    }
  } finally {
    btn.disabled = !transport.isConnected;
  }
});

// ---------------------------------------------------------------------
// Live per-node firing (docs/working-notes/inject-node-live-fire-and-
// startup-node.md): editor -> device FIRE_NODE, replied FIRE_ACK/
// FIRE_ERROR -- same request/response shape as Deploy's own DEPLOY_ACK/
// DEPLOY_ERROR wait above, just keyed by nodeId instead of being a single
// outstanding operation. store.ts's fireNodeImpl is how PropertyPanel.vue
// (a separately-mounted Vue app with no access to this file's `transport`
// closure) reaches this without either file importing the other's
// internals.
// ---------------------------------------------------------------------
const FIRE_TIMEOUT_MS = 5000; // a single node's own msg-build + downstream chain, not a whole flow -- comfortably shorter than DEPLOY_TIMEOUT_MS

async function fireNode(nodeId: string): Promise<FireResult> {
  const ackP = waitForMessage((m) => (m.type === "FIRE_ACK" || m.type === "FIRE_ERROR") && m.nodeId === nodeId, FIRE_TIMEOUT_MS);
  try {
    await transport.send({ type: "FIRE_NODE", nodeId });
  } catch (err) {
    return { ok: false, code: "SEND_FAILED", message: err instanceof Error ? err.message : String(err) };
  }
  try {
    const result = await ackP;
    return result.type === "FIRE_ERROR" ? { ok: false, code: result.code, message: result.message } : { ok: true };
  } catch {
    return { ok: false, code: "TIMEOUT", message: `no FIRE_ACK/FIRE_ERROR within ${FIRE_TIMEOUT_MS}ms` };
  }
}
fireNodeImpl.value = fireNode;

if (!("serial" in navigator)) {
  logLine("[Web Serial API not available -- use Chrome or Edge, served over http(s)://]", "err");
  el<HTMLButtonElement>("btnConnect").disabled = true;
}
