// SPDX-License-Identifier: Apache-2.0
// editor/src/protocol/messages.ts
//
// The §13 wire protocol's message types, as real TypeScript types --
// HELLO, DEPLOY, DEPLOY_ACK/DEPLOY_ERROR, VALUE_STREAM, NODE_ERROR,
// STATE_READ/STATE_WRITE, FIRE_NODE/FIRE_ACK/FIRE_ERROR. Deliberately not
// fixed by the design doc: auth/pairing fields and OTA mechanics (§13
// explicitly defers both) are NOT modeled here -- don't add them
// speculatively.
//
// Two things this file has to invent, since §13 sketches the message
// *list* but not exact field layouts or wire byte values -- flagged
// explicitly rather than silently decided, matching this session's
// convention for filling a genuine spec gap:
//
// 1. Numeric type-byte assignments (MessageType below). §13's original
//    v1 list is assigned 1..8 in the order it's given there (0 reserved/
//    invalid); FIRE_NODE/FIRE_ACK/FIRE_ERROR (9-11) are a later addition
//    (docs/working-notes/inject-node-live-fire-and-startup-node.md), not
//    in §13's original text, appended after rather than renumbering
//    anything already assigned. device-runtime/src/messages.py's own
//    table must match this one exactly -- that file's own header says so.
// 2. Per-message field names/shapes below, each commented with which
//    part of §5/§13's prose they're read from.
//
// Every field name here is intentionally verbose over terse (`nodeId`
// not `id`, `exceptionMessage` not `msg`) since NODE_ERROR's `msg` would
// otherwise collide in meaning with the *different* `msg` envelope
// (envelope.ts) that flows through deployed nodes -- these are two
// unrelated things that happen to share a design-doc word.

/** Runtime version as major.minor.patch (§13: "not a single opaque number"). */
export interface ProtocolVersion {
  readonly major: number;
  readonly minor: number;
  readonly patch: number;
}

/**
 * Wire byte values for each message type's 1-byte frame header field
 * (framing.ts). See file header note (1): this exact numbering is a
 * decision made in this chat, not sourced from the design doc, and has
 * to be mirrored by whatever implements the device-side listener.
 */
export const MessageType = {
  HELLO: 1,
  DEPLOY: 2,
  DEPLOY_ACK: 3,
  DEPLOY_ERROR: 4,
  VALUE_STREAM: 5,
  NODE_ERROR: 6,
  STATE_READ: 7,
  STATE_WRITE: 8,
  FIRE_NODE: 9,
  FIRE_ACK: 10,
  FIRE_ERROR: 11,
} as const;

export type MessageTypeId = (typeof MessageType)[keyof typeof MessageType];

/**
 * Device -> editor, on connect. "chip type, MicroPython/runtime version,
 * and free flash/RAM, so the editor can warn before a flow is too big
 * for the target" (§13). `runtimeVersion` is the field §5/§11's
 * major/minor/patch deploy-safety policy reads (version.ts).
 */
export interface HelloMessage {
  readonly type: "HELLO";
  readonly chipType: string;
  readonly runtimeVersion: ProtocolVersion;
  readonly freeFlashBytes: number;
  readonly freeRamBytes: number;
}

/**
 * Editor -> device. "Full flow bytecode plus static data, replacing
 * whatever's currently deployed" (§13) -- full-flow replace only, no
 * per-node-ID diffing in v1 (§6's multi-flow scoping is v2). Bytecode and
 * static data are carried as native CBOR byte strings, not base64 --
 * unlike envelope.ts's `BytesValue` (needed there because the flow-file
 * *JSON* format has no native bytes type), CBOR does, so no base64
 * indirection is needed at this layer.
 */
export interface DeployMessage {
  readonly type: "DEPLOY";
  readonly bytecode: Uint8Array;
  readonly staticData: Uint8Array;
}

/**
 * Device -> editor: deploy succeeded. §13 doesn't specify fields beyond
 * "success"; echoing back updated free-space is cheap and directly useful
 * to the same "warn before a flow is too big" purpose HELLO serves, so
 * it's included here rather than an empty body -- flagged as this file's
 * own addition, not literally spec'd.
 */
export interface DeployAckMessage {
  readonly type: "DEPLOY_ACK";
  readonly freeFlashBytes: number;
  readonly freeRamBytes: number;
}

/** Device -> editor: deploy failed. "A structured compile/space error" (§13). */
export interface DeployErrorMessage {
  readonly type: "DEPLOY_ERROR";
  readonly code: string;
  readonly message: string;
}

/**
 * Device -> editor, throttled. "Live port values while the editor has a
 * flow open" (§13/§5). `payload` is whatever that port's typed value is
 * (envelope.ts's PayloadType range) -- carried as a native CBOR value,
 * same "no base64 needed" reasoning as DeployMessage above.
 */
export interface ValueStreamMessage {
  readonly type: "VALUE_STREAM";
  readonly nodeId: string;
  readonly portId: string;
  readonly payload: unknown;
  readonly timestampMs: number;
}

/** Device -> editor: the §5 fault-isolation report. "Node ID plus exception type/message" (§13). */
export interface NodeErrorMessage {
  readonly type: "NODE_ERROR";
  readonly nodeId: string;
  readonly exceptionType: string;
  readonly exceptionMessage: string;
}

/**
 * §13 lists STATE_READ but not a separate response type -- this file's
 * interpretation (flagged, not spec'd): the same message type carries
 * both directions, distinguished by whether `value` is present. Editor ->
 * device sends a request with `value` omitted; device -> editor responds
 * with the same shape, `value` populated. Mirrors how DEPLOY_ACK is
 * DEPLOY's "response" as a distinct type, except STATE_READ has no
 * distinct type to reuse for its reply.
 */
export interface StateReadMessage {
  readonly type: "STATE_READ";
  readonly nodeId: string;
  readonly key: string;
  readonly value?: unknown;
}

/** Editor -> device: write a value into the persisted state store (§5) without a full redeploy. */
export interface StateWriteMessage {
  readonly type: "STATE_WRITE";
  readonly nodeId: string;
  readonly key: string;
  readonly value: unknown;
}

/**
 * Editor -> device (docs/working-notes/inject-node-live-fire-and-startup-
 * node.md): fire one fireable-source node's msg-build + downstream chain
 * right now, independent of anything else running -- the mechanism
 * `inject` needs since it no longer fires automatically at all (see
 * node-library/inject.ts). `nodeId` names a node the currently-deployed
 * flow registered into its fire-dispatch table (device-runtime/src/
 * runtime.py's `_fireables`, populated by compiler-generated
 * `runtime.register_fireable()` calls) -- an ID that flow never
 * registered, including one from a since-superseded deploy, gets
 * FIRE_ERROR back, not silence.
 */
export interface FireNodeMessage {
  readonly type: "FIRE_NODE";
  readonly nodeId: string;
}

/** Device -> editor: the named node was found in the fire-dispatch table and spawned. Doesn't itself mean the node's own code ran without error -- a failure inside it is reported the ordinary way, via NODE_ERROR, same as any other spawned task. */
export interface FireAckMessage {
  readonly type: "FIRE_ACK";
  readonly nodeId: string;
}

/** Device -> editor: FIRE_NODE rejected before anything ran -- e.g. `nodeId` isn't in the currently-deployed flow's fire-dispatch table at all (unknown, or from a flow since replaced by a later DEPLOY). */
export interface FireErrorMessage {
  readonly type: "FIRE_ERROR";
  readonly nodeId: string;
  readonly code: string;
  readonly message: string;
}

export type Message =
  | HelloMessage
  | DeployMessage
  | DeployAckMessage
  | DeployErrorMessage
  | ValueStreamMessage
  | NodeErrorMessage
  | StateReadMessage
  | StateWriteMessage
  | FireNodeMessage
  | FireAckMessage
  | FireErrorMessage;

export const MESSAGE_TYPE_BY_NAME: Record<Message["type"], MessageTypeId> = {
  HELLO: MessageType.HELLO,
  DEPLOY: MessageType.DEPLOY,
  DEPLOY_ACK: MessageType.DEPLOY_ACK,
  DEPLOY_ERROR: MessageType.DEPLOY_ERROR,
  VALUE_STREAM: MessageType.VALUE_STREAM,
  NODE_ERROR: MessageType.NODE_ERROR,
  STATE_READ: MessageType.STATE_READ,
  STATE_WRITE: MessageType.STATE_WRITE,
  FIRE_NODE: MessageType.FIRE_NODE,
  FIRE_ACK: MessageType.FIRE_ACK,
  FIRE_ERROR: MessageType.FIRE_ERROR,
};

export const MESSAGE_NAME_BY_TYPE: Record<MessageTypeId, Message["type"]> = {
  [MessageType.HELLO]: "HELLO",
  [MessageType.DEPLOY]: "DEPLOY",
  [MessageType.DEPLOY_ACK]: "DEPLOY_ACK",
  [MessageType.DEPLOY_ERROR]: "DEPLOY_ERROR",
  [MessageType.VALUE_STREAM]: "VALUE_STREAM",
  [MessageType.NODE_ERROR]: "NODE_ERROR",
  [MessageType.STATE_READ]: "STATE_READ",
  [MessageType.STATE_WRITE]: "STATE_WRITE",
  [MessageType.FIRE_NODE]: "FIRE_NODE",
  [MessageType.FIRE_ACK]: "FIRE_ACK",
  [MessageType.FIRE_ERROR]: "FIRE_ERROR",
};
