// SPDX-License-Identifier: Apache-2.0
// editor/src/compiler/graph.ts
//
// The graph input shape the compiler consumes: originally Litegraph's
// `LGraph.serialize()` output (`{ nodes, links }`, numeric node IDs) --
// the same format pocs/poc-d/compiler.js already used.
//
// GraphNode.id/GraphLink's node-id fields changed from `number` to
// `string` (docs/working-notes/inject-node-live-fire-and-startup-node.md,
// prompted by Mike asking "why not use UUIDs, like Node-RED does"): the
// numeric scheme was a Litegraph-era leftover that graph-adapter.ts kept
// re-deriving fresh on every compile even after Rete (which already
// assigns every node a stable UUID) replaced Litegraph, which meant a
// compiler-facing node ID had no persistent meaning across two different
// compiles of the same canvas. That had a real consequence, not just a
// theoretical one: main.ts's device-NODE_ERROR/mpy-cross-error
// attribution used exactly that fragile mapping and could highlight the
// wrong node if the canvas was edited between a deploy and a later error
// arriving from that still-running flow. IDs are now each node's own
// Rete-assigned UUID, passed straight through by graph-adapter.ts with no
// renumbering -- stable for a node's whole lifetime on the canvas, unique
// across everything else on it (configs included, see GraphConfigNode's
// own comment below), gone only if the node itself is deleted. `type`
// (link_id, always numeric) and the slot-index fields are unaffected --
// see GraphLink's own comment.

export interface GraphNode {
  id: string;
  type: string;
  properties: Record<string, unknown>;
}

/** [link_id, origin_id, origin_slot, target_id, target_slot, type]. Only
 * origin_id/target_id (node IDs) are strings -- link_id is a plain
 * per-compile ordinal, not an identity that needs to survive across
 * compiles, so it stays numeric. */
export type GraphLink = [number, string, number, string, number, string];

/**
 * A config node (docs/working-notes/config-node-and-palette-implementation-
 * briefing.md) -- the Node-RED "Server"-dropdown pattern: a small object
 * configured once (e.g. WiFi credentials) and referenced by ID from
 * ordinary nodes' properties, instead of duplicated as raw values on every
 * node that needs it. Deliberately NOT a GraphNode: no ports, never wired,
 * no codegen output of its own -- see compile.ts's header comment on why
 * configs are kept structurally separate from `GraphData.nodes` rather than
 * a 4th NodeKind, so the DAG walk (reachability/cycle detection/source-sink
 * rules) never has to know configs exist at all.
 *
 * `id` is a string here the same way `GraphNode.id` now is too, but the
 * two remain separate ID spaces on purpose -- configs and nodes are
 * different entities with different identity, tracked in entirely
 * separate maps by compile.ts (`configsById` vs. `nodesById`), so nothing
 * ever checks the two against each other for a collision. Both happen to
 * be `crypto.randomUUID()` values in practice (store.ts's createConfig,
 * Rete's own node-ID assignment), so an accidental overlap is exactly as
 * unlikely as any two random UUIDs colliding -- not a real risk either
 * way, and not the reason these stay separate.
 */
export interface GraphConfigNode {
  id: string;
  type: string;
  properties: Record<string, unknown>;
}

export interface GraphData {
  nodes: GraphNode[];
  links: GraphLink[];
  /** Optional -- a graph with no config nodes simply omits this (or leaves
   * it empty); every existing hand-built GraphData literal in the test
   * suite predates this field and stays valid unchanged. */
  configs?: GraphConfigNode[];
}
