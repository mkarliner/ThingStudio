// SPDX-License-Identifier: Apache-2.0
// editor/src/node-library/mqtt-shared.ts
//
// Shared between mqtt-publish.ts and mqtt-subscribe.ts: broker/client
// config validation, the client-construction setup statement, and the
// "make sure we're connected" snippet both node types need before doing
// anything else. Factored out (rather than duplicated per node type, or
// left to mergeSetup's ordinary dedup) for a real correctness reason, not
// just to avoid repetition: mergeSetup's dedup is "first writer under this
// key wins, later writers under the same key are silently dropped, no
// consistency check" (compile.ts's mergeSetup). If mqtt-publish.ts and
// mqtt-subscribe.ts independently generated their OWN setup code for the
// same broker, and a flow happened to compile the publish node before the
// subscribe node, the publish node's version would win -- and if it
// hadn't been written to also enable the client's event/queue interface
// (`queue_len > 0`), the subscribe node sharing that same client would
// silently get no queue at all, a real functional break, not just
// suboptimal codegen. Both node types calling this same function with the
// same config always produces byte-identical setup code regardless of
// which one compiles first, so which one "wins" the dedup race is a
// non-issue by construction rather than a documented gap to live with.
//
// mqtt_publish/mqtt_subscribe manage their OWN WiFi connection via
// mqtt_as's `connect()` (which internally calls `wifi_connect()` using the
// `ssid`/`wifi_pw` in the client's own config) rather than sharing
// wifi-status.ts's "wifi-sta" setup key. Deliberate, not an oversight:
// mqtt_as's `_keep_connected()` gives real outage recovery (the entire
// reason it was vendored over `umqtt.simple` -- see
// device-runtime/src/vendor/mqtt_as/README.md), and forcing it to share a
// plain `network.WLAN.connect()`-once statement with wifi_status.ts would
// throw that away. This does mean `ssid`/`password` may end up configured
// twice in a flow that also has a wifi_status node -- an accepted v1
// duplication, not a conflict: `network.WLAN(network.STA_IF)` returns a
// fresh Python wrapper object on each call, but every wrapper proxies to
// the same one physical station interface, so wifi_status's own handle
// still reports accurate `isconnected()`/`ifconfig()` state regardless of
// which code path actually brought the link up.
//
// Possible future enhancement, not built: the vendored mqtt_as hardcodes
// `network.WLAN(network.STA_IF)` inside its own `MQTT_base.__init__` --
// unlike wifi-status.ts/http-request.ts's interface choice (also
// hardcoded today, but only on our side), this one lives in third-party
// code we don't control. The most likely real case wanting a different
// interface is a board with WiFi plus a wired Ethernet add-on (e.g. a
// WIZnet W5500 over SPI) that wants MQTT traffic over Ethernet instead of
// WiFi. Doing that would need a fork/patch of the vendored file (or
// upstream support for it), not just a config change here -- a real
// enough lift that it's worth confirming there's an actual board/use case
// before starting, not speculatively built now.
//
// Config nodes (config-node-and-palette-implementation-briefing.md):
// **behavior change, 2026-08-21** -- `parseMqttBrokerProps` no longer reads
// raw `ssid`/`password` node properties directly. Credentials now come from
// a referenced `thingstudio/config/wifi` config node, via
// `properties.wifiConfigId` + `ctx.resolveConfig()`, resolved through
// wifi-status.ts's `resolveWifiCredentials()` -- the same shared lookup
// udp-send.ts/udp-receive.ts already use, so mqtt_publish/mqtt_subscribe
// close the exact gap `outstanding-items.md`'s "Network / config nodes"
// section named ("http_request/mqtt_publish/mqtt_subscribe never got the
// config-node treatment"). `http_request` is NOT migrated by this change --
// still reading raw ssid/password, an explicitly flagged, separate
// follow-up (see that file's own header).
//
// **One real divergence from udp-send.ts/udp-receive.ts's own treatment,
// not a smaller version of the same migration:** a config whose `security`
// is `"unmanaged"` is a CompileError here, not a supported state.
// wifiSetupStatement() (wifi-status.ts) can skip its `.connect()` call
// entirely for "unmanaged" because it's just bringing an interface up --
// but mqtt_as has no equivalent "don't manage WiFi" mode; per this file's
// own header above, it always drives its own connect/reconnect loop
// through the ssid/wifi_pw baked into its config dict, and always has,
// even before config nodes existed (`parseMqttBrokerProps` already
// required a non-empty ssid). Accepting "unmanaged" here would mean
// silently handing mqtt_as an empty ssid, and per Problem 2's "barf on
// undefined network details" precedent (`redeploy-cleanup-and-network-
// fault-detection-briefing.md`), a loud rejection is the right behavior,
// not a quiet best-effort attempt. Same reasoning now also applied to an
// empty password on a `"password"`-security config -- wifiSetupStatement()
// already rejects that combination for wifi_status/udp_send/udp_receive;
// parseMqttBrokerProps didn't check it before (there was no `security`
// field to check against until config nodes existed), so this closes a
// real, previously-unchecked gap, not just extending an existing one.
//
// Broker config (Mike's own follow-up request, same day): `broker`/`port`
// -- plus, newly, broker-level `username`/`password` auth -- also moved
// out of each node's own properties into a second referenced config,
// `thingstudio/config/mqtt-broker` (config-types.ts), via
// `properties.brokerConfigId`. Same motivation as the WiFi migration
// above: two mqtt_publish/mqtt_subscribe nodes pointed at the same broker
// no longer duplicate broker host/port (or, now, broker credentials)
// across node instances. `resolveMqttBrokerConfig()` below is the
// counterpart to wifi-status.ts's `resolveWifiCredentials()` -- a second,
// independent config reference resolved on the same node, since a node's
// WiFi network and its MQTT broker are genuinely two different things
// with two different credential pairs: the referenced WiFi config's own
// `ssid`/`password` authenticate to the WiFi network (`mqtt_as`'s
// `ssid`/`wifi_pw` config keys); the broker config's `username`/
// `password` authenticate to the broker itself (`mqtt_as`'s `user`/
// `password` config keys) -- unrelated credentials that happen to share
// the English word "password." `brokerConfigId` is mandatory, no
// optional/implicit fallback at all (unlike `wifiConfigId`, which has
// "unmanaged" as its explicit opt-out) -- there's no sensible default
// broker to silently fall back to the way an already-connected WiFi
// interface is a sensible "ride on it" fallback, so this is mandatory
// from day one rather than shipped optional and reversed later the way
// `wifiConfigId` was (`redeploy-cleanup-and-network-fault-detection-
// briefing.md`, Problem 2b).
//
// WiFi-reconnect race fix, 2026-08-21, on Thingstudio's own side rather
// than as a patch to the vendored mqtt_as: real-hardware testing
// (`mqtttest.flow.json`, a pure mqtt_publish/mqtt_subscribe flow sharing
// one wifiConfigId/brokerConfigId -- so NOT the wifi_status-vs-mqtt_as
// cross-node race this file's header above already accepts as a known
// duplication) hit `E (...) wifi:sta is connecting, cannot set config`.
// Root cause, confirmed by reading the vendored source directly: mqtt_as's
// own `wifi_connect()` (ESP32 branch) does `s.active(True)` then
// unconditionally `s.connect(self._ssid, self._wifi_pw)`, with no check
// for a connect already in progress. `s.active(True)` alone can trigger
// ESP-IDF's own NVS-cached auto-reconnect from a previous deploy's saved
// station config; if that's still resolving when the very next line fires
// its own connect, ESP-IDF refuses the second connect's config-set.
//
// A local patch to the vendored file (adding the missing guard, mirroring
// the ESP8266 branch's own existing `isconnected()` check a few lines
// above) was drafted and briefly applied, then deliberately reverted --
// this exact class of fix has already been raised against this library
// more than once (peterhinch/micropython-mqtt#59, #61, and discussed in
// #57) without landing upstream, and Mike's own call, after reviewing
// that history, was not to carry a diverging local patch against the
// maintainer's evident preference.
//
// **First attempt (2026-08-21), reverted 2026-08-22 -- did NOT hold on
// real hardware.** `mqttWifiPrecheckStatement()` (removed) was a
// module-scope statement -- run once, synchronously, at flow-module
// import time, before the asyncio event loop even started -- that
// blocking-`time.sleep_ms`-polled `status()` for up to ~5s. Reasoned
// through and off-device-verified (compiled-source `ast.parse` check,
// 273/273 editor tests), but re-tested on real hardware 2026-08-22 (same
// board redeployed onto a still-live prior session rather than a freshly
// erased one -- Mike's own description of what he actually did) and the
// exact same `wifi:sta is connecting, cannot set config` recurred.
// Diagnosed, not just retried, before changing anything -- two real gaps
// in that design, not a timeout that needed to be bigger:
//   1. **Wrong place in time.** The statement ran at module load, before
//      the event loop starts and before mqtt_as's own `.connect()` (which
//      only runs later, inside a coroutine, once `runtime.spawn()`
//      actually schedules and runs the flow's async functions). Whatever
//      gap of real elapsed time existed between "precheck finished" and
//      "mqtt_as's connect() actually runs" was exactly where a
//      slower-to-appear auto-reconnect could still start unopposed -- the
//      precheck logic wasn't wrong, it was checking too early relative to
//      the call it was meant to guard.
//   2. **Checked before waiting, not after.** The loop's first `status()`
//      read happened immediately after `.active(True)`, with no delay --
//      if ESP-IDF's WiFi task (a separate FreeRTOS task, scheduled
//      independently of this checking code) hadn't yet processed the
//      `active(True)` event into an observable `STAT_CONNECTING`
//      transition, the loop would see "not connecting" and exit on its
//      very first check, having waited 0ms. A check-too-early race, not a
//      bound that was merely too short.
//
// **Second attempt (2026-08-22, same day), superseded before a hardware
// retest even happened -- a real hardware run in the meantime (unrelated
// board state, not the from-scratch rebuild) surfaced a THIRD gap this
// attempt didn't cover either:** the second attempt inlined the precheck
// into `mqttEnsureConnectedSnippet()`, immediately before the real
// `await {client}.connect()` call, using `await asyncio.sleep_ms(...)`
// (a real event-loop yield, Mike's own suggestion) and checking `status()`
// only after each yield. That closes gaps 1 and 2 above for OUR OWN
// initial `.connect()` call -- but reading the vendored source further
// turned up a THIRD path to the identical race that neither attempt
// touched: `MQTTClient.connect()` only calls `self.wifi_connect()` on the
// very FIRST connect (`if not self._has_connected: ...`); every
// subsequent reconnect is driven entirely by mqtt_as's own background
// `_keep_connected()` task, which calls `self.wifi_connect()` DIRECTLY --
// completely bypassing anything wrapped around our own `.connect()` call,
// initial or not. If THAT call hits the same ESP-IDF race, `_keep_connected()`
// swallows the resulting OSError (`except OSError: continue`) and loops
// back to retry -- silently, forever, with zero console output -- exactly
// matching a real symptom Mike hit: a flow that published/subscribed
// successfully a couple of times, then went completely silent (no error,
// no debug, nothing) on every later attempt. A precheck that only guards
// our own explicit `.connect()` call can never close this gap, no matter
// where in time it runs -- it needs to guard `wifi_connect()` itself,
// every time anything calls it, not just the times WE call it.
//
// **Third attempt (2026-08-22, same day) -- monkey-patched `wifi_connect`
// itself, but delegated its own wait/connect logic to a private,
// per-client precheck, not shared with the other network node types.**
// Closed the "every caller of wifi_connect()" gap the second attempt
// missed, but real-hardware testing against Mike's own `mqtt-test.flow.json`
// (a flow with mqtt_publish/mqtt_subscribe AND a wifi_status node on the
// SAME wifi config -- exactly the cross-node case this file's earlier
// header paragraph above already flagged as an accepted duplication)
// still hit the identical error. Root cause, found by reading mqtt_as's
// `wifi_connect()` itself line by line: its ESP32 branch calls
// `s.connect(self._ssid, self._wifi_pw)` **unconditionally**, with no
// `isconnected()` guard (unlike its own ESP8266 branch, which checks
// first). So even a correctly-waiting precheck would wait out
// wifi_status's own module-scope connect, see it clear, and then
// immediately reissue a SECOND, redundant `.connect()` right after the
// first one succeeded -- itself enough to retrigger ESP-IDF's "cannot set
// config" depending on timing. "Waiting rather than cancelling" (this
// file's retired reasoning, see git history) was the right call but an
// incomplete one: it assumed there'd only ever be one *other* attempt to
// wait out, not a second, self-inflicted one issued right after the wait.
//
// **Current fix (2026-08-22, same day):** rather than each call site
// (wifi_status/http_request/udp_send/udp_receive's module-scope connect,
// and mqtt's own `wifi_connect` monkey-patch) running its own separate
// wait-then-maybe-connect logic, there is now exactly ONE connect
// implementation for the whole generated program:
// `_wifi_ensure_connected()` (wifi-status.ts, defined under the shared
// "wifi-sta" key both this file and wifi-status.ts's own node types emit),
// lock-protected and `isconnected()`-aware both before AND after its wait.
// `mqttSetupStatement()`'s `wifi_connect` monkey-patch below now just
// `await`s that shared function, then returns immediately if it already
// achieved a connection -- only falling through to the vendored
// `wifi_connect()` body (preserved untouched, not bypassed -- same
// "no diverging patch to the vendored file" call as before) as a
// last-resort fallback if the shared connect genuinely didn't get the
// interface up (e.g. this client's own ssid/password differ from
// whichever config the shared function actually used -- the existing,
// already-documented "two different wifi configs in one flow" gap,
// not a new one). **Still unverified on real hardware as of this
// change.** See `decisions.md`'s 2026-08-22 entries for the full
// ruled-out-alternatives record.
//
// Loud network errors (redeploy-cleanup-and-network-fault-detection-
// briefing.md Problem 2a, extended here per the MQTT-hardware-validation
// briefing's Problem 3): `mqttEnsureConnectedSnippet()`'s `.connect()`
// call now re-raises an `OSError` with the broker's own host:port folded
// into the message, same "make a bare `OSError: -N` diagnosable without
// opening generated source" motivation as udp-send.ts's own treatment.
// mqtt-publish.ts's `.publish()`/mqtt-subscribe.ts's `.subscribe()` calls
// get the same treatment directly in those files. Deliberately NOT added
// around mqtt_as's own internal `_keep_connected()` reconnect loop --
// that's the vendored file's own error-handling design (silently retry
// forever, by intent, per its own header on `_keep_connected` -- "Runs
// forever unless user issues .disconnect()"), not a gap of ours to patch
// over; the WiFi-reconnect precheck above is the right level to fix that
// path at, not wrapping its already-intentional retry loop in more error
// reporting.
//
// MQTTS/TLS explicitly deferred, not built, not even a reserved field:
// the vendored mqtt_as's own `config` dict already has `ssl`/`ssl_params`
// keys (device-runtime/src/vendor/mqtt_as/__init__.py) this file doesn't
// touch. Checked against CLAUDE.md's "don't paint into an architectural
// dead end" principle before deferring outright, not skipped by default:
// a config's `properties` is a plain JSON blob (config-types.ts), and
// `ConfigTypeDescriptor.fields` is just what the property panel currently
// renders for it -- adding a `tls`/`ssl` field to
// `thingstudio/config/mqtt-broker` later needs no migration of
// already-saved flow files (an old config simply won't have the key, and
// new code can default it), unlike a one-way-door case such as `HELLO`'s
// reserved `authRequired`/`authScheme` fields. So there's nothing to
// reserve now -- this is the plain cheap-by-default case, not an
// exception to it. `outstanding-items.md`, `decisions.md`.

import { CompileError } from "../compiler/errors.js";
import type { CodegenContext } from "../compiler/node-definition.js";
import { pyStringLiteral } from "./py-literals.js";
import { resolveWifiCredentials } from "./wifi-status.js";

// wifiSetupStatement's own "wifi-sta"-keyed statement is NOT imported/
// called here -- mqtt-publish.ts/mqtt-subscribe.ts each include it
// directly, alongside this file's own mqttSetupStatement(), in their own
// `statements` arrays (see either file's codegen). Keeping that call at
// the node-definition layer, not buried inside this shared helper, means
// a flow with mqtt nodes but no wifi_status-family node still gets
// `_wifi_ensure_connected()` defined (mergeSetup dedups it against
// wifi_status's own copy when both are present, byte-identical as long as
// they resolve the same wifi config -- see wifiSetupStatement()'s own doc
// comment).

export interface MqttBrokerConfig {
  broker: string;
  port: number;
  ssid: string;
  wifiPassword: string;
  username: string;
  password: string;
}

function sanitizeIdent(s: string): string {
  return s.replace(/[^a-zA-Z0-9]/g, "_");
}

function idSuffix(cfg: MqttBrokerConfig): string {
  return `${sanitizeIdent(cfg.broker)}_${cfg.port}`;
}

export function mqttClientVar(cfg: MqttBrokerConfig): string {
  return `_mqtt_client_${idSuffix(cfg)}`;
}

function mqttConnectedVar(cfg: MqttBrokerConfig): string {
  return `_mqtt_connected_${idSuffix(cfg)}`;
}

function mqttLockVar(cfg: MqttBrokerConfig): string {
  return `_mqtt_lock_${idSuffix(cfg)}`;
}

export function mqttSetupKey(cfg: MqttBrokerConfig): string {
  return `mqtt-client-${cfg.broker}-${cfg.port}`;
}

/** Resolves `properties.brokerConfigId` via `ctx.resolveConfig()` -- a
 * referenced `thingstudio/config/mqtt-broker` config's own `broker`/
 * `port`/`username`/`password` (config-types.ts). `context` is prefixed
 * onto error messages, same convention `resolveWifiCredentials()` uses.
 * Mandatory -- see this file's header for why there's no optional/
 * implicit-fallback state the way `wifiConfigId`'s "unmanaged" is one.
 * `username`/`password` are NOT validated for non-emptiness -- unlike the
 * WiFi config's password, an empty broker username/password is a normal,
 * common "no broker auth" setup, not a likely-forgotten-credential case
 * worth a loud CompileError over. */
function resolveMqttBrokerConfig(
  properties: Record<string, unknown>,
  ctx: CodegenContext,
  context: string,
): { broker: string; port: number; username: string; password: string } {
  const configId = properties.brokerConfigId;
  if (configId === undefined || configId === null || configId === "") {
    throw new CompileError(`${context} requires an MQTT broker config (properties.brokerConfigId) -- reference one, or create a new one from the property panel`);
  }
  const resolved = ctx.resolveConfig(String(configId));
  const broker = typeof resolved.broker === "string" ? resolved.broker.trim() : "";
  if (!broker) {
    throw new CompileError(`${context}'s referenced broker config has no "broker" hostname/IP set`);
  }
  const port = Math.round(Number(resolved.port ?? 1883));
  if (!Number.isFinite(port) || port <= 0 || port > 65535) {
    throw new CompileError(`${context}'s referenced broker config has an invalid port "${String(resolved.port)}" -- must be a valid port number (1-65535)`);
  }
  const username = typeof resolved.username === "string" ? resolved.username : "";
  const password = typeof resolved.password === "string" ? resolved.password : "";
  return { broker, port, username, password };
}

/** `context` is prefixed onto error messages (e.g. "mqtt_publish", so a
 * caller's CompileError says which node type actually rejected it).
 * `ctx` resolves both `properties.brokerConfigId` (this file's own
 * `resolveMqttBrokerConfig()`, above) and `properties.wifiConfigId`
 * (`resolveWifiCredentials()`, wifi-status.ts) -- see this file's header
 * for why these are two independent config references on the same node,
 * and for why "unmanaged" WiFi security is rejected here even though it's
 * a supported state for wifi_status/udp_send/udp_receive. */
export function parseMqttBrokerProps(properties: Record<string, unknown>, ctx: CodegenContext, context: string): MqttBrokerConfig {
  const { broker, port, username, password } = resolveMqttBrokerConfig(properties, ctx, context);

  const resolved = resolveWifiCredentials(properties, ctx, context);
  if (resolved.security === "unmanaged") {
    throw new CompileError(
      `${context}'s WiFi config has security "unmanaged", which isn't supported here -- mqtt_as manages its own WiFi connection and needs real credentials to do so, unlike wifi_status/udp_send/udp_receive, which can ride on an externally-managed connection. Reference a config with a real ssid/password instead.`,
    );
  }
  const ssid = typeof resolved.ssid === "string" ? resolved.ssid.trim() : "";
  if (!ssid) {
    // Deliberately required rather than optional-with-fallback (contrast
    // wifi-status.ts/http-request.ts, where an empty ssid just skips the
    // connect call and assumes something else brings the link up) -- see
    // this file's header on why mqtt_as owns its own WiFi lifecycle
    // rather than assuming a connection already exists.
    throw new CompileError(`${context} requires "ssid" -- mqtt_as manages its own WiFi connection and needs credentials to do so`);
  }
  const wifiPassword = typeof resolved.password === "string" ? resolved.password : "";
  if (resolved.security === "password" && !wifiPassword) {
    throw new CompileError(
      `${context}'s WiFi config for ssid "${ssid}" has no password but security is "password" -- set a password, or choose "open" if this network intentionally has none`,
    );
  }
  return { broker, port, ssid, wifiPassword, username, password };
}

/** Module-scope statement that constructs the shared MQTTClient for this
 * broker. `queue_len` is always set to a fixed positive value regardless
 * of whether the calling node is mqtt_publish or mqtt_subscribe -- see
 * this file's header for why that's what makes the dedup-sharing safe.
 *
 * Also installs the WiFi-reconnect-race fix (this file's header, "Current
 * fix (2026-08-22)") by monkey-patching the constructed client's own
 * `wifi_connect` bound method -- captured once as
 * `_mqtt_orig_wifi_connect_<suffix>`, then replaced with a plain function
 * that `await`s the shared `_wifi_ensure_connected()` (wifi-status.ts) and
 * returns immediately if that already got the interface connected, only
 * falling through to the original vendored implementation as a fallback.
 * Assigning a plain function directly onto an instance attribute (not the
 * class) means Python/MicroPython never pass an implicit `self` when it's
 * later called as `client.wifi_connect(...)` -- the closed-over original
 * bound method already has its own `self` baked in from before the
 * reassignment, so the replacement's own `(quick=False)` signature lines
 * up with both real call sites (`MQTTClient.connect()`'s
 * `self.wifi_connect(quick)` on the first connect, and
 * `_keep_connected()`'s bare `self.wifi_connect()` on every later
 * reconnect) without needing to know which one is calling. Caller (mqtt-
 * publish.ts/mqtt-subscribe.ts) is responsible for also including
 * wifi-status.ts's `wifiSetupStatement()` in the same node's `statements`
 * array, since THIS function's own generated code references
 * `_wifi_ensure_connected()`/`network.WLAN` without defining them itself
 * -- see this file's header for why that split is deliberate. */
export function mqttSetupStatement(cfg: MqttBrokerConfig): { key: string; code: string } {
  const clientVar = mqttClientVar(cfg);
  const suffix = idSuffix(cfg);
  const origWifiConnectVar = `_mqtt_orig_wifi_connect_${suffix}`;
  const wrappedWifiConnectVar = `_mqtt_wifi_connect_precheck_${suffix}`;
  const staVar = `_mqtt_wifi_precheck_sta_${suffix}`;
  const lines = [
    `${clientVar}_cfg = dict(mqtt_as.config)`,
    `${clientVar}_cfg['server'] = ${pyStringLiteral(cfg.broker)}`,
    `${clientVar}_cfg['port'] = ${cfg.port}`,
    `${clientVar}_cfg['ssid'] = ${pyStringLiteral(cfg.ssid)}`,
    `${clientVar}_cfg['wifi_pw'] = ${pyStringLiteral(cfg.wifiPassword)}`,
    // Broker-level auth -- mqtt_as's own `user`/`password` config keys,
    // distinct from the `ssid`/`wifi_pw` pair just above (this file's
    // header). Always set, even when empty, matching this function's own
    // existing convention for ssid/wifi_pw -- no conditional skip, so
    // generated code never silently inherits `mqtt_as.config`'s own `""`
    // defaults in a way that would look identical to an intentional
    // empty value.
    `${clientVar}_cfg['user'] = ${pyStringLiteral(cfg.username)}`,
    `${clientVar}_cfg['password'] = ${pyStringLiteral(cfg.password)}`,
    // Fixed, not configurable -- the queue is only ever read by
    // mqtt_subscribe nodes (mqtt-subscribe.ts), a publish-only flow just
    // never drains it, which is harmless (MsgQueue discards oldest on
    // overflow, per the vendored mqtt_as's own MsgQueue.put()).
    `${clientVar}_cfg['queue_len'] = 20`,
    `${clientVar} = mqtt_as.MQTTClient(${clientVar}_cfg)`,
    `${mqttConnectedVar(cfg)} = False`,
    `${mqttLockVar(cfg)} = asyncio.Lock()`,
    // WiFi-reconnect-race precheck, installed on every call path uniformly
    // -- see this function's own doc comment and this file's header.
    `${origWifiConnectVar} = ${clientVar}.wifi_connect`,
    `async def ${wrappedWifiConnectVar}(quick=False):`,
    `    await _wifi_ensure_connected()`,
    `    ${staVar} = network.WLAN(network.STA_IF)`,
    `    if ${staVar}.isconnected():`,
    `        return`,
    `    return await ${origWifiConnectVar}(quick)`,
    `${clientVar}.wifi_connect = ${wrappedWifiConnectVar}`,
  ];
  return { key: mqttSetupKey(cfg), code: lines.join("\n") };
}

/** NOT indented; caller embeds this at the top of an async function body
 * (mqtt-publish.ts's sink functionBody, or mqtt-subscribe.ts's buildMsg --
 * both already run inside an `async def`/coroutine, so `await` here is
 * always legal). Double-checked-locking: the fast path (already
 * connected) never touches the lock; only the first caller across
 * however many chains share this client actually awaits `.connect()`,
 * everyone else just observes `_mqtt_connected_*` flip to True.
 *
 * No WiFi-reconnect-race precheck inlined here (an earlier version of
 * this function had one) -- as of `mqttSetupStatement()`'s own
 * `wifi_connect` monkey-patch (this file's header, "Current fix
 * (2026-08-22)"), the precheck lives at the one place that actually covers
 * every caller, including mqtt_as's own internal reconnect loop, which
 * this function has no visibility into at all. Doing it here too would
 * just be dead, redundant code.
 *
 * The `.connect()` call itself is wrapped to re-raise an `OSError` with
 * this broker's own host:port folded into the message (Problem 3, this
 * file's header) -- same "make a bare `OSError: -N` diagnosable without
 * opening generated source" motivation as udp-send.ts's own treatment. */
export function mqttEnsureConnectedSnippet(cfg: MqttBrokerConfig): string {
  const clientVar = mqttClientVar(cfg);
  const connectedVar = mqttConnectedVar(cfg);
  const lockVar = mqttLockVar(cfg);
  const brokerLit = pyStringLiteral(cfg.broker);
  return [
    `global ${connectedVar}`,
    `if not ${connectedVar}:`,
    `    async with ${lockVar}:`,
    `        if not ${connectedVar}:`,
    `            try:`,
    `                await ${clientVar}.connect()`,
    `            except OSError as _e:`,
    `                raise OSError("mqtt: connect to %s:%s failed: %r" % (${brokerLit}, ${cfg.port}, _e))`,
    `            ${connectedVar} = True`,
  ].join("\n");
}

// payloadToBytesSnippet used to live here (mqtt_publish's outgoing-payload
// encoding). Moved to py-literals.ts 2026-08-18 when udp-send.ts needed
// the identical snippet -- see that file's doc comment for why. Re-exported
// from here too, so mqtt-publish.ts's existing import path keeps working
// without a churny cross-file rename.
export { payloadToBytesSnippet } from "./py-literals.js";
