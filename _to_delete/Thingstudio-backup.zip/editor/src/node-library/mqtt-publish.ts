// SPDX-License-Identifier: Apache-2.0
// editor/src/node-library/mqtt-publish.ts
//
// Tier 1 network batch (mvp-feature-priorities.md item 4). A sink: takes
// an inbound msg, publishes msg.payload to the configured topic via the
// vendored mqtt_as client (device-runtime/src/vendor/mqtt_as/). See
// mqtt-shared.ts's header for the broker-client-sharing design (dedup
// across mqtt_publish/mqtt_subscribe nodes pointed at the same broker)
// and why mqtt_as owns its own WiFi connection rather than sharing
// wifi-status.ts's setup statement.
//
// Config nodes (config-node-and-palette-implementation-briefing.md):
// **behavior change, 2026-08-21** -- credentials now come from a
// referenced `thingstudio/config/wifi` config node via
// `node.properties.wifiConfigId`, resolved inside parseMqttBrokerProps
// (mqtt-shared.ts) via wifi-status.ts's `resolveWifiCredentials()` -- not
// raw `ssid`/`password` properties on this node directly. See
// mqtt-shared.ts's own header for why "unmanaged" security is rejected
// here even though wifi_status/udp_send/udp_receive accept it. Same day,
// on Mike's own follow-up request: `broker`/`port` also moved out of this
// node's own properties into a second referenced config,
// `thingstudio/config/mqtt-broker`, via `node.properties.brokerConfigId`
// -- see mqtt-shared.ts's header for the broker-config design and why it's
// a second, independent config reference rather than folded into the WiFi
// config.
//
// Also given real canvas presence in this change (`ports` below) --
// previously registry-only, per outstanding-items.md's "Network / config
// nodes" section.
//
// 2026-08-21/2026-08-22: mqttSetupStatement() (mqtt-shared.ts) installs
// the WiFi-reconnect-race precheck as a `wifi_connect` monkey-patch on the
// constructed client, covering every caller of that method (our own
// `mqttEnsureConnectedSnippet()`'s `.connect()` AND mqtt_as's own internal
// reconnect loop) uniformly -- see that file's header for the full story,
// including two earlier attempts that didn't hold on real hardware.
//
// 2026-08-22: `.publish()` below is wrapped to re-raise an OSError with
// this broker's host:port AND the topic folded into the message
// (Problem 3, mqtt-shared.ts header) -- same motivation as
// mqttEnsureConnectedSnippet()'s own `.connect()` wrapping.

import type { GraphNode } from "../compiler/graph.js";
import type { CodegenContext, NodeDefinition, SinkCodegenResult } from "../compiler/node-definition.js";
import { CompileError } from "../compiler/errors.js";
import { mqttClientVar, mqttEnsureConnectedSnippet, mqttSetupStatement, parseMqttBrokerProps, payloadToBytesSnippet } from "./mqtt-shared.js";
import { pyStringLiteral } from "./py-literals.js";
import { wifiSetupStatement } from "./wifi-status.js";

export const mqttPublishNode: NodeDefinition = {
  type: "thingstudio/mqtt_publish",
  kind: "sink",
  // input `msg` type `any` -- payloadToBytesSnippet handles bytes/str/other
  // uniformly (same reasoning udp_send's own `any` input gets,
  // wire-type-system-scoping.md).
  ports: {
    inputs: [{ name: "msg", type: "any" }],
  },
  codegenSink(node: GraphNode, ctx: CodegenContext): SinkCodegenResult {
    const cfg = parseMqttBrokerProps(node.properties, ctx, "mqtt_publish");

    const topic = typeof node.properties.topic === "string" ? node.properties.topic.trim() : "";
    if (!topic) {
      throw new CompileError("mqtt_publish requires a non-empty \"topic\"");
    }

    const qos = Math.round(Number(node.properties.qos ?? 0));
    if (qos !== 0 && qos !== 1) {
      throw new CompileError(`mqtt_publish qos "${String(node.properties.qos)}" must be 0 or 1 -- qos 2 isn't supported (mqtt_as's own limitation, matches design doc §6's MQTT scope)`);
    }

    const retain = node.properties.retain === true || node.properties.retain === "true";
    const clientVar = mqttClientVar(cfg);
    const topicLit = pyStringLiteral(topic);
    const brokerLit = pyStringLiteral(cfg.broker);

    const functionBody = [
      mqttEnsureConnectedSnippet(cfg),
      payloadToBytesSnippet("_mqtt_body"),
      "try:",
      `    await ${clientVar}.publish(${topicLit}, _mqtt_body, retain=${retain ? "True" : "False"}, qos=${qos})`,
      "except OSError as _e:",
      `    raise OSError("mqtt_publish to %s:%s (topic %s) failed: %r" % (${brokerLit}, ${cfg.port}, ${topicLit}, _e))`,
    ].join("\n");

    return {
      // network/sys: mqttEnsureConnectedSnippet()'s own WiFi-reconnect-race
      // precheck (mqtt-shared.ts header) -- not needed for mqtt_as/publish
      // itself.
      imports: ["import mqtt_as", "import network", "import sys"],
      // wifiSetupStatement() first -- same "wifi-sta" key wifi_status/
      // http_request/udp_send/udp_receive use, so a flow with any of those
      // AND this node shares exactly one `_wifi_ensure_connected()`
      // (wifi-status.ts's 2026-08-22 header) rather than two independent
      // connect owners racing the same interface. In a flow with no
      // wifi_status-family node at all, this is what defines it in the
      // first place -- mqttSetupStatement()'s own monkey-patch calls it
      // unconditionally, so it must exist either way.
      statements: [wifiSetupStatement(cfg.ssid, cfg.wifiPassword, "password"), mqttSetupStatement(cfg)],
      functionName: ctx.uniqueName("mqtt_publish"),
      functionBody,
    };
  },
};
