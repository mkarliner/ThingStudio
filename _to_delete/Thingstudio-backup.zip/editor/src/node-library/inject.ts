// SPDX-License-Identifier: Apache-2.0
// editor/src/node-library/inject.ts
//
// Ported from pocs/poc-d/nodes.js (editor descriptor) and pocs/poc-d/compiler.js
// (codegen), generalized onto the real registry contract
// (compiler/node-definition.ts).
//
// docs/working-notes/inject-node-live-fire-and-startup-node.md: inject is
// now click-only -- no repeat presets, no automatic firing at deploy/boot
// at all. Mike's own call: a live device should re-fire inject only when
// the editor explicitly asks it to (PropertyPanel.vue's Fire button, via
// the §13 FIRE_NODE message), and firing automatically at flow start is a
// different, more useful thing (works after the editor disconnects, fires
// again on a bare device reset too) covered by the separate `startup` node
// (node-library/startup.ts) instead -- not a checkbox on inject. This is
// why inject uses codegenFireableSource (the fifth codegen pattern,
// node-definition.ts) rather than codegenSource: it contributes a
// fire-dispatch-table entry, never a spawned background coroutine.
//
// The old `repeat` property (manual/1s/5s/30s) is gone entirely, not just
// defaulted to "manual" -- `timer` (node-library/timer.ts) already covers
// repeating sources, and carrying inject's own redundant repeat mechanism
// forward would just be two ways to do the same thing on the canvas.

import type { GraphNode } from "../compiler/graph.js";
import type { CodegenContext, FireableSourceCodegenResult, NodeDefinition, PayloadType } from "../compiler/node-definition.js";
import { pyPayloadLiteral } from "./py-literals.js";

export const injectNode: NodeDefinition = {
  type: "thingstudio/inject",
  kind: "source",
  // The one dynamic port in the current node set (node-definition.ts's
  // PortType header comment) -- output type tracks the `payloadType`
  // property exactly the way codegenFireableSource's own `payloadType`
  // read below does, so this can't drift from what actually gets emitted.
  // Falls back to "bool" for an unset/unrecognized value, matching
  // codegenFireableSource's own `?? "bool"` default.
  ports: {
    outputs: [{ name: "msg", type: (properties) => (properties.payloadType as PayloadType | undefined) ?? "bool" }],
  },
  codegenFireableSource(node: GraphNode, _ctx: CodegenContext): FireableSourceCodegenResult {
    const payloadType = (node.properties.payloadType as string | undefined) ?? "bool";
    const payloadLiteral = pyPayloadLiteral(payloadType, node.properties.payloadValue, "inject payload");

    return {
      buildMsg: `msg = {'payload': ${payloadLiteral}, 'topic': ''}`,
    };
  },
};
