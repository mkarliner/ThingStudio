// docs/working-notes/inject-node-live-fire-and-startup-node.md: inject
// (editor/src/node-library/inject.ts) is now click-only -- the fifth
// codegen pattern, codegenFireableSource (node-definition.ts). Unlike
// codegenSource nodes (node-timer.test.ts's own header explains that
// pattern's own test style), a fireable source is never spawned
// automatically at flow start, so this file checks two separate things:
// (1) codegenFireableSource's own buildMsg output, called directly, same
// "isolated snippet" style node-timer.test.ts already established; (2)
// compiling into a full flow produces a registration
// (runtime.register_fireable), NOT a spawn call, and the registered
// function actually runs the right code when invoked directly (standing
// in for what runtime.fire() would do device-side on a live FIRE_NODE).

import { execFileSync } from "node:child_process";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { compile } from "../src/compiler/compile.js";
import { CompileError } from "../src/compiler/errors.js";
import type { GraphData, GraphNode } from "../src/compiler/graph.js";
import type { CodegenContext } from "../src/compiler/node-definition.js";
import { injectNode } from "../src/node-library/inject.js";
import { buildRegistry } from "../src/node-library/registry.js";

const __dirname = dirname(fileURLToPath(import.meta.url));

function node(properties: Record<string, unknown>): GraphNode {
  return { id: "1", type: "thingstudio/inject", properties };
}

function freshCtx(): CodegenContext {
  const used = new Set<string>();
  return {
    uniqueName(hint: string): string {
      let candidate = `_${hint}`;
      let i = 1;
      while (used.has(candidate)) candidate = `_${hint}_${i++}`;
      used.add(candidate);
      return candidate;
    },
    resolveConfig(id: string): Record<string, unknown> {
      throw new Error(`unexpected resolveConfig("${id}") call -- this test file's ctx doesn't stub any configs`);
    },
  };
}

function runBuildMsg(properties: Record<string, unknown>): string {
  const result = injectNode.codegenFireableSource!(node(properties), freshCtx());
  const lines = [...(result.imports ?? []), ...(result.statements ?? []).map((s) => s.code), result.buildMsg, "print(msg['payload'])"];
  const dir = mkdtempSync(join(tmpdir(), "thingstudio-nodetest-"));
  const scriptPath = join(dir, "_snippet.py");
  writeFileSync(scriptPath, lines.join("\n"));
  const pymockDir = join(__dirname, "fixtures", "pymock");
  return execFileSync("python3", [scriptPath], { env: { ...process.env, PYTHONPATH: pymockDir }, encoding: "utf8" });
}

describe("thingstudio/inject node", () => {
  it("builds a bool payload", () => {
    expect(runBuildMsg({ payloadType: "bool", payloadValue: "true" }).trim()).toBe("True");
    expect(runBuildMsg({ payloadType: "bool", payloadValue: "false" }).trim()).toBe("False");
  });

  it("builds a number payload", () => {
    expect(runBuildMsg({ payloadType: "number", payloadValue: "42" }).trim()).toBe("42");
  });

  it("builds a string payload", () => {
    expect(runBuildMsg({ payloadType: "string", payloadValue: "hello" }).trim()).toBe("hello");
  });

  it("defaults payloadType to bool when unset", () => {
    expect(runBuildMsg({ payloadValue: "true" }).trim()).toBe("True");
  });

  it("rejects an invalid number payload", () => {
    expect(() => injectNode.codegenFireableSource!(node({ payloadType: "number", payloadValue: "not-a-number" }), freshCtx())).toThrow(
      CompileError,
    );
  });

  it("has no repeat property and no codegenSource -- click-only, per docs/working-notes/inject-node-live-fire-and-startup-node.md", () => {
    expect(injectNode.codegenSource).toBeUndefined();
    expect(injectNode.codegenEventSource).toBeUndefined();
    expect(typeof injectNode.codegenFireableSource).toBe("function");
  });

  it("compiles into a fire-dispatch registration, NOT a spawn call", () => {
    const graph: GraphData = {
      nodes: [
        { id: "inject-1", type: "thingstudio/inject", properties: { payloadType: "bool", payloadValue: "true" } },
        { id: "gpio-1", type: "thingstudio/gpio_out", properties: { pin: 12 } },
      ],
      links: [[1, "inject-1", 0, "gpio-1", 0, "bool"]],
    };
    const { source } = compile(graph, buildRegistry());
    expect(source).toContain('runtime.register_fireable("inject-1", ');
    expect(source).not.toMatch(/runtime\.spawn\(/);
    // No poll/sleep loop either -- a fireable source runs its body once
    // per firing, straight-line, same shape a repeatMs:0 codegenSource
    // node's body would take (compile.ts's own repeatMs>0 branch).
    expect(source).not.toContain("while True:");
    expect(source).not.toContain("asyncio.sleep_ms");
  });

  it("the registered fire function, when actually called (standing in for a live FIRE_NODE), runs the sink with the configured payload", () => {
    const graph: GraphData = {
      nodes: [
        { id: "inject-1", type: "thingstudio/inject", properties: { payloadType: "bool", payloadValue: "true" } },
        { id: "gpio-1", type: "thingstudio/gpio_out", properties: { pin: 12 } },
      ],
      links: [[1, "inject-1", 0, "gpio-1", 0, "bool"]],
    };
    const { source } = compile(graph, buildRegistry());
    // fixtures/pymock/runtime.py mirrors the real device-runtime/src/
    // runtime.py's register_fireable/fire shape -- calling runtime.fire()
    // here is the same on-demand path listener.py's _handle_fire_node()
    // takes on a real device in response to a live §13 FIRE_NODE message.
    const driver = `${source}\nruntime.fire("inject-1")\n`;
    const dir = mkdtempSync(join(tmpdir(), "thingstudio-compile-"));
    const scriptPath = join(dir, "_flow.py");
    writeFileSync(scriptPath, driver);
    const pymockDir = join(__dirname, "fixtures", "pymock");
    const output = execFileSync("python3", [scriptPath], { env: { ...process.env, PYTHONPATH: pymockDir }, encoding: "utf8" });
    expect(output).toContain("PIN_VALUE 12 1");
  });
});
