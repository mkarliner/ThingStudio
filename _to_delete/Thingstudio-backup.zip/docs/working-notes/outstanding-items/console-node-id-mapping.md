# Live console output shows raw node IDs only

No way to map `NODE_ERROR node=<id>`/`DEBUG node=<id>` back to a canvas node without reading the flow
file's JSON by hand. Logged as a priority bug, 2026-08-19, in `mikes-questions-and-points.md`'s "Bugs --
priority" section.

**Still unstarted; framing updated 2026-08-22.** Node IDs are now UUIDs
(`inject-node-live-fire-and-startup-node.md`'s Decision 3) — this item originally described the fix as easy
because "the editor already tracks a node-id ↔ canvas-node mapping internally (`graph-adapter.ts`'s
`reteIdByNodeId`/`nodeIdByReteId`)"; that mapping no longer exists, and doesn't need to, since a node's own
ID now *is* its canvas identity directly with zero indirection — if anything the eventual fix is now
simpler (render `node.id` next to the console line, no map to thread through first). But the raw ID a
device error actually reports is now a full UUID instead of a small integer, which is harder to eyeball on
a console than `NODE_ERROR node=4` ever was — the underlying "how am I supposed to know which node this
is?" complaint got slightly worse in the meantime even though the plumbing got simpler. Worth considering a
short human-readable label (or truncated UUID prefix, as the property panel's own `#{{ node.id.slice(0, 6)
}}` already does) alongside the fix, not just a straight `node.id` dump. Unstarted.
