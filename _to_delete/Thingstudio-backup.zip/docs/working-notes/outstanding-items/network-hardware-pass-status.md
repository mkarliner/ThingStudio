# Network nodes' real hardware pass — partially closed

`wifi_status`/`http_request` still off-device verified only (`mvp-validation-plan.md`'s 2026-08-14 Results entry);
no pass against a real HTTP test server on real hardware has been recorded. (UDP send/receive got a real hardware
pass earlier, via the echo-tester flow — that part was already closed.)

**`mqtt_publish`/`mqtt_subscribe` got their first real hardware pass 2026-08-21**, via Mike's own
`mqtttest.flow.json` against a real local broker — and it surfaced a real bug, not just confirmed the happy path: a
WiFi station-interface reconnect race (`E (...) wifi:sta is connecting, cannot set config`) inside the vendored
`mqtt_as`'s `wifi_connect()`. Root-caused the same day; fixed on Thingstudio's own side
(`mqttWifiPrecheckStatement()`, `mqtt-shared.ts`), not by patching the vendored file — see `decisions.md`'s
2026-08-21 entry for the full story, including why an initial patch to `mqtt_as` was reverted.

**Second hardware pass, 2026-08-22 — the 2026-08-21 fix did NOT hold.** Same board, same error, redeployed onto a
still-live prior session rather than a freshly erased one. This is the mqtt-hardware-validation briefing's own named
stop condition; the design was re-opened rather than retimed — see `decisions.md`'s 2026-08-22 entries for the
diagnosis (a checked-too-early / checked-in-the-wrong-place bug, not an insufficient bound) and the first replacement
fix (the precheck moved inline into `mqttEnsureConnectedSnippet()`, using a real `asyncio.sleep_ms` yield).

**Superseded the same day, before that fix even got its hardware retest** — a separate real symptom Mike hit in the
meantime (a flow that worked a couple of inject presses then went completely silent, no error at all) led to reading
the vendored source further and finding a second, unguarded path to the same race: `mqtt_as`'s own background
`_keep_connected()` reconnect loop calls `wifi_connect()` directly, bypassing any wrapper around just our own
`.connect()` call, and silently retries forever if it hits the race. Current fix monkey-patches the constructed
client's `wifi_connect` method itself so every caller goes through the precheck — see `decisions.md`'s second
2026-08-22 entry.

**Third recurrence, same day, before the from-scratch retest even ran** — real-hardware log against Mike's actual
`mqtt-test.flow.json` (mqtt_publish/mqtt_subscribe **and** a `wifi_status` node, all sharing one wifi config) hit the
identical error again. Root cause this time was never MQTT-specific: `mqtt_as`'s `wifi_connect()` calls `.connect()`
unconditionally on ESP32 (no `isconnected()` guard), so even a correctly-waiting precheck reissues a redundant second
`.connect()` right after `wifi_status`'s own separate, uncoordinated module-scope connect succeeds. Fixed by
collapsing every `.connect()` call site in the whole generated program (`wifi_status`/`http_request`/`udp_send`/
`udp_receive`'s own connects, and MQTT's `wifi_connect` monkey-patch) into one shared, lock-protected
`_wifi_ensure_connected()` (`wifi-status.ts`) — see `decisions.md`'s third 2026-08-22 entry for the full diagnosis.
**Still unverified on real hardware** — Mike's from-scratch board rebuild is still the real test, now against this
design. This item stays open until that retest lands one way or the other; a fourth recurrence means the
interface-level `.connect()` semantics need re-examining directly (e.g. a real ESP-IDF trace), not another
codegen-side patch, per `decisions.md`'s own note.
