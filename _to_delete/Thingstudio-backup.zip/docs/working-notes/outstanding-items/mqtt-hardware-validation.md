# MQTT real-hardware validation + network follow-ups (in progress)

Mike's own direct request, takes priority over the sequencing below. Doesn't remove or reorder the rp2350 item — just goes first.

Scope: real-hardware validation of the MQTT WiFi-precheck fix and full MQTT functional pass (pub/sub, broker auth, qos 1,
retain, outage recovery — none run on real hardware yet), plus `http_request`'s still-open config-node/canvas migration
and hardware pass, plus extending Problem 2a's loud-network-error fix to `http_request`/`mqtt-shared.ts`.

**2026-08-22 update: the first hardware retest hit the briefing's own named stop condition** — the WiFi-precheck fix
did not hold (same `wifi:sta is connecting, cannot set config` error, same board reused rather than freshly erased).
Design re-opened per the stop condition, not retimed. The first replacement (precheck moved inline into
`mqttEnsureConnectedSnippet()`) was itself superseded the same day, before it got a hardware retest: a separate real
symptom (a flow going completely silent after a couple of successful injects) led to finding that mqtt_as's own
internal reconnect loop calls `wifi_connect()` directly, bypassing anything wrapped around just our own `.connect()`
call. Current fix monkey-patches `wifi_connect` on the client itself so every caller is covered. See `decisions.md`'s
2026-08-22 entries and `network-hardware-pass-status.md` for the full diagnosis chain. Problem 3's loud-error fix for
`mqtt-shared.ts` landed in the same change.

**2026-08-22 update 2: that fix recurred a third time**, same day, before the from-scratch retest even ran — turned
out the race was never MQTT-specific (`mqtt_as`'s `wifi_connect()` reissues `.connect()` unconditionally, racing
`wifi_status`'s own separate, uncoordinated connect on the same flow). Fixed by unifying every network node type's
`.connect()` behind one shared `_wifi_ensure_connected()` (`wifi-status.ts`) instead of a per-node-type precheck —
see `decisions.md`'s third 2026-08-22 entry and `network-hardware-pass-status.md`. Also folded in, same change:
Problem 3's loud-error fix extended to `http_request` (`asyncio.open_connection()` wrapped with host:port context),
and `wifi_status` now only emits on a connection-state change (event compression, Mike's own request) via a small
new `compile.ts`-level "buildMsg may set `msg = None` to skip this tick" contract. **Still awaiting a hardware
retest against a from-scratch board rebuild** before this item can close — Mike's own next step. `http_request`'s
config-node/canvas migration is still separately in progress (not blocking this retest) — see
`http-request-config-node-gap.md`/`canvas-presence-gaps.md`.

Full brief: `mqtt-hardware-validation-and-network-followups-briefing.md`.
