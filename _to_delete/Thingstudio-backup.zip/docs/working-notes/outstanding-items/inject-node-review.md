# Mike's own suspicion, not yet diagnosed: `inject` might be doing the job of two separate nodes

Flagged 2026-08-17 in `mikes-questions-and-points.md`'s "To review" section, wants a review "fairly soon."

**Resolved 2026-08-22.** Confirmed real: `repeat: "manual"` compiled to `repeatMs: 0`, which `compile.ts`
ran exactly once at boot with no loop at all, and there was no live "fire again on click" mechanism wired
up anywhere — clicking the node on a running/deployed flow did nothing. Fixed by splitting the two jobs
into two nodes: `inject` is now click-only (a real live `FIRE_NODE`/`FIRE_ACK`/`FIRE_ERROR` wire round trip
to a connected, deployed device; `repeat` presets dropped entirely — `timer` already covers repeating
sources), and automatic fire-at-flow-start became the new `startup` node
(`outstanding-items/init-node-on-flow-start.md`). Full design/implementation record:
`docs/working-notes/inject-node-live-fire-and-startup-node.md`.
