# "Init node triggered by start of flow?" — raw open question, never discussed

From `mikes-questions-and-points.md`'s "Nodes - to be prioritised" list, never discussed even in the Tier 1
prioritization session that triaged every other item on that list.

**Resolved 2026-08-22, as the new `thingstudio/startup` node.** Not folded into `inject` as a checkbox —
Mike's own explicit call: "I don't want fire on deploy at all. I want an init (boot) node that fires at
boot time. Deploy is not useful if the device is disconnected from the editor, while a boot/init node will
fire on deploy and on a device reset which is the more useful use case." `startup` fires once automatically
at flow start (deploy or reset), reusing `inject`'s old pre-split `codegenSource`/`repeatMs: 0` shape.
Required a new boot-time flow auto-resume mechanism in `device-runtime/src/listener.py`
(`_resume_persisted_flow()`) so a bare device reset re-imports the persisted flow with no `DEPLOY` sent —
verified end-to-end against a real MicroPython unix-port build
(`device-runtime/test/test_listener_integration.py`). Full design/implementation record:
`docs/working-notes/inject-node-live-fire-and-startup-node.md`.
