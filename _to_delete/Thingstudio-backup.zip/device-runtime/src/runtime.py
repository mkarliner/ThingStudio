# SPDX-License-Identifier: Apache-2.0
# device-runtime/src/runtime.py
#
# The device-side module a compiled flow imports to reach the scheduler --
# the real, named successor to pocs/poc-a's and pocs/poc-d's harness.py
# (see the naming decision in
# docs/working-notes/repo-structure-and-conventions.md: no
# "harness" in real v1 code).
#
# Design doc §5, "Fault isolation" -- half 1 (per-task exception boundary),
# implemented here: "An uncaught exception inside a node's coroutine is
# caught at the per-task boundary (uasyncio surfaces exceptions on task
# completion) instead of crashing the whole event loop. The failing
# subgraph's task stops and reports a structured error back over the
# transport... while the rest of the flow keeps running."
#
# Two things had to change from the pre-hardware stub (see git history)
# to make that real:
#
# 1. spawn() now wraps every coroutine in _guarded(), which catches at
#    task completion instead of letting uasyncio's "Task exception wasn't
#    retrieved" default kill the task silently. Catching inside the task
#    itself (rather than via some external supervisor) is what lets the
#    task return normally afterward -- an unretrieved exception is exactly
#    the failure mode POC-D's listener hit (see listener.py's own header),
#    and the fix there and here is the same shape: never let a bare
#    exception be the last thing a task does.
#
# 2. NodeError exists so a *specific node's* failure inside a multi-node
#    chain can be reported accurately. The current compiler
#    (editor/src/compiler/compile.ts) generates one coroutine per
#    independently-triggered chain (source -> transform* -> sink), not one
#    coroutine per node (§5: "each node, or more likely each
#    independently-triggered subgraph... is a coroutine") -- so without
#    this, an exception anywhere in a multi-node chain could only be
#    blamed on the whole chain, not the one node that actually raised.
#    compile.ts now wraps each transform/sink node's call in a
#    try/except that raises NodeError(node_id, original_exception) before
#    it can unwind past that node's own call site; _guarded() below is
#    what turns that back into an accurate NODE_ERROR report. An exception
#    NOT wrapped in NodeError (e.g. a bug in buildMsg itself, before any
#    node-specific call) still gets reported, blamed on the chain's source
#    node as a documented fallback rather than silently lost.
#
# 3. register_cleanup()/the _cleanups registry (added
#    docs/working-notes/redeploy-cleanup-and-network-fault-detection-briefing.md,
#    Problem 1) -- cancel_running() cancelling a task never touched any
#    OS-level resource (a socket) that task's *module-level* setup code
#    claimed, since that resource isn't owned by the cancelled task's own
#    stack frame. The only thing that used to release it was the old
#    `_flow` module object itself getting garbage-collected, which is
#    exactly why redeploying the same flow twice back-to-back used to fail
#    the first time with an EADDRINUSE-style OSError and succeed on the
#    second -- collection timing, not anything deterministic. This
#    registry is the explicit, symmetric counterpart to
#    compile.ts's mergeSetup dedup on the setup side: a node's generated
#    setup statement self-registers its own cleanup (e.g.
#    `runtime.register_cleanup("udp-send-sock", lambda: _udp_send_sock.close())`)
#    right where it creates the resource, and cancel_running() below is
#    what actually calls every registered cleanup, deterministically, on
#    every redeploy -- no longer relying on GC timing at all.
#
# 4. register_fireable()/the _fireables registry, fire() (added
#    docs/working-notes/inject-node-live-fire-and-startup-node.md) -- the
#    device-side half of the fifth codegen pattern
#    (editor/src/compiler/node-definition.ts's FireableSourceCodegenResult):
#    a fireable-source node (currently just `inject`) contributes a named
#    function here instead of a spawned background task, and only actually
#    runs when the editor sends a live §13 FIRE_NODE naming it
#    (listener.py's _dispatch()). Keyed by node_id, plain dict assignment
#    (no dedup like register_cleanup's "first wins") -- a collision would
#    mean two nodes compiled with the same ID, which the UUID node-ID
#    scheme (editor/src/compiler/graph.ts) makes vanishingly unlikely, and
#    cancel_running() below always clears this dict before a new DEPLOY's
#    registrations land, so even a same-flow re-registration case can't
#    actually arise in practice.

import uasyncio as asyncio

_tasks = []  # tasks spawned by the deployed flow -- tracked so a redeploy
             # can cancel exactly these, same bookkeeping as pocs/poc-a and pocs/poc-d.

_cleanups = {}  # key -> callable; see this file's header, point 3. Keyed the
                # same way setup-statement dedup already works
                # (compile.ts's mergeSetup, "first node's code wins") so two
                # nodes sharing one resource don't register (and double-close)
                # it twice.

_fireables = {}  # node_id (string) -> zero-arg callable returning a coroutine;
                 # see this file's header, point 4. Populated by compiler-
                 # generated `runtime.register_fireable(...)` calls at flow
                 # start, cleared (with everything else) on every redeploy.

# Set by listener.py once it's importable (device-runtime/src/listener.py)
# so this module stays independently importable/testable without ever
# needing to import the listener itself -- avoids a runtime<->listener
# circular import, and keeps this file's own off-device tests
# (device-runtime/test/test_runtime.py) free of any transport/serial
# dependency. Signature: on_node_error(node_id: str, exception_type: str,
# exception_message: str) -> None. Must never raise -- see _report_error's
# own try/except around calling it.
on_node_error = None


class NodeError(Exception):
    """Raised by compiler-generated per-node call wrappers (see this file's
    header) to tag which node an exception happened in before the per-task
    boundary in _guarded() catches it. `node_id` matches NODE_ERROR's wire
    field (messages.py): always a string -- a node's own stable Rete-
    assigned UUID (editor/src/compiler/graph.ts's UUID switch, docs/
    working-notes/inject-node-live-fire-and-startup-node.md), not a
    compiler-internal renumbering, so it stays meaningful across redeploys
    of an edited canvas."""

    def __init__(self, node_id, orig):
        super().__init__(node_id, orig)
        self.node_id = node_id
        self.orig = orig


def _exception_type_name(exc):
    # type(exc).__name__ is confirmed identical in shape between CPython
    # and the MicroPython unix-port build used for this project's
    # off-device tests (device-runtime/test/README.md) -- both give the
    # bare class name (e.g. "ZeroDivisionError"), matching NODE_ERROR's
    # exceptionType field (messages.py / editor/src/protocol/messages.ts).
    return type(exc).__name__


def _report_error(node_id, exc):
    node_label = node_id if node_id is not None else "unknown"
    exc_type = _exception_type_name(exc)
    exc_message = str(exc)
    # Always printed, independent of on_node_error -- keeps a human-
    # readable trail on the serial console even before/without a listener
    # attached, same spirit as every prior POC's plain print()-based
    # status lines.
    print("NODE_ERROR node=%s type=%s msg=%s" % (node_label, exc_type, exc_message))
    if on_node_error is not None:
        try:
            on_node_error(str(node_label), exc_type, exc_message)
        except Exception as e:  # noqa: BLE001 -- reporting itself must never be able to kill a task
            print("NODE_ERROR report callback failed: %r" % (e,))


async def _guarded(coro, fallback_node_id):
    """The actual per-task exception boundary. Runs `coro` to completion;
    any exception it raises is caught HERE, inside the task, so the task
    itself always completes normally -- uasyncio never sees an unretrieved
    exception, and every other task on the event loop is completely
    unaffected (design doc §5's own claim, made concretely true by this
    function existing)."""
    try:
        await coro
    except asyncio.CancelledError:
        raise  # a redeploy cancelling this task is not a fault -- must propagate normally
    except NodeError as e:
        _report_error(e.node_id, e.orig)
    except Exception as e:  # noqa: BLE001 -- this IS the fault boundary; anything not already a NodeError is still reported, not silently dropped
        _report_error(fallback_node_id, e)


def spawn(coro, node_id=None):
    """Spawn a flow-generated coroutine under the per-task fault boundary.
    `node_id` (a string) is the chain's source node -- used only as the
    fallback attribution for an exception that happens outside any
    NodeError-wrapped call (see this file's header, point 2). Compiler-
    generated code always passes it; it's optional here so hand-written
    coroutines (this file's own off-device tests, or a POC-style throwaway
    script) can still call spawn() without a node graph behind them."""
    t = asyncio.create_task(_guarded(coro, node_id))
    _tasks.append(t)
    return t


def register_cleanup(key, fn):
    """Registers a callable to run the next time the currently-deployed
    flow is torn down (redeploy today; any future stop path would get this
    for free too) -- see this file's header, point 3. Only the first
    registration for a given key sticks, matching mergeSetup's own "first
    node's code wins" precedent, so e.g. two udp_receive nodes
    (incorrectly) sharing one port don't each register their own close on
    what's actually one shared socket."""
    if key not in _cleanups:
        _cleanups[key] = fn


def register_fireable(node_id, fn):
    """Registers `fn` (a zero-arg callable returning a coroutine) as what
    runs when the editor fires `node_id` live via §13 FIRE_NODE -- see this
    file's header, point 4. Plain overwrite, no dedup -- see the
    `_fireables` declaration's own comment for why that's safe here even
    though register_cleanup (above) deliberately does dedup."""
    _fireables[node_id] = fn


def fire(node_id):
    """Looks up `node_id` in the current flow's fire-dispatch table and, if
    found, spawns it under the same per-task fault boundary every other
    flow-generated coroutine gets (spawn() above) -- a failure inside the
    fired node is reported the ordinary way, via NODE_ERROR, not as part of
    this call's own return value. Returns True if a fireable was found and
    spawned, False if `node_id` isn't (or isn't currently) registered --
    listener.py's _dispatch() turns that into FIRE_ACK/FIRE_ERROR."""
    fn = _fireables.get(node_id)
    if fn is None:
        return False
    spawn(fn(), node_id)
    return True


async def cancel_running():
    global _tasks
    for t in _tasks:
        try:
            t.cancel()
        except Exception:
            pass
    _tasks = []
    _fireables.clear()
    await asyncio.sleep_ms(10)
    # Cleanups run AFTER the grace period above, not before -- closing a
    # socket out from under a task that's still mid-recvfrom()/sendto() on
    # it (before cancellation has actually propagated) risks a confusing
    # exception inside the task being torn down, instead of a clean
    # CancelledError. Each cleanup gets its own try/except so one
    # resource's failure to close cleanly can't block the others from
    # running or crash the redeploy itself -- same "never let one failure
    # kill the whole path" convention _report_error/_send_message_safe
    # already follow in listener.py.
    for key, fn in _cleanups.items():
        try:
            fn()
        except Exception as e:  # noqa: BLE001 -- one resource's cleanup failing must never block the others or the redeploy itself
            print("CLEANUP_ERR key=%s %r" % (key, e))
    _cleanups.clear()
