# Decisions log

Status: index, started 2026-08-19. An append-only, one-entry-per-decision
ledger — not a re-derivation of the reasoning behind each one. Each entry
is dated, states the decision in one line, and points back to the working
note (or design doc section) with the full argument. Read this to
orient fast across ~15 real decisions otherwise scattered across 33+
working-notes files; read the pointed-to source when the *why* actually
matters for what you're about to do.

**Scope boundary, so this doesn't duplicate two things that already
exist:** `docs/thingstudio-design-doc.md` §11 is still the record for
architecture-level, user-facing decisions, using its own strikethrough-
plus-dated-resolution style in place — this log doesn't replace that, it
indexes it alongside everything else (tooling, library, process, and
implementation-technology choices the design doc's own convention says
don't belong in it). A design-doc decision gets one line here too, so this
stays the single place to scan.

**Maintenance rule:** whenever a session writes or updates a
`Status: decision`/`Status: resolved` note, or resolves a design-doc open
question, add one line here in the same change — not batched for later.
Same convention already established for `docs/third-party-licenses.md`.

---

## Architecture

- **2026-08-11 — MicroPython over CircuitPython.** Already validated
  end-to-end by POC-A/B/D against stock MicroPython; re-spiking
  CircuitPython would strand that validation for an unlikely win.
  `thingstudio-design-doc.md` §11.
- **2026-08-11 — Litegraph.js over Drawflow for the canvas (POC-C).**
  Native type-checked wiring, live value propagation, multi-select;
  Drawflow needed all three hand-rolled. **Reversed 2026-08-16** — see
  below.
- **2026-08-16 — Rete.js over Litegraph.js (reversal of the above).**
  Not a correction of POC-C's method — a maintenance/ecosystem finding
  POC-C wasn't scoped to weigh: Litegraph is a vendored, unmaintained
  single file; Rete is a real, actively-installed npm package set.
  `rete-migration-decision.md`, `thingstudio-design-doc.md` §11.
- **2026-08-11 — Human-readable generated Python, not a compact
  intermediate form.** `mpy-cross` compile latency is sub-millisecond
  regardless of source verbosity, so compactness buys nothing; readable
  source keeps `NODE_ERROR` reports traceable. `thingstudio-design-doc.md`
  §11.
- **2026-08-11 — No function-node sandboxing for v1.** No marketplace or
  shared-flow mechanism exists yet, so the only stated reason to harden it
  doesn't apply. Revisit if/when one is scoped. §11.
- **2026-08-11 — No node distribution/versioning system for v1.** v1's
  node set is fixed at flash time as part of the runtime image; a node's
  "version" is just the runtime image's version, already carried by
  `HELLO`. §11.
- **2026-08-11 — No no-hardware simulation mode, ever — not deferred, out
  of the project's roadmap entirely.** Real hardware doesn't behave like a
  simulator; POC-D's own hardware-only bug list is exactly what a
  simulator wouldn't catch. §11.
- **2026-08-11 — USB-only runtime image updates for v1; OTA deferred to
  v2.** No wireless transport exists yet for OTA to ride on. One hedge
  taken now regardless: reserve OTA-capable ESP32 partitions from the
  first flash (still not actually done — see `outstanding-items.md`). §11.
- **2026-08-12 — Precompiled `.mpy` bytecode over raw-source `exec()`.**
  Not a latency call (POC-A showed raw-source is fast enough) — a RAM
  call: on-device compilation needs RAM on top of what the compiled code
  needs, and can OOM a constrained board even when the bytecode runs fine.
  §15.1 addendum.

## Repo / tooling

- **2026-08-12 — Single monorepo** (editor, device-runtime glue, node
  library together), not split repos — the pieces are tightly coupled
  right now. `repo-structure-and-conventions.md`.
- **2026-08-12 — TypeScript for the editor, Python for device-runtime.**
  Static typing catches the `msg` envelope/node-registry/CBOR-shape
  mismatches at build time; MicroPython target leaves no choice on the
  device side. Same note.
- **2026-08-12 — Vite + Vitest** as build/test tooling, replacing the
  POCs' no-build-step habit. Same note.
- **2026-08-12 — `ruff` for `device-runtime`'s Python**, configured around
  expected MicroPython-only-name false positives rather than suppressing
  broadly. Same note.
- **2026-08-12 — Apache-2.0 project license**, over MIT, mainly for the
  explicit patent grant on an embedded/wireless project. §14.
- **"Harness" retired as a name** for the on-device listener — too easily
  misread as agent-harness. Real code uses `runtime`/`listener`. Doesn't
  touch the POCs' own frozen `harness.py`. `repo-structure-and-conventions.md`.

## Backend (design-complete, zero code as of 2026-08-19 — see `outstanding-items.md`)

- **2026-08-16 — Thin local backend + browser-based web editor — explicitly
  not a native GUI app (Electron/Tauri), and not browser-only
  WebSerial-direct either.** A backend decouples "where the device is"
  from "where the human is" (remote access as a first-class use case, not
  just packaging) — a capability unlock Electron/Tauri can't provide
  either, since a desktop GUI app is just as tied to the machine it runs
  on. Tauri specifically ruled out on a technical ground, not taste: its
  system webview (WKWebView/WebKitGTK) doesn't implement Web Serial, so it
  would force the transport rewrite anyway while also adding Rust and the
  full packaging/signing burden — strictly more cost than the backend
  alone. `rete-migration-decision.md` Decision 2 (§"Not Electron, not
  Tauri").
- **2026-08-16 — Python + `aiohttp`, not FastAPI or raw
  `asyncio`+`websockets`.** The job is narrow (relay + static files);
  FastAPI's Pydantic/Starlette/Uvicorn weight isn't needed; raw
  asyncio means hand-writing what aiohttp already provides.
  `backend-platform-decision.md`.
- **2026-08-16 — Plain `pyserial` (sync, wrapped in
  `asyncio.to_thread`), not `pyserial-asyncio`.** That package is dead
  (no release since Sept 2021); one fewer dependency to audit, at the cost
  of hand-writing the thread-executor wiring. Same note.
- **2026-08-16 — WebSocket wire shape: one endpoint, multiplexed by frame
  type** — binary frames are §13's CBOR bytes passed through verbatim (no
  backend-side decode), text frames are backend-local JSON control
  messages (port list, connect, status). `backend-editor-auth-and-protocol.md`.
- **2026-08-16 — Posture 1 (default) auth: Host-header allowlist is the
  load-bearing defense against DNS rebinding, not `Origin`.** Same-origin
  policy doesn't cover WebSocket connections from page JS the way it
  covers `fetch`/XHR. Same note.
- **2026-08-16 — Posture 2 (opt-in remote access) auth: hand-rolled
  `bcrypt` + signed, expiring session cookie, not `aiohttp-session`.**
  That library has had no release in ~12 months; the actual surface needed
  is small enough to implement directly against the stdlib. Same note.
- **2026-08-16 — Session cookie, not a bearer token**, specifically
  because the browser's native `WebSocket` constructor cannot set custom
  headers — no way to send `Authorization: Bearer` on a WS handshake from
  page JS. Same note.
- **2026-08-21 — `~/.thingstudio` local-state persistence is backend-owned,
  not a browser-only stopgap, and this backend work is now marked
  MVP-needed by Mike.** A browser can't silently target a fixed
  home-relative path — only a user-driven picker, with reliably persisted
  permission in Chrome/Edge only — so this waits for the backend rather
  than building something thrown away once it exists. The MVP mark is a
  real scope change: the backend wasn't in `mvp-feature-priorities.md`'s
  tier list at all before this. Scoped as the app's general local-state
  directory (custom node packages as the first consumer), not
  custom-nodes-only, per Mike's own framing — not yet reconfirmed as a
  separate answer. `local-persistence-scoping.md`.

## Board-transport auth (perimeter 2)

- **2026-08-16 — HMAC-SHA256 + a persisted monotonic counter, not a
  random-nonce challenge–response.** The ESP32-C3's hardware RNG is not a
  true RNG unless WiFi/BT is enabled, and v1 is USB-only with no radio
  bring-up — a nonce would be pseudo-random. A counter defeats replay
  without needing any entropy on-device. `transport-auth-design.md`.
- **2026-08-16 — Real v1 commitment is just two `HELLO` fields**
  (`authRequired`, `authScheme`), even shipping `authRequired: false`.
  Everything else about the codec is additive and cheap to add later —
  the one real one-way door is capability *advertisement*, not encoding.
  **Still not implemented** — see `outstanding-items.md`. Same note.
- **2026-08-16 — No keypair auth for v1.** Costs a firmware rebuild for a
  native module (or unmeasured, likely-slow pure-Python verification) to
  defend against a threat (backend compromise) v1 doesn't yet meaningfully
  face. Reserved as a future `authScheme` value, not a protocol revision.
  Same note.

## Editor / canvas

- **2026-08-16 — Rete migration: an adapter over `compiler/graph.ts`,
  not a rewrite of its accepted shape.** Keeps the tested compiler-input
  contract unchanged; `graph-adapter.ts` translates Rete's graph into the
  existing `{nodes, links}` shape. `rete-migration-decision.md`.
- **2026-08-16 — Hand-rolled palette drag-and-drop, not
  `rete-dock-plugin`.** Sub-decision 2, same note.
- **2026-08-16 — Wire-type system deliberately NOT bundled into the Rete
  migration** — kept as its own, immediately-following task so any
  regression stays attributable to one or the other. Sub-decision 3, same
  note.
- **2026-08-16 — Wire-type system: ship narrow and loose, tighten later
  if real use shows real pain.** Three-bucket coercion matrix (truthiness
  into `bool` always allowed; numeric widening allowed, narrowing
  refused; `bytes`↔`string` and `any`-into-concrete-types refused, need an
  explicit conversion node). No conversion node built yet — nothing in
  the current node set needs one. `wire-type-system-scoping.md`.
- **2026-08-14 — Compiler emits `async def`/`await` uniformly for every
  transform/sink node**, not an opt-in per-node flag or blocking sockets
  with no compiler change — avoids stalling the flow's one event loop
  during real network I/O, mechanical for every other node type.
  `mvp-validation-plan.md`, 2026-08-14 network-batch Results entry.
- **2026-08-17 — Debounce uses the cooldown algorithm** (ignore
  transitions within N ms of the last accepted one), not
  settle-and-confirm — the cheap version, per `CLAUDE.md`'s
  premature-optimization principle. `tier1-interrupt-node-implementation-briefing.md`.
- **2026-08-14 — Vendor `mqtt_as` (Peter Hinch, MIT), not `umqtt.simple`.**
  Non-blocking I/O and built-in WiFi/broker reconnection, worth the
  vendoring cost over the more commonly-cited blocking library.
  `mvp-validation-plan.md`, 2026-08-14 network-batch Results entry.

## Config nodes / Tier 1 scope

- **2026-08-17 — Tier 1 item 5 resolved: interrupt/pin-change (replacing
  `gpio_in`), filter/event-compression, and four UDP/TCP nodes pulled into
  v1.** ADC and file ops rejected as node types entirely (both reduce to
  a `function`-node one-liner or an already-tracked need elsewhere); mDNS
  deferred to v2 (MicroPython support unconfirmed across targets); HTTP-in
  (on-device server) stays deferred per §6's existing dashboard reasoning.
  `tier1-node-candidates-prioritization-briefing.md`.
- **2026-08-21 — `boolean`/`arithmetic`/`comparator` node types removed
  entirely, same reasoning as ADC/file ops above.** Mike's call, checked
  rather than rubber-stamped: the one real counter-argument (a dedicated
  node could carry narrower, statically-checked port types than
  `function`'s necessarily-`any` ports) didn't hold for the code as
  shipped — none of the three declared a `ports` field, so they had zero
  type-safety benefit in practice, and all three were single-input
  transforms against a configured constant, so `function` was already a
  strict functional superset. Never wired onto the canvas. Not a one-way
  door — nothing deployed references these types, cheap to re-add later
  if canvas wiring + real typed ports is ever actually built for them.
  `thingstudio-design-doc.md` §6 addendum, `registry.ts`.
- **2026-08-18 — Config nodes: build Node-RED's per-flow, referenced-by-ID
  pattern, not the design doc's original per-device-override vision.**
  Direct override from Mike ("entering ssid credentials multiple times is
  not acceptable even for an MVP") — smaller, fixes the actual pain,
  per-device override stays a v2 layer on top.
  `config-node-and-palette-implementation-briefing.md`.
- **2026-08-18 — A config reference (`wifiConfigId`) stays optional, not
  mandatory**, for the four non-MQTT network node types — smaller behavior
  change, keeps a config-less flow compiling exactly as before. Same
  note.
- **2026-08-21 — `mqtt_publish`/`mqtt_subscribe` migrated to `wifiConfigId`
  (closing the last flagged config-node follow-up besides `http_request`)
  and given real canvas presence for the first time in the same change.**
  A referenced config with `security: "unmanaged"` is rejected as a
  `CompileError` for these two specifically, diverging from
  `wifi_status`/`udp_send`/`udp_receive` — `mqtt_as` always drives its own
  connect/reconnect loop and needs real credentials to do so, so there's
  no "ride on an externally-managed connection" mode to map `"unmanaged"`
  onto. `mqtt-shared.ts`, `mqtt-publish.ts`, `mqtt-subscribe.ts`,
  `thingstudio-design-doc.md` §6 addendum.
- **2026-08-21 — Second config type, `thingstudio/config/mqtt-broker`
  (`broker`, `port`, `username`, `password`), for `mqtt_publish`/
  `mqtt_subscribe`'s broker connection — Mike's own same-day follow-up
  request.** `brokerConfigId` is mandatory from day one, no
  optional-then-later-reversed cycle the way `wifiConfigId`'s own
  mandatory-ness was (the immediately preceding entry) — there's no
  sensible default broker to fall back to the way an already-connected
  WiFi interface is a sensible "ride on it" fallback. Kept as a SECOND,
  independent config reference rather than folded into
  `thingstudio/config/wifi` — the WiFi network and the MQTT broker are
  authenticated to with two genuinely different credential pairs
  (`mqtt_as`'s `ssid`/`wifi_pw` vs. its `user`/`password` config keys).
  `username`/`password` are optional (no forced-non-empty check the way
  the WiFi config's password gets) — an unauthenticated broker is a
  normal, common setup, not a likely-forgotten-credential case. MQTTS
  (TLS) explicitly deferred without reserving a field for it — checked
  against `CLAUDE.md`'s one-way-door principle first: a config's
  properties are a plain JSON blob, so this isn't a one-way door, unlike
  `HELLO`'s reserved auth fields. `config-types.ts`, `mqtt-shared.ts`,
  `outstanding-items.md`.

## Redeploy / network fault handling

- **2026-08-20 — Explicit cleanup registry (`runtime.register_cleanup`/
  `cancel_running`), not GC-timing reordering, fixes the redeploy socket
  leak.** A `gc.collect()` reorder would only make the `EADDRINUSE` flake
  less frequent, still relying on incidental collection timing for
  something that needs to be deterministic. `redeploy-cleanup-and-
  network-fault-detection-briefing.md` Problem 1, `runtime.py`.
- **2026-08-20 — `wifiConfigId` made mandatory for `wifi_status`/
  `udp_send`/`udp_receive` (Option B), reversing the config-node
  briefing's "optional" call.** The optional/implicit fallback was
  exactly what let `wifi_status` report a connection the flow never
  declared. `http_request` is untouched (still unmigrated to config
  nodes at all). Mike's own explicit sign-off, not a default. Same
  briefing, Problem 2b; see `config-node-and-palette-implementation-
  briefing.md`'s own retroactive note.
- **2026-08-20 — WiFi config `security` field: `"password"` (default) |
  `"open"` | `"unmanaged"`, not just the two the briefing scoped.** The
  third state (`"unmanaged"` -- no managed connection, ride on whatever
  the device already has) is the explicit, labeled replacement for what
  an omitted `wifiConfigId` used to mean implicitly, kept specifically so
  Option B's mandatory-config rule doesn't foreclose a future captive-
  portal/AP-fallback WiFi provisioning flow (raised by Mike 2026-08-20,
  not built or scoped -- see `outstanding-items.md`). An empty password
  on a `"password"`-security config is a compile-time `CompileError`.
  `config-types.ts`, `wifi-status.ts`.
- **2026-08-20 — Network OSError messages re-raised with host:port
  context, `udp_send`/`udp_receive` only.** `http_request`/`mqtt-
  shared.ts` left untouched -- the briefing flagged touching them as a
  judgment call, not mandated; not done this session, still open for
  whoever picks it up next.
- **2026-08-21 — "sta is connecting, cannot set config" deploy failure
  (real hardware, `mqtttest.flow.json`) fixed on Thingstudio's own side,
  NOT by patching the vendored `mqtt_as` -- reversing this same day's
  earlier call to patch it, on Mike's own explicit direction after he
  reviewed the library's own issue history.** Root cause, confirmed by
  reading the vendored source directly: mqtt_as's `wifi_connect()` (ESP32
  branch) does `s.active(True)` then unconditionally
  `s.connect(self._ssid, self._wifi_pw)`, with no check for a connect
  already in progress; `s.active(True)` alone can trigger ESP-IDF's own
  NVS-cached auto-reconnect from a previous deploy's saved station config,
  and if that's still resolving when the very next line fires its own
  connect, ESP-IDF refuses the second connect's config-set. Ruled out
  first: not a cross-node-type race (wifi_status/http_request/udp_send/
  udp_receive vs. mqtt_as's own connect) -- the reproducing flow has only
  `mqtt_publish`/`mqtt_subscribe`, sharing one `wifiConfigId`/
  `brokerConfigId`, and the existing lock/dedup mechanism
  (`mqttEnsureConnectedSnippet`) was already working correctly, so the bug
  is entirely inside `wifi_connect()` itself.
  A local patch to the vendored file (adding the missing guard, mirroring
  the ESP8266 branch's own existing `isconnected()` check a few lines
  above) was drafted, applied, and delivered -- then reverted the same
  day. Mike reviewed this library's own GitHub issue history and found
  this exact class of fix (an `isconnected()`/connecting-state guard on
  the ESP32 branch) already raised more than once
  ([peterhinch/micropython-mqtt#59](https://github.com/peterhinch/micropython-mqtt/issues/59),
  [#61](https://github.com/peterhinch/micropython-mqtt/issues/61), and a
  `_is_connecting`-flag variant discussed in
  [#57](https://github.com/peterhinch/micropython-mqtt/pull/57)) without
  landing in the base implementation -- his call was not to carry a
  diverging local patch against the maintainer's evident preference, and
  to fix this entirely on Thingstudio's own side instead.
  `mqttWifiPrecheckStatement()` (`mqtt-shared.ts`) is that fix: a
  module-scope statement, emitted by every mqtt_publish/mqtt_subscribe
  node (deduped to one occurrence per flow via the existing `mergeSetup`
  mechanism), that WAITS OUT -- never cancels -- any WiFi connect already
  in progress, bounded, before mqtt_as's own async `.connect()` ever gets
  a chance to run. Waiting rather than cancelling is what keeps this safe
  for a flow that also has wifi_status/http_request/udp_send/udp_receive:
  those issue their own real `.connect()` call in their own module-scope
  setup, and a cancel-based approach (the reverted vendored-file patch)
  would have risked tearing down another node's legitimate, still-
  resolving connect attempt; a wait can only let something already
  destined to finish, finish, before mqtt_as's own connect call runs.
  Deliberately gated to `sys.platform == "esp32"` -- the underlying race
  is an ESP-IDF-specific behavior, and `network.STAT_CONNECTING` isn't
  confirmed present on every MicroPython port this project targets (the
  vendored file's own code only ever references that constant inside its
  own `if ESP32:` branches). Verified against the real reproducing flow:
  compiled `mqtttest.flow.json`'s equivalent graph and confirmed the
  precheck statement appears exactly once, ahead of the client-setup
  code, in the generated source (`ast.parse`-checked). 273/273 editor
  tests still pass (existing tests updated to look up the client-setup
  statement by content rather than a fixed array index, since the
  precheck statement is now emitted first). The vendored file itself is
  back to byte-identical-with-upstream; `device-runtime/src/vendor/
  mqtt_as/README.md`'s "Local patches" section now says so explicitly and
  points here. Filing an issue upstream (not a PR, given the history) may
  still be worth doing independent of our own fix -- Mike's call, not
  decided either way this session -- see `outstanding-items.md`.
- **2026-08-22 — Ruled out: the 2026-08-21 `mqttWifiPrecheckStatement()`
  fix above, re-tested on real hardware, did NOT hold.** Mike redeployed
  (reusing an already-live prior session on the board, not a freshly
  erased one) and hit the identical `E (...) wifi:sta is connecting,
  cannot set config` again. This is the MQTT-hardware-validation
  briefing's own named stop condition ("the WiFi-precheck fix does NOT
  hold under the stale-NVS repro -- stop and re-open the design rather
  than tweaking the timeout/loop bound and hoping") -- so the design was
  re-opened, not retimed. Diagnosis (not just a retry): the precheck ran
  as a module-scope statement, executed once at flow-module import time,
  well before mqtt_as's own `.connect()` call actually runs (that only
  happens later, inside a coroutine, once `runtime.spawn()` schedules it)
  -- so real elapsed time between "precheck passed" and "mqtt_as connects"
  was exactly where a slower-to-appear auto-reconnect could still start
  unopposed. Compounding it: the loop's first `status()` read happened
  immediately after `.active(True)`, with no yield beforehand -- if
  ESP-IDF's WiFi task (a separate FreeRTOS task) hadn't yet processed that
  event into an observable `STAT_CONNECTING` transition, the loop would
  see "not connecting" and exit having waited 0ms. Two check-timing bugs,
  not an insufficient bound.
- **2026-08-22 — Fix: move the precheck inline into
  `mqttEnsureConnectedSnippet()`, immediately before its own
  `await client.connect()`, using `await asyncio.sleep_ms(...)` (a real
  event-loop yield -- Mike's own suggestion, in place of the previous
  blocking `time.sleep_ms()`) and checking `status()` only AFTER each
  yield, never before.** `mqttWifiPrecheckStatement()` and
  `MQTT_WIFI_PRECHECK_KEY` are removed entirely, not kept alongside the new
  version -- there's no longer a separate module-scope statement for this
  at all. This closes both gaps above by construction: the check now runs
  at the exact point it's meant to guard (no elapsed-time gap to race
  through), and it never trusts a "not connecting" read that hasn't
  actually waited. Same ~5s bound (50 × 100ms) as before -- this is a
  relocation and a yield-mechanism change, not a bigger number. Also
  folded in while touching this code: `mqttEnsureConnectedSnippet()`'s
  `.connect()` call, and `mqtt-publish.ts`'s `.publish()`/
  `mqtt-subscribe.ts`'s `.subscribe()` calls, now re-raise `OSError` with
  the broker's own host:port (and, for publish/subscribe, the topic)
  folded into the message -- the MQTT-hardware-validation briefing's
  Problem 3, extending the same udp-send.ts-established loud-network-error
  pattern. `mqtt-shared.ts`'s header carries the full writeup.
  **Superseded later the same day, before a hardware retest even
  happened** — see the next entry; the fix above only ever guarded our own
  explicit `.connect()` call, not mqtt_as's own internal reconnect loop.
- **2026-08-22 — Superseding fix: `mqttSetupStatement()` now monkey-patches
  the constructed client's own `wifi_connect` bound method, once, at
  construction, instead of wrapping one specific call site.** Found by
  reading the vendored source further (not by a repro of this exact
  failure mode) while the entry above was still awaiting its hardware
  retest: `MQTTClient.connect()` only calls `self.wifi_connect()` on the
  very first connect; every later reconnect is driven entirely by
  mqtt_as's own background `_keep_connected()` task, which calls
  `self.wifi_connect()` directly — completely bypassing anything wrapped
  around our own `.connect()` call. If that internal reconnect hits the
  same ESP-IDF race, `_keep_connected()` swallows the OSError and loops
  back to retry silently, forever (`except OSError: continue`) — which
  lines up with a real symptom Mike hit in the meantime: a flow that
  published/subscribed successfully a couple of times, then went
  completely silent (no error, no debug, nothing) on every later inject.
  The fix: capture `client.wifi_connect` once right after construction,
  replace it with a plain function that runs the same bounded,
  yield-before-check wait and then calls the captured original — so every
  future call to `wifi_connect`, from any caller, goes through the
  precheck uniformly. Confirmed the underlying monkey-patch mechanic
  (instance-attribute assignment shadowing a bound method, no implicit
  `self` passed to the replacement) behaves as expected with a standalone
  CPython repro before shipping this. Still instance-level patching from
  OUR generated code, not a diverging patch to the vendored file itself —
  `device-runtime/src/vendor/mqtt_as/__init__.py` stays untouched, same
  constraint Mike set 2026-08-21. `mqttEnsureConnectedSnippet()`'s own
  inlined precheck (the previous entry) is now redundant and was removed
  — the snippet is back to just the double-checked lock plus the
  loud-error wrap. **Still unverified on real hardware** — this closes a
  gap found by code reading, not a repro of THIS specific failure; the
  from-scratch board rebuild Mike is doing is still the real test for both
  fixes together. A third recurrence re-triggers the same stop condition
  — re-open the design again, don't retime it.
- **2026-08-22 — Third recurrence: the WiFi race isn't MQTT-specific at
  all. Fix: one shared, lock-protected `_wifi_ensure_connected()` for the
  whole generated program, not a per-node-type precheck.** Real-hardware
  retest of the above monkey-patch, against Mike's actual
  `mqtt-test.flow.json` (mqtt_publish/mqtt_subscribe **and** a `wifi_status`
  node, all three sharing one wifi config — confirmed from the flow file
  itself after an initial wrong guess that no MQTT node was present), hit
  the identical `wifi:sta is connecting, cannot set config` again — stop
  condition triggered a third time. Root cause, found by reading
  `mqtt_as.wifi_connect()`'s ESP32 branch line by line: it calls
  `s.connect(self._ssid, self._wifi_pw)` **unconditionally**, with no
  `isconnected()` guard (its own ESP8266 branch checks first; ESP32
  doesn't). So even a correctly-waiting precheck would wait out
  `wifi_status`'s own module-scope connect (`wifi-status.ts`'s
  `wifiSetupStatement()`, which fired synchronously at import time, before
  the event loop — and therefore before MQTT's own precheck — existed),
  see it clear, and immediately reissue a second, redundant `.connect()`
  right after the first one succeeded. "Waiting rather than cancelling"
  (the previous entry's reasoning) was right but incomplete: it assumed
  only one *other* attempt would ever need waiting out, not a second,
  self-inflicted one fired immediately after. Fix: collapsed every
  `.connect()` call site in the whole generated program — `wifi_status`/
  `http_request`/`udp_send`/`udp_receive`'s own connects (moved out of
  eager module-scope setup, now lazy + `await`ed from each node's own
  function body) and MQTT's `wifi_connect` monkey-patch — into one shared,
  lock-protected, `isconnected()`-aware `_wifi_ensure_connected()`
  (`wifi-status.ts`, under the existing `"wifi-sta"` dedup key; MQTT's
  wrapper `await`s it first, only falling through to the vendored
  `wifi_connect()` body if it still didn't get connected). Exactly one
  connect owner now, regardless of how many network node types share the
  interface. Verified off-device: `tsc --noEmit` clean, and the new
  `_wifi_ensure_connected()`/event-compression logic hand-run through
  pymock (a duplicate-`global`-statement `SyntaxError` was caught this way
  in the new wifi_status test before it shipped — see `learnings.md`).
  **Still unverified on real hardware** — same from-scratch-rebuild retest
  as before, now against this design instead. A fourth recurrence means
  the interface-level `.connect()` semantics themselves need re-examining
  (e.g. against a real ESP-IDF trace), not another codegen-side patch.
  `wifi-status.ts`'s and `mqtt-shared.ts`'s own headers carry the full
  diagnosis chain.
- **2026-08-22 — `wifi_status` gets event compression: only emits on a
  connection-state change, not every poll.** Mike's own request, prompted
  by a hardware log showing `payload=True`/`payload=False` on every single
  5s poll. Needed a small compiler-level addition, not just a node-level
  one: `compile.ts`'s regular (non-event-source) `codegenSource` loop now
  wraps a source's downstream `chainBody` in `if msg is not None:`, mirroring
  the contract `codegenEventSource`'s own `buildMsg` already documented
  (`msg = None` means "nothing to propagate this tick") but had never
  actually been given to the plain polling-loop path — the sleep/yield
  still runs unconditionally every iteration either way, so this doesn't
  reopen the "must not busy-loop" hazard. `wifi_status` tracks its last-
  reported state in a per-node-instance global (not shared via the
  `"wifi-sta"` key — two `wifi_status` nodes need independent tracking),
  seeded to `None` so the very first poll always emits once.

## Node authoring / extensibility

- **2026-08-20 — Custom nodes: two-file package (`<name>.node.json` +
  `<name>.node.py`), no new wire protocol.** Inlined into the existing
  DEPLOY-compiled flow module via a generic `NodeDefinition` builder
  (`buildCustomNodeDefinition`, `node-library/custom-node.ts`) that wraps
  user Python in a per-instance closure — `compile.ts` itself needs zero
  changes; a custom node's `NodeDefinition` is indistinguishable from a
  first-party one to the compiler. Distribution mechanism deliberately
  narrower than design doc §11's module-push sketch — that stays
  deferred until a real need (shared-across-flows, size) forces it, per
  `CLAUDE.md`'s no-premature-optimization principle.
  `custom-node-authoring-scoping.md`.
- **2026-08-20 — No sandboxing for custom node Python — same trust
  boundary as the `function` node, and doesn't reopen §11's dormant
  sandboxing question.** Custom nodes don't cross the existing
  deploy-access trust perimeter (§9). Mike's explicit call: "go with the
  trust-boundary call (until it bites us)." Loading is session-scoped only
  (browser File System Access API multi-file picker) — no persistence,
  file-watching, registry, or URL-install mechanism built or planned.
  Same note.
- **2026-08-20 — Custom node output ports capped at 1 by codegen
  validation, not by the package format.** The `.node.json` schema itself
  places no limit on `ports.outputs`; `validateCustomNodeDescriptor` is
  what enforces ≤1 for v1, specifically so this doesn't compromise the
  higher-priority multi-output-routing roadmap item — confirmed as the
  right framing directly with Mike ("multiple outputs is fairly high on
  the priority list... just don't do anything to compromise it"). Same
  note.
- **2026-08-21 — Custom node package persistence across app runs: waits
  for the backend, resolving Decision 4's "future work" either/or in favor
  of its backend-owned half.** Not a browser-side File System Access
  handle-persistence build — see the `Backend` section entry above for the
  reasoning and the MVP-priority consequence. `local-persistence-scoping.md`.

## Session sequencing

- **2026-08-20 — Custom node authoring + documentation come next, ahead of
  `outstanding-items.md`'s normal order, followed by a documentation-only
  validation session before resuming normal order.** Mike's own explicit
  call: implement custom node authoring (design doc §7's groundwork,
  `outstanding-items.md`'s "Node authoring / extensibility" section) and
  end-user documentation together in one session, despite that backlog
  entry's own note that it "needs its own dedicated scoping session" —
  that scoping now happens inside this session, not before it. Once done,
  a separate session gets *only* the resulting end-user docs (not this
  file, not `CLAUDE.md`) and has to build a new node type from a brief —
  a real test of whether the documentation is actually sufficient, not
  just written. `outstanding-items.md`'s "Next up" section.

## What this list doesn't include

Small per-file implementation judgment calls (exact property names, which
bucket a specific type pair lands in, pin numbers) — those live in the
node's or file's own header comment, per this project's existing
convention, and aren't worth indexing here.
