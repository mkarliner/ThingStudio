# Key learnings

Status: index, started 2026-08-19. An append-only ledger of hard-won
technical facts and gotchas — things that cost real time to discover and
will bite again if forgotten, but aren't a behavioral rule for how a
session should operate (that's `CLAUDE.md`'s job — a few of these
*did* get promoted there, e.g. the git-lock issue and the stray-`.js`
issue, and are cross-referenced rather than duplicated below). Each entry
is short: what was learned, why it matters, where the full story is.

**Maintenance rule:** whenever a session hits something like this — a
surprising platform behavior, a library gotcha, a test-methodology trap,
a hardware quirk — add one line here in the same change, not batched for
later. If it turns out to be a repeatable process rule Claude should
always follow (not just a fact worth knowing), promote it to `CLAUDE.md`
instead, and leave a pointer here rather than duplicating the text.

---

## Already promoted to `CLAUDE.md` (standing rules, not repeated here)

Git writes from the agent sandbox leave stale `.git/*.lock` files behind
on the live-mounted repo (`git add`/`git commit` never run from the
sandbox, ever). Stray compiled `.js` files can shadow real `.ts` sources
when a sandboxed `npx tsc --noEmit` silently doesn't respect the flag
(check and delete before trusting any test/build result). See
`CLAUDE.md` directly for both — this file doesn't restate them.

## MicroPython / device-runtime

- **A one-time "wait for this async state to settle" check needs to run
  adjacent in time to the operation it guards, and needs to yield BEFORE
  its first read, not just after.** `mqttWifiPrecheckStatement()`'s first
  attempt (2026-08-21) polled `network.WLAN.status()` in a bounded loop,
  reasoned through carefully and off-device-verified — and still didn't
  hold on real hardware (2026-08-22 retest, same board reused rather than
  freshly erased). Two independent bugs, not one bigger-number fix: (1) it
  ran as a module-scope statement, well before the real racing call
  (`mqtt_as`'s own `.connect()`, which only fires later inside a
  coroutine) — real elapsed time in between was exactly where the race it
  was meant to prevent could still happen; (2) its first `status()` read
  happened immediately after `.active(True)`, with zero delay — if the
  ESP-IDF WiFi task (a separate FreeRTOS task) hadn't yet processed that
  event into an observable state change, the loop saw "nothing happening"
  and exited having waited 0ms. Fixed by moving the check inline,
  immediately before the guarded call, and yielding (`await
  asyncio.sleep_ms(...)`) BEFORE each check rather than after. Worth
  remembering generically: a "wait for X to become quiescent" guard is
  only as good as (a) how close in time it runs to the thing it's
  protecting, and (b) whether it gives the state it's polling for an
  actual chance to appear before trusting a negative read. `mqtt-shared.ts`
  (`mqttEnsureConnectedSnippet()`'s doc comment), `decisions.md`'s
  2026-08-22 entries.
- **A guard wrapped around your own call site only protects calls you
  make — it does nothing for a library's own internal retry/reconnect
  logic that calls the same underlying function independently.** The fix
  above (relocating the WiFi precheck to wrap our own `.connect()` call)
  still didn't fully close the bug: `mqtt_as`'s own background
  `_keep_connected()` task calls `self.wifi_connect()` directly on every
  reconnect after the first, a code path our wrapper never touched, and
  it swallows the resulting OSError silently and retries forever
  (`except OSError: continue`) if it hits the same race — a flow that
  worked a few times then went completely silent, no error anywhere. Real
  fix needed patching the shared method itself (an instance-level
  monkey-patch of `client.wifi_connect`, not the vendored file), so every
  caller — ours and the library's own internal one — goes through the
  same guard. Worth checking for generically: when wrapping a call to
  guard against a race, check whether the thing you're calling has its
  OWN internal callers of the same function before assuming your wrapper
  covers every path. `mqtt-shared.ts` (`mqttSetupStatement()`'s doc
  comment), `decisions.md`'s second 2026-08-22 entry.
- **A precheck that only waits for a race to clear doesn't stop a THIRD
  party from redundantly repeating the very call you just waited out.**
  The `wifi_connect` monkey-patch above (guard #2) still didn't hold on
  real hardware — this time confirmed via the actual failing flow's file
  contents (`mqtt-test.flow.json`), not assumed from a log alone (an
  earlier guess that the flow had no MQTT node in it was wrong and cost a
  detour — always check the actual flow/config, don't infer node
  composition from log output shape). Root cause: `mqtt_as`'s
  `wifi_connect()` (ESP32 branch) calls `.connect()` **unconditionally**,
  no `isconnected()` guard — so even a perfectly-timed wait-for-in-flight-
  connect-to-clear precheck will, the instant it clears, immediately
  reissue a REDUNDANT second `.connect()` on an interface something else
  (`wifi_status`'s own module-scope connect, in this case) just finished
  connecting moments earlier. "Wait, don't cancel" (the previous entry's
  fix) assumed there'd only ever be one *other* attempt to wait out, not a
  second, self-inflicted one fired right after. Generalizes: when multiple
  independent code paths can all reach the same underlying resource,
  a precheck on each path individually is not the same guarantee as one
  shared owner all paths defer to — collapse them into one lock-protected
  function instead of prechecking N separate call sites. `wifi-status.ts`
  (`_wifi_ensure_connected()`'s doc comment), `decisions.md`'s third
  2026-08-22 entry.
- **Python raises a real `SyntaxError` ("name used prior to global
  declaration") if the same function body contains two separate `global x`
  statements for the same name, even when each one textually precedes its
  own local use.** Hit while hand-writing a test that pasted the same
  generated `buildMsg` snippet (itself containing `global
  _wifi_status_last`) into a Python script twice, to simulate "poll a few
  times, then change state" without running the real compiled while-loop.
  The fix generalizes beyond this one test: never paste/duplicate a
  generated code snippet that declares `global` into the same enclosing
  function more than once — drive repetition with a real loop (`for`/
  `while`) around ONE copy of the snippet instead, matching how the actual
  compiler only ever emits `buildMsg` once per node regardless of how many
  times it runs. Caught by hand-running the exact shape through pymock
  before it shipped, not by vitest (this sandbox can't run vitest at all —
  see the Cowork section below) — worth doing for any new test that
  duplicates snippet text for convenience. `node-wifi-status.test.ts`'s
  event-compression test.
- **A hand-verified reproduction proves your mental model of the code is
  correct — it doesn't prove the actual file bytes match that model.** The
  `_wifi_ensure_connected()` shared-connect fix above shipped with a real
  bug: its first `if sys.platform == "esp32":` precheck block was
  hand-typed at one indent level too shallow (4 spaces instead of 8),
  which (correct Python, wrong semantics) dragged the entire connect-
  issuing branch AND the final `_wifi_link_ready` update into being nested
  *inside* that ESP32-only gate — so on any non-ESP32 platform, including
  every off-device test, `.connect()` silently never got called at all. On
  real ESP32 hardware the branch happens to be taken anyway, so this
  wouldn't have shown up as a hardware failure — it would have shown up as
  tests silently exercising nothing. Not caught by hand-running a
  standalone repro before shipping (that repro typed the *intended*
  indentation from memory, not the actual generated string literals in the
  file — verifying the idea, not the bytes) — caught only once Mike ran the
  real `vitest` suite and two connect-assertion tests failed with "expected
  X to contain WLAN_CONNECT" and an empty actual value. Generalizes: when
  verification can't run the actual code path (this sandbox can't run
  vitest), a hand-reproduction needs to be copy-derived from the literal
  file content, not retyped from what the author believes it says — and
  even then, it's a supplement to running the real test suite, not a
  replacement for it. `wifi-status.ts`'s `wifiSetupStatement()`.
- **`sys.stdin.read(n)`/`readexactly(n)` can hang a port's event loop
  outright — not just slow, a genuine non-yielding block `asyncio.wait_for`
  can't preempt.** Confirmed on the ESP32-C3 LuatOS CORE board during
  POC-D. Fixed by riding binary payloads over `readline()` (base64-encoded
  text line) instead. Verify per-port before trusting a specific-byte-count
  read anywhere in this protocol again — never assume it's safe just
  because it works in browser-side simulation. `thingstudio-design-doc.md`
  §15.5, `fault-isolation-briefing.md`.
- **`mpy-cross` needs RAM headroom beyond what the compiled code itself
  needs.** On-device compilation of large-enough source (MQTT client
  libraries were a real historical trigger, pre-`mpy-cross`-era) can OOM a
  constrained board even though the identical code runs fine once it's
  bytecode. Directly why v1 ships precompiled `.mpy`, not raw-source
  `exec()`. `thingstudio-design-doc.md` §15.1 resolution.
- **The ESP32-C3's hardware RNG is not a true RNG unless WiFi or
  Bluetooth is enabled** (Espressif's own ESP-IDF docs, verified directly).
  A USB-only v1 with no radio bring-up generating a nonce via
  `os.urandom()` would be pseudo-random. Chip-agnostic lesson, not an
  ESP32-C3 workaround: don't assume any given MicroPython target has a
  trustworthy on-chip RNG. `transport-auth-design.md`.
- **MicroPython's `asyncio` has no first-class UDP primitive on any port**
  (confirmed against upstream issue #13382, open). Unlike
  `open_connection`/`start_server` for TCP, UDP needs a non-blocking
  socket polled on a short interval, try/except around `recvfrom()`
  catching `EAGAIN`. `udp-tcp-nodes-implementation-briefing.md`.
- **A board with no auto-reset circuit needs a software fallback.** Some
  boards don't reset when a browser opens the WebSerial port the way
  `esptool`-flashable boards typically do — a best-effort
  `port.setSignals()` RTS trick helps but isn't universal; document the
  physical-reset fallback rather than assuming the software path always
  works. `thingstudio-design-doc.md` §15.5 (POC-D).
- **Client/device timeout mismatches make a working deploy look like a
  hard failure.** If the browser gives up waiting before the device's own
  internal timeout would have fired, a possibly-fine deploy reads as
  broken. Keep the client's wait comfortably longer than the device's
  worst case, never shorter. Same section.
- **ESP-IDF's own NVS-cached station auto-reconnect can fire from
  `network.WLAN(network.STA_IF).active(True)` alone, and races an
  immediately-following explicit `.connect()` call.** If a *previous*
  deploy left credentials in NVS, `active(True)` alone can kick off
  ESP-IDF's own reconnect using those stale credentials; code that then
  unconditionally calls `.connect(ssid, password)` right after (with no
  `isconnected()`/`status()` check first) can collide with that in-flight
  attempt, which ESP-IDF refuses with `E (...) wifi:sta is connecting,
  cannot set config` — its own driver-level error, not a MicroPython
  exception, so it surfaces as a raw serial log line rather than a Python
  traceback. Confirmed on real hardware via `mqtttest.flow.json`; root
  cause traced into the vendored `mqtt_as`'s `wifi_connect()` (ESP32
  branch), which had exactly this gap — `docs/working-notes/decisions.md`,
  2026-08-21 entry. Worth checking for the same shape (`active(True)`
  immediately followed by an unconditional `.connect()`, no connecting-state
  guard) in any other code that brings up `STA_IF` directly, not just this
  one call site.
- **Standing directive from Mike (2026-08-22), after the third WiFi-race
  fix went live: never use a blocking call inside a coroutine — always its
  async variant (`asyncio.sleep`/`sleep_ms`, never `time.sleep`/
  `time.sleep_ms`), even for a wait that looks "quick."** A blocking sleep
  inside a coroutine stalls the whole event loop, not just that task — on
  a single-threaded MicroPython runtime that means every other coroutine
  (network polling, other sources, the deploy/debug link) is frozen for
  the duration, which is exactly the kind of silent, hard-to-attribute
  stall this project's fault-handling-first priority exists to avoid.
  `_wifi_ensure_connected()` (`wifi-status.ts`) already only ever awaits
  `asyncio.sleep_ms(...)` in its wait loops, so it complies as shipped —
  treat this as a standing check for every future coroutine, not a one-off
  fix.
- **Standing directive from Mike (2026-08-22), same note: watch for shared
  state across code paths — the WiFi connection status
  (`_wifi_sta`/`_wifi_link_ready`) is the concrete example, but the
  category is general.** The whole third-recurrence WiFi race (two entries
  above) was exactly this failure mode — multiple independent call sites
  mutating/reading the same underlying resource with no single owner
  coordinating them. The double-checked-locking shape now used for
  `_wifi_ensure_connected()` (fast-path read outside the lock, real
  check-and-act inside it) is the template to reach for again, but it has
  to be deliberately applied to each new piece of shared state — it's not
  a one-time structural fix, it's a review question to keep asking as new
  node types and new module-level state get added.

## Hardware bring-up / HIL rig

- **A floating witness GPIO input pin picks up what looks exactly like a
  real signal — steady ~27–29µs-spaced edge bursts, present even with
  nothing driving the DUT side.** Diagnosed from the burst's suspicious
  regularity (inconsistent with a real transition or simple wire
  crosstalk) — fixed by giving every watching pin an internal
  `PULL_DOWN`. Design around this from the start on any new witness-rig
  wiring, don't rediscover it. `fault-isolation-briefing.md`,
  `tier1-sensors-network-briefing.md`.
- **Long breadboard patch wires cause real electrical ringing on fast
  GPIO edges.** Harmless for "did *a* transition happen" checks; would
  corrupt anything relying on precise edge *counts* (PWM duty-cycle,
  timer measurements) until the wiring is cleaned up (shorter leads, a
  series resistor). `tier1-sensors-network-briefing.md`.
- **A witness's first `.irq()` arm in a session can `MemoryError` under
  heap fragmentation.** Pre-existing MicroPython behavior, not a bug in
  this project's firmware — worked around with a `gc.collect()` plus a
  throwaway warm-up call before the real checks. `mvp-validation-plan.md`,
  2026-08-14 GPIO/timer hardware Results entry.
- **Watching a board's first boot through Thonny is unreliable.**
  Thonny's Shell sends a keyboard interrupt on connect/reconnect, which
  `listener.py`'s deliberate few-second boot-delay window (§5's
  physical-access fallback) interprets as a real request to drop to
  REPL — looks exactly like "never reaches HELLO" even when boot is
  correct. Use a passive `mpremote connect <port>` (no interrupt) or any
  serial monitor that doesn't auto-send Ctrl-C on open. Not
  board-specific — will bite on any board watched this way.
  `rp2040-bringup-findings.md`.
- **Declared node `width`/`height` are a real rendering clipping budget
  in Rete's classic preset, not layout hints the way Litegraph's `size`
  is.** A node sized against the default renderer can clip its own socket
  once custom per-type styling changes padding/font — verify, don't
  assume old sizes still fit. `editor-look-and-feel-briefing.md`,
  `rete-migration-implementation-briefing.md`.

## Editor / build tooling

- **`vite build` does not type-check** — esbuild strips types rather than
  checking them. A green build proves nothing about type correctness;
  `tsc --noEmit` is the only real check. Cost real bugs in the poc-rete
  spike before this was learned. `rete-migration-implementation-briefing.md`.
- **Litegraph's file-picker `accept` filter doesn't reliably match
  compound/multi-dot extensions** (`.flow.json`) in Chromium's File
  System Access API — even a file just saved with that exact name showed
  up greyed out on open. Fixed by filtering on the single trailing
  extension (`.json`) instead; the saved filename can still be
  `flow.flow.json` as a convention. `editor-hands-on-briefing.md`.
- **`execFileSync` deadlocks Node's own event loop when the child process
  needs to talk back to an in-process test server.** `execFileSync`
  blocks the entire single-threaded event loop until the child exits, but
  an `http.Server` needing to *answer* the child's request lives on that
  same event loop — it can never respond while blocked, and the child
  hangs until its own timeout. Reproduced outside vitest (a plain Node
  script) before concluding it wasn't a codegen bug. Fixed by switching to
  async `execFile`. `mvp-validation-plan.md`, `http_request` Results
  entry.
- **Node's `http` module defaults to chunked transfer-encoding whenever a
  handler doesn't set `Content-Length` itself** — and this project's
  hand-rolled `http_request` client deliberately doesn't support chunked
  (documented v1 gap). Any local test server stood up against this node
  needs an explicit `Content-Length` header to be usable.
  `mvp-validation-plan.md`, same entry.

## Backend / security research

- **Same-origin policy does not cover WebSocket connections initiated
  from page JS the way it covers `fetch`/XHR.** A DNS-rebinding attack can
  get a browser to resolve an attacker-controlled hostname to `127.0.0.1`
  after an initial same-origin check passes, then open a WebSocket to a
  local server with no browser-level barrier stopping it. The `Host`
  header on that request still reads the attacker's hostname (can't be
  forged) — a server-side `Host` allowlist is the actual defense, not
  `Origin` checking. Verified against a real 2026 advisory
  (`GHSA-89vp-x53w-74fx`) against a structurally similar local WebSocket
  server. `backend-editor-auth-and-protocol.md`.
- **The browser's native `WebSocket` constructor cannot set custom
  request headers.** No `Authorization: Bearer …` is possible on a WS
  handshake from page JS — this is a real API limitation, not a design
  preference, and it's why session auth for the backend has to be
  cookie-based rather than token-based. Same note.
- **Check a dependency's actual release activity before trusting it,
  every time — not just for npm.** `pyserial-asyncio` turned out fully
  dead (no release since Sept 2021); `aiohttp-session` has had no release
  in ~12 months. Applied the same diligence `CLAUDE.md` already requires
  for npm packages to Python dependencies too, and it changed both
  decisions. `backend-platform-decision.md`, `backend-editor-auth-and-protocol.md`.
- **A citation can be wrong even when it "sounds right" — verify by
  direct inspection, not by trusting the name.** `connection-mastery-plugin`
  was cited as the drag-to-splice mechanism for a full session before
  being checked directly and found dead (Rete 1.x only, ~6 years stale)
  and, separately, not even the same feature. Corrected to Rete's own
  "Insert node" example. `rete-spike-briefing.md`, `architecture-review-briefing.md`.
- **Browser transport support isn't what it used to be assumed to be —
  check current support before relying on a browser API.** Safari has
  never supported WebSerial with no stated plans to; Firefox only gained
  it in v151 (May 2026); Web Bluetooth is *permanently* Chromium-only —
  a stated policy position from both Firefox and Safari, not a lagging
  gap that will close. `architecture-review-briefing.md`.

## Cowork remote-device testing environment

- **`device_bash`'s desktop workspace is a Linux VM, not literally Mike's
  macOS host -- a `node_modules` with platform-specific native bindings
  (installed on the real Mac) doesn't work there.** Confirmed 2026-08-20:
  `npx vitest run` via `device_bash` failed with "Cannot find native
  binding" (rolldown's `@rolldown/binding-darwin-x64` vs. the VM's own
  `linux x86_64`). `./node_modules/.bin/tsc --noEmit` worked fine there
  (pure JS, no native binding) -- only tools with a platform-specific
  compiled dependency hit this. Workaround: tar the project (excluding
  `node_modules`) into the connected folder, stage it, extract into the
  cloud session's own workspace (which has network), `npm ci` fresh there
  (pulls the right platform's bindings automatically), run the real test
  suite there instead. Worth trying `device_bash` first for any future
  session's test run (cheaper, no extra hop) but don't be surprised by
  this failure mode or waste time debugging it as if it were a real bug --
  it's an environment mismatch, not a code problem.
- **The cloud session's own staged read-only mirror of the repo (under
  the uploads directory) can be a partial/curated snapshot, not a full
  checkout -- don't trust it for `npm test`/`vitest run` without first
  confirming the full `src`/`test` tree is actually present.** Discovered
  2026-08-20: the mirror available during the custom-node session was
  missing `src/compiler/errors.ts` and several other node-library/test
  files, so a same-session verification attempt (tried because the device
  bridge to Mike's machine was down) failed on unrelated
  import-resolution errors, not real regressions in the new code. When
  `device_bash` can't reach Mike's machine either, there is currently no
  way to get a fully trustworthy test/typecheck signal from inside the
  cloud session alone for this project -- say so plainly rather than
  reporting a red result as if it were a real one, and defer the actual
  verification to Mike's machine.

## Custom node authoring

- **A custom node's top-level `.node.py` code runs inside a generated
  per-instance wrapper function, not at true module scope — `nonlocal`,
  not `global`, is the correct idiom for persistent state.** First-party
  node codegen (e.g. `timer.ts`) inlines its code directly at true
  module/coroutine scope, where `global` is correct; a custom-node author
  following that same familiar pattern would hit a `NameError` at deploy
  time instead, since no module-level name exists inside the wrapper.
  Self-caught while writing `custom-node.test.ts`'s closure-isolation
  test, not by a real deploy failure — documented prominently in
  `custom-node.ts`'s header comment and in `docs/user-guide/custom-nodes.md` (its own
  dedicated section) given the project's fault-handling-first priority.
  `custom-node-authoring-scoping.md`.

## Reusable patterns worth remembering

- **A bounded, drop-oldest ring buffer for queued outbound messages** —
  the vendored `mqtt_as`'s own `MsgQueue` already implements exactly this
  eviction shape for *inbound* subscribed messages; a validated precedent
  worth reusing for any future "buffer while disconnected, flush on
  reconnect" need, even though the data path differs (inbound vs.
  outbound). `mvp-feature-priorities.md`.
