var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t,t.exports),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=(n,r,o)=>(o=n==null?{}:e(i(n)),s(r||!n||!n.__esModule||!a.call(n,`default`)?t(o,`default`,{value:n,enumerable:!0}):o,n));(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function l(e){let t=Object.create(null);for(let n of e.split(`,`))t[n]=1;return e=>e in t}var u={},d=[],f=()=>{},p=()=>!1,m=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),h=e=>e.startsWith(`onUpdate:`),g=Object.assign,_=(e,t)=>{let n=e.indexOf(t);n>-1&&e.splice(n,1)},v=Object.prototype.hasOwnProperty,y=(e,t)=>v.call(e,t),b=Array.isArray,x=e=>ie(e)===`[object Map]`,S=e=>ie(e)===`[object Set]`,ee=e=>ie(e)===`[object Date]`,C=e=>typeof e==`function`,w=e=>typeof e==`string`,te=e=>typeof e==`symbol`,T=e=>typeof e==`object`&&!!e,ne=e=>(T(e)||C(e))&&C(e.then)&&C(e.catch),re=Object.prototype.toString,ie=e=>re.call(e),ae=e=>ie(e).slice(8,-1),oe=e=>ie(e)===`[object Object]`,se=e=>w(e)&&e!==`NaN`&&e[0]!==`-`&&``+parseInt(e,10)===e,ce=l(`,key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted`),le=e=>{let t=Object.create(null);return(n=>t[n]||(t[n]=e(n)))},ue=/-\w/g,de=le(e=>e.replace(ue,e=>e.slice(1).toUpperCase())),fe=/\B([A-Z])/g,pe=le(e=>e.replace(fe,`-$1`).toLowerCase()),me=le(e=>e.charAt(0).toUpperCase()+e.slice(1)),he=le(e=>e?`on${me(e)}`:``),ge=(e,t)=>!Object.is(e,t),_e=(e,...t)=>{for(let n=0;n<e.length;n++)e[n](...t)},ve=(e,t,n,r=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:r,value:n})},ye=e=>{let t=parseFloat(e);return isNaN(t)?e:t},be,xe=()=>be||=typeof globalThis<`u`?globalThis:typeof self<`u`?self:typeof window<`u`?window:typeof global<`u`?global:{};function Se(e){if(b(e)){let t={};for(let n=0;n<e.length;n++){let r=e[n],i=w(r)?Ee(r):Se(r);if(i)for(let e in i)t[e]=i[e]}return t}if(w(e)||T(e))return e}var Ce=/;(?![^(]*\))/g,we=/:([^]+)/,Te=/"(?:[^"\\]|\\[^])*"|'(?:[^'\\]|\\[^])*'|\\[^]|\/\*[^]*?\*\//g;function Ee(e){let t={};return e.replace(Te,e=>e.startsWith(`/*`)?``:e).split(Ce).forEach(e=>{if(e){let n=e.split(we);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function De(e){let t=``;if(w(e))t=e;else if(b(e))for(let n=0;n<e.length;n++){let r=De(e[n]);r&&(t+=r+` `)}else if(T(e))for(let n in e)e[n]&&(t+=n+` `);return t.trim()}var Oe=l(`itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,playsinline,readonly`);function ke(e){return!!e||e===``}function Ae(e,t,n){if(e.length!==t.length)return!1;let r=!0;for(let i=0;r&&i<e.length;i++)r=Pe(e[i],t[i],n);return r}function je(e,t,n){if(e.size!==t.size)return!1;let r=Array.from(t),i=new Uint8Array(r.length);for(let t of e){let e=-1;for(let a=0;a<r.length;a++)if(!i[a]&&Pe(t,r[a],n)){e=a;break}if(e<0)return!1;i[e]=1}return!0}function Me(e,t,n){let r=x(e),i=x(t);if(r||i||(r=S(e),i=S(t),r||i))return r&&i?je(e,t,n):!1;if(Object.keys(e).length!==Object.keys(t).length)return!1;for(let r in e){let i=e.hasOwnProperty(r),a=t.hasOwnProperty(r);if(i&&!a||!i&&a||!Pe(e[r],t[r],n))return!1}return String(e)===String(t)}function Ne(e,t,n,r){n||=[new Map,new Map];let[i,a]=n;if(i.has(e)||a.has(t))return i.get(e)===t&&a.get(t)===e;i.set(e,t),a.set(t,e);let o=r(e,t,n);return i.delete(e),a.delete(t),o}function Pe(e,t,n){if(e===t)return!0;let r=ee(e),i=ee(t);return r||i?r&&i?e.getTime()===t.getTime():!1:(r=te(e),i=te(t),r||i?e===t:(r=b(e),i=b(t),r||i?r&&i?Ne(e,t,n,Ae):!1:(r=T(e),i=T(t),r||i?!r||!i?!1:Ne(e,t,n,Me):String(e)===String(t))))}function Fe(e,t){return e.findIndex(e=>Pe(e,t))}var Ie=e=>!!(e&&e.__v_isRef===!0),E=e=>w(e)?e:e==null?``:b(e)||T(e)&&(e.toString===re||!C(e.toString))?Ie(e)?E(e.value):JSON.stringify(e,Le,2):String(e),Le=(e,t)=>Ie(t)?Le(e,t.value):x(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((e,[t,n],r)=>(e[Re(t,r)+` =>`]=n,e),{})}:S(t)?{[`Set(${t.size})`]:[...t.values()].map(e=>Re(e))}:te(t)?Re(t):T(t)&&!b(t)&&!oe(t)?String(t):t,Re=(e,t=``)=>te(e)?`Symbol(${e.description??t})`:e,ze,Be=class{constructor(e=!1){this.detached=e,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!e&&ze&&(ze.active?(this.parent=ze,this.index=(ze.scopes||(ze.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let e,t;if(this.scopes){let n=this.scopes.slice();for(e=0,t=n.length;e<t;e++)n[e].pause()}for(e=0,t=this.effects.length;e<t;e++)this.effects[e].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let e,t;if(this.scopes){let n=this.scopes.slice();for(e=0,t=n.length;e<t;e++)n[e].resume()}let n=this.effects.slice();for(e=0,t=n.length;e<t;e++)n[e].resume()}}run(e){if(this._active){let t=ze;try{return ze=this,e()}finally{ze=t}}}on(){++this._on===1&&(this.prevScope=ze,ze=this)}off(){if(this._on>0&&--this._on===0){if(ze===this)ze=this.prevScope;else{let e=ze;for(;e;){if(e.prevScope===this){e.prevScope=this.prevScope;break}e=e.prevScope}}this.prevScope=void 0}}stop(e){if(this._active){this._active=!1;let t,n;for(t=0,n=this.effects.length;t<n;t++)this.effects[t].stop();for(this.effects.length=0,t=0,n=this.cleanups.length;t<n;t++)this.cleanups[t]();if(this.cleanups.length=0,this.scopes){let e=this.scopes.slice();for(t=0,n=e.length;t<n;t++)e[t].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!e){let e=this.parent.scopes.pop();e&&e!==this&&(this.parent.scopes[this.index]=e,e.index=this.index)}this.parent=void 0}}};function Ve(){return ze}var He,Ue=new WeakSet,We=class{constructor(e){this.fn=e,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ze&&(ze.active?ze.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Ue.has(this)&&(Ue.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Je(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,st(this),Ze(this);let e=He,t=rt;He=this,rt=!0;try{return this.fn()}finally{Qe(this),He=e,rt=t,this.flags&=-3}}stop(){if(this.flags&1){for(let e=this.deps;e;e=e.nextDep)tt(e);this.deps=this.depsTail=void 0,st(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Ue.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){$e(this)&&this.run()}get dirty(){return $e(this)}},Ge=0,Ke,qe;function Je(e,t=!1){e.flags|=8,t?(e.next=qe,qe=e):(e.next=Ke,Ke=e)}function Ye(){Ge++}function Xe(){if(--Ge>0)return;if(qe){let e=qe;for(qe=void 0;e;){let t=e.next;e.next=void 0,e.flags&=-9,e=t}}let e;for(;Ke;){let t=Ke;for(Ke=void 0;t;){let n=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(t){e||=t}t=n}}if(e)throw e}function Ze(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Qe(e){let t,n=e.depsTail,r=n;for(;r;){let e=r.prevDep;r.version===-1?(r===n&&(n=e),tt(r),nt(r)):t=r,r.dep.activeLink=r.prevActiveLink,r.prevActiveLink=void 0,r=e}e.deps=t,e.depsTail=n}function $e(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(et(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function et(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===ct)||(e.globalVersion=ct,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!$e(e))))return;e.flags|=2;let t=e.dep,n=He,r=rt;He=e,rt=!0;try{Ze(e);let n=e.fn(e._value);(t.version===0||ge(n,e._value))&&(e.flags|=128,e._value=n,t.version++)}catch(e){throw t.version++,e}finally{He=n,rt=r,Qe(e),e.flags&=-3}}function tt(e,t=!1){let{dep:n,prevSub:r,nextSub:i}=e;if(r&&(r.nextSub=i,e.prevSub=void 0),i&&(i.prevSub=r,e.nextSub=void 0),n.subs===e&&(n.subs=r,!r&&n.computed)){n.computed.flags&=-5;for(let e=n.computed.deps;e;e=e.nextDep)tt(e,!0)}!t&&!--n.sc&&n.map&&n.map.delete(n.key)}function nt(e){let{prevDep:t,nextDep:n}=e;t&&(t.nextDep=n,e.prevDep=void 0),n&&(n.prevDep=t,e.nextDep=void 0)}var rt=!0,it=[];function at(){it.push(rt),rt=!1}function ot(){let e=it.pop();rt=e===void 0||e}function st(e){let{cleanup:t}=e;if(e.cleanup=void 0,t){let e=He;He=void 0;try{t()}finally{He=e}}}var ct=0,lt=class{constructor(e,t){this.sub=e,this.dep=t,this.version=t.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}},ut=class{constructor(e){this.computed=e,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(e){if(!He||!rt||He===this.computed)return;let t=this.activeLink;if(t===void 0||t.sub!==He)t=this.activeLink=new lt(He,this),He.deps?(t.prevDep=He.depsTail,He.depsTail.nextDep=t,He.depsTail=t):He.deps=He.depsTail=t,dt(t);else if(t.version===-1&&(t.version=this.version,t.nextDep)){let e=t.nextDep;e.prevDep=t.prevDep,t.prevDep&&(t.prevDep.nextDep=e),t.prevDep=He.depsTail,t.nextDep=void 0,He.depsTail.nextDep=t,He.depsTail=t,He.deps===t&&(He.deps=e)}return t}trigger(e){this.version++,ct++,this.notify(e)}notify(e){Ye();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{Xe()}}};function dt(e){if(e.dep.sc++,e.sub.flags&4){let t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let e=t.deps;e;e=e.nextDep)dt(e)}let n=e.dep.subs;n!==e&&(e.prevSub=n,n&&(n.nextSub=e)),e.dep.subs=e}}var ft=new WeakMap,pt=Symbol(``),mt=Symbol(``),ht=Symbol(``);function gt(e,t,n){if(rt&&He){let t=ft.get(e);t||ft.set(e,t=new Map);let r=t.get(n);r||(t.set(n,r=new ut),r.map=t,r.key=n),r.track()}}function _t(e,t,n,r,i,a){let o=ft.get(e);if(!o){ct++;return}let s=e=>{e&&e.trigger()};if(Ye(),t===`clear`)o.forEach(s);else{let i=b(e),a=i&&se(n);if(i&&n===`length`){let e=Number(r);o.forEach((t,n)=>{(n===`length`||n===ht||!te(n)&&n>=e)&&s(t)})}else switch((n!==void 0||o.has(void 0))&&s(o.get(n)),a&&s(o.get(ht)),t){case`add`:i?a&&s(o.get(`length`)):(s(o.get(pt)),x(e)&&s(o.get(mt)));break;case`delete`:i||(s(o.get(pt)),x(e)&&s(o.get(mt)));break;case`set`:x(e)&&s(o.get(pt))}}Xe()}function vt(e){let t=D(e);return t===e||(gt(t,`iterate`,ht),an(e))?t:rn(e)?nn(e)?t.map(e=>ln(cn(e))):t.map(ln):t.map(cn)}function yt(e){return gt(e=D(e),`iterate`,ht),e}function bt(e,t){return rn(e)?ln(nn(e)?cn(t):t):cn(t)}var xt={__proto__:null,[Symbol.iterator](){return St(this,Symbol.iterator,e=>bt(this,e))},concat(...e){return vt(this).concat(...e.map(e=>b(e)?vt(e):e))},entries(){return St(this,`entries`,e=>(e[1]=bt(this,e[1]),e))},every(e,t){return Tt(this,`every`,e,t,void 0,arguments)},filter(e,t){return Tt(this,`filter`,e,t,e=>e.map(e=>bt(this,e)),arguments)},find(e,t){return Tt(this,`find`,e,t,e=>bt(this,e),arguments)},findIndex(e,t){return Tt(this,`findIndex`,e,t,void 0,arguments)},findLast(e,t){return Tt(this,`findLast`,e,t,e=>bt(this,e),arguments)},findLastIndex(e,t){return Tt(this,`findLastIndex`,e,t,void 0,arguments)},forEach(e,t){return Tt(this,`forEach`,e,t,void 0,arguments)},includes(...e){return Dt(this,`includes`,e)},indexOf(...e){return Dt(this,`indexOf`,e)},join(e){return vt(this).join(e)},lastIndexOf(...e){return Dt(this,`lastIndexOf`,e)},map(e,t){return Tt(this,`map`,e,t,void 0,arguments)},pop(){return Ot(this,`pop`)},push(...e){return Ot(this,`push`,e)},reduce(e,...t){return Et(this,`reduce`,e,t)},reduceRight(e,...t){return Et(this,`reduceRight`,e,t)},shift(){return Ot(this,`shift`)},some(e,t){return Tt(this,`some`,e,t,void 0,arguments)},splice(...e){return Ot(this,`splice`,e)},toReversed(){return vt(this).toReversed()},toSorted(e){return vt(this).toSorted(e)},toSpliced(...e){return vt(this).toSpliced(...e)},unshift(...e){return Ot(this,`unshift`,e)},values(){return St(this,`values`,e=>bt(this,e))}};function St(e,t,n){let r=yt(e),i=r[t],a=i.call(r);if(r!==e&&!an(e)){if(a[Symbol.toStringTag]===`Array Iterator`){let e=Object.create(Object.getPrototypeOf(a));return e.next=()=>Ct(a.next(),n),i!==wt[t]&&Object.defineProperties(e,{return:{get(){let e=a.return;return typeof e==`function`?e.bind(a):e}},throw:{get(){let e=a.throw;return typeof e==`function`?e.bind(a):e}}}),e}a._next=a.next,a.next=()=>Ct(a._next(),n)}return a}function Ct(e,t){return e.done||(e.value=t(e.value)),e}var wt=Array.prototype;function Tt(e,t,n,r,i,a){let o=yt(e),s=o!==e&&!an(e),c=o[t];if(c!==wt[t]){let t=c.apply(e,a);return s?cn(t):t}let l=n;o!==e&&(s?l=function(t,r){return n.call(this,bt(e,t),r,e)}:n.length>2&&(l=function(t,r){return n.call(this,t,r,e)}));let u=c.call(o,l,r);return s&&i?i(u):u}function Et(e,t,n,r){let i=yt(e),a=i!==e&&!an(e),o=n,s=!1;i!==e&&(a?(s=r.length===0,o=function(t,r,i){return s&&(s=!1,t=bt(e,t)),n.call(this,t,bt(e,r),i,e)}):n.length>3&&(o=function(t,r,i){return n.call(this,t,r,i,e)}));let c=i[t](o,...r);return s?bt(e,c):c}function Dt(e,t,n){let r=D(e);gt(r,`iterate`,ht);let i=r[t](...n);return(i===-1||i===!1)&&on(n[0])?(n[0]=D(n[0]),r[t](...n)):i}function Ot(e,t,n=[]){at(),Ye();let r=D(e)[t].apply(e,n);return Xe(),ot(),r}var kt=l(`__proto__,__v_isRef,__isVue`),At=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!==`arguments`&&e!==`caller`).map(e=>Symbol[e]).filter(te));function jt(e){te(e)||(e=String(e));let t=D(this);return gt(t,`has`,e),t.hasOwnProperty(e)}var Mt=class{constructor(e=!1,t=!1){this._isReadonly=e,this._isShallow=t}get(e,t,n){if(t===`__v_skip`)return e.__v_skip;let r=this._isReadonly,i=this._isShallow;if(t===`__v_isReactive`)return!r;if(t===`__v_isReadonly`)return r;if(t===`__v_isShallow`)return i;if(t===`__v_raw`)return n===(r?i?Xt:Yt:i?Jt:qt).get(e)||Object.getPrototypeOf(e)===Object.getPrototypeOf(n)?e:void 0;let a=b(e);if(!r){let e;if(a&&(e=xt[t]))return e;if(t===`hasOwnProperty`)return jt}let o=Reflect.get(e,t,un(e)?e:n);if((te(t)?At.has(t):kt(t))||(r||gt(e,`get`,t),i))return o;if(un(o)){let e=a&&se(t)?o:o.value;return r&&T(e)?en(e):e}return T(o)?r?en(o):Qt(o):o}},Nt=class extends Mt{constructor(e=!1){super(!1,e)}set(e,t,n,r){let i=e[t],a=b(e)&&se(t);if(!this._isShallow){let e=rn(i);if(!an(n)&&!rn(n)&&(i=D(i),n=D(n)),!a&&un(i)&&!un(n))return e||(i.value=n),!0}let o=a?Number(t)<e.length:y(e,t),s=Reflect.set(e,t,n,un(e)?e:r);return e===D(r)&&s&&(o?ge(n,i)&&_t(e,`set`,t,n,i):_t(e,`add`,t,n)),s}deleteProperty(e,t){let n=y(e,t),r=e[t],i=Reflect.deleteProperty(e,t);return i&&n&&_t(e,`delete`,t,void 0,r),i}has(e,t){let n=Reflect.has(e,t);return te(t)&&At.has(t)||gt(e,`has`,t),n}ownKeys(e){return gt(e,`iterate`,b(e)?`length`:pt),Reflect.ownKeys(e)}},Pt=class extends Mt{constructor(e=!1){super(!0,e)}set(e,t){return!0}deleteProperty(e,t){return!0}},Ft=new Nt,It=new Pt,Lt=new Nt(!0),Rt=e=>e,zt=e=>Reflect.getPrototypeOf(e);function Bt(e,t,n){return function(...r){let i=this.__v_raw,a=D(i),o=x(a),s=e===`entries`||e===Symbol.iterator&&o,c=e===`keys`&&o,l=i[e](...r),u=n?Rt:t?ln:cn;return!t&&gt(a,`iterate`,c?mt:pt),g(Object.create(l),{next(){let{value:e,done:t}=l.next();return t?{value:e,done:t}:{value:s?[u(e[0]),u(e[1])]:u(e),done:t}}})}}function Vt(e){return function(...t){return e===`delete`?!1:e===`clear`?void 0:this}}function Ht(e,t){let n={get(n){let r=this.__v_raw,i=D(r),a=D(n);e||(ge(n,a)&&gt(i,`get`,n),gt(i,`get`,a));let{has:o}=zt(i),s=t?Rt:e?ln:cn;if(o.call(i,n))return s(r.get(n));if(o.call(i,a))return s(r.get(a));r!==i&&r.get(n)},get size(){let t=this.__v_raw;return!e&&gt(D(t),`iterate`,pt),t.size},has(t){let n=this.__v_raw,r=D(n),i=D(t);return e||(ge(t,i)&&gt(r,`has`,t),gt(r,`has`,i)),t===i?n.has(t):n.has(t)||n.has(i)},forEach(n,r){let i=this,a=i.__v_raw,o=D(a),s=t?Rt:e?ln:cn;return!e&&gt(o,`iterate`,pt),a.forEach((e,t)=>n.call(r,s(e),s(t),i))}};return g(n,e?{add:Vt(`add`),set:Vt(`set`),delete:Vt(`delete`),clear:Vt(`clear`)}:{add(e){let n=D(this),r=zt(n),i=D(e),a=!t&&!an(e)&&!rn(e)?i:e;return r.has.call(n,a)||ge(e,a)&&r.has.call(n,e)||ge(i,a)&&r.has.call(n,i)||(n.add(a),_t(n,`add`,a,a)),this},set(e,n){t||an(n)||rn(n)||(n=D(n));let r=D(this),{has:i,get:a}=zt(r),o=i.call(r,e);o||=(e=D(e),i.call(r,e));let s=a.call(r,e);return r.set(e,n),o?ge(n,s)&&_t(r,`set`,e,n,s):_t(r,`add`,e,n),this},delete(e){let t=D(this),{has:n,get:r}=zt(t),i=n.call(t,e);i||=(e=D(e),n.call(t,e));let a=r?r.call(t,e):void 0,o=t.delete(e);return i&&_t(t,`delete`,e,void 0,a),o},clear(){let e=D(this),t=e.size!==0,n=e.clear();return t&&_t(e,`clear`,void 0,void 0,void 0),n}}),[`keys`,`values`,`entries`,Symbol.iterator].forEach(r=>{n[r]=Bt(r,e,t)}),n}function Ut(e,t){let n=Ht(e,t);return(r,i,a)=>i===`__v_isReactive`?!e:i===`__v_isReadonly`?e:i===`__v_isShallow`?t:i===`__v_raw`?r:Reflect.get(y(n,i)&&i in r?n:r,i,a)}var Wt={get:Ut(!1,!1)},Gt={get:Ut(!1,!0)},Kt={get:Ut(!0,!1)},qt=new WeakMap,Jt=new WeakMap,Yt=new WeakMap,Xt=new WeakMap;function Zt(e){switch(e){case`Object`:case`Array`:return 1;case`Map`:case`Set`:case`WeakMap`:case`WeakSet`:return 2;default:return 0}}function Qt(e){return rn(e)?e:tn(e,!1,Ft,Wt,qt)}function $t(e){return tn(e,!1,Lt,Gt,Jt)}function en(e){return tn(e,!0,It,Kt,Yt)}function tn(e,t,n,r,i){if(!T(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;let a=i.get(e);if(a)return a;let o=Zt(ae(e));if(o===0)return e;let s=new Proxy(e,o===2?r:n);return i.set(e,s),s}function nn(e){return rn(e)?nn(e.__v_raw):!!(e&&e.__v_isReactive)}function rn(e){return!!(e&&e.__v_isReadonly)}function an(e){return!!(e&&e.__v_isShallow)}function on(e){return e?!!e.__v_raw:!1}function D(e){let t=e&&e.__v_raw;return t?D(t):e}function sn(e){return!y(e,`__v_skip`)&&Object.isExtensible(e)&&ve(e,`__v_skip`,!0),e}var cn=e=>T(e)?Qt(e):e,ln=e=>T(e)?en(e):e;function un(e){return e?e.__v_isRef===!0:!1}function O(e){return fn(e,!1)}function dn(e){return fn(e,!0)}function fn(e,t){return un(e)?e:new pn(e,t)}var pn=class{constructor(e,t){this.dep=new ut,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=t?e:D(e),this._value=t?e:cn(e),this.__v_isShallow=t}get value(){return this.dep.track(),this._value}set value(e){let t=this._rawValue,n=this.__v_isShallow||an(e)||rn(e);e=n?e:D(e),ge(e,t)&&(this._rawValue=e,this._value=n?e:cn(e),this.dep.trigger())}};function mn(e){return un(e)?e.value:e}var hn={get:(e,t,n)=>t===`__v_raw`?e:mn(Reflect.get(e,t,n)),set:(e,t,n,r)=>{let i=e[t];return un(i)&&!un(n)?(i.value=n,!0):Reflect.set(e,t,n,r)}};function gn(e){return nn(e)?e:new Proxy(e,hn)}var _n=class{constructor(e,t,n){this.fn=e,this.setter=t,this._value=void 0,this.dep=new ut(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=ct-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!t,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&He!==this)return Je(this,!0),!0}get value(){let e=this.dep.track();return et(this),e&&(e.version=this.dep.version),this._value}set value(e){this.setter&&this.setter(e)}};function vn(e,t,n=!1){let r,i;return C(e)?r=e:(r=e.get,i=e.set),new _n(r,i,n)}var yn={},bn=new WeakMap,xn=void 0;function Sn(e,t=!1,n=xn){if(n){let t=bn.get(n);t||bn.set(n,t=[]),t.push(e)}}function Cn(e,t,n=u){let{immediate:r,deep:i,once:a,scheduler:o,augmentJob:s,call:c}=n,l=e=>i?e:an(e)||i===!1||i===0?wn(e,1):wn(e),d,p,m,h,g=!1,v=!1;if(un(e)?(p=()=>e.value,g=an(e)):nn(e)?(p=()=>l(e),g=!0):b(e)?(v=!0,g=e.some(e=>nn(e)||an(e)),p=()=>e.map(e=>{if(un(e))return e.value;if(nn(e))return l(e);if(C(e))return c?c(e,2):e()})):p=C(e)?t?c?()=>c(e,2):e:()=>{if(m){at();try{m()}finally{ot()}}let t=xn;xn=d;try{return c?c(e,3,[h]):e(h)}finally{xn=t}}:f,t&&i){let e=p,t=i===!0?1/0:i;p=()=>wn(e(),t)}let y=Ve(),x=()=>{d.stop(),y&&y.active&&_(y.effects,d)};if(a&&t){let e=t;t=(...t)=>{try{return e(...t)}finally{x()}}}let S=v?Array(e.length).fill(yn):yn,ee=e=>{if(d.flags&1&&(d.dirty||e)){if(t){let n=d.run();if(e||i||g||(v?n.some((e,t)=>ge(e,S[t])):ge(n,S))){let e=xn;at();try{m&&m(),xn=d;let e=[n,S===yn?void 0:v&&S[0]===yn?[]:S,h];S=n,c?c(t,3,e):t(...e)}finally{xn=e,ot()}}}else d.run()}};return s&&s(ee),d=new We(p),d.scheduler=o?()=>o(ee,!1):ee,h=e=>Sn(e,!1,d),m=d.onStop=()=>{let e=bn.get(d);if(e){if(c)c(e,4);else for(let t of e)t();bn.delete(d)}},t?r?ee(!0):S=d.run():o?o(ee.bind(null,!0),!0):d.run(),x.pause=d.pause.bind(d),x.resume=d.resume.bind(d),x.stop=x,x}function wn(e,t=1/0,n){if(t<=0||!T(e)||e.__v_skip||(n||=new Map,(n.get(e)||0)>=t))return e;if(n.set(e,t),t--,un(e))wn(e.value,t,n);else if(b(e))for(let r=0;r<e.length;r++)wn(e[r],t,n);else if(S(e)||x(e))e.forEach(e=>{wn(e,t,n)});else if(oe(e)){for(let r in e)wn(e[r],t,n);for(let r of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,r)&&wn(e[r],t,n)}return e}function Tn(e,t,n,r){try{return r?e(...r):e()}catch(e){Dn(e,t,n)}}function En(e,t,n,r){if(C(e)){let i=Tn(e,t,n,r);return i&&ne(i)&&i.catch(e=>{Dn(e,t,n)}),i}if(b(e)){let i=[];for(let a=0;a<e.length;a++)i.push(En(e[a],t,n,r));return i}}function Dn(e,t,n,r=!0){let i=t?t.vnode:null,{errorHandler:a,throwUnhandledErrorInProduction:o}=t&&t.appContext.config||u;if(t){let r=t.parent,i=t.proxy,o=`https://vuejs.org/error-reference/#runtime-${n}`;for(;r;){let t=r.ec;if(t){for(let n=0;n<t.length;n++)if(t[n](e,i,o)===!1)return}r=r.parent}if(a){at(),Tn(a,null,10,[e,i,o]),ot();return}}On(e,n,i,r,o)}function On(e,t,n,r=!0,i=!1){if(i)throw e;console.error(e)}var kn=[],An=-1,jn=[],Mn=null,Nn=0,Pn=Promise.resolve(),Fn=null;function In(e){let t=Fn||Pn;return e?t.then(this?e.bind(this):e):t}function Ln(e){let t=An+1,n=kn.length;for(;t<n;){let r=t+n>>>1,i=kn[r],a=Gn(i);a<e||a===e&&i.flags&2?t=r+1:n=r}return t}function Rn(e){if(!(e.flags&1)){let t=Gn(e),n=kn[kn.length-1];!n||!(e.flags&2)&&t>=Gn(n)?kn.push(e):kn.splice(Ln(t),0,e),e.flags|=1,zn()}}function zn(){Fn||=Pn.then(Kn)}function Bn(e){if(!b(e))Mn&&e.id===-1?Mn.splice(Nn+1,0,e):e.flags&1||(jn.push(e),e.flags|=1);else for(let t=0;t<e.length;t++)jn.push(e[t]);zn()}function Vn(e,t,n,r=An+1){for(;r<kn.length;r++){let n=kn[r];if(n&&n.flags&2){if(e&&n.id!==e.uid||t!==void 0&&!(n.id>=t))continue;kn.splice(r,1),r=e?r-1:An,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Hn(e,t,n=0){if(jn.length){let e=jn,r=0;if(t){e=[];for(let i=0;i<jn.length;i++){let a=jn[i];(a.i===void 0?t.has(a):!a.i||a.i.uid<n)?jn[r++]=a:e.push(a)}}let i=[...new Set(e)].sort((e,t)=>Gn(e)-Gn(t));if(jn.length=r,Mn){for(let e=0;e<i.length;e++)Mn.push(i[e]);return}for(Mn=i,Nn=0;Nn<Mn.length;Nn++){let e=Mn[Nn];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}Mn=null,Nn=0}}var Un=!1;function Wn(e,t){if(Un){e();return}let n=t===void 0?void 0:new Set(jn);e(),Un=!0;try{Vn(void 0,t),Hn(void 0,n,t)}finally{Un=!1}}var Gn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Kn(e){try{for(An=0;An<kn.length;An++){let e=kn[An];e&&!(e.flags&8)&&(e.flags&4&&(e.flags&=-2),Tn(e,e.i,e.i?15:14),e.flags&4||(e.flags&=-2))}}finally{for(;An<kn.length;An++){let e=kn[An];e&&(e.flags&=-2)}An=-1,kn.length=0,Hn(e),Fn=null,(kn.length||jn.length)&&Kn(e)}}var qn=null,Jn=null;function Yn(e){let t=qn;return qn=e,Jn=e&&e.type.__scopeId||null,t}function Xn(e,t=qn,n){if(!t||e._n)return e;let r=(...n)=>{r._d&&fa(-1);let i=Yn(t),a=ca.length,o;try{o=e(...n)}finally{for(let e=ca.length;e>a;e--)ua();Yn(i),r._d&&fa(1)}return o};return r._n=!0,r._c=!0,r._d=!0,r}function k(e,t){if(qn===null)return e;let n=qa(qn),r=e.dirs||=[];for(let e=0;e<t.length;e++){let[i,a,o,s=u]=t[e];i&&(C(i)&&(i={mounted:i,updated:i}),i.deep&&wn(a),r.push({dir:i,instance:n,value:a,oldValue:void 0,arg:o,modifiers:s}))}return e}function Zn(e,t,n,r){let i=e.dirs,a=t&&t.dirs;for(let o=0;o<i.length;o++){let s=i[o];a&&(s.oldValue=a[o].value);let c=s.dir[r];c&&(at(),En(c,n,8,[e.el,s,e,t]),ot())}}function Qn(e,t){if(Na){let n=Na.provides,r=Na.parent&&Na.parent.provides;r===n&&(n=Na.provides=Object.create(r)),n[e]=t}}function $n(e,t,n=!1){let r=Pa();if(r||mi){let i=mi?mi._context.provides:r?r.parent==null||r.ce?r.vnode.appContext&&r.vnode.appContext.provides:r.parent.provides:void 0;if(i&&e in i)return i[e];if(arguments.length>1)return n&&C(t)?t.call(r&&r.proxy):t}}var er=Symbol.for(`v-scx`),tr=()=>$n(er);function nr(e,t,n){return rr(e,t,n)}function rr(e,t,n=u){let{immediate:r,deep:i,flush:a,once:o}=n,s=g({},n),c=t&&r||!t&&a!==`post`,l;if(Ba){if(a===`sync`){let e=tr();l=e.__watcherHandles||=[]}else if(!c){let e=()=>{};return e.stop=f,e.resume=f,e.pause=f,e}}let d=Na;s.call=(e,t,n)=>En(e,d,t,n);let p=!1;a===`post`?s.scheduler=e=>{e.i=d,Ki(e,d&&d.suspense)}:a!==`sync`&&(p=!0,s.scheduler=(e,t)=>{t?e():Rn(e)}),s.augmentJob=e=>{t&&(e.flags|=4),p&&(e.flags|=2,d&&(e.id=d.uid,e.i=d))};let m=Cn(e,t,s);return Ba&&(l?l.push(m):c&&m()),m}function ir(e,t,n){let r=this.proxy,i=w(e)?e.includes(`.`)?ar(r,e):()=>r[e]:e.bind(r,r),a;C(t)?a=t:(a=t.handler,n=t);let o=La(this),s=rr(i,a.bind(r),n);return o(),s}function ar(e,t){let n=t.split(`.`);return()=>{let t=e;for(let e=0;e<n.length&&t;e++)t=t[n[e]];return t}}var or=Symbol(`_vte`),sr=e=>e.__isTeleport,cr=Symbol(`_leaveCb`);function lr(e){let t=e[0];if(e.length>1){for(let n of e)if(n.type!==oa){t=n;break}}return t}function ur(e){if(!br(e))return sr(e.type)&&e.children?lr(e.children):e;if(e.component)return e.component.subTree;let{shapeFlag:t,children:n}=e;if(n){if(t&16)return n[0];if(t&32&&C(n.default))return n.default()}}function dr(e,t){if(e.shapeFlag&6&&e.component){e.transition=t;let n=e.component.subTree;dr(sr(n.type)&&ur(n)||n,t)}else if(e.shapeFlag&128)e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback);else if(e.transition=t,e.type===j&&b(e.children)){let n=xi(e.children,!1);n&&dr(n,t)}}function fr(e){if(e.component)return fr(e.component.subTree);if(e.type===j){let t=b(e.children)&&xi(e.children,!1);return t?fr(t):void 0}if(e.type!==oa)return e}function pr(e,t){return C(e)?g({name:e.name},t,{setup:e}):e}function mr(e){e.ids=[e.ids[0]+e.ids[2]+++`-`,0,0]}function hr(e,t){let n;return!!((n=Object.getOwnPropertyDescriptor(e,t))&&!n.configurable)}var gr=new WeakMap;function _r(e,t,n,r,i=!1){if(b(e)){e.forEach((e,a)=>_r(e,t&&(b(t)?t[a]:t),n,r,i));return}if(yr(r)&&!i){r.shapeFlag&512&&r.type.__asyncResolved&&r.component.subTree.component&&_r(e,t,n,r.component.subTree);return}let a=r.shapeFlag&4?qa(r.component):r.el,o=i?null:a,{i:s,r:c}=e,l=t&&t.r,d=s.refs===u?s.refs={}:s.refs,f=s.setupState,m=D(f),h=f===u?p:e=>!hr(d,e)&&y(m,e),g=(e,t)=>!(t&&hr(d,t));if(l!=null&&l!==c){if(vr(t),w(l))d[l]=null,h(l)&&(f[l]=null);else if(un(l)){let e=t;g(l,e.k)&&(l.value=null),e.k&&(d[e.k]=null)}}if(C(c))Tn(c,s,12,[o,d]);else{let t=w(c),r=un(c);if(t||r){let s=()=>{if(e.f){let n=t?h(c)?f[c]:d[c]:g(c)||!e.k?c.value:d[e.k];if(i)b(n)&&_(n,a);else if(b(n))n.includes(a)||n.push(a);else if(t)d[c]=[a],h(c)&&(f[c]=d[c]);else{let t=[a];g(c,e.k)&&(c.value=t),e.k&&(d[e.k]=t)}}else t?(d[c]=o,h(c)&&(f[c]=o)):r&&(g(c,e.k)&&(c.value=o),e.k&&(d[e.k]=o))};if(o){let t=()=>{s(),gr.delete(e)};t.id=-1,gr.set(e,t),Ki(t,n)}else vr(e),s()}}}function vr(e){let t=gr.get(e);t&&(t.flags|=8,gr.delete(e))}xe().requestIdleCallback,xe().cancelIdleCallback;var yr=e=>!!e.type.__asyncLoader,br=e=>e.type.__isKeepAlive;function xr(e,t){Cr(e,`a`,t)}function Sr(e,t){Cr(e,`da`,t)}function Cr(e,t,n=Na){let r=e.__wdc||=()=>{let t=n;for(;t;){if(t.isDeactivated)return;t=t.parent}return e()};if(Tr(t,r,n),n){let e=n.parent;for(;e&&e.parent;)br(e.parent.vnode)&&wr(r,t,n,e),e=e.parent}}function wr(e,t,n,r){let i=Tr(t,e,r,!0);Mr(()=>{_(r[t],i)},n)}function Tr(e,t,n=Na,r=!1){if(n){let i=n[e]||(n[e]=[]),a=t.__weh||=(...r)=>{at();let i=La(n),a=En(t,n,e,r);return i(),ot(),a};return r?i.unshift(a):i.push(a),a}}var Er=e=>(t,n=Na)=>{Ba&&e!==`sp`||Tr(e,(...e)=>t(...e),n)},Dr=Er(`bm`),Or=Er(`m`),kr=Er(`bu`),Ar=Er(`u`),jr=Er(`bum`),Mr=Er(`um`),Nr=Er(`sp`),Pr=Er(`rtg`),Fr=Er(`rtc`);function Ir(e,t=Na){Tr(`ec`,e,t)}var Lr=`components`;function Rr(e,t){return Vr(Lr,e,!0,t)||e}var zr=Symbol.for(`v-ndc`);function Br(e){return w(e)?Vr(Lr,e,!1)||e:e||zr}function Vr(e,t,n=!0,r=!1){let i=qn||Na;if(i){let n=i.type;if(e===Lr){let e=Ja(n,!1);if(e&&(e===t||e===de(t)||e===me(de(t))))return n}let a=Hr(i[e]||n[e],t)||Hr(i.appContext[e],t);return!a&&r?n:a}}function Hr(e,t){return e&&(e[t]||e[de(t)]||e[me(de(t))])}function A(e,t,n,r){let i,a=n&&n[r],o=b(e);if(o||w(e)){let n=o&&nn(e),r=!1,s=!1;n&&(r=!an(e),s=rn(e),e=yt(e)),i=Array(e.length);for(let n=0,o=e.length;n<o;n++)i[n]=t(r?s?ln(cn(e[n])):cn(e[n]):e[n],n,void 0,a&&a[n])}else if(typeof e==`number`){if(!Number.isInteger(e)||e<0)i=[];else{i=Array(e);for(let n=0;n<e;n++)i[n]=t(n+1,n,void 0,a&&a[n])}}else if(T(e)){if(e[Symbol.iterator])i=Array.from(e,(e,n)=>t(e,n,void 0,a&&a[n]));else{let n=Object.keys(e);i=Array(n.length);for(let r=0,o=n.length;r<o;r++){let o=n[r];i[r]=t(e[o],o,r,a&&a[r])}}}else i=[];return n&&(n[r]=i),i}function Ur(e,t,n,r,i,a){if(n??={},qn.ce||qn.parent&&yr(qn.parent)&&qn.parent.ce){let e=a!=null&&n.key==null?g({},n,{key:a}):n,i=Object.keys(e).length>0;return t!=="default"&&(e.name=t),M(),ma(j,null,[ya(`slot`,e,r&&r())],i?-2:64)}let o=e[t];o&&o._c&&(o._d=!1);let s=ca.length;M();let c;try{let i=o&&Wr(o(n)),s=n.key||a||i&&i.key;c=ma(j,{key:(s&&!te(s)?s:`_${t}`)+(!i&&r?`_fb`:``)},i||(r?r():[]),i&&e._===1?64:-2)}catch(e){for(let e=ca.length;e>s;e--)ua();throw e}finally{o&&o._c&&(o._d=!0)}return!i&&c.scopeId&&(c.slotScopeIds=[c.scopeId+`-s`]),c}function Wr(e){return e.some(e=>!ha(e)||!(e.type===oa||e.type===j&&!Wr(e.children)))?e:null}var Gr=e=>e?za(e)?qa(e):Gr(e.parent):null,Kr=g(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Gr(e.parent),$root:e=>Gr(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>ti(e),$forceUpdate:e=>e.f||=()=>{Rn(e.update)},$nextTick:e=>e.n||=In.bind(e.proxy),$watch:e=>ir.bind(e)}),qr=(e,t)=>e!==u&&!e.__isScriptSetup&&y(e,t),Jr={get({_:e},t){if(t===`__v_skip`)return!0;let{ctx:n,setupState:r,data:i,props:a,accessCache:o,type:s,appContext:c}=e;if(t[0]!==`$`){let e=o[t];if(e!==void 0)switch(e){case 1:return r[t];case 2:return i[t];case 4:return n[t];case 3:return a[t]}else if(qr(r,t))return o[t]=1,r[t];else if(i!==u&&y(i,t))return o[t]=2,i[t];else if(y(a,t))return o[t]=3,a[t];else if(n!==u&&y(n,t))return o[t]=4,n[t];else Xr&&(o[t]=0)}let l=Kr[t],d,f;if(l)return t===`$attrs`&&gt(e.attrs,`get`,``),l(e);if((d=s.__cssModules)&&(d=d[t]))return d;if(n!==u&&y(n,t))return o[t]=4,n[t];if(f=c.config.globalProperties,y(f,t))return f[t]},set({_:e},t,n){let{data:r,setupState:i,ctx:a}=e;return qr(i,t)?(i[t]=n,!0):r!==u&&y(r,t)?(r[t]=n,!0):y(e.props,t)||t[0]===`$`&&t.slice(1)in e?!1:(a[t]=n,!0)},has({_:{data:e,setupState:t,accessCache:n,ctx:r,appContext:i,props:a,type:o}},s){let c;return!!(n[s]||e!==u&&s[0]!==`$`&&y(e,s)||qr(t,s)||y(a,s)||y(r,s)||y(Kr,s)||y(i.config.globalProperties,s)||(c=o.__cssModules)&&c[s])},defineProperty(e,t,n){return n.get==null?y(n,`value`)&&this.set(e,t,n.value,null):e._.accessCache[t]=0,Reflect.defineProperty(e,t,n)}};function Yr(e){return b(e)?e.reduce((e,t)=>(e[t]=null,e),{}):e}var Xr=!0;function Zr(e){let t=ti(e),n=e.proxy,r=e.ctx;Xr=!1,t.beforeCreate&&$r(t.beforeCreate,e,`bc`);let{data:i,computed:a,methods:o,watch:s,provide:c,inject:l,created:u,beforeMount:d,mounted:p,beforeUpdate:m,updated:h,activated:g,deactivated:_,beforeDestroy:v,beforeUnmount:y,destroyed:x,unmounted:S,render:ee,renderTracked:w,renderTriggered:te,errorCaptured:ne,serverPrefetch:re,expose:ie,inheritAttrs:ae,components:oe,directives:se,filters:ce}=t;if(l&&Qr(l,r,null),o)for(let e in o){let t=o[e];C(t)&&(r[e]=t.bind(n))}if(i){let t=i.call(n,n);T(t)&&(e.data=Qt(t))}if(Xr=!0,a)for(let e in a){let t=a[e],i=I({get:C(t)?t.bind(n,n):C(t.get)?t.get.bind(n,n):f,set:!C(t)&&C(t.set)?t.set.bind(n):f});Object.defineProperty(r,e,{enumerable:!0,configurable:!0,get:()=>i.value,set:e=>i.value=e})}if(s)for(let e in s)ei(s[e],r,n,e);if(c){let e=C(c)?c.call(n):c;Reflect.ownKeys(e).forEach(t=>{Qn(t,e[t])})}u&&$r(u,e,`c`);function le(e,t){b(t)?t.forEach(t=>e(t.bind(n))):t&&e(t.bind(n))}if(le(Dr,d),le(Or,p),le(kr,m),le(Ar,h),le(xr,g),le(Sr,_),le(Ir,ne),le(Fr,w),le(Pr,te),le(jr,y),le(Mr,S),le(Nr,re),b(ie)){if(ie.length){let t=e.exposed||={};ie.forEach(e=>{Object.defineProperty(t,e,{get:()=>n[e],set:t=>n[e]=t,enumerable:!0})})}else e.exposed||={}}ee&&e.render===f&&(e.render=ee),ae!=null&&(e.inheritAttrs=ae),oe&&(e.components=oe),se&&(e.directives=se),re&&mr(e)}function Qr(e,t,n=f){b(e)&&(e=oi(e));for(let n in e){let r=e[n],i;i=T(r)?`default`in r?$n(r.from||n,r.default,!0):$n(r.from||n):$n(r),un(i)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>i.value,set:e=>i.value=e}):t[n]=i}}function $r(e,t,n){En(b(e)?e.map(e=>e.bind(t.proxy)):e.bind(t.proxy),t,n)}function ei(e,t,n,r){let i=r.includes(`.`)?ar(n,r):()=>n[r];if(w(e)){let n=t[e];C(n)&&nr(i,n)}else if(C(e))nr(i,e.bind(n));else if(T(e)){if(b(e))e.forEach(e=>ei(e,t,n,r));else{let r=C(e.handler)?e.handler.bind(n):t[e.handler];C(r)&&nr(i,r,e)}}}function ti(e){let t=e.type,{mixins:n,extends:r}=t,{mixins:i,optionsCache:a,config:{optionMergeStrategies:o}}=e.appContext,s=a.get(t),c;return s?c=s:!i.length&&!n&&!r?c=t:(c={},i.length&&i.forEach(e=>ni(c,e,o,!0)),ni(c,t,o)),T(t)&&a.set(t,c),c}function ni(e,t,n,r=!1){let{mixins:i,extends:a}=t;a&&ni(e,a,n,!0),i&&i.forEach(t=>ni(e,t,n,!0));for(let i in t)if(!(r&&i===`expose`)){let r=ri[i]||n&&n[i];e[i]=r?r(e[i],t[i]):t[i]}return e}var ri={data:ii,props:li,emits:li,methods:ci,computed:ci,beforeCreate:si,created:si,beforeMount:si,mounted:si,beforeUpdate:si,updated:si,beforeDestroy:si,beforeUnmount:si,destroyed:si,unmounted:si,activated:si,deactivated:si,errorCaptured:si,serverPrefetch:si,components:ci,directives:ci,watch:ui,provide:ii,inject:ai};function ii(e,t){return t?e?function(){return g(C(e)?e.call(this,this):e,C(t)?t.call(this,this):t)}:t:e}function ai(e,t){return ci(oi(e),oi(t))}function oi(e){if(b(e)){let t={};for(let n=0;n<e.length;n++)t[e[n]]=e[n];return t}return e}function si(e,t){return e?[...new Set([].concat(e,t))]:t}function ci(e,t){return e?g(Object.create(null),e,t):t}function li(e,t){return e?b(e)&&b(t)?[...new Set([...e,...t])]:g(Object.create(null),Yr(e),Yr(t??{})):t}function ui(e,t){if(!e)return t;if(!t)return e;let n=g(Object.create(null),e);for(let r in t)n[r]=si(e[r],t[r]);return n}function di(){return{app:null,config:{isNativeTag:p,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}var fi=0;function pi(e,t){return function(n,r=null){C(n)||(n=g({},n)),r!=null&&!T(r)&&(r=null);let i=di(),a=new WeakSet,o=[],s=!1,c=i.app={_uid:fi++,_component:n,_props:r,_container:null,_context:i,_instance:null,version:Za,get config(){return i.config},set config(e){},use(e,...t){return a.has(e)||(e&&C(e.install)?(a.add(e),e.install(c,...t)):C(e)&&(a.add(e),e(c,...t))),c},mixin(e){return i.mixins.includes(e)||i.mixins.push(e),c},component(e,t){return t?(i.components[e]=t,c):i.components[e]},directive(e,t){return t?(i.directives[e]=t,c):i.directives[e]},mount(a,o,l){if(!s){let u=c._ceVNode||ya(n,r);return u.appContext=i,l===!0?l=`svg`:l===!1&&(l=void 0),o&&t?t(u,a):e(u,a,l),s=!0,c._container=a,a.__vue_app__=c,qa(u.component)}},onUnmount(e){o.push(e)},unmount(){s&&(En(o,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(e,t){return i.provides[e]=t,c},runWithContext(e){let t=mi;mi=c;try{return e()}finally{mi=t}}};return c}}var mi=null,hi=(e,t)=>t===`modelValue`||t===`model-value`?e.modelModifiers:e[`${t}Modifiers`]||e[`${de(t)}Modifiers`]||e[`${pe(t)}Modifiers`];function gi(e,t,...n){if(e.isUnmounted)return;let r=e.vnode.props||u,i=n,a=t.startsWith(`update:`),o=a&&hi(r,t.slice(7));o&&(o.trim&&(i=n.map(e=>w(e)?e.trim():e)),o.number&&(i=i.map(ye)));let s,c=r[s=he(t)]||r[s=he(de(t))];!c&&a&&(c=r[s=he(pe(t))]),c&&En(c,e,6,i);let l=r[s+`Once`];if(l){if(!e.emitted)e.emitted={};else if(e.emitted[s])return;e.emitted[s]=!0,En(l,e,6,i)}}var _i=new WeakMap;function vi(e,t,n=!1){let r=n?_i:t.emitsCache,i=r.get(e);if(i!==void 0)return i;let a=e.emits,o={},s=!1;if(!C(e)){let r=e=>{let n=vi(e,t,!0);n&&(s=!0,g(o,n))};!n&&t.mixins.length&&t.mixins.forEach(r),e.extends&&r(e.extends),e.mixins&&e.mixins.forEach(r)}return!a&&!s?(T(e)&&r.set(e,null),null):(b(a)?a.forEach(e=>o[e]=null):g(o,a),T(e)&&r.set(e,o),o)}function yi(e,t){return!e||!m(t)?!1:(t=t.slice(2),t=t===`Once`?t:t.replace(/Once$/,``),y(e,t[0].toLowerCase()+t.slice(1))||y(e,pe(t))||y(e,t))}function bi(e){let{type:t,vnode:n,proxy:r,withProxy:i,propsOptions:[a],slots:o,attrs:s,emit:c,render:l,renderCache:u,props:d,data:f,setupState:p,ctx:m,inheritAttrs:g}=e,_=Yn(e),v,y;try{if(n.shapeFlag&4){let e=i||r,t=e;v=wa(l.call(t,e,u,d,p,f,m)),y=s}else{let e=t;v=wa(e.length>1?e(d,{attrs:s,slots:o,emit:c}):e(d,null)),y=t.props?s:Si(s)}}catch(t){ca.length=0,Dn(t,e,1),v=ya(oa)}let b=v;if(y&&g!==!1){let e=Object.keys(y),{shapeFlag:t}=b;e.length&&t&7&&(a&&e.some(h)&&(y=Ci(y,a)),b=Sa(b,y,!1,!0))}return n.dirs&&(b=Sa(b,null,!1,!0),b.dirs=b.dirs?b.dirs.concat(n.dirs):n.dirs),n.transition&&dr(sr(b.type)&&ur(b)||b,n.transition),v=b,Yn(_),v}function xi(e,t=!0){let n;for(let t=0;t<e.length;t++){let r=e[t];if(ha(r)){if(r.type!==oa||r.children===`v-if`){if(n)return;n=r}}else return}return n}var Si=e=>{let t;for(let n in e)(n===`class`||n===`style`||m(n))&&((t||={})[n]=e[n]);return t},Ci=(e,t)=>{let n={};for(let r in e)h(r)&&r.slice(9)in t||(n[r]=e[r]);return n};function wi(e,t,n){let{props:r,children:i,component:a}=e,{props:o,children:s,patchFlag:c}=t,l=a.emitsOptions;if(t.dirs||t.transition)return!0;if(n&&c>=0){if(c&1024)return!0;if(c&16)return r?Ti(r,o,l):!!o;if(c&8){let e=t.dynamicProps;for(let t=0;t<e.length;t++){let n=e[t];if(Ei(o,r,n)&&!yi(l,n))return!0}}}else return(i||s)&&(!s||!s.$stable)?!0:r===o?!1:r?!o||Ti(r,o,l):!!o;return!1}function Ti(e,t,n){let r=Object.keys(t);if(r.length!==Object.keys(e).length)return!0;for(let i=0;i<r.length;i++){let a=r[i];if(!y(e,a)||Ei(t,e,a)&&!yi(n,a))return!0}return!1}function Ei(e,t,n){let r=e[n],i=t[n];return n===`style`&&T(r)&&T(i)?!Pe(r,i):r!==i}function Di({vnode:e,parent:t,suspense:n},r){for(;t;){let n=t.subTree;if(n.suspense&&n.suspense.activeBranch===e&&(n.suspense.vnode.el=n.el=r,e=n),n===e)(e=t.vnode).el=r,t=t.parent;else break}n&&n.activeBranch===e&&(n.vnode.el=r)}var Oi={},ki=()=>Object.create(Oi),Ai=e=>Object.getPrototypeOf(e)===Oi;function ji(e,t,n,r=!1){let i={},a=ki();e.propsDefaults=Object.create(null),Ni(e,t,i,a);for(let t in e.propsOptions[0])t in i||(i[t]=void 0);e.props=n?r?i:$t(i):e.type.props?i:a,e.attrs=a}function Mi(e,t,n,r){let{props:i,attrs:a,vnode:{patchFlag:o}}=e,s=D(i),[c]=e.propsOptions,l=!1;if((r||o>0)&&!(o&16)){if(o&8){let n=e.vnode.dynamicProps;for(let r=0;r<n.length;r++){let o=n[r];if(yi(e.emitsOptions,o))continue;let u=t[o];if(c){if(y(a,o))u!==a[o]&&(a[o]=u,l=!0);else{let t=de(o);i[t]=Pi(c,s,t,u,e,!1)}}else u!==a[o]&&(a[o]=u,l=!0)}}}else{Ni(e,t,i,a)&&(l=!0);let r;for(let a in s)t&&(y(t,a)||(r=pe(a))!==a&&y(t,r))||(c?n&&(n[a]!==void 0||n[r]!==void 0)&&(i[a]=Pi(c,s,a,void 0,e,!0)):delete i[a]);if(a!==s)for(let e in a)t&&y(t,e)||(delete a[e],l=!0)}l&&_t(e.attrs,`set`,``)}function Ni(e,t,n,r){let[i,a]=e.propsOptions,o=!1,s;if(t)for(let c in t){if(ce(c))continue;let l=t[c],u;i&&y(i,u=de(c))?!a||!a.includes(u)?n[u]=l:(s||={})[u]=l:yi(e.emitsOptions,c)||c in r&&l===r[c]||(r[c]=l,o=!0)}if(a){let t=D(n),r=s||u;for(let o=0;o<a.length;o++){let s=a[o];n[s]=Pi(i,t,s,r[s],e,!y(r,s))}}return o}function Pi(e,t,n,r,i,a){let o=e[n];if(o!=null){let e=y(o,`default`);if(e&&r===void 0){let e=o.default;if(o.type!==Function&&!o.skipFactory&&C(e)){let{propsDefaults:a}=i;if(n in a)r=a[n];else{let o=La(i);r=a[n]=e.call(null,t),o()}}else r=e;i.ce&&i.ce._setProp(n,r)}o[0]&&(a&&!e?r=!1:o[1]&&(r===``||r===pe(n))&&(r=!0))}return r}var Fi=new WeakMap;function Ii(e,t,n=!1){let r=n?Fi:t.propsCache,i=r.get(e);if(i)return i;let a=e.props,o={},s=[],c=!1;if(!C(e)){let r=e=>{c=!0;let[n,r]=Ii(e,t,!0);g(o,n),r&&s.push(...r)};!n&&t.mixins.length&&t.mixins.forEach(r),e.extends&&r(e.extends),e.mixins&&e.mixins.forEach(r)}if(!a&&!c)return T(e)&&r.set(e,d),d;if(b(a))for(let e=0;e<a.length;e++){let t=de(a[e]);Li(t)&&(o[t]=u)}else if(a)for(let e in a){let t=de(e);if(Li(t)){let n=a[e],r=o[t]=b(n)||C(n)?{type:n}:g({},n),i=r.type,c=!1,l=!0;if(b(i))for(let e=0;e<i.length;++e){let t=i[e],n=C(t)&&t.name;if(n===`Boolean`){c=!0;break}n===`String`&&(l=!1)}else c=C(i)&&i.name===`Boolean`;r[0]=c,r[1]=l,(c||y(r,`default`))&&s.push(t)}}let l=[o,s];return T(e)&&r.set(e,l),l}function Li(e){return e[0]!==`$`&&!ce(e)}var Ri=e=>e===`_`||e===`_ctx`||e===`$stable`,zi=e=>b(e)?e.map(wa):[wa(e)],Bi=(e,t,n)=>{if(t._n)return t;let r=Xn((...e)=>zi(t(...e)),n);return r._c=!1,r},Vi=(e,t,n)=>{let r=e._ctx;for(let n in e){if(Ri(n))continue;let i=e[n];if(C(i))t[n]=Bi(n,i,r);else if(i!=null){let e=zi(i);t[n]=()=>e}}},Hi=(e,t)=>{let n=zi(t);e.slots.default=()=>n},Ui=(e,t,n)=>{for(let r in t)(n||!Ri(r))&&(e[r]=t[r])},Wi=(e,t,n)=>{let r=e.slots=ki();if(e.vnode.shapeFlag&32){let e=t._;e?(Ui(r,t,n),n&&ve(r,`_`,e,!0)):Vi(t,r)}else t&&Hi(e,t)},Gi=(e,t,n)=>{let{vnode:r,slots:i}=e,a=!0,o=u;if(r.shapeFlag&32){let e=t._;e?n&&e===1?a=!1:Ui(i,t,n):(a=!t.$stable,Vi(t,i)),o=t}else t&&(Hi(e,t),o={default:1});if(a)for(let e in i)!Ri(e)&&o[e]==null&&delete i[e]},Ki=ia;function qi(e){return Ji(e)}function Ji(e,t){let n=xe();n.__VUE__=!0;let{insert:r,remove:i,patchProp:a,createElement:o,createText:s,createComment:c,setText:l,setElementText:p,parentNode:m,nextSibling:h,setScopeId:g=f,insertStaticContent:_}=e,v=(e,t,n,r=null,i=null,a=null,o=void 0,s=null,c=!!t.dynamicChildren)=>{if(e===t)return;e&&!ga(e,t)&&(r=Ce(e),ge(e,i,a,!0),e=null),t.patchFlag===-2&&(c=!1,t.dynamicChildren=null),t.dynamicChildren&&e&&e.dynamicChildren&&e.dynamicChildren.hasOnce&&(t.dynamicChildren===d&&(t.dynamicChildren=[]),t.dynamicChildren.hasOnce=!0);let{type:l,ref:u,shapeFlag:f}=t;switch(l){case aa:y(e,t,n,r);break;case oa:b(e,t,n,r);break;case sa:e??x(t,n,r,o);break;case j:ae(e,t,n,r,i,a,o,s,c);break;default:f&1?C(e,t,n,r,i,a,o,s,c):f&6?oe(e,t,n,r,i,a,o,s,c):(f&64||f&128)&&l.process(e,t,n,r,i,a,o,s,c,Te)}u!=null&&i?_r(u,e&&e.ref,a,t||e,!t):u==null&&e&&e.ref!=null&&_r(e.ref,null,a,e,!0)},y=(e,t,n,i)=>{if(e==null)r(t.el=s(t.children),n,i);else{let n=t.el=e.el;t.children!==e.children&&l(n,t.children)}},b=(e,t,n,i)=>{e==null?r(t.el=c(t.children||``),n,i):t.el=e.el},x=(e,t,n,r)=>{[e.el,e.anchor]=_(e.children,t,n,r,e.el,e.anchor)},S=({el:e,anchor:t},n,i)=>{let a;for(;e&&e!==t;)a=h(e),r(e,n,i),e=a;r(t,n,i)},ee=({el:e,anchor:t})=>{let n;for(;e&&e!==t;)n=h(e),i(e),e=n;i(t)},C=(e,t,n,r,i,a,o,s,c)=>{if(t.type===`svg`?o=`svg`:t.type===`math`&&(o=`mathml`),e==null)w(t,n,r,i,a,o,s,c);else{let n=e.el&&e.el._isVueCE?e.el:null;try{n&&n._beginPatch(),ne(e,t,i,a,o,s,c)}finally{n&&n._endPatch()}}},w=(e,t,n,i,s,c,l,u)=>{let d,f,{props:m,shapeFlag:h,transition:g,dirs:_}=e;if(d=e.el=o(e.type,c,m&&m.is,m),h&8?p(d,e.children):h&16&&T(e.children,d,null,i,s,Yi(e,c),l,u),_&&Zn(e,null,i,`created`),te(d,e,e.scopeId,l,i),m){for(let e in m)e!==`value`&&!ce(e)&&a(d,e,null,m[e],c,i);`value`in m&&a(d,`value`,null,m.value,c),(f=m.onVnodeBeforeMount)&&Oa(f,i,e)}_&&Zn(e,null,i,`beforeMount`);let v=Zi(s,g);v&&g.beforeEnter(d),r(d,t,n),((f=m&&m.onVnodeMounted)||v||_)&&Ki(()=>{try{f&&Oa(f,i,e),v&&g.enter(d),_&&Zn(e,null,i,`mounted`)}finally{}},s)},te=(e,t,n,r,i)=>{if(n&&g(e,n),r)for(let t=0;t<r.length;t++)g(e,r[t]);if(i){let n=i.subTree;if(t===n||ra(n.type)&&(n.ssContent===t||n.ssFallback===t)){let t=i.vnode;te(e,t,t.scopeId,t.slotScopeIds,i.parent)}}},T=(e,t,n,r,i,a,o,s,c=0)=>{for(let l=c;l<e.length;l++){let c=e[l]=s?Ta(e[l]):wa(e[l]);v(null,c,t,n,r,i,a,o,s)}},ne=(e,t,n,r,i,o,s)=>{let c=t.el=e.el,{patchFlag:l,dynamicChildren:d,dirs:f}=t;l|=e.patchFlag&16;let m=e.props||u,h=t.props||u,g;if(n&&Xi(n,!1),(g=h.onVnodeBeforeUpdate)&&Oa(g,n,t,e),f&&Zn(t,e,n,`beforeUpdate`),n&&Xi(n,!0),d&&(!e.dynamicChildren||e.dynamicChildren.length!==d.length)&&(l=0,s=!1,d=null),(m.innerHTML&&h.innerHTML==null||m.textContent&&h.textContent==null)&&p(c,``),d?re(e.dynamicChildren,d,c,n,r,Yi(t,i),o):s||fe(e,t,c,null,n,r,Yi(t,i),o,!1),l>0){if(l&16)ie(c,m,h,n,i);else if(l&2&&m.class!==h.class&&a(c,`class`,null,h.class,i),l&4&&a(c,`style`,m.style,h.style,i),l&8){let e=t.dynamicProps;for(let t=0;t<e.length;t++){let r=e[t],o=m[r],s=h[r];(s!==o||r===`value`)&&a(c,r,o,s,i,n)}}l&1&&e.children!==t.children&&p(c,t.children)}else!s&&d==null&&ie(c,m,h,n,i);((g=h.onVnodeUpdated)||f)&&Ki(()=>{g&&Oa(g,n,t,e),f&&Zn(t,e,n,`updated`)},r)},re=(e,t,n,r,i,a,o)=>{for(let s=0;s<t.length;s++){let c=e[s],l=t[s],u=c.el||na(c),d=u&&(c.type===j||!ga(c,l)||c.shapeFlag&198)?m(u):n;v(c,l,d,null,r,i,a,o,!0)}},ie=(e,t,n,r,i)=>{if(t!==n){if(t!==u)for(let o in t)!ce(o)&&!(o in n)&&a(e,o,t[o],null,i,r);for(let o in n){if(ce(o))continue;let s=n[o],c=t[o];s!==c&&o!==`value`&&a(e,o,c,s,i,r)}`value`in n&&a(e,`value`,t.value,n.value,i)}},ae=(e,t,n,i,a,o,c,l,u)=>{let d=t.el=e?e.el:s(``),f=t.anchor=e?e.anchor:s(``),{patchFlag:p,dynamicChildren:m,slotScopeIds:h}=t;h&&(l=l?l.concat(h):h),e==null?(r(d,n,i),r(f,n,i),T(t.children||[],n,f,a,o,c,l,u)):p>0&&p&64&&m&&e.dynamicChildren&&e.dynamicChildren.length===m.length?(re(e.dynamicChildren,m,n,a,o,c,l),(t.key!=null||a&&t===a.subTree)&&Qi(e,t,!0)):fe(e,t,n,f,a,o,c,l,u)},oe=(e,t,n,r,i,a,o,s,c)=>{t.slotScopeIds=s,e==null?t.shapeFlag&512?i.ctx.activate(t,n,r,o,c):se(t,n,r,i,a,o,c):le(e,t,c)},se=(e,t,n,r,i,a,o)=>{let s=e.component=Ma(e,r,i);if(br(e)&&(s.ctx.renderer=Te),Va(s,!1,o),s.asyncDep){if(i&&i.registerDep(s,ue,o,a),!e.el){let r=s.subTree=ya(oa);b(null,r,t,n),e.placeholder=r.el}}else ue(s,e,t,n,i,a,o)},le=(e,t,n)=>{let r=t.component=e.component;if(wi(e,t,n)){if(r.asyncDep&&!r.asyncResolved){t.el=e.el,t.placeholder=e.placeholder,de(r,t,n);return}r.next=t,r.update()}else t.el=e.el,t.placeholder=e.placeholder,r.vnode=t},ue=(e,t,n,r,i,a,o)=>{let s=()=>{if(e.isMounted){let{next:t,bu:n,u:r,parent:s,vnode:c}=e;{let n=ea(e);if(n){t&&(t.el=c.el,de(e,t,o)),n.asyncDep.then(()=>{Ki(()=>{e.isUnmounted||l()},i)});return}}let u=t,d;Xi(e,!1),t?(t.el=c.el,de(e,t,o)):t=c,n&&_e(n),(d=t.props&&t.props.onVnodeBeforeUpdate)&&Oa(d,s,t,c),Xi(e,!0);let f=bi(e),p=e.subTree;e.subTree=f,v(p,f,m(p.el),Ce(p),e,i,a),t.el=f.el,u===null&&Di(e,f.el),r&&Ki(r,i),(d=t.props&&t.props.onVnodeUpdated)&&Ki(()=>Oa(d,s,t,c),i)}else{let o,{el:s,props:c}=t,{bm:l,m:u,parent:d,root:f,type:p}=e,m=yr(t);if(Xi(e,!1),l&&_e(l),!m&&(o=c&&c.onVnodeBeforeMount)&&Oa(o,d,t),Xi(e,!0),s&&De){let t=()=>{e.subTree=bi(e),De(s,e.subTree,e,i,null)};m&&p.__asyncHydrate?p.__asyncHydrate(s,e,t):t()}else{f.ce&&f.ce._hasShadowRoot()&&f.ce._injectChildStyle(p,e.parent?e.parent.type:void 0);let o=e.subTree=bi(e);v(null,o,n,r,e,i,a),t.el=o.el}if(u&&Ki(u,i),!m&&(o=c&&c.onVnodeMounted)){let e=t;Ki(()=>Oa(o,d,e),i)}(t.shapeFlag&256||d&&yr(d.vnode)&&d.vnode.shapeFlag&256)&&e.a&&Ki(e.a,i),e.isMounted=!0,t=n=r=null}};e.scope.on();let c=e.effect=new We(s);e.scope.off();let l=e.update=c.run.bind(c),u=e.job=c.runIfDirty.bind(c);u.i=e,u.id=e.uid,c.scheduler=()=>Rn(u),Xi(e,!0),l()},de=(e,t,n)=>{t.component=e;let r=e.vnode.props;e.vnode=t,e.next=null,Mi(e,t.props,r,n),Gi(e,t.children,n),at(),Vn(e),ot()},fe=(e,t,n,r,i,a,o,s,c=!1)=>{let l=e&&e.children,u=e?e.shapeFlag:0,d=t.children,{patchFlag:f,shapeFlag:m}=t;if(f>0){if(f&128){me(l,d,n,r,i,a,o,s,c);return}if(f&256){pe(l,d,n,r,i,a,o,s,c);return}}m&8?(u&16&&Se(l,i,a),d!==l&&p(n,d)):u&16?m&16?me(l,d,n,r,i,a,o,s,c):Se(l,i,a,!0):(u&8&&p(n,``),m&16&&T(d,n,r,i,a,o,s,c))},pe=(e,t,n,r,i,a,o,s,c)=>{e||=d,t||=d;let l=e.length,u=t.length,f=Math.min(l,u),p=0;for(;p<f;p++){let r=t[p]=c?Ta(t[p]):wa(t[p]);v(e[p],r,n,null,i,a,o,s,c)}l>u?Se(e,i,a,!0,!1,f):T(t,n,r,i,a,o,s,c,f)},me=(e,t,n,r,i,a,o,s,c)=>{let l=0,u=t.length,f=e.length-1,p=u-1;for(;l<=f&&l<=p;){let r=e[l],u=t[l]=c?Ta(t[l]):wa(t[l]);if(ga(r,u))v(r,u,n,null,i,a,o,s,c);else break;l++}for(;l<=f&&l<=p;){let r=e[f],l=t[p]=c?Ta(t[p]):wa(t[p]);if(ga(r,l))v(r,l,n,null,i,a,o,s,c);else break;f--,p--}if(l>f){if(l<=p){let e=p+1,d=e<u?t[e].el:r;for(;l<=p;)v(null,t[l]=c?Ta(t[l]):wa(t[l]),n,d,i,a,o,s,c),l++}}else if(l>p)for(;l<=f;)ge(e[l],i,a,!0),l++;else{let m=l,h=l,g=new Map;for(l=h;l<=p;l++){let e=t[l]=c?Ta(t[l]):wa(t[l]);e.key!=null&&g.set(e.key,l)}let _,y=0,b=p-h+1,x=!1,S=0,ee=Array(b);for(l=0;l<b;l++)ee[l]=0;for(l=m;l<=f;l++){let r=e[l];if(y>=b){ge(r,i,a,!0);continue}let u;if(r.key!=null)u=g.get(r.key);else for(_=h;_<=p;_++)if(ee[_-h]===0&&ga(r,t[_])){u=_;break}u===void 0?ge(r,i,a,!0):(ee[u-h]=l+1,u>=S?S=u:x=!0,v(r,t[u],n,null,i,a,o,s,c),y++)}let C=x?$i(ee):d;for(_=C.length-1,l=b-1;l>=0;l--){let e=h+l,d=t[e],f=t[e+1],p=e+1<u?f.el||na(f):r;ee[l]===0?v(null,d,n,p,i,a,o,s,c):x&&(_<0||l!==C[_]?he(d,n,p,2):_--)}}},he=(e,t,n,a,o=null)=>{let{el:s,type:c,transition:l,children:u,shapeFlag:d}=e;if(d&6)he(e.component.subTree,t,n,a);else if(d&128)e.suspense.move(t,n,a);else if(d&64)c.move(e,t,n,Te);else if(c===j){r(s,t,n);for(let e=0;e<u.length;e++)he(u[e],t,n,a);r(e.anchor,t,n)}else if(c===sa)S(e,t,n);else if(a!==2&&d&1&&l){if(a===0)l.persisted&&!s[cr]?r(s,t,n):(l.beforeEnter(s),r(s,t,n),Ki(()=>l.enter(s),o));else{let{leave:a,delayLeave:o,afterLeave:c}=l,u=()=>{e.ctx.isUnmounted?i(s):r(s,t,n)},d=()=>{let e=s._isLeaving||!!s[cr];s._isLeaving&&s[cr](!0),l.persisted&&!e?u():a(s,()=>{u(),c&&c()})};o?o(s,u,d):d()}}else r(s,t,n)},ge=(e,t,n,r=!1,i=!1)=>{let{type:a,props:o,ref:s,children:c,dynamicChildren:l,shapeFlag:u,patchFlag:d,dirs:f,cacheIndex:p,memo:m}=e;if((d===-2||l&&l.hasOnce)&&(i=!1),s!=null&&(at(),_r(s,null,n,e,!0),ot()),p==null||e.ctx&&e.ctx!==t||(t.renderCache[p]=void 0),u&256){t.ctx.deactivate(e);return}let h=u&1&&f,g=!yr(e),_;if(g&&(_=o&&o.onVnodeBeforeUnmount)&&Oa(_,t,e),u&6)be(e.component,n,r);else{if(u&128){e.suspense.unmount(n,r);return}h&&Zn(e,null,t,`beforeUnmount`),u&64?e.type.remove(e,t,n,Te,r):l&&!l.hasOnce&&(a!==j||d>0&&d&64)?Se(l,t,n,!1,!0):(a===j&&d&384||!i&&u&16)&&Se(c,t,n),r&&ve(e)}let v=m!=null&&p==null;(g&&(_=o&&o.onVnodeUnmounted)||h||v)&&Ki(()=>{_&&Oa(_,t,e),h&&Zn(e,null,t,`unmounted`),v&&(e.el=null)},n)},ve=e=>{let{type:t,el:n,anchor:r,transition:a}=e,o=t===j;if(o&&!a){ye(n,r);return}if(t===sa){ee(e),a&&!a.persisted&&a.afterLeave&&a.afterLeave();return}let s=o?fr(e):e,c=()=>{o?m(n)&&ye(n,r):i(n),a&&!a.persisted&&a.afterLeave&&a.afterLeave()};if(s&&s.shapeFlag&1&&a&&!a.persisted){let{leave:e,delayLeave:t}=a,n=s.el,r=()=>e(n,c);t?t(n,c,r):r()}else c()},ye=(e,t)=>{let n;for(;e!==t;)n=h(e),i(e),e=n;i(t)},be=(e,t,n)=>{let{bum:r,scope:i,job:a,subTree:o,um:s,m:c,a:l}=e;ta(c),ta(l),r&&_e(r),i.stop(),a?(a.flags|=8,ge(o,e,t,n)):e.vnode.el&&o&&(o.transition=e.vnode.transition,ge(o,e,t,n)),s&&Ki(s,t),Ki(()=>{e.isUnmounted=!0},t)},Se=(e,t,n,r=!1,i=!1,a=0)=>{for(let o=a;o<e.length;o++)ge(e[o],t,n,r,i)},Ce=e=>{if(e.shapeFlag&6)return Ce(e.component.subTree);if(e.shapeFlag&128)return e.suspense.next();let t=h(e.anchor||e.el),n=t&&t[or];return n?h(n):t},we=(e,t,n)=>{Wn(()=>{e==null?t._vnode&&ge(t._vnode,null,null,!0):v(t._vnode||null,e,t,null,null,null,n),t._vnode=e},e&&t._vnode?void 0:e&&e.component?e.component.uid:ja())},Te={p:v,um:ge,m:he,r:ve,mt:se,mc:T,pc:fe,pbc:re,n:Ce,o:e},Ee,De;return t&&([Ee,De]=t(Te)),{render:we,hydrate:Ee,createApp:pi(we,Ee)}}function Yi({type:e,props:t},n){return n===`svg`&&e===`foreignObject`||n===`mathml`&&e===`annotation-xml`&&t&&t.encoding&&t.encoding.includes(`html`)?void 0:n}function Xi({effect:e,job:t},n){n?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function Zi(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Qi(e,t,n=!1){let r=e.children,i=t.children;if(b(r)&&b(i))for(let e=0;e<r.length;e++){let t=r[e],a=i[e];a.shapeFlag&1&&!a.dynamicChildren&&((a.patchFlag<=0||a.patchFlag===32)&&(a=i[e]=Ta(i[e]),a.el=t.el),!n&&a.patchFlag!==-2&&Qi(t,a)),a.type===aa&&(a.patchFlag===-1&&(a=i[e]=Ta(a)),a.el=t.el),a.type===oa&&!a.el&&(a.el=t.el)}}function $i(e){let t=e.slice(),n=[0],r,i,a,o,s,c=e.length;for(r=0;r<c;r++){let c=e[r];if(c!==0){if(i=n[n.length-1],e[i]<c){t[r]=i,n.push(r);continue}for(a=0,o=n.length-1;a<o;)s=a+o>>1,e[n[s]]<c?a=s+1:o=s;c<e[n[a]]&&(a>0&&(t[r]=n[a-1]),n[a]=r)}}for(a=n.length,o=n[a-1];a-->0;)n[a]=o,o=t[o];return n}function ea(e){let t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:ea(t)}function ta(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function na(e){if(e.placeholder)return e.placeholder;let t=e.component;return t?na(t.subTree):null}var ra=e=>e.__isSuspense;function ia(e,t){t&&t.pendingBranch?b(e)?t.effects.push(...e):t.effects.push(e):Bn(e)}var j=Symbol.for(`v-fgt`),aa=Symbol.for(`v-txt`),oa=Symbol.for(`v-cmt`),sa=Symbol.for(`v-stc`),ca=[],la=null;function M(e=!1){ca.push(la=e?null:[])}function ua(){ca.pop(),la=ca[ca.length-1]||null}var da=1;function fa(e,t=!1){da+=e,e<0&&la&&t&&(la.hasOnce=!0)}function pa(e){return e.dynamicChildren=da>0?la||d:null,ua(),da>0&&la&&la.push(e),e}function N(e,t,n,r,i,a){return pa(P(e,t,n,r,i,a,!0))}function ma(e,t,n,r,i){return pa(ya(e,t,n,r,i,!0))}function ha(e){return e?e.__v_isVNode===!0:!1}function ga(e,t){return e.type===t.type&&e.key===t.key}var _a=({key:e})=>e??null,va=({ref:e,ref_key:t,ref_for:n})=>(typeof e==`number`&&(e=``+e),e==null?null:w(e)||un(e)||C(e)?{i:qn,r:e,k:t,f:!!n}:e);function P(e,t=null,n=null,r=0,i=null,a=e===j?0:1,o=!1,s=!1){let c={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&_a(t),ref:t&&va(t),scopeId:Jn,slotScopeIds:null,children:n,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:a,patchFlag:r,dynamicProps:i,dynamicChildren:null,appContext:null,ctx:qn};return s?(Ea(c,n),a&128&&e.normalize(c)):n&&(c.shapeFlag|=w(n)?8:16),da>0&&!o&&la&&(c.patchFlag>0||a&6)&&c.patchFlag!==32&&la.push(c),c}var ya=ba;function ba(e,t=null,n=null,r=0,i=null,a=!1){if(e&&e!==zr||(e=oa),ha(e)){let r=Sa(e,t,!0);return n&&Ea(r,n),da>0&&!a&&la&&(r.shapeFlag&6?la[la.indexOf(e)]=r:la.push(r)),r.patchFlag=-2,r}if(Ya(e)&&(e=e.__vccOpts),t){t=xa(t);let{class:e,style:n}=t;e&&!w(e)&&(t.class=De(e)),T(n)&&(on(n)&&!b(n)&&(n=g({},n)),t.style=Se(n))}let o=w(e)?1:ra(e)?128:sr(e)?64:T(e)?4:C(e)?2:0;return P(e,t,n,r,i,o,a,!0)}function xa(e){return e?on(e)||Ai(e)?g({},e):e:null}function Sa(e,t,n=!1,r=!1){let{props:i,ref:a,patchFlag:o,children:s,transition:c}=e,l=t?Da(i||{},t):i,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:l,key:l&&_a(l),ref:t&&t.ref?n&&a?b(a)?a.concat(va(t)):[a,va(t)]:va(t):a,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:s,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==j?o===-1?16:o|16:o,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:c,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&Sa(e.ssContent),ssFallback:e.ssFallback&&Sa(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce,cacheIndex:e.cacheIndex};return c&&r&&dr(u,c.clone(u)),u}function Ca(e=` `,t=0){return ya(aa,null,e,t)}function F(e=``,t=!1){return t?(M(),ma(oa,null,e)):ya(oa,null,e)}function wa(e){return e==null||typeof e==`boolean`?ya(oa):b(e)?ya(j,null,e.slice()):ha(e)?Ta(e):ya(aa,null,String(e))}function Ta(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:Sa(e)}function Ea(e,t){let n=0,{shapeFlag:r}=e;if(t==null)t=null;else if(b(t))n=16;else if(typeof t==`object`){if(r&65){let n=t.default;n&&(n._c&&(n._d=!1),Ea(e,n()),n._c&&(n._d=!0));return}{n=32;let r=t._;!r&&!Ai(t)?t._ctx=qn:r===3&&qn&&(qn.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}}else if(C(t)){if(r&65){Ea(e,{default:t});return}t={default:t,_ctx:qn},n=32}else t=String(t),r&64?(n=16,t=[Ca(t)]):n=8;e.children=t,e.shapeFlag|=n}function Da(...e){let t={};for(let n=0;n<e.length;n++){let r=e[n];for(let e in r)if(e===`class`)t.class!==r.class&&(t.class=De([t.class,r.class]));else if(e===`style`)t.style=Se([t.style,r.style]);else if(m(e)){let n=t[e],i=r[e];i&&n!==i&&!(b(n)&&n.includes(i))?t[e]=n?[].concat(n,i):i:i==null&&n==null&&!h(e)&&(t[e]=i)}else e!==``&&(t[e]=r[e])}return t}function Oa(e,t,n,r=null){En(e,t,7,[n,r])}var ka=di(),Aa=0;function ja(){return Aa}function Ma(e,t,n){let r=e.type,i=(t?t.appContext:e.appContext)||ka,a={uid:Aa++,vnode:e,type:r,parent:t,appContext:i,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Be(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(i.provides),ids:t?t.ids:[``,0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Ii(r,i),emitsOptions:vi(r,i),emit:null,emitted:null,propsDefaults:u,inheritAttrs:r.inheritAttrs,ctx:u,data:u,props:u,attrs:u,slots:u,refs:u,setupState:u,setupContext:null,suspense:n,suspenseId:n?n.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return a.ctx={_:a},a.root=t?t.root:a,a.emit=gi.bind(null,a),e.ce&&e.ce(a),a}var Na=null,Pa=()=>Na||qn,Fa,Ia;{let e=xe(),t=(t,n)=>{let r;return(r=e[t])||(r=e[t]=[]),r.push(n),e=>{r.length>1?r.forEach(t=>t(e)):r[0](e)}};Fa=t(`__VUE_INSTANCE_SETTERS__`,e=>Na=e),Ia=t(`__VUE_SSR_SETTERS__`,e=>Ba=e)}var La=e=>{let t=Na;return Fa(e),e.scope.on(),()=>{e.scope.off(),Fa(t)}},Ra=()=>{Na&&Na.scope.off(),Fa(null)};function za(e){return e.vnode.shapeFlag&4}var Ba=!1;function Va(e,t=!1,n=!1){t&&Ia(t);let{props:r,children:i}=e.vnode,a=za(e);ji(e,r,a,t),Wi(e,i,n||t);let o=a?Ha(e,t):void 0;return t&&Ia(!1),o}function Ha(e,t){let n=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Jr);let{setup:r}=n;if(r){at();let n=e.setupContext=r.length>1?Ka(e):null,i=La(e),a=Tn(r,e,0,[e.props,n]),o=ne(a);if(ot(),i(),(o||e.sp)&&!yr(e)&&mr(e),o){if(a.then(Ra,Ra),t)return a.then(n=>{Ia(!0);try{Ua(e,n,t)}finally{Ia(!1)}}).catch(t=>{Dn(t,e,0)});e.asyncDep=a}else Ua(e,a,t)}else Wa(e,t)}function Ua(e,t,n){C(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:T(t)&&(e.setupState=gn(t)),Wa(e,n)}function Wa(e,t,n){let r=e.type;e.render||=r.render||f;{let t=La(e);at();try{Zr(e)}finally{ot(),t()}}}var Ga={get(e,t){return gt(e,`get`,``),e[t]}};function Ka(e){return{attrs:new Proxy(e.attrs,Ga),slots:e.slots,emit:e.emit,expose:t=>{e.exposed=t||{}}}}function qa(e){return e.exposed?e.exposeProxy||=new Proxy(gn(sn(e.exposed)),{get(t,n){if(n in t)return t[n];if(n in Kr)return Kr[n](e)},has(e,t){return t in e||t in Kr}}):e.proxy}function Ja(e,t=!0){return C(e)?e.displayName||e.name:e.name||t&&e.__name}function Ya(e){return C(e)&&`__vccOpts`in e}var I=(e,t)=>vn(e,t,Ba);function Xa(e,t,n){try{fa(-1);let r=arguments.length;return r===2?T(t)&&!b(t)?ha(t)?ya(e,null,[t]):ya(e,t):ya(e,null,t):(r>3?n=Array.prototype.slice.call(arguments,2):r===3&&ha(n)&&(n=[n]),ya(e,t,n))}finally{fa(1)}}var Za=`3.5.44`,Qa=void 0,$a=typeof window<`u`&&window.trustedTypes;if($a)try{Qa=$a.createPolicy(`vue`,{createHTML:e=>e})}catch{}var eo=Qa?e=>Qa.createHTML(e):e=>e,to=`http://www.w3.org/2000/svg`,no=`http://www.w3.org/1998/Math/MathML`,ro=typeof document<`u`?document:null,io=ro&&ro.createElement(`template`),ao={insert:(e,t,n)=>{t.insertBefore(e,n||null)},remove:e=>{let t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,n,r)=>{let i=t===`svg`?ro.createElementNS(to,e):t===`mathml`?ro.createElementNS(no,e):n?ro.createElement(e,{is:n}):ro.createElement(e);return e===`select`&&r&&r.multiple!=null&&i.setAttribute(`multiple`,r.multiple),i},createText:e=>ro.createTextNode(e),createComment:e=>ro.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>ro.querySelector(e),setScopeId(e,t){e.setAttribute(t,``)},insertStaticContent(e,t,n,r,i,a){let o=n?n.previousSibling:t.lastChild;if(i&&(i===a||i.nextSibling))for(;t.insertBefore(i.cloneNode(!0),n),i!==a&&(i=i.nextSibling););else{io.innerHTML=eo(r===`svg`?`<svg>${e}</svg>`:r===`mathml`?`<math>${e}</math>`:e);let i=io.content;if(r===`svg`||r===`mathml`){let e=i.firstChild;for(;e.firstChild;)i.appendChild(e.firstChild);i.removeChild(e)}t.insertBefore(i,n)}return[o?o.nextSibling:t.firstChild,n?n.previousSibling:t.lastChild]}},oo=Symbol(`_vtc`);function so(e,t,n){let r=e[oo];r&&(t=(t?[t,...r]:[...r]).join(` `)),t==null?e.removeAttribute(`class`):n?e.setAttribute(`class`,t):e.className=t}var co=Symbol(`_vod`),lo=Symbol(`_vsh`),uo={name:`show`,beforeMount(e,{value:t},{transition:n}){e[co]=e.style.display===`none`?``:e.style.display,n&&t?n.beforeEnter(e):fo(e,t)},mounted(e,{value:t},{transition:n}){n&&t&&n.enter(e)},updated(e,{value:t,oldValue:n},{transition:r}){!t!=!n&&(r?t?(r.beforeEnter(e),fo(e,!0),r.enter(e)):r.leave(e,()=>{fo(e,!1)}):fo(e,t))},beforeUnmount(e,{value:t}){fo(e,t)}};function fo(e,t){e.style.display=t?e[co]:`none`,e[lo]=!t}var po=Symbol(``),mo=/(?:^|;)\s*display\s*:/;function ho(e,t,n){let r=e.style,i=w(n),a=!1;if(n&&!i){if(t){if(w(t))for(let e of t.split(`;`)){let t=e.slice(0,e.indexOf(`:`)).trim();n[t]??_o(r,t,``)}else for(let e in t)n[e]??_o(r,e,``)}for(let i in n){i===`display`&&(a=!0);let o=n[i];o==null?_o(r,i,``):xo(e,i,!w(t)&&t?t[i]:void 0,o)||_o(r,i,o)}}else if(i){if(t!==n){let e=r[po];e&&(n+=`;`+e),r.cssText=n,a=mo.test(n)}}else t&&e.removeAttribute(`style`);co in e&&(i&&t===n||(e[co]=a?r.display:``),e[lo]&&(r.display=`none`))}var go=/\s*!important$/;function _o(e,t,n){if(b(n))n.forEach(n=>_o(e,t,n));else if(n??=``,t.startsWith(`--`))go.test(n)?e.setProperty(t,n.replace(go,``),`important`):e.setProperty(t,n);else{let r=bo(e,t);go.test(n)?e.setProperty(pe(r),n.replace(go,``),`important`):e[r]=n}}var vo=[`Webkit`,`Moz`,`ms`],yo={};function bo(e,t){let n=yo[t];if(n)return n;let r=de(t);if(r!==`filter`&&r in e)return yo[t]=r;r=me(r);for(let n=0;n<vo.length;n++){let i=vo[n]+r;if(i in e)return yo[t]=i}return t}function xo(e,t,n,r){return e.tagName===`TEXTAREA`&&(t===`width`||t===`height`)&&w(r)&&n===r}var So=`http://www.w3.org/1999/xlink`;function Co(e,t,n,r,i,a=Oe(t)){r&&t.startsWith(`xlink:`)?n==null?e.removeAttributeNS(So,t.slice(6,t.length)):e.setAttributeNS(So,t,n):n==null||a&&!ke(n)?e.removeAttribute(t):e.setAttribute(t,a?``:te(n)?String(n):n)}function wo(e,t,n,r,i){if(t===`innerHTML`||t===`textContent`){n!=null&&(e[t]=t===`innerHTML`?eo(n):n);return}let a=e.tagName;if(t===`value`&&a!==`PROGRESS`&&!a.includes(`-`)){let r=a===`OPTION`?e.getAttribute(`value`)||``:e.value,i=n==null?e.type===`checkbox`?`on`:``:String(n);r===i&&`_value`in e||(e.value=i),n??e.removeAttribute(t),e._value=n;return}let o=!1;if(n===``||n==null){let r=typeof e[t];r===`boolean`?n=ke(n):n==null&&r===`string`?(n=``,o=!0):r===`number`&&(n=0,o=!0)}try{e[t]=n}catch{}o&&e.removeAttribute(i||t)}function To(e,t,n,r){e.addEventListener(t,n,r)}function Eo(e,t,n,r){e.removeEventListener(t,n,r)}var Do=Symbol(`_vei`);function Oo(e,t,n,r,i=null){let a=e[Do]||(e[Do]={}),o=a[t];if(r&&o)o.value=r;else{let[n,s]=jo(t);r?To(e,n,a[t]=Fo(r,i),s):o&&(Eo(e,n,o,s),a[t]=void 0)}}var ko=/(Once|Passive|Capture)$/,Ao=/^on:?(?:Once|Passive|Capture)$/;function jo(e){let t,n;for(;(n=e.match(ko))&&!Ao.test(e);)t||={},e=e.slice(0,e.length-n[1].length),t[n[1].toLowerCase()]=!0;return[e[2]===`:`?e.slice(3):pe(e.slice(2)),t]}var Mo=0,No=Promise.resolve(),Po=()=>Mo||=(No.then(()=>Mo=0),Date.now());function Fo(e,t){let n=e=>{if(!e._vts)e._vts=Date.now();else if(e._vts<=n.attached)return;let r=n.value;if(b(r)){let n=e.stopImmediatePropagation;e.stopImmediatePropagation=()=>{n.call(e),e._stopped=!0};let i=r.slice(),a=[e];for(let n=0;n<i.length&&!e._stopped;n++){let e=i[n];e&&En(e,t,5,a)}}else En(r,t,5,[e])};return n.value=e,n.attached=Po(),n}var Io=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Lo=(e,t,n,r,i,a)=>{let o=i===`svg`;t===`class`?so(e,r,o):t===`style`?ho(e,n,r):m(t)?h(t)||Oo(e,t,n,r,a):(t[0]===`.`?(t=t.slice(1),1):t[0]===`^`?(t=t.slice(1),0):Ro(e,t,r,o))?(wo(e,t,r),e.tagName.includes(`-`)||t!==`value`&&t!==`checked`&&t!==`selected`||Co(e,t,r,o,a,t!==`value`)):e._isVueCE&&(zo(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!w(r)))?wo(e,de(t),r,a,t):(t===`true-value`?e._trueValue=r:t===`false-value`&&(e._falseValue=r),Co(e,t,r,o))};function Ro(e,t,n,r){if(r)return!!(t===`innerHTML`||t===`textContent`||t in e&&Io(t)&&C(n));if(t===`spellcheck`||t===`draggable`||t===`translate`||t===`autocorrect`||t===`sandbox`&&e.tagName===`IFRAME`||t===`form`||t===`list`&&e.tagName===`INPUT`||t===`type`&&e.tagName===`TEXTAREA`)return!1;if(t===`width`||t===`height`){let t=e.tagName;if(t===`IMG`||t===`VIDEO`||t===`CANVAS`||t===`SOURCE`)return!1}return Io(t)&&w(n)?!1:t in e}function zo(e,t){let n=e._def.props;if(!n)return!1;let r=de(t);return Array.isArray(n)?n.some(e=>de(e)===r):Object.keys(n).some(e=>de(e)===r)}var Bo=e=>{let t=e.props[`onUpdate:modelValue`]||!1;return b(t)?e=>_e(t,e):t};function Vo(e){e.target.composing=!0}function Ho(e){let t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event(`input`)))}var Uo=Symbol(`_assign`),Wo=Symbol(`_initialValue`);function Go(e,t,n){return t&&(e=e.trim()),n&&(e=ye(e)),e}var Ko={created(e,{modifiers:{lazy:t,trim:n,number:r}},i){e.parentNode&&(e.type===`text`?e[Wo]=e.defaultValue.replace(/[\r\n]/g,``):e.type===`textarea`&&(e[Wo]=e.defaultValue.replace(/\r\n?/g,`
`))),e[Uo]=Bo(i);let a=r||i.props&&i.props.type===`number`;To(e,t?`change`:`input`,t=>{t.target.composing||e[Uo](Go(e.value,n,a))}),(n||a)&&To(e,`change`,()=>{e.value=Go(e.value,n,a)}),t||(To(e,`compositionstart`,Vo),To(e,`compositionend`,Ho),To(e,`change`,Ho))},mounted(e,{value:t,modifiers:{trim:n,number:r}}){let i=t??``,a=e[Wo];delete e[Wo],a!==void 0&&(e.type===`text`||e.type===`textarea`)&&e.value!==a?e[Uo](Go(e.value,n,r)):e.value=i},beforeUpdate(e,{value:t,oldValue:n,modifiers:{lazy:r,trim:i,number:a}},o){if(e[Uo]=Bo(o),e.composing)return;let s=(a||e.type===`number`)&&!/^0\d/.test(e.value)?ye(e.value):e.value,c=t??``;if(s===c)return;let l=e.getRootNode();(l instanceof Document||l instanceof ShadowRoot)&&l.activeElement===e&&e.type!==`range`&&(r&&t===n||i&&e.value.trim()===c)||(e.value=c)}},qo={deep:!0,created(e,t,n){e[Uo]=Bo(n),To(e,`change`,()=>{let t=e._modelValue,n=$o(e),r=e.checked,i=e[Uo];if(b(t)){let e=Fe(t,n),a=e!==-1;if(r&&!a)i(t.concat(n));else if(!r&&a){let n=[...t];n.splice(e,1),i(n)}}else if(S(t)){let e=new Set(t);r?e.add(n):e.delete(n),i(e)}else i(es(e,r))})},mounted:Jo,beforeUpdate(e,t,n){e[Uo]=Bo(n),Jo(e,t,n)}};function Jo(e,{value:t,oldValue:n},r){e._modelValue=t;let i;if(b(t))i=Fe(t,r.props.value)>-1;else if(S(t))i=t.has(r.props.value);else{if(t===n)return;i=Pe(t,es(e,!0))}e.checked!==i&&(e.checked=i)}var Yo={created(e,{value:t},n){e.checked=Pe(t,n.props.value),e[Uo]=Bo(n),To(e,`change`,()=>{e[Uo]($o(e))})},beforeUpdate(e,{value:t,oldValue:n},r){e[Uo]=Bo(r),t!==n&&(e.checked=Pe(t,r.props.value))}},Xo={deep:!0,created(e,{value:t,modifiers:{number:n}},r){e._modelValue=t,To(e,`change`,()=>{let t=Array.prototype.filter.call(e.options,e=>e.selected).map(e=>n?ye($o(e)):$o(e)),r=e.multiple,i=r?S(e._modelValue)?new Set(t):t:t[0],a=e._pendingValue=[r,r?b(i)?t.slice():t:i];try{e[Uo](i)}finally{In(()=>{e._pendingValue===a&&(e._pendingValue=void 0)})}}),e[Uo]=Bo(r)},mounted(e,{value:t}){Qo(e,t)},beforeUpdate(e,{value:t},n){e._modelValue=t,e[Uo]=Bo(n)},updated(e,{value:t}){let n=e._pendingValue;e._pendingValue=void 0,n&&n[0]===e.multiple&&Zo(t,n[1],n[0])||Qo(e,t)}};function Zo(e,t,n){if(!n||b(e))return Pe(e,t);if(S(e)){if(e.size!==t.length)return!1;for(let n of t)if(!e.has(n))return!1;return!0}return!1}function Qo(e,t){let n=e.multiple,r=b(t);if(!n||r||S(t)){for(let i=0,a=e.options.length;i<a;i++){let a=e.options[i],o=$o(a);if(n){if(r){let e=typeof o;a.selected=e===`string`||e===`number`?t.some(e=>String(e)===String(o)):Fe(t,o)>-1}else a.selected=t.has(o)}else if(Pe($o(a),t)){e.selectedIndex!==i&&(e.selectedIndex=i);return}}!n&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function $o(e){return`_value`in e?e._value:e.value}function es(e,t){let n=t?`_trueValue`:`_falseValue`;return n in e?e[n]:t}var ts={created(e,t,n){rs(e,t,n,null,`created`)},mounted(e,t,n){rs(e,t,n,null,`mounted`)},beforeUpdate(e,t,n,r){rs(e,t,n,r,`beforeUpdate`)},updated(e,t,n,r){rs(e,t,n,r,`updated`)}};function ns(e,t){switch(e){case`SELECT`:return Xo;case`TEXTAREA`:return Ko;default:switch(t){case`checkbox`:return qo;case`radio`:return Yo;default:return Ko}}}function rs(e,t,n,r,i){let a=ns(e.tagName,n.props&&n.props.type)[i];a&&a(e,t,n,r)}var is=[`ctrl`,`shift`,`alt`,`meta`],as={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>`button`in e&&e.button!==0,middle:e=>`button`in e&&e.button!==1,right:e=>`button`in e&&e.button!==2,exact:(e,t)=>is.some(n=>e[`${n}Key`]&&!t.includes(n))},os=(e,t)=>{if(!e)return e;let n=e._withMods||={},r=t.join(`.`);return n[r]||(n[r]=((n,...r)=>{for(let e=0;e<t.length;e++){let r=as[t[e]];if(r&&r(n,t))return}return e(n,...r)}))},ss={esc:`escape`,space:` `,up:`arrow-up`,left:`arrow-left`,right:`arrow-right`,down:`arrow-down`,delete:`backspace`},cs=(e,t)=>{let n=e._withKeys||={},r=t.join(`.`);return n[r]||(n[r]=(n=>{if(!(`key`in n))return;let r=pe(n.key);if(t.some(e=>e===r||ss[e]===r))return e(n)}))},ls=g({patchProp:Lo},ao),us;function ds(){return us||=qi(ls)}var fs=((...e)=>{let t=ds().createApp(...e),{mount:n}=t;return t.mount=e=>{let r=ms(e);if(!r)return;let i=t._component;C(i)||i.render||i.template||(i.template=r.innerHTML),r.nodeType===1&&(r.textContent=``);let a=n(r,!1,ps(r));return r instanceof Element&&(r.removeAttribute(`v-cloak`),r.setAttribute(`data-v-app`,``)),a},t});function ps(e){if(e instanceof SVGElement)return`svg`;if(typeof MathMLElement==`function`&&e instanceof MathMLElement)return`mathml`}function ms(e){return w(e)?document.querySelector(e):e}var L=class extends Error{constructor(e){super(e),this.name=`CompileError`}};function hs(e,t){let n=e.type;return typeof n==`string`?n:n.map[String(t[n.property])]??n.default}function gs(e,t,n){for(let t of e??[])if(!t.when||_s(t.when,n))return t.text;return t}function _s(e,t){let n=t[e.field];if(e.equals!==void 0)return n===e.equals;if(e.notEquals!==void 0)return n!==e.notEquals;if(e.in!==void 0)return e.in.includes(n);let r=Number(n);return e.gt===void 0?e.gte===void 0?e.lt===void 0?e.lte===void 0||r<=e.lte:r<e.lt:r>=e.gte:r>e.gt}function vs(e,t){let n=Math.round(Number(t[e.property]));return!Number.isFinite(n)||n<e.min?e.min:Math.min(n,e.max)}function ys(e){return e.map(e=>`"${e}"`).join(`, `)}function bs(e,t,n){let r=n?.capabilities??[];if(r.length===0)return;let i=`node ${t.id} (${t.type})`,a=e.target??null;if(!a){e.warn?.(`${i} needs ${ys(r)}, not checked: no board or processor known.`);return}let o=r.filter(e=>!a.capabilities.has(e));if(o.length===0)return;let s=[...a.capabilities].sort();throw new L(`${i} needs ${ys(o)}, which ${a.label} doesn't provide`+(s.length?` (it has: ${s.join(`, `)}).`:`.`))}function xs(e,t,n={}){let r=new Map;for(let t of e.nodes){if(r.has(t.id))throw new L(`duplicate node id ${t.id}`);r.set(t.id,t)}for(let n of e.nodes)if(!t.has(n.type))throw new L(`unknown node type "${n.type}" (node ${n.id})`);let i=new Map;for(let t of e.configs??[]){if(i.has(t.id))throw new L(`duplicate config id "${t.id}"`);i.set(t.id,t)}let a=new Map,o=new Map;for(let t of e.links){let[,e,,n]=t;if(!r.has(e))throw new L(`link references unknown origin node ${e}`);if(!r.has(n))throw new L(`link references unknown target node ${n}`);a.has(e)||a.set(e,[]),a.get(e).push(t),o.set(n,(o.get(n)??0)+1)}function s(e,t){return(a.get(e)??[]).filter(e=>e[2]===t)}function c(e){let n=t.get(e.type);return n.dynamicOutputs?vs(n.dynamicOutputs,e.properties):n.ports?.outputs?.length??1}let l=e.nodes.filter(e=>t.get(e.type).kind===`source`);for(let e of l)if(o.has(e.id))throw new L(`source node ${e.id} (${e.type}) has an incoming connection -- sources take no input`);function u(e){let n=t.get(e.type);return n.kind!==`source`&&n.codegenEventSource!==void 0}for(let n of e.nodes)if(u(n)&&t.get(n.type).kind!==`sink`)throw new L(`node ${n.id} (${n.type}) defines codegenEventSource but is not a sink -- only sinks can also be event sources`);let d=e.nodes.filter(e=>t.get(e.type).kind===`source`||u(e));if(d.length===0)throw new L(`graph has no source node (e.g. inject) to drive any flow`);for(let n of e.nodes)if(t.get(n.type).kind===`sink`&&!u(n)&&(a.get(n.id)?.length??0)>0)throw new L(`node ${n.id} (${n.type}) is a sink but has an outgoing connection -- sinks must be terminal`);let f=new Map,p=new Set;function m(e,t,n=!1){if(!n&&u(r.get(t))){p.add(t);return}let i=f.get(t);if(i!==`black`){if(i===`gray`)throw new L(`cycle detected in the flow starting at node ${e} (revisits node ${t})`);f.set(t,`gray`),p.add(t);for(let n of a.get(t)??[])m(e,n[3]);f.set(t,`black`)}}for(let e of d)m(e.id,e.id,!0);for(let n of e.nodes)if(!p.has(n.id)&&!t.get(n.type).allowUnwired)throw new L(`node ${n.id} (${n.type}) is disconnected from any source`);let h=new Set,g=new Set(n.hookWarnings??[]),_=new Map,v={target:n.target??null,hookResult(e){return n.hookResults?.get(e)},warn(e){g.add(e)},uniqueName(e){let t=`_${e}`,n=1;for(;h.has(t);)t=`_${e}_${n++}`;return h.add(t),t},resolveConfig(e){let t=i.get(e);if(!t)throw new L(`referenced config "${e}" not found`);return t.properties},findNodesOfType(t){return e.nodes.filter(e=>e.type===t)},findConfigsOfType(e){return[...i.values()].filter(t=>t.type===e)},screens:e.screens,isInputWired:e=>(o.get(e)??0)>0,findWiredTargets:e=>(a.get(e)??[]).map(e=>r.get(e[3])),isOutputWired:e=>(a.get(e)?.length??0)>0,claimResource(e,t,n){let r=_.get(e);if(!r)_.set(e,{use:t,who:n});else if(r.use!==t)throw new L(`${e}: ${n} sets it up as ${t}, but ${r.who} already has it as ${r.use}. Set both up the same way, or use another pin.`)}};for(let n of e.nodes)bs(v,n,t.get(n.type).requires);let y=new Set([`import runtime`]),b=new Map,x=[],S=[],ee=[],C=new Map,w=new Map;function te(e){let n=C.get(e.id);if(!n){let r=t.get(e.type);if(!r.codegenTransform)throw new L(`node type "${e.type}" declares kind "transform" but has no codegenTransform`);n=r.codegenTransform(e,v),Ss(n,y,b),x.push({nodeId:e.id,text:`# node:${e.id}\nasync def ${n.functionName}(msg):\n${ws(n.functionBody,4)}`}),C.set(e.id,n)}return n}function T(e){let n=w.get(e.id);if(!n){let r=t.get(e.type);if(!r.codegenSink)throw new L(`node type "${e.type}" declares kind "sink" but has no codegenSink`);n=r.codegenSink(e,v),Ss(n,y,b),x.push({nodeId:e.id,text:`# node:${e.id}\nasync def ${n.functionName}(msg):\n${ws(n.functionBody,4)}`}),w.set(e.id,n)}return n}function ne(e,n){let i=r.get(e),o=t.get(i.type).kind;if(o===`sink`){let e=T(i);return Cs(i.id,`await ${e.functionName}(${n})`)}if(o!==`transform`)throw new L(`node ${i.id} (${i.type}) of kind "${o}" cannot appear downstream of another node (only "transform" and "sink" can)`);let l=te(i),u=c(i);if(u<=1){let t=Cs(i.id,`${n} = await ${l.functionName}(${n})`),r=re(a.get(e)??[],n);return r?`${t}\nif ${n} is not None:\n${ws(r,4)}`:t}let d=v.uniqueName(`outputs`),f=[Cs(i.id,`${d} = await ${l.functionName}(${n})`),`if not isinstance(${d}, list):`,`    ${d} = [${d}]`];for(let t=0;t<u;t++){let n=s(e,t);if(n.length===0)continue;let r=v.uniqueName(`out${t}`),i=v.uniqueName(`msg_out`),a=v.uniqueName(`out_msgs`),o=re(n,i)||`pass`;f.push(`${r} = ${d}[${t}] if len(${d}) > ${t} else None`),f.push(`if ${r} is not None:`),f.push(ws([`if isinstance(${r}, list):`,`    ${a} = ${r}`,`else:`,`    ${a} = [${r}]`,`for ${i} in ${a}:`,ws(o,4)].join(`
`),4))}return f.join(`
`)}function re(e,t){if(e.length===0)return``;let n=[],r=e.map((e,r)=>{if(r===0)return t;let i=v.uniqueName(`msg_branch`);return n.push(`${i} = dict(${t})`),i}),i=e.map((e,t)=>ne(e[3],r[t])).filter(e=>e.length>0);return[...n,...i].join(`
`)}d.forEach((e,n)=>{let r=t.get(e.type),i=re(a.get(e.id)??[],`msg`),o;if(r.codegenEventSource){let t=r.codegenEventSource(e,v);Ss(t,y,b);let n=[t.waitStatement,t.buildMsg];i&&n.push(`if msg is not None:\n${ws(i,4)}`),o=`while True:\n${ws(n.join(`
`),4)}`}else if(r.codegenSource){let t=r.codegenSource(e,v);Ss(t,y,b);let n=[t.buildMsg];i&&n.push(`if msg is not None:\n${ws(i,4)}`),t.repeatMs>0&&n.push(`await asyncio.sleep_ms(${t.repeatMs})`),o=t.repeatMs>0?`while True:\n${ws(n.join(`
`),4)}`:n.join(`
`)}else throw new L(`node type "${e.type}" declares kind "source" but has no codegenSource or codegenEventSource`);let s=v.uniqueName(`flow_${n}`);S.push(`async def ${s}():\n${ws(o,4)}`),ee.push(`runtime.spawn(${s}(), "${e.id}")`)});let ie=[],ae=0;function oe(e){ie.push(e),ae+=e.split(`
`).length}oe(`# --- generated by the Thingstudio compiler (${new Date().toISOString()}) ---`),oe(`# See design doc §6 for the graph/compiler model this implements.`);for(let e of y)oe(e);oe(`asyncio = runtime.asyncio`),oe(``);for(let e of b.values())oe(e);oe(``);let se=[];for(let e of x){let t=ae+1;oe(e.text),se.push({nodeId:e.nodeId,startLine:t,endLine:ae})}oe(``);for(let e of S)oe(e);oe(``);for(let e of ee)oe(e);return oe(``),{source:ie.join(`
`),nodeLineRanges:se,warnings:[...g]}}function Ss(e,t,n){for(let n of e.imports??[])t.add(n);for(let t of e.statements??[])n.has(t.key)||n.set(t.key,t.code)}function Cs(e,t){return`try:\n${ws(t,4)}\nexcept Exception as _e:\n    raise runtime.NodeError("${e}", _e)`}function ws(e,t){let n=` `.repeat(t);return e.split(`
`).map(e=>e.length?n+e:e).join(`
`)}function Ts(e){return JSON.stringify(String(e))}function Es(e,t,n){switch(e){case`bool`:return t===`true`||t===!0?`True`:`False`;case`number`:{let e=Number(t);if(Number.isNaN(e))throw new L(`${n} value "${String(t)}" is not a valid number`);return String(e)}default:return Ts(String(t))}}var Ds=`thingstudio/config/wifi`,Os=[`thingstudio/wifi_status`,`thingstudio/wifi_gate`,`thingstudio/udp_send`,`thingstudio/udp_receive`,`thingstudio/http_request`,`thingstudio/http_in`,`thingstudio/mqtt_publish`,`thingstudio/mqtt_subscribe`];function ks(e,t){let n=t.filter(e=>e.type===Ds);if(n.length===0)return{nodes:e,configs:t,dropped:[]};let r=e=>typeof e.properties.wifiConfigId==`string`?e.properties.wifiConfigId:``,i=e=>n.some(t=>t.id===e),a=e.filter(e=>e.type===`thingstudio/wifi_status`).map(r).find(i),o=e.map(r).find(i),s=a??o??n[0].id,c=n.filter(e=>e.id!==s);return{nodes:e.map(e=>`wifiConfigId`in e.properties&&e.properties.wifiConfigId!==s?{...e,properties:{...e.properties,wifiConfigId:s}}:e),configs:t.filter(e=>!c.includes(e)),dropped:c}}function As(e){if(!e.nodes.some(e=>Os.includes(e.type)))return null;let t=(e.configs??[]).filter(e=>e.type===Ds);if(t.length!==1)return null;let n=t[0];return n.properties.security===`unmanaged`?{selfProvision:!0,allowReprovision:n.properties.allowReprovisioning===!0}:null}var js={type:`thingstudio/debug`,kind:`sink`,paletteId:`debug`,label:`debug`,group:`general`,priority:50,color:`#2e4a6e`,bgcolor:`#1f2c3f`,icon:`≡`,width:84,description:`Prints msg.payload to the console, so you can see what's flowing through a wire.`,ports:{inputs:[{name:`msg`,type:`any`}]},properties:[{name:`fullMessage`,label:`full message`,kind:`boolean`,default:!1,help:`Print the whole message (topic and any extra fields a source adds) instead of just payload.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Ms=`async def run(msg, properties):
    if properties['fullMessage']:
        print("DEBUG node=%s msg=%r" % (properties['nodeId'], msg))
    else:
        print("DEBUG node=%s payload=%r" % (properties['nodeId'], msg.get('payload')))
`,Ns={type:`thingstudio/display_i2c`,kind:`sink`,paletteId:`display_i2c`,label:`display i2c`,group:`hardware`,priority:41,color:`#3f2e8a`,bgcolor:`#1f144a`,icon:`▦`,width:128,presetType:`display_i2c`,description:`Shows a frame on an I2C mono OLED. msg.payload is a MONO_VLSB framebuffer of width × height/8 bytes, built upstream.`,ports:{inputs:[{name:`frame`,type:`bytes`}]},resources:[{kind:`i2c`,config:`i2cConfigId`,fallback:{bus:`i2cBus`,scl:`scl`,sda:`sda`,freq:`freq`}}],properties:[{name:`controller`,label:`controller`,kind:`select`,default:`ssd1306`,options:[{value:`ssd1306`,label:`SSD1306`}]},{name:`i2cConfigId`,label:`I2C bus`,kind:`configRef`,configType:`thingstudio/config/i2c-bus`,default:``},{name:`addr`,label:`address`,kind:`number`,default:60,min:0,max:127},{name:`width`,label:`width (px)`,kind:`number`,default:128,min:1},{name:`height`,label:`height (px, multiple of 8)`,kind:`number`,default:64,min:8,step:8},{name:`i2cBus`,label:`i2c bus`,kind:`number`,default:0,hidden:!0},{name:`scl`,label:`scl pin`,kind:`pin`,default:``,optional:!0,hidden:!0},{name:`sda`,label:`sda pin`,kind:`pin`,default:``,optional:!0,hidden:!0},{name:`freq`,label:`frequency (Hz)`,kind:`number`,default:4e5,hidden:!0}]},Ps=`import machine
from ssd1306 import SSD1306_I2C

_bus = properties['i2cConfigId']
_legacy_bus = properties['i2cBus']
_legacy_scl = properties['scl']
_legacy_sda = properties['sda']
_legacy_freq = properties['freq']
_addr = properties['addr']
_width = properties['width']
_height = properties['height']

if _bus is not None:
    _bus_num = int(_bus['bus'])
    _scl = _bus['scl']
    _sda = _bus['sda']
    _freq = _bus['freq']
else:
    # Legacy: the pins live on the node itself (a flow saved before the shared bus config).
    _bus_num = 0 if _legacy_bus is None else int(_legacy_bus)
    _scl = _legacy_scl
    _sda = _legacy_sda
    _freq = 400000 if _legacy_freq is None else _legacy_freq

_i2c = runtime.shared('i2c', _bus_num, (_scl, _sda, _freq),
                      lambda: machine.I2C(_bus_num, scl=machine.Pin(_scl), sda=machine.Pin(_sda), freq=_freq))
_disp = SSD1306_I2C(_width, _height, _i2c, addr=_addr)
_expected = _width * (_height // 8)


async def run(msg, properties):
    _buf = msg.get('payload', b'')
    if len(_buf) != _expected:
        raise ValueError('display_i2c: expected %d bytes (%dx%d MONO_VLSB), got %d' % (_expected, _width, _height, len(_buf)))
    _disp.buffer[:] = _buf
    _disp.show()
`,Fs=`thingstudio/config/gui-theme`,Is=[`bg`,`card`,`fg`,`muted`,`track`,`accent`,`on_accent`,`ok`,`warn`,`alarm`],Ls={bg:`background`,card:`card`,fg:`foreground`,muted:`muted (stale values)`,track:`track (bar and cell background)`,accent:`accent (bars, lights)`,on_accent:`text on accent`,ok:`ok`,warn:`warn`,alarm:`alarm`};function Rs(){return[...Object.entries(Vs).map(([e,t])=>({value:e,label:t.label})),{value:``,label:`custom (keep what is set)`}]}function zs(e,t,n){e[t]=n;let r=Vs[n];if(r)for(let t of Is)e[t]=r.roles[t]}function Bs(){return{bg:0,card:0,fg:65535,muted:25388,track:25388,accent:16113,on_accent:0,ok:65535,warn:65535,alarm:65535}}var Vs={"dark-slate":{label:`dark slate`,roles:{bg:4258,card:8484,fg:65535,muted:35953,track:16904,accent:16113,on_accent:2113,ok:15974,warn:64608,alarm:63488}},"light-paper":{label:`light paper`,roles:{bg:65535,card:61277,fg:2113,muted:35953,track:52825,accent:592,on_accent:65535,ok:7269,warn:50176,alarm:45056}},vivid:{label:`vivid`,roles:{bg:2116,card:26971,fg:65535,muted:46425,track:14699,accent:1855,on_accent:131,ok:1838,warn:65056,alarm:63656}}};function Hs(e,t){if(t===`rgb565`)return{values:{...e},shades:!0};if(t===`gs4`){let t=Is.map(t=>e[t]);for(;t.length<16;)t.push(0);let n={...e};return Is.forEach((e,t)=>{n[e]=t}),{values:n,palette:t,shades:!0}}let n=t===`gs2`,r=n?[e.bg,e.fg,e.muted,e.accent]:[e.bg,e.fg],i={bg:0,card:0,fg:1,muted:n?2:1,track:n?2:1,accent:n?3:1,on_accent:0,ok:1,warn:1,alarm:1},a={...e};for(let e of Is)a[e]=i[e];return{values:a,palette:r,shades:n}}function Us(e,t){let n=e=>t?(e&255)<<8|e>>8:e,r=e=>`0x${n(e).toString(16).padStart(4,`0`)}`;return`{${Is.map(t=>`'${t}': ${r(e[t])}`).join(`, `)}}`}function Ws(e,t,n){let r=Vs[typeof e[t]==`string`?e[t]:``],i={...r?r.roles:Bs()};for(let t of Is){let r=e[t];if(r==null||r===``)continue;let a=Number(r);if(!Number.isInteger(a)||a<0||a>65535)throw new L(`${n} "${t}" must be an RGB565 colour (0-65535), got "${String(r)}"`);i[t]=a}return i}function Gs(e){return(typeof e.themePreset==`string`?e.themePreset:``)!==``||Is.some(t=>e[t]!==void 0&&e[t]!==null&&e[t]!==``)}function Ks(e,t){let n=t.properties;if(Gs(n)){let e=typeof n.themePreset==`string`?n.themePreset:``;if(e!==``&&!Vs[e])throw new L(`GUI screen theme: unknown starting point "${e}"`);return Ws(n,`themePreset`,`GUI screen theme`)}let r=n.themeConfigId;return typeof r!=`string`||r===``?Bs():Ws(e.resolveConfig(r),`preset`,`GUI theme`)}var qs=[0,65535,63488,2016,31,65504,2047,63519,33808,16904,50712,64800,32768,1024,16,1040],Js={gs4:16,gs2:4,mono:2},Ys={type:`thingstudio/display_spi`,kind:`sink`,paletteId:`display_spi`,label:`display spi`,group:`hardware`,priority:40,color:`#4a3f8a`,bgcolor:`#2a1f4a`,icon:`▤`,width:128,presetType:`display_spi`,description:`Shows a frame on an SPI colour TFT. msg.payload is a framebuffer in the frame format below, usually from a gui screen. Set the pins from your board's pinout.`,resources:[{kind:`spi`,bus:`spiBus`,sck:`sck`,mosi:`mosi`,baudrate:`baudrate`},{kind:`pin`,property:`dc`,direction:`output`,use:`display DC`},{kind:`pin`,property:`cs`,direction:`output`,use:`SPI CS`,optional:!0},{kind:`pin`,property:`reset`,direction:`output`,use:`output`,optional:!0},{kind:`pin`,property:`backlight`,direction:`output`,use:`output`,optional:!0}],ports:{inputs:[{name:`frame`,type:`bytes`}]},properties:[{name:`orientation`,label:`orientation`,kind:`select`,default:``,options:[{value:``,label:`off (raw rotation)`},{value:`0`,label:`0 degrees (the panel's own)`},{value:`90`,label:`90 degrees clockwise`},{value:`180`,label:`180 degrees`},{value:`270`,label:`270 degrees clockwise`}],help:`Width and height are the panel's own size; rotation is how the panel is mounted (0 to 3). A gui screen wired to this display turns its size and touch to match.`},{name:`controller`,label:`controller`,kind:`select`,default:`st7789`,options:[{value:`st7789`,label:`ST7789`},{value:`st7796`,label:`ST7796 (320x480)`}]},{name:`frameFormat`,label:`frame format`,kind:`select`,default:`rgb565`,options:[{value:`rgb565`,label:`RGB565 (full color, default)`},{value:`gs4`,label:`GS4 4-bit indexed (1/4 the memory, 16-color palette)`},{value:`gs2`,label:`GS2 2-bit indexed (1/8 the memory, 4-color palette)`},{value:`mono`,label:`Mono 1-bit indexed (1/16 the memory, 2-color palette)`}],help:`Byte-swap an RGB565 buffer before sending it, or colours come out wrong. Indexed formats use the palette below.`},{name:`palette`,label:`palette`,kind:`palette`,default:[...qs]},{name:`spiBus`,label:`SPI bus`,kind:`number`,default:2,min:0},{name:`baudrate`,label:`baudrate`,kind:`number`,default:4e7,min:1},{name:`sck`,label:`sck pin`,kind:`pin`,default:12},{name:`mosi`,label:`mosi pin`,kind:`pin`,default:11},{name:`dc`,label:`dc pin`,kind:`pin`,default:13},{name:`cs`,label:`cs pin (-1 = not wired)`,kind:`pin`,default:-1,optional:!0},{name:`reset`,label:`reset pin (-1 = not wired)`,kind:`pin`,default:-1,optional:!0},{name:`backlight`,label:`backlight pin (-1 = not wired)`,kind:`pin`,default:-1,optional:!0},{name:`width`,label:`width (px)`,kind:`number`,default:135,min:1},{name:`height`,label:`height (px)`,kind:`number`,default:240,min:1},{name:`rotation`,label:`rotation (0-7)`,kind:`number`,default:1,min:0,max:7},{name:`colorOrder`,label:`color order`,kind:`select`,default:`bgr`,options:[{value:`bgr`,label:`BGR (default)`},{value:`rgb`,label:`RGB`}]},{name:`invertColors`,label:`invert colors`,kind:`boolean`,default:!1},{name:`dataLatchOrder`,label:`data latch order (MH bit)`,kind:`boolean`,default:!0},{name:`xstart`,label:`xstart (-1 = auto)`,kind:`number`,default:-1,min:-1},{name:`ystart`,label:`ystart (-1 = auto)`,kind:`number`,default:-1,min:-1}]};function Xs(e){return`{`+Is.map(t=>`'${t}': 0x${e[t].toString(16).padStart(4,`0`)}`).join(`, `)+`}`}var Zs=Xs(Bs()),Qs=Object.entries(Vs).map(([e,t])=>`    '${e}': ${Xs(t.roles)},`).join(`
`),$s=`MADCTL_MY = 0x80
MADCTL_MX = 0x40
MADCTL_MV = 0x20
MADCTL_BGR = 0x08
MADCTL_MH = 0x04
ROTATION_BITS = (0, MADCTL_MX, MADCTL_MY, MADCTL_MX | MADCTL_MY,
                 MADCTL_MV, MADCTL_MV | MADCTL_MX, MADCTL_MV | MADCTL_MY, MADCTL_MV | MADCTL_MX | MADCTL_MY)
PIXELS_PER_BYTE = {'gs4': 2, 'gs2': 4, 'mono': 8}
BITS_PER_PIXEL = {'gs4': 4, 'gs2': 2, 'mono': 1}
ENTRIES_USED = {'gs4': 16, 'gs2': 4, 'mono': 2}
FRAMEBUF_ATTR = {'gs4': 'GS4_HMSB', 'gs2': 'GS2_HMSB', 'mono': 'MONO_HMSB'}
DEFAULT_PALETTE = [0x0000, 0xffff, 0xf800, 0x07e0, 0x001f, 0xffe0, 0x07ff, 0xf81f,
                   0x8410, 0x4208, 0xc618, 0xfd20, 0x8000, 0x0400, 0x0010, 0x0410]


def _whole(props, name, dflt, low, what):
    raw = props.get(name)
    if raw is None or raw == '':
        raw = dflt
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None, 'display_spi %s "%s" must be a whole number, %d or more' % (what, raw, low)
    if value < low:
        return None, 'display_spi %s "%s" must be a whole number, %d or more' % (what, raw, low)
    return value, None


def _turned(width, height, angle):
    return (height, width) if angle in (90, 270) else (width, height)


def _from_turned(n, w, h, angle):
    if angle == 0:
        return n
    if angle == 90:
        return (w - 1 - n[1], n[0])
    if angle == 180:
        return (w - 1 - n[0], h - 1 - n[1])
    return (n[1], h - 1 - n[0])


def _madctl_map(bits, l, pw, ph):
    t = (l[1], l[0]) if bits & MADCTL_MV else l
    return ((pw - 1 - t[0]) if bits & MADCTL_MX else t[0], (ph - 1 - t[1]) if bits & MADCTL_MY else t[1])


def _oriented_madctl(base_bits, angle, width, height):
    if base_bits & MADCTL_MV:
        return None
    tw, th = _turned(width, height, angle)
    for bits in range(8):
        axes = bits << 5
        ok = True
        for n in ((0, 0), (tw - 1, 0), (0, th - 1), (1, 2), (tw - 2, 3)):
            old = _from_turned(n, width, height, angle)
            if _madctl_map(axes, n, width, height) != _madctl_map(base_bits, old, width, height):
                ok = False
                break
        if ok:
            return axes
    return None



# A gui screen's theme owns the palette while it is wired to this display (2026-10-23,
# gui-widget-styles-and-colour-scoping.md). The fold has to exist in Python too, because this package decides the
# palette. The role list, default and preset table are generated from gui-theme-shared.ts above, so there is one
# source; editor/test/display-spi-theme-palette.test.ts runs the real hook against resolveThemeForFormat() for
# every preset and format.
_THEME_ROLES = (${Is.map(e=>`'${e}'`).join(`, `)})
_THEME_DEFAULT = ${Zs}
_THEME_PRESETS = {
${Qs}
}


def _roles_from(props, preset_key):
    """Roles from form properties: the named starting point's, then any role set on top."""
    preset = _THEME_PRESETS.get(str(props.get(preset_key) or ''))
    theme = dict(preset) if preset else dict(_THEME_DEFAULT)
    for role in _THEME_ROLES:
        if role in props and props[role] not in (None, ''):
            theme[role] = int(props[role])
    return theme


def _theme_of(ctx, panel_id):
    """(roles, screen id) of the gui screen wired to this display and using a theme, or (None, None). The screen's
    own themePreset/roles win (2026-10-24); a themeConfigId shared config is the older path."""
    links = ctx['flow'].get('links') or []
    nodes = ctx['flow'].get('nodes') or []
    for link in links:
        if len(link) < 3 or link[2] != panel_id:
            continue
        source = None
        for n in nodes:
            if n['id'] == link[0]:
                source = n
                break
        if source is None or source['type'] != 'thingstudio/gui_screen':
            continue
        props = source.get('properties') or {}
        own_preset = str(props.get('themePreset') or '')
        own_roles = False
        for role in _THEME_ROLES:
            if role in props and props[role] not in (None, ''):
                own_roles = True
                break
        if own_preset or own_roles:
            return _roles_from(props, 'themePreset'), source['id']
        theme_id = str(props.get('themeConfigId') or '')
        if not theme_id:
            continue
        for c in ctx['flow'].get('configs') or []:
            if c['id'] == theme_id and c['type'] == 'thingstudio/config/gui-theme':
                return _roles_from(c.get('properties') or {}, 'preset'), source['id']
    return None, None


def _theme_palette(theme, fmt):
    """The palette this format reads, folded from the roles (the same fold as gui-theme-shared.ts)."""
    if fmt == 'gs4':
        palette = [theme[role] for role in _THEME_ROLES]
        while len(palette) < 16:
            palette.append(0)
        return palette
    if fmt == 'gs2':
        return [theme['bg'], theme['fg'], theme['muted'], theme['accent']]
    return [theme['bg'], theme['fg']]

def compile(ctx, properties):
    controller = str(properties.get('controller') or 'st7789')
    if controller not in ('st7789', 'st7796'):
        return {'errors': ['display_spi controller "%s" must be st7789 or st7796' % controller]}
    fmt = str(properties.get('frameFormat') or 'rgb565')
    if fmt not in ('rgb565', 'gs4', 'gs2', 'mono'):
        return {'errors': ['display_spi frameFormat "%s" must be rgb565, gs4, gs2 or mono' % fmt]}
    indexed = fmt != 'rgb565'
    palette = None
    warnings = []
    if indexed:
        raw_palette = properties.get('palette')
        if raw_palette is None:
            raw_palette = DEFAULT_PALETTE
        if not isinstance(raw_palette, list) or len(raw_palette) != 16:
            return {'errors': ['display_spi palette must be an array of exactly 16 RGB565 values (0-65535)']}
        palette = []
        for i, entry in enumerate(raw_palette):
            try:
                value = int(entry)
            except (TypeError, ValueError):
                return {'errors': ['display_spi palette[%d] "%s" must be an integer 0-65535 (a raw RGB565 value)' % (i, entry)]}
            if value < 0 or value > 0xffff:
                return {'errors': ['display_spi palette[%d] "%s" must be an integer 0-65535 (a raw RGB565 value)' % (i, entry)]}
            palette.append(value)
        palette = palette[:ENTRIES_USED[fmt]]
        theme, screen_id = _theme_of(ctx, ctx['node']['id'])
        if theme is not None:
            # Warn only if this display's palette was actually changed from the shipped default: the default is
            # what a flow carries without anyone thinking about it, and warning on it would be noise.
            shipped = list(DEFAULT_PALETTE)[:ENTRIES_USED[fmt]]
            if raw_palette is not None and [int(v) for v in raw_palette][:ENTRIES_USED[fmt]] != shipped:
                warnings.append("the theme on the wired gui screen sets this display's palette; the palette set on "
                                "this display is ignored while that screen is wired to it")
            palette = _theme_palette(theme, fmt)[:ENTRIES_USED[fmt]]

    spi_bus, err = _whole(properties, 'spiBus', 2, 0, 'spiBus')
    if err:
        return {'errors': [err]}
    baud, err = _whole(properties, 'baudrate', 40000000, 1, 'baudrate')
    if err:
        return {'errors': [err]}
    panel_width, err = _whole(properties, 'width', 135, 1, 'width')
    if err:
        return {'errors': [err]}
    panel_height, err = _whole(properties, 'height', 240, 1, 'height')
    if err:
        return {'errors': [err]}
    rotation, err = _whole(properties, 'rotation', 1, 0, 'rotation')
    if err:
        return {'errors': [err]}
    if rotation > 7:
        return {'errors': ['display_spi rotation "%s" must be an integer 0-7' % properties.get('rotation')]}
    color_order = str(properties.get('colorOrder') or 'bgr')
    if color_order not in ('rgb', 'bgr'):
        return {'errors': ['display_spi colorOrder "%s" must be rgb or bgr' % color_order]}
    invert = properties.get('invertColors') is True
    latch = properties.get('dataLatchOrder') is not False
    xstart, err = _whole(properties, 'xstart', -1, -1, 'xstart')
    if err:
        return {'errors': [err]}
    ystart, err = _whole(properties, 'ystart', -1, -1, 'ystart')
    if err:
        return {'errors': [err]}

    angle = None
    raw_angle = properties.get('orientation')
    if raw_angle is not None and raw_angle != '':
        try:
            angle = int(raw_angle)
        except (TypeError, ValueError):
            angle = -1
        if angle not in (0, 90, 180, 270):
            return {'errors': ['display_spi orientation "%s" must be 0, 90, 180 or 270' % raw_angle]}
        if rotation > 3:
            return {'errors': ['display_spi rotation %d swaps axes: with an orientation, use 0 to 3 for how the panel is mounted' % rotation]}
        if xstart != -1 or ystart != -1 or (panel_width == 135 and panel_height == 240):
            return {'errors': ["display_spi: an orientation isn't supported with a panel offset (xstart/ystart, or a 135x240 panel) yet. Clear the orientation, or set rotation by hand."]}
        width, height = _turned(panel_width, panel_height, angle)
        axis = _oriented_madctl(ROTATION_BITS[rotation], angle, panel_width, panel_height)
        if axis is None:
            return {'errors': ['display_spi: no display orientation matches a turn of %d degrees' % angle]}
    else:
        width, height = panel_width, panel_height
        axis = ROTATION_BITS[rotation]

    madctl = axis | (MADCTL_MH if latch else 0) | (MADCTL_BGR if color_order == 'bgr' else 0)
    if indexed:
        stride = (width + PIXELS_PER_BYTE[fmt] - 1) // PIXELS_PER_BYTE[fmt]
        expected = stride * height
        row_bytes = stride
        fmt_note = '%dx%d %s/framebuf.%s, %dbpp, %d bytes/row' % (width, height, fmt, FRAMEBUF_ATTR[fmt], BITS_PER_PIXEL[fmt], stride)
    else:
        stride = None
        expected = width * height * 2
        row_bytes = width * 2
        fmt_note = '%dx%d RGB565' % (width, height)

    return {'properties': {
        'controller': controller, 'frameFormat': fmt, 'indexed': indexed,
        'palette': palette, 'spiBus': spi_bus, 'baudrate': baud,
        'sck': int(properties.get('sck', 12)), 'mosi': int(properties.get('mosi', 11)),
        'dc': int(properties.get('dc', 13)),
        'cs': int(properties.get('cs', -1)) if properties.get('cs') not in (None, '') else -1,
        'reset': int(properties.get('reset', -1)) if properties.get('reset') not in (None, '') else -1,
        'backlight': int(properties.get('backlight', -1)) if properties.get('backlight') not in (None, '') else -1,
        'width': width, 'height': height, 'panelWidth': panel_width, 'panelHeight': panel_height,
        'rotation': rotation, 'madctl': madctl, 'invertColors': invert, 'dataLatchOrder': latch,
        'xstart': xstart, 'ystart': ystart, 'stride': stride, 'expected': expected,
        'rowBytes': row_bytes, 'formatNote': fmt_note,
    }, 'warnings': warnings}
`,ec=`import array
import machine
import micropython
import st7789py
from st7789py import ST7789, ST7789_MADCTL
from st7796py import ST7796
import runtime

_spi = runtime.shared(
    'spi', properties['spiBus'], (properties['sck'], properties['mosi'], properties['baudrate']),
    lambda: machine.SPI(properties['spiBus'], baudrate=properties['baudrate'], polarity=0, phase=0,
                        sck=machine.Pin(properties['sck']), mosi=machine.Pin(properties['mosi'])))
_dc = runtime.shared('pin', properties['dc'], ('out', 'none'), lambda: machine.Pin(properties['dc'], machine.Pin.OUT))
_cs = None
if properties['cs'] >= 0:
    _cs = runtime.shared('pin', properties['cs'], ('out', 'none'), lambda: machine.Pin(properties['cs'], machine.Pin.OUT))
_rst = None
if properties['reset'] >= 0:
    _rst = runtime.shared('pin', properties['reset'], ('out', 'none'), lambda: machine.Pin(properties['reset'], machine.Pin.OUT))
_bl = None
if properties['backlight'] >= 0:
    _bl = runtime.shared('pin', properties['backlight'], ('out', 'none'), lambda: machine.Pin(properties['backlight'], machine.Pin.OUT))

_Driver = ST7796 if properties['controller'] == 'st7796' else ST7789
_disp = _Driver(_spi, properties['width'], properties['height'], _rst, _dc, cs=_cs, backlight=_bl,
                xstart=properties['xstart'], ystart=properties['ystart'])
_disp.init()
_disp.inversion_mode(properties['invertColors'])
_disp.write(ST7789_MADCTL, bytes([properties['madctl']]))
if _bl is not None:
    _bl.value(1)

_width = properties['width']
_height = properties['height']
_stride = properties['stride']
_row_bytes = properties['rowBytes']
_expected = properties['expected']
_fmt = properties['frameFormat']
_note = properties['formatNote']
_indexed = properties['indexed']
_pal = None
_scratch = None
_expand = None


@micropython.viper
def _expand_gs4(src: ptr8, off: int, stride: int, dst: ptr8, width: int, rows: int, pal: ptr16):
    full = width >> 1
    odd = width & 1
    row_dst_bytes = width * 2
    for r in range(rows):
        s = off + r * stride
        d = r * row_dst_bytes
        for i in range(full):
            b = int(src[s + i])
            hi = b >> 4
            lo = b & 0x0F
            c0 = int(pal[hi])
            c1 = int(pal[lo])
            j = d + i * 4
            dst[j] = c0 >> 8
            dst[j + 1] = c0 & 0xFF
            dst[j + 2] = c1 >> 8
            dst[j + 3] = c1 & 0xFF
        if odd:
            b = int(src[s + full])
            hi = b >> 4
            c0 = int(pal[hi])
            j = d + full * 4
            dst[j] = c0 >> 8
            dst[j + 1] = c0 & 0xFF


@micropython.viper
def _expand_gs2(src: ptr8, off: int, stride: int, dst: ptr8, width: int, rows: int, pal: ptr16):
    full = width >> 2
    rem = width & 3
    row_dst_bytes = width * 2
    for r in range(rows):
        s = off + r * stride
        d = r * row_dst_bytes
        for i in range(full):
            b = int(src[s + i])
            j = d + i * 8
            for k in range(4):
                c = int(pal[(b >> (k * 2)) & 0x3])
                dst[j + k * 2] = c >> 8
                dst[j + k * 2 + 1] = c & 0xFF
        if rem:
            b = int(src[s + full])
            j = d + full * 8
            for k in range(rem):
                c = int(pal[(b >> (k * 2)) & 0x3])
                dst[j + k * 2] = c >> 8
                dst[j + k * 2 + 1] = c & 0xFF


@micropython.viper
def _expand_mono(src: ptr8, off: int, stride: int, dst: ptr8, width: int, rows: int, pal: ptr16):
    full = width >> 3
    rem = width & 7
    row_dst_bytes = width * 2
    for r in range(rows):
        s = off + r * stride
        d = r * row_dst_bytes
        for i in range(full):
            b = int(src[s + i])
            j = d + i * 16
            for k in range(8):
                c = int(pal[(b >> k) & 0x1])
                dst[j + k * 2] = c >> 8
                dst[j + k * 2 + 1] = c & 0xFF
        if rem:
            b = int(src[s + full])
            j = d + full * 16
            for k in range(rem):
                c = int(pal[(b >> k) & 0x1])
                dst[j + k * 2] = c >> 8
                dst[j + k * 2 + 1] = c & 0xFF


if _indexed:
    _pal = array.array('H', properties['palette'])
    _scratch = bytearray(_width * 2 * 2)
    if _fmt == 'gs4':
        _expand = _expand_gs4
    elif _fmt == 'gs2':
        _expand = _expand_gs2
    else:
        _expand = _expand_mono


async def run(msg, properties):
    _buf = msg.get('payload', b'')
    _y0 = msg.get('y')
    if _y0 is None:
        if len(_buf) != _expected:
            raise ValueError('display_spi: expected %d bytes (%s), got %d' % (_expected, _note, len(_buf)))
        _y0 = 0
        _rows = _height
    else:
        _rows = len(_buf) // _row_bytes
        if _rows < 1 or len(_buf) != _rows * _row_bytes or _y0 < 0 or _y0 + _rows > _height:
            raise ValueError('display_spi: a strip must be whole rows of %d bytes inside the %d-row screen, got %d bytes at row %r' % (_row_bytes, _height, len(_buf), _y0))
    if _indexed:
        _disp.set_window(0, _y0, _width - 1, _y0 + _rows - 1)
        _row = 0
        while _row < _rows:
            _n = 2 if (_rows - _row) >= 2 else (_rows - _row)
            _expand(_buf, _row * _stride, _stride, _scratch, _width, _n, _pal)
            _disp.write(None, memoryview(_scratch)[:_width * 2 * _n])
            _row += _n
    else:
        _disp.blit_buffer(_buf, 0, _y0, _width, _rows)
    return msg
`,tc={type:`thingstudio/change`,kind:`transform`,paletteId:`change`,label:`change`,group:`general`,priority:24,color:`#4a5c7a`,bgcolor:`#2a3445`,icon:`✎`,width:118,description:`Sets or deletes one value: a msg property or a flow variable (shared with function nodes' flow.get/set). Chain change nodes for more than one change.`,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},properties:[{name:`operation`,label:`operation`,kind:`select`,default:`set`,options:[{value:`set`,label:`set`},{value:`delete`,label:`delete`}]},{name:`scope`,label:`target`,kind:`select`,default:`msg`,options:[{value:`msg`,label:`msg property`},{value:`flow`,label:`flow variable`}]},{name:`property`,label:`property / name`,kind:`text`,default:`payload`},{name:`valueFrom`,label:`value from`,kind:`select`,default:`literal`,options:[{value:`literal`,label:`a literal value`},{value:`msg`,label:`another msg property`},{value:`flow`,label:`a flow variable`}],visibleWhen:{field:`operation`,equals:`set`}},{name:`valueType`,label:`literal type`,kind:`select`,default:`string`,options:[{value:`string`,label:`string`},{value:`number`,label:`number`},{value:`bool`,label:`bool`}],visibleWhen:{field:`valueFrom`,equals:`literal`}},{name:`value`,label:`value / source property`,kind:`text`,default:``,visibleWhen:{field:`operation`,equals:`set`}},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},nc=`def compile(ctx, properties):
    operation = str(properties.get('operation') or 'set')
    if operation not in ('set', 'delete'):
        return {'errors': ['change operation "%s" must be set or delete' % operation]}
    scope = str(properties.get('scope') or 'msg')
    if scope not in ('msg', 'flow'):
        return {'errors': ['change target "%s" must be msg or flow' % scope]}
    prop = str(properties.get('property') or '').strip()
    for prefix in ('msg.', 'flow.'):
        if prop.startswith(prefix):
            prop = prop[len(prefix):]
    if not prop:
        return {'errors': ['change needs a property or variable name']}

    if operation == 'delete':
        return {'properties': {'operation': operation, 'scope': scope, 'property': prop}}

    value_from = str(properties.get('valueFrom') or 'literal')
    if value_from not in ('literal', 'msg', 'flow'):
        return {'errors': ['change value source "%s" must be literal, msg or flow' % value_from]}
    raw = properties.get('value')
    value_type = str(properties.get('valueType') or 'string')
    if value_from == 'literal':
        if value_type not in ('string', 'number', 'bool'):
            return {'errors': ['change literal type "%s" must be string, number or bool' % value_type]}
        if value_type == 'bool':
            value = raw == 'true' or raw is True
        elif value_type == 'number':
            try:
                n = float(raw if raw not in (None, '') else 0)
            except (TypeError, ValueError):
                return {'errors': ['change value "%s" is not a valid number' % raw]}
            value = int(n) if n == int(n) else n
        else:
            value = str(raw if raw is not None else '')
    else:
        value = str(raw if raw is not None else '').strip()
        for prefix in ('msg.', 'flow.'):
            if value.startswith(prefix):
                value = value[len(prefix):]
        if not value:
            return {'errors': ['change needs a source property or variable name']}
        value_type = 'string'
    return {'properties': {'operation': operation, 'scope': scope, 'property': prop,
                           'valueFrom': value_from, 'valueType': value_type, 'value': value}}
`,rc=`import runtime

_flow = runtime.shared('flow_vars', 'v1', 'v1', lambda: {})
_scope = properties['scope']
_property = properties['property']
_operation = properties['operation']
_value_from = properties.get('valueFrom', 'literal')
_source_key = properties.get('value', '')
_literal = properties.get('value')


def _target(msg):
    if _scope == 'msg':
        return msg
    return _flow


async def run(msg, properties):
    target = _target(msg)
    if _operation == 'delete':
        target.pop(_property, None)
        return msg
    if _value_from == 'msg':
        value = msg.get(_source_key)
    elif _value_from == 'flow':
        value = _flow.get(_source_key)
    else:
        value = _literal
    target[_property] = value
    return msg
`,ic={type:`thingstudio/delay`,kind:`transform`,paletteId:`delay`,label:`delay`,group:`general`,priority:40,color:`#4a4a6e`,bgcolor:`#2a2a3f`,icon:`⌛`,width:100,description:`Passes each message on unchanged, after waiting the delay.`,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},properties:[{name:`delayMs`,label:`delay (ms)`,kind:`number`,default:1e3,min:1}]},ac=`async def run(msg, properties):
    await asyncio.sleep_ms(int(properties['delayMs']))
    return msg
`,oc={type:`thingstudio/filter`,kind:`transform`,paletteId:`filter`,label:`filter`,group:`general`,priority:35,color:`#2e6e4a`,bgcolor:`#1f3f2c`,icon:`▽`,width:100,description:`Passes a message on only when it's worth sending, and drops the rest. Messages that pass are unchanged.`,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},properties:[{name:`mode`,label:`mode`,kind:`select`,default:`change`,options:[{value:`change`,label:`change: only when the payload changes`},{value:`deadband`,label:`deadband: only when a number moves enough`},{value:`rate`,label:`rate: at most one per interval`}]},{name:`threshold`,label:`threshold`,kind:`number`,default:1,min:0,step:`any`,visibleWhen:{field:`mode`,equals:`deadband`}},{name:`intervalMs`,label:`interval (ms)`,kind:`number`,default:1e3,min:1,visibleWhen:{field:`mode`,equals:`rate`}},{name:`ignoreFirst`,label:`ignore first message`,kind:`boolean`,default:!1,visibleWhen:{field:`mode`,notEquals:`rate`}},{name:`perTopic`,label:`separately for each topic`,kind:`boolean`,default:!0},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},sc=`import time

_node_id = properties['nodeId']
_mode = properties['mode']
_threshold = properties['threshold']
_interval_ms = properties['intervalMs']
_ignore_first = properties['ignoreFirst']
_per_topic = properties['perTopic']

_state = {}
_full_warned = False
_nan_warned = False


def _num(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (bytes, bytearray)):
        try:
            v = v.decode()
        except Exception:
            return None
    if isinstance(v, str):
        try:
            v = float(v.strip())
        except ValueError:
            return None
    if not isinstance(v, (int, float)):
        return None
    v = float(v)
    if v != v or v in (float('inf'), float('-inf')):
        return None
    return v


async def run(msg, properties):
    nonlocal _state, _full_warned, _nan_warned
    if _per_topic:
        _k = msg.get('topic', '')
        if not isinstance(_k, str):
            _k = str(_k)
    else:
        _k = ''
    if _k not in _state and len(_state) >= 32:
        _state.clear()
        if not _full_warned:
            _full_warned = True
            print("FILTER_INFO node=%s more than 32 topics, starting again" % _node_id)

    if _mode == 'change':
        _v = msg['payload']
        if _k in _state:
            if _state[_k] == _v:
                return None
            _state[_k] = _v
            return msg
        _state[_k] = _v
        return None if _ignore_first else msg

    if _mode == 'deadband':
        _n = _num(msg['payload'])
        if _n is None:
            if not _nan_warned:
                _nan_warned = True
                runtime._report_error(_node_id, ValueError("deadband needs a number, got %s %r" % (type(msg['payload']).__name__, msg['payload'])))
            return None
        _nan_warned = False
        if _k in _state:
            if abs(_n - _state[_k]) < _threshold:
                return None
            _state[_k] = _n
            return msg
        _state[_k] = _n
        return None if _ignore_first else msg

    # rate
    _now = time.ticks_ms()
    if _k in _state and time.ticks_diff(_now, _state[_k]) < _interval_ms:
        return None
    _state[_k] = _now
    return msg
`,cc={type:`thingstudio/journal`,kind:`transform`,paletteId:`journal`,label:`journal`,group:`general`,priority:36,color:`#2e6e4a`,bgcolor:`#1f3f2c`,icon:`≋`,width:100,description:`Keeps the last rows of a number, as an average with its min and max. The first output sends the series (wire it to a histogram); the second sends one summary message every roll-up (wire it to the next journal for a longer time scale). Rows with no readings are gaps. With seconds per row set, a row closes when a message arrives after its time is up.`,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`series`,type:`any`},{name:`rollup`,type:`any`}]},properties:[{name:`rows`,label:`rows kept`,kind:`number`,default:60,min:1,max:256},{name:`stepSeconds`,label:`seconds per row (0 = one row per message)`,kind:`number`,default:60,min:0,step:`any`},{name:`steps`,label:`rows per roll-up (0 = none)`,kind:`number`,default:0,min:0},{name:`xff`,label:`gaps allowed in a roll-up (0 to 1)`,kind:`number`,default:.5,min:0,max:1,step:.05,visibleWhen:{field:`steps`,gt:0}},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},lc=`import array
import time

_node_id = properties['nodeId']
_rows = properties['rows']
_steps = properties['steps']
_xff = properties['xff']
_step_ms = round(properties['stepSeconds'] * 1000)
_warned = False

_NAN = float('nan')


class _Journal:
    def __init__(self, rows, step_ms, steps, xff):
        self.rows = rows
        self.avg = array.array('f', [_NAN] * rows)
        self.lo = array.array('f', [_NAN] * rows)
        self.hi = array.array('f', [_NAN] * rows)
        self.n = 0
        self.head = 0
        self.total = 0
        self.step_ms = step_ms
        self.steps = steps
        self.xff = xff
        self.start = None
        self.s = 0.0
        self.c = 0
        self.mn = _NAN
        self.mx = _NAN
        self.cur = 0
        self.cs = 0.0
        self.cc = 0
        self.cmn = _NAN
        self.cmx = _NAN

    def _row(self, a, lo, hi, out):
        i = self.head
        self.avg[i] = a
        self.lo[i] = lo
        self.hi[i] = hi
        self.head = (i + 1) % self.rows
        if self.n < self.rows:
            self.n += 1
        self.total += 1
        if not self.steps:
            return
        self.cur += 1
        if a == a:
            self.cs += a
            self.cc += 1
            if self.cmn != self.cmn or lo < self.cmn:
                self.cmn = lo
            if self.cmx != self.cmx or hi > self.cmx:
                self.cmx = hi
        if self.cur >= self.steps:
            if self.cc and (self.steps - self.cc) <= self.xff * self.steps:
                out.append((self.cs / self.cc, self.cmn, self.cmx))
            else:
                out.append((None, None, None))
            self.cur = 0
            self.cs = 0.0
            self.cc = 0
            self.cmn = _NAN
            self.cmx = _NAN

    def _close(self, out):
        if self.c:
            self._row(self.s / self.c, self.mn, self.mx, out)
        else:
            self._row(_NAN, _NAN, _NAN, out)
        self.s = 0.0
        self.c = 0
        self.mn = _NAN
        self.mx = _NAN

    def add(self, v, lo, hi, now):
        """Takes one reading; returns (the series changed, the roll-ups produced)."""
        out = []
        before = self.total
        if not self.step_ms:
            if v is None:
                self._row(_NAN, _NAN, _NAN, out)
            else:
                self._row(v, lo, hi, out)
            return self.total != before, out
        if self.start is None:
            self.start = now
        k = time.ticks_diff(now, self.start) // self.step_ms
        if k > 0:
            for _ in range(k if k < self.rows + 1 else self.rows + 1):
                self._close(out)
            self.start = time.ticks_add(self.start, k * self.step_ms)
        if v is not None:
            self.s += v
            self.c += 1
            if self.mn != self.mn or lo < self.mn:
                self.mn = lo
            if self.mx != self.mx or hi > self.mx:
                self.mx = hi
        return self.total != before, out


_j = _Journal(_rows, _step_ms, _steps, _xff)


async def run(msg, properties):
    nonlocal _warned
    _v = msg.get('payload')
    _lo = msg.get('min')
    _hi = msg.get('max')
    if _v is not None:
        try:
            _v = float(_v)
        except (TypeError, ValueError):
            if not _warned:
                _warned = True
                runtime._report_error(_node_id, ValueError("journal needs a number, got %s %r" % (type(_v).__name__, _v)))
            return None
        _warned = False
        _lo = _v if _lo is None else float(_lo)
        _hi = _v if _hi is None else float(_hi)
    _changed, _out = _j.add(_v, _lo, _hi, time.ticks_ms())
    _topic = msg.get('topic', '')
    _series = {'payload': _j, 'topic': _topic} if _changed else None
    _roll = [{'payload': a, 'min': l, 'max': h, 'topic': _topic} for (a, l, h) in _out]
    return [_series, _roll if _roll else None]
`,uc={type:`thingstudio/bme280`,kind:`source`,paletteId:`bme280`,label:`bme280`,group:`hardware`,priority:15,color:`#8a4a2e`,bgcolor:`#4a2a1f`,icon:`°`,width:110,description:`Sends {temperature °C, humidity %, pressure hPa} in msg.payload. A BMP280 works too; its humidity is null. The status dot shows whether the sensor is answering.`,ports:{outputs:[{name:`msg`,type:`any`}]},resources:[{kind:`i2c`,config:`i2cConfigId`}],properties:[{name:`i2cConfigId`,label:`I2C bus`,kind:`configRef`,configType:`thingstudio/config/i2c-bus`,default:``},{name:`address`,label:`address`,kind:`select`,default:118,options:[{value:118,label:`0x76 (SDO to GND, most boards)`},{value:119,label:`0x77 (SDO to VCC)`}]},{name:`intervalMs`,label:`interval (ms)`,kind:`number`,default:5e3,min:100},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},dc=`import machine
import bme280_float

_bus = properties['i2cConfigId']
_address = properties['address']
_node_id = properties['nodeId']
_dev = None
_state = None

if _bus is None:
    raise ValueError('bme280: pick an I2C bus in the node properties')

_bus_num = int(_bus['bus'])
if _bus.get('scl') is None or _bus.get('sda') is None:
    raise ValueError('bme280: set the SCL and SDA pins on the I2C bus config')

# The same shared bus object every I2C node uses, keyed by bus id (i2c-shared.ts / runtime.shared).
_i2c = runtime.shared('i2c', _bus_num, (_bus['scl'], _bus['sda'], _bus['freq']),
                      lambda: machine.I2C(_bus_num, scl=machine.Pin(_bus['scl']),
                                          sda=machine.Pin(_bus['sda']), freq=_bus['freq']))


def _status(state, text):
    nonlocal _state
    if _state != (state, text):
        _state = (state, text)
        runtime.report_status(_node_id, state, text)


async def emit(properties):
    nonlocal _dev
    try:
        if _dev is None:
            _dev = bme280_float.BME280(i2c=_i2c, address=_address)
        _t, _p, _h = await _dev.read_async()
    except OSError:
        _dev = None
        _status('disconnected', 'no reply at 0x%02x on I2C bus %d' % (_address, _bus_num))
        return None
    except Exception as _e:
        _dev = None
        _status('error', str(_e))
        return None
    else:
        _status('connected', 'BME280' if _dev.has_humidity else 'BMP280')
        return {'payload': {'temperature': round(_t, 2),
                            'humidity': None if _h is None else round(_h, 2),
                            'pressure': round(_p / 100, 2)},
                'topic': ''}
`,fc={type:`thingstudio/touch_i2c`,kind:`source`,paletteId:`touch_i2c`,label:`touch`,group:`hardware`,priority:16,color:`#8a2e6e`,bgcolor:`#4a1f3a`,icon:`☞`,width:100,description:`Raw touch from the flow's touch panel config (FT6336U): {x, y} with topic 'down' when a finger lands and 'up' when it lifts. One panel feeds one touch node or one gui screen, not both.`,resources:[{kind:`i2c`,config:`touchPanelConfigId`,nestedField:`i2cConfigId`}],ports:{outputs:[{name:`msg`,type:`any`}]},properties:[{name:`touchPanelConfigId`,label:`Touch panel`,kind:`configRef`,configType:`thingstudio/config/touch-panel`,default:``},{name:`orientation`,label:`orientation`,kind:`select`,default:``,options:[{value:``,label:`off (panel's own axes)`},{value:`0`,label:`0 degrees (the panel's own)`},{value:`90`,label:`90 degrees clockwise`},{value:`180`,label:`180 degrees`},{value:`270`,label:`270 degrees clockwise`}],help:`The turn of the picture this touch matches, for a flow with no gui screen (a gui screen takes it from its display). Same four angles as the display's orientation. Off leaves the coordinates as the panel reports them.`},{name:`intervalMs`,label:`interval`,kind:`number`,default:20,hidden:!0},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},pc=`def _touch_map(flags, point, width, height):
    # The driver's transform: swap the axes, then flip on the swapped size (ft6336u's own order).
    x, y = point
    if flags[0]:
        x, y = y, x
        width, height = height, width
    if flags[1]:
        x = width - 1 - x
    if flags[2]:
        y = height - 1 - y
    return (x, y)


def _to_turned(point, width, height, angle):
    # The turned picture's pixel at the position of unturned pixel 'point'. Mirrors orientation-shared.ts.
    x, y = point
    if angle == 0:
        return (x, y)
    if angle == 90:
        return (y, width - 1 - x)
    if angle == 180:
        return (width - 1 - x, height - 1 - y)
    return (height - 1 - y, x)


def _samples(width, height):
    return [(0, 0), (width - 1, 0), (0, height - 1), (1, 2), (width - 2, 3)]


def _oriented_touch(base, angle, width, height):
    # The flags that give coordinates in the picture turned by 'angle', given the panel's own flags. Brute-forced
    # over the eight swap/flip combinations rather than a hand-written table, so it cannot disagree with the
    # mapping it is derived from. editor/test/node-touch-i2c.test.ts checks this against orientedTouch() in
    # orientation-shared.ts, which is the same algorithm -- the two must agree, and the test says so.
    if base[0]:
        turned_width, turned_height = height, width
    else:
        turned_width, turned_height = width, height
    for n in range(8):
        flags = ((n & 1) != 0, (n & 2) != 0, (n & 4) != 0)
        ok = True
        for point in _samples(width, height):
            want = _to_turned(_touch_map(base, point, width, height), turned_width, turned_height, angle)
            if _touch_map(flags, point, width, height) != want:
                ok = False
                break
        if ok:
            return flags
    return None


def _whole(props, name, dflt, low, what):
    raw = props.get(name)
    if raw is None or raw == '':
        raw = dflt
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None, 'touch panel %s "%s" must be a whole number, %d or more' % (what, raw, low)
    if value < low:
        return None, 'touch panel %s "%s" must be a whole number, %d or more' % (what, raw, low)
    return value, None

def compile(ctx, properties):
    panel_id = str(properties.get('touchPanelConfigId') or '')
    if not panel_id:
        return {'errors': ['%s has no touch panel. Pick one, or add one with +.' % ctx['node']['type']]}
    panel = (ctx.get('referencedConfigs') or {}).get(panel_id)
    if panel is None:
        return {'errors': ['could not resolve the touch panel config -- reopen the flow in the editor']}
    me = ctx['node']['id']
    for other in ctx['flow']['nodes']:
        if other['id'] == me:
            continue
        if other['type'] not in ('thingstudio/gui_screen', 'thingstudio/touch_i2c'):
            continue
        props = other.get('properties') or {}
        if str(props.get('touchPanelConfigId') or '') == panel_id:
            return {'errors': ['node %s and node %s both use the same touch panel. A panel feeds one gui screen or one touch node, not both.' % (me, other['id'])]}

    controller = str(panel.get('controller') or 'ft6336u')
    if controller != 'ft6336u':
        return {'errors': ['touch panel controller "%s" is not supported yet (FT6336U only)' % controller]}
    bus_id = str(panel.get('i2cConfigId') or '')
    if not bus_id:
        return {'errors': ['the touch panel has no I2C bus. Pick one, or add one with +.']}
    bus = None
    for config in ctx['flow']['configs']:
        if config['id'] == bus_id:
            bus = config.get('properties') or {}
            break
    if bus is None:
        return {'errors': ['could not resolve the touch panel I2C bus -- reopen the flow in the editor']}

    raw_address = panel.get('address', '0x38')
    try:
        address = raw_address if isinstance(raw_address, int) else int(str(raw_address), 0)
    except (TypeError, ValueError):
        return {'errors': ['touch panel address "%s" must be 0x08 to 0x77' % raw_address]}
    if address < 0x08 or address > 0x77:
        return {'errors': ['touch panel address "%s" must be 0x08 to 0x77' % raw_address]}
    poll, err = _whole(panel, 'pollMs', 20, 5, 'poll interval')
    if err:
        return {'errors': [err]}
    width, err = _whole(panel, 'width', 320, 1, 'width')
    if err:
        return {'errors': [err]}
    height, err = _whole(panel, 'height', 480, 1, 'height')
    if err:
        return {'errors': [err]}
    rst_raw = panel.get('rstPin')
    rst = -1
    if rst_raw is not None and rst_raw != '':
        try:
            rst = int(rst_raw)
        except (TypeError, ValueError):
            return {'errors': ['touch panel reset pin "%s" must be a pin number' % rst_raw]}

    base = (panel.get('swapXY') is True, panel.get('flipX') is True, panel.get('flipY') is True)
    raw_angle = properties.get('orientation')
    if raw_angle is None or raw_angle == '':
        flags = base
    else:
        try:
            angle = int(raw_angle)
        except (TypeError, ValueError):
            angle = -1
        if angle not in (0, 90, 180, 270):
            return {'errors': ['%s orientation "%s" must be 0, 90, 180 or 270' % (ctx['node']['type'], raw_angle)]}
        flags = _oriented_touch(base, angle, width, height)
        if flags is None:
            return {'errors': ['%s: no touch orientation matches a turn of %d degrees' % (ctx['node']['type'], angle)]}

    claims = []
    if rst >= 0:
        claims.append({'resource': 'GPIO %d' % rst, 'use': 'output'})
    return {'properties': {
        'bus': bus.get('bus', 0), 'scl': bus.get('scl'), 'sda': bus.get('sda'),
        'freq': bus.get('freq', 400000), 'address': address, 'rstPin': rst,
        'width': width, 'height': height,
        'swapXY': flags[0], 'flipX': flags[1], 'flipY': flags[2],
        'pollMs': poll, 'intervalMs': poll,
        'where': 'FT6336U at 0x%x on I2C bus %s' % (address, bus.get('bus', 0)),
    }, 'claims': claims}
`,mc=`import machine
import ft6336u
import runtime

_bus = runtime.shared(
    'i2c', properties['bus'], (properties['scl'], properties['sda'], properties['freq']),
    lambda: machine.I2C(properties['bus'], scl=machine.Pin(properties['scl']),
                        sda=machine.Pin(properties['sda']), freq=properties['freq']))
_rst = None
if properties['rstPin'] >= 0:
    _rst = runtime.shared('pin', properties['rstPin'], ('out', 'none'),
                          lambda: machine.Pin(properties['rstPin'], machine.Pin.OUT))
_dev = None
_last = None
_state = None
_where = properties['where']
_node_id = properties['nodeId']


def _report(state, text):
    nonlocal _state
    if _state != (state, text):
        _state = (state, text)
        runtime.report_status(_node_id, state, text)


async def emit(properties):
    nonlocal _dev, _last
    try:
        if _dev is None:
            _dev = ft6336u.FT6336U(_bus, properties['address'], _rst, properties['width'],
                                   properties['height'], properties['swapXY'], properties['flipX'],
                                   properties['flipY'])
        _pt = _dev.read()
    except OSError:
        _dev = None
        _report('disconnected', 'no reply from ' + _where)
        return None
    except Exception as _e:
        _dev = None
        _report('error', str(_e))
        return None
    _report('connected', 'FT6336U')
    if _pt is not None:
        if _last is None:
            _last = _pt
            return {'payload': {'x': _pt[0], 'y': _pt[1]}, 'topic': 'down'}
        _last = _pt
        return None
    if _last is not None:
        _msg = {'payload': {'x': _last[0], 'y': _last[1]}, 'topic': 'up'}
        _last = None
        return _msg
    return None
`;function hc(e){return typeof e==`number`?`GPIO ${e}`:`pin ${e}`}var R=class extends Error{},gc=/^[a-z0-9][a-z0-9_-]*$/,_c=255;function vc(e){return typeof e==`object`&&!!e&&!Array.isArray(e)}function yc(e,t,n){for(let r of Object.keys(e))if(!t.includes(r))throw new R(`${n}: unknown key "${r}" (allowed: ${t.join(`, `)})`)}function bc(e,t){if(typeof e!=`number`||!Number.isInteger(e)||e<0||e>_c)throw new R(`${t}: ${JSON.stringify(e)} isn't a GPIO number`);return e}var xc=/^[A-Za-z][A-Za-z0-9_-]*$/;function Sc(e){return xc.test(e)&&!Cc(e)}function Cc(e){return/^\s*\d+\s*(?:-\s*\d+\s*)?$/.test(e)}function wc(e,t){let n=/^\s*(\d+)\s*(?:-\s*(\d+)\s*)?$/.exec(e);if(!n)throw new R(`${t}: "${e}" isn't a pin or a range like "0-19"`);let r=Number(n[1]),i=n[2]===void 0?r:Number(n[2]);if(r>_c||i>_c||i<r)throw new R(`${t}: "${e}" isn't a valid range`);let a=[];for(let e=r;e<=i;e++)a.push(e);return a}function Tc(e,t){if(typeof e==`number`)return[bc(e,t)];if(typeof e==`string`){if(Cc(e))return wc(e,t);let n=e.trim();if(xc.test(n))return[n]}throw new R(`${t}: ${JSON.stringify(e)} isn't a pin or a range like "0-19", or a pin name`)}function Ec(e,t){if(!Array.isArray(e))throw new R(`${t}: must be a list, e.g. [0, 2, "4-7"]`);let n=[];for(let r of e)n.push(...Tc(r,t));return n}function Dc(e,t){if(!vc(e))throw new R(`${t}: must be an object like {"6-11": "reason"}`);let n=new Map;for(let[r,i]of Object.entries(e)){if(typeof i!=`string`||i.trim()===``)throw new R(`${t}."${r}": the reason must be a non-empty string`);for(let e of Tc(r,t))n.set(e,i)}return n}function Oc(e,t){if(typeof e!=`string`||e.trim()===``)throw new R(`${t}: must be a non-empty string`);return e}function kc(e,t){if(!Array.isArray(e)||e.some(e=>typeof e!=`string`||e.trim()===``))throw new R(`${t}: must be a list of strings (may be empty)`);return e}function Ac(e,t){if(typeof e!=`number`||!Number.isInteger(e)||e<=0)throw new R(`${t}: must be a positive whole number`);return e}function jc(e,t){if(!/^\d+$/.test(e))throw new R(`${t}: bus id "${e}" must be a number, e.g. "1"`);return Number(e)}function Mc(e,t,n){for(let r of e)if(!t.has(r))throw new R(`${n}: ${hc(r)} isn't in "gpio"`)}function Nc(e,t){let n=Tc(e,t);if(n.length!==1)throw new R(`${t}: ${JSON.stringify(e)} names more than one pin`);return n[0]}var Pc=[`name`,`match`,`nativeArch`,`nativeArchConfirmed`,`capabilities`,`gpio`,`inputOnly`,`noPull`,`adc2`,`reserved`,`avoid`,`spi`,`i2c`,`notes`,`flash`],Fc=[`name`,`processor`,`match`,`pins`,`gpio`,`reserved`,`avoid`,`notes`,`wifi`,`capabilities`,`header`,`free`,`headerOrder`,`usb`,`variant`];function Ic(e,t){if(!vc(e))throw new R(`"spi": must be an object`);yc(e,[`maxHz`,`otherPinsMaxHz`,`buses`],`"spi"`);let n=e.maxHz===void 0?void 0:Ac(e.maxHz,`"spi.maxHz"`),r=e.otherPinsMaxHz===void 0?void 0:Ac(e.otherPinsMaxHz,`"spi.otherPinsMaxHz"`);if(!vc(e.buses))throw new R(`"spi.buses": must be an object like {"1": {}}`);let i=new Map;for(let[n,r]of Object.entries(e.buses)){let e=`"spi.buses.${n}"`,a=jc(n,e);if(!vc(r))throw new R(`${e}: must be an object (use {} for "any pins")`);yc(r,[`fastPins`,`pins`],e);let o={};if(r.fastPins!==void 0){if(!vc(r.fastPins))throw new R(`${e}.fastPins: must be an object`);yc(r.fastPins,[`sck`,`mosi`,`miso`],`${e}.fastPins`);let n={};for(let t of[`sck`,`mosi`,`miso`])r.fastPins[t]!==void 0&&(n[t]=Nc(r.fastPins[t],`${e}.fastPins.${t}`));Mc(Object.values(n),t,`${e}.fastPins`),o.fastPins=n}if(r.pins!==void 0){if(!vc(r.pins))throw new R(`${e}.pins: must be an object`);yc(r.pins,[`sck`,`mosi`,`miso`],`${e}.pins`);let n={};for(let i of[`sck`,`mosi`,`miso`])r.pins[i]!==void 0&&(n[i]=Ec(r.pins[i],`${e}.pins.${i}`),Mc(n[i],t,`${e}.pins.${i}`));o.pins=n}i.set(a,o)}return{maxHz:n,otherPinsMaxHz:r,buses:i}}function Lc(e,t){if(!vc(e))throw new R(`"i2c": must be an object`);if(yc(e,[`buses`],`"i2c"`),!vc(e.buses))throw new R(`"i2c.buses": must be an object like {"0": {}}`);let n=new Map;for(let[r,i]of Object.entries(e.buses)){let e=`"i2c.buses.${r}"`,a=jc(r,e);if(!vc(i))throw new R(`${e}: must be an object (use {} for "any pins")`);yc(i,[`pins`],e);let o={};if(i.pins!==void 0){if(!vc(i.pins))throw new R(`${e}.pins: must be an object`);yc(i.pins,[`sda`,`scl`],`${e}.pins`);let n={};for(let r of[`sda`,`scl`])i.pins[r]!==void 0&&(n[r]=Ec(i.pins[r],`${e}.pins.${r}`),Mc(n[r],t,`${e}.pins.${r}`));o.pins=n}n.set(a,o)}return{buses:n}}function Rc(e,t){if(!gc.test(e))throw new R(`file name "${e}" must be lowercase letters, digits, "-" or "_"`);if(!vc(t))throw new R(`must be a JSON object`);yc(t,Pc,`processor`);for(let e of[`name`,`match`,`nativeArch`,`gpio`])if(t[e]===void 0)throw new R(`missing required key "${e}"`);let n=new Set(Ec(t.gpio,`"gpio"`));if(n.size===0)throw new R(`"gpio": must list at least one pin`);let r=new Set(t.inputOnly===void 0?[]:Ec(t.inputOnly,`"inputOnly"`)),i=new Set(t.noPull===void 0?[]:Ec(t.noPull,`"noPull"`)),a=new Set(t.adc2===void 0?[]:Ec(t.adc2,`"adc2"`)),o=t.reserved===void 0?new Map:Dc(t.reserved,`"reserved"`),s=t.avoid===void 0?new Map:Dc(t.avoid,`"avoid"`);if(Mc(r,n,`"inputOnly"`),Mc(i,n,`"noPull"`),Mc(a,n,`"adc2"`),Mc(o.keys(),n,`"reserved"`),Mc(s.keys(),n,`"avoid"`),t.nativeArchConfirmed!==void 0&&typeof t.nativeArchConfirmed!=`boolean`)throw new R(`"nativeArchConfirmed": must be true or false`);return{id:e,name:Oc(t.name,`"name"`),match:kc(t.match,`"match"`),nativeArch:Oc(t.nativeArch,`"nativeArch"`),nativeArchConfirmed:t.nativeArchConfirmed!==!1,capabilities:new Set(t.capabilities===void 0?[]:kc(t.capabilities,`"capabilities"`)),gpio:n,inputOnly:r,noPull:i,adc2:a,reserved:o,avoid:s,spi:t.spi===void 0?null:Ic(t.spi,n),i2c:t.i2c===void 0?null:Lc(t.i2c,n),notes:t.notes===void 0?``:Oc(t.notes,`"notes"`),flash:t.flash===void 0?null:Bc(t.flash)}}var zc=[`esptool`,`uf2`];function Bc(e){if(!vc(e))throw new R(`"flash": must be an object like {"tool": "esptool", "chip": "esp32", "address": 4096}`);yc(e,[`tool`,`chip`,`address`],`"flash"`);let t=Uc(e.tool,zc,`"flash.tool"`);if(t===`uf2`){if(e.chip!==void 0||e.address!==void 0)throw new R(`"flash": "uf2" takes no "chip" or "address" — the address is inside the .uf2`);return{tool:t,chip:null,address:0}}let n=e.chip===void 0?null:Oc(e.chip,`"flash.chip"`),r=e.address===void 0?0:e.address;if(typeof r!=`number`||!Number.isInteger(r)||r<0)throw new R(`"flash.address": must be a whole number of bytes (0 for the start of flash)`);return{tool:t,chip:n,address:r}}function Vc(e,t,n){if(!gc.test(e))throw new R(`file name "${e}" must be lowercase letters, digits, "-" or "_"`);if(!vc(t))throw new R(`must be a JSON object`);yc(t,Fc,`board`);for(let e of[`name`,`processor`,`match`,`pins`])if(t[e]===void 0)throw new R(`missing required key "${e}"`);let r=Oc(t.processor,`"processor"`),i=n.get(r);if(!i)throw new R(`"processor": no processor "${r}" (known: ${[...n.keys()].sort().join(`, `)})`);let a=null;t.gpio!==void 0&&(a=new Set(Ec(t.gpio,`"gpio"`)),Mc(a,i.gpio,`"gpio" (must be pins ${i.name} has)`));let o=a??i.gpio;if(!vc(t.pins))throw new R(`"pins": must be an object like {"LED": 15}`);let s=new Map;for(let[e,n]of Object.entries(t.pins)){if(e.trim()===``)throw new R(`"pins": labels can't be empty`);let t=Nc(n,`"pins.${e}"`);if(!o.has(t))throw new R(`"pins.${e}": ${hc(t)} doesn't exist on this board`);s.set(e,t)}let c=t.reserved===void 0?new Map:Dc(t.reserved,`"reserved"`),l=t.avoid===void 0?new Map:Dc(t.avoid,`"avoid"`);Mc(c.keys(),o,`"reserved"`),Mc(l.keys(),o,`"avoid"`);let u=new Set(t.free===void 0?[]:Ec(t.free,`"free"`));Mc(u,o,`"free"`);let d=t.headerOrder===void 0?`around`:Uc(t.headerOrder,[`around`,`down`],`"headerOrder"`),f=t.usb===void 0?null:Uc(t.usb,[`top`,`bottom`],`"usb"`);if((t.headerOrder!==void 0||f!==null)&&t.header===void 0)throw new R(`"${t.usb===void 0?`headerOrder`:`usb`}": needs "header", the pins it describes`);for(let e of u)if(c.has(e)||l.has(e))throw new R(`"free": ${hc(e)} is also in this board's own "${c.has(e)?`reserved`:`avoid`}"`);return{id:e,name:Oc(t.name,`"name"`),processor:r,match:kc(t.match,`"match"`),pins:s,gpio:a,reserved:c,avoid:l,free:u,notes:t.notes===void 0?``:Oc(t.notes,`"notes"`),wifi:t.wifi===void 0?null:Wc(t.wifi,`"wifi"`),capabilities:new Set(t.capabilities===void 0?[]:kc(t.capabilities,`"capabilities"`)),header:t.header===void 0?new Map:Hc(t.header,o),headerOrder:d,usb:f,variant:t.variant===void 0?null:Oc(t.variant,`"variant"`)}}function Hc(e,t){if(!vc(e))throw new R(`"header": must be an object like {"1": 0, "3": "GND"}`);let n=new Map,r=new Map,i=(e,t)=>{let i=r.get(t);if(i!==void 0)throw new R(`"header.${e}": ${hc(t)} is already on header pin ${i}`);r.set(t,e),n.set(e,t)};for(let[r,a]of Object.entries(e)){if(r.trim()===``)throw new R(`"header": physical pin names can't be empty`);if(typeof a==`string`){if(a.trim()===``)throw new R(`"header.${r}": the label can't be empty`);t.has(a)?i(r,a):n.set(r,a);continue}let e=Nc(a,`"header.${r}"`);if(!t.has(e))throw new R(`"header.${r}": ${hc(e)} doesn't exist on this board`);i(r,e)}return n}function Uc(e,t,n){if(typeof e!=`string`||!t.includes(e))throw new R(`${n}: must be ${t.map(e=>`"${e}"`).join(` or `)}`);return e}function Wc(e,t){if(typeof e!=`boolean`)throw new R(`${t}: must be true or false`);return e}function Gc(e){return e instanceof Error?e.message:String(e)}function Kc(e,t){let n=[],r=[],i=new Map,a=new Map,o=new Map(e.map(e=>[`${e.kind}:${e.id}`,JSON.stringify(e.data)])),s=[...e,...t],c=t=>{if(t.parseError)n.push({kind:t.kind,id:t.id,source:t.source,message:t.parseError});else try{t.kind===`processor`?i.set(t.id,Rc(t.id,t.data)):a.set(t.id,Vc(t.id,t.data,i));let n=o.get(`${t.kind}:${t.id}`);!e.includes(t)&&n!==void 0&&n!==JSON.stringify(t.data)&&r.push({kind:t.kind,id:t.id,source:t.source})}catch(e){n.push({kind:t.kind,id:t.id,source:t.source,message:Gc(e)})}};for(let e of s)e.kind===`processor`&&c(e);for(let e of s)e.kind===`board`&&c(e);return{processors:i,boards:a,problems:n,overrides:r}}function qc(e){let t=[],n=[];for(let r of e)typeof r==`number`?t.push(r):n.includes(r)||n.push(r);let r=[],i=[...new Set(t)].sort((e,t)=>e-t),a=0;for(;a<i.length;){let e=a;for(;e+1<i.length&&i[e+1]===i[e]+1;)e++;r.push(e===a?String(i[a]):`${i[a]}-${i[e]}`),a=e+1}return r.push(...n.sort((e,t)=>e.localeCompare(t))),r.join(`, `)}var Jc=`No board or processor known, so pins are only checked against 0-48. Connect the board, or pick it in the Board menu, for full checks.`;function Yc(e,t){e.warn?.(t)}function Xc(e,t){let n=e.pinLabels.get(t);return n&&n.length>0?` (${n.join(`, `)})`:``}function Zc(e,t){let n=[...e.gpio].filter(e=>typeof e==`string`),r=[...e.gpio].some(e=>typeof e==`number`);return typeof t==`number`&&n.length>0&&!r?` -- this board names its pins (${n.slice(0,3).join(`, `)}), it has no GPIO numbers`:typeof t==`string`&&n.length===0&&r?` -- this board uses GPIO numbers, not pin names`:``}function Qc(e,t){if(typeof e==`string`){let n=e.trim();if(/^\d+(\.\d+)?$/.test(n)){let e=Math.round(Number(n));if(Number.isFinite(e)&&e>=0)return e}if(Sc(n))return n;throw new L(`${t} "${n}" isn't a GPIO number or a pin name`)}let n=Math.round(Number(e));if(e==null||!Number.isFinite(n)||n<0)throw new L(`${t} ${String(e)} isn't a GPIO number or a pin name`);return n}function $c(e,t,n,r,i={}){let a=Qc(n,t),o=e.target??null;if(!o){if(typeof a==`number`&&a>48)throw new L(`${t} ${a} is out of range (0-48, the widest any supported processor has)`);return Yc(e,Jc),a}if(!o.gpio.has(a))throw new L(`${t} ${a} doesn't exist on ${o.label}${Zc(o,a)}. Pins: ${qc(o.gpio)}`);let s=o.reserved.get(a);if(s!==void 0)throw new L(`${t} ${a}${Xc(o,a)} can't be used on ${o.label}: ${s}`);if(r!==`input`&&o.inputOnly.has(a))throw new L(`${t} ${a} is input-only on ${o.label}, and this pin drives an output`);i.pull&&o.noPull.has(a)&&Yc(e,`${t} ${a} has no internal pull resistor on ${o.label}. Fit an external one, or the input will float.`);let c=o.avoid.get(a);return c!==void 0&&Yc(e,`${t} ${a}${Xc(o,a)} on ${o.label}: ${c}`),a}function el(e,t,n,r){return n==null||n===``||typeof n==`number`&&n===-1||typeof n==`string`&&n.trim()===`-1`?null:$c(e,t,n,r)}function tl(e){return`${Number((e/1e6).toFixed(2))} MHz`}function nl(e,t,n,r,i,a){if(r&&!r.includes(n))throw new L(`${e} ${t} pin ${n} can't be ${i} ${t.toUpperCase()} on ${a.label}. Use one of: ${r.join(`, `)}`)}function rl(e,t,n,r,i){let a=e.target??null,o=a?.processor.spi;if(!a||!o)return;let s=o.buses.get(n);if(!s)throw new L(`${t} spiBus ${n} doesn't exist on ${a.label}. SPI buses: ${[...o.buses.keys()].join(`, `)}`);let c=`SPI bus ${n}`;if(nl(t,`sck`,r.sck,s.pins?.sck,c,a),nl(t,`mosi`,r.mosi,s.pins?.mosi,c,a),r.miso!==void 0&&r.miso!==null&&nl(t,`miso`,r.miso,s.pins?.miso,c,a),o.maxHz!==void 0&&i>o.maxHz)throw new L(`${t} baudrate ${tl(i)} is faster than ${a.label}'s SPI maximum of ${tl(o.maxHz)}`);if(o.otherPinsMaxHz!==void 0&&i>o.otherPinsMaxHz){let e=s.fastPins;if(e===void 0||e.sck!==r.sck||e.mosi!==r.mosi){let s=e?`, or move SCK and MOSI to bus ${n}'s fast pins (${e.sck} and ${e.mosi})`:``;s+=`.`;for(let[e,t]of o.buses)e!==n&&t.fastPins?.sck===r.sck&&t.fastPins?.mosi===r.mosi&&(s+=` These pins are SPI bus ${e}'s fast pins, so spiBus ${e} would also work.`);throw new L(`${t} baudrate ${tl(i)} is too fast for these pins on ${a.label}. Off the bus's fast pins the limit is ${tl(o.otherPinsMaxHz)}, and above it the board crashes. Use ${tl(o.otherPinsMaxHz)} or less${s}`)}}}function il(e,t,n,r){let i=e.target??null,a=i?.processor.i2c;if(!i||!a)return;let o=a.buses.get(n);if(!o)throw new L(`${t} i2cBus ${n} doesn't exist on ${i.label}. I2C buses: ${[...a.buses.keys()].join(`, `)}`);nl(t,`scl`,r.scl,o.pins?.scl,`I2C bus ${n}`,i),nl(t,`sda`,r.sda,o.pins?.sda,`I2C bus ${n}`,i)}var al=new Map(Object.values(Object.assign({"./fonts/font_body12.json":{id:`font_body12`,charset:`body`,size:12,height:11,baseline:9,maxWidth:11,errchar:`?`,glyphs:{" ":[3,`AAAAAAAAAAAAAAA=`],"!":[3,`AEBAQEBAQEBAAAA=`],'"':[4,`AKCgoAAAAAAAAAA=`],"#":[8,`ABQUfiQk/igoAAA=`],$:[7,`EHxUUHAcFtQ8EAA=`],"%":[11,`AABxgIkASgB0AAXACiASIDHAAAAAAA==`],"&":[8,`ADgkJDh6zkZ7AAA=`],"'":[2,`AICAgAAAAAAAAAA=`],"(":[4,`ACBAQEBAQEBAQCA=`],")":[4,`AEBAICAgICAgQMA=`],"*":[5,`ACBwcAAAAAAAAAA=`],"+":[7,`AAAAEBAQfhAQAAA=`],",":[2,`AAAAAAAAAADAQEA=`],"-":[4,`AAAAAAAA8AAAAAA=`],".":[2,`AAAAAAAAAEDAAAA=`],"/":[5,`ABAQICAgQECAAAA=`],0:[8,`ADxmYlJKSkY8AAA=`],1:[5,`ABDwEBAQEBAQAAA=`],2:[7,`ADhEBAwIEGD8AAA=`],3:[7,`ADhEBBgEhER4AAA=`],4:[7,`AAgYOChI/ggIAAA=`],5:[7,`AHxAeEQEBEQ4AAA=`],6:[7,`ADhEQHhEREQ4AAA=`],7:[6,`APwICBAQMCBgAAA=`],8:[7,`ADgkJDxEQkQ8AAA=`],9:[7,`ADhEREREOAgQAAA=`],":":[2,`AAAAwEAAAEDAAAA=`],";":[2,`AAAAwEAAAADAQEA=`],"<":[7,`AAAABBhg4BgEAAA=`],"=":[7,`AAAAAAB+AH4AAAA=`],">":[7,`AAAAgHAMDHDAAAA=`],"?":[6,`AHjMCBggACAgAAA=`],"@":[9,`AAAeACEAXIBUgFSAWwBgABwAAAAAAA==`],A:[8,`ABgYKCREfEKCAAA=`],B:[7,`AHxGRHxCQkJ8AAA=`],C:[8,`ADxiQEBAQGI8AAA=`],D:[8,`AHxGQkJCQkZ8AAA=`],E:[7,`AHxAQHhAQEB8AAA=`],F:[7,`AHxAQHxAQEBAAAA=`],G:[9,`AAA8AGIAQABAAE8AQQBjAD0AAAAAAA==`],H:[8,`AEJCQn5CQkJCAAA=`],I:[5,`AHAgICAgICBwAAA=`],J:[6,`AAgICAgIiIhwAAA=`],K:[8,`AEZMWFB4TERCAAA=`],L:[6,`AEBAQEBAQEB8AAA=`],M:[10,`AABhgGGAcoBSgFKATIBMgEyAAAAAAA==`],N:[8,`AGJiUlJKTkZGAAA=`],O:[9,`AAA8AGIAQQBBAEEAQQBiADwAAAAAAA==`],P:[7,`AHxGQkZ8QEBAAAA=`],Q:[9,`AAA8AGIAQQBBAE0ARwBjAD2AAAAAAA==`],R:[7,`AHxGQkZ8SExGAAA=`],S:[7,`ADhEQHAMBsY8AAA=`],T:[7,`AP4QEBAQEBAQAAA=`],U:[8,`AEJCQkJCQmI8AAA=`],V:[7,`AMJEREQoKCgQAAA=`],W:[10,`AACMQEzATIBMgFKAM4AzADMAAAAAAA==`],X:[7,`AMZkKBgYLGTCAAA=`],Y:[7,`AMZELCgQEBAQAAA=`],Z:[7,`AH4ECBgQIEB+AAA=`],"[":[4,`AGBAQEBAQEBAQGA=`],"\\":[5,`AIBAQCAgIBAQAAA=`],"]":[4,`AOAgICAgICAgIOA=`],"^":[7,`EDAoSEQAAAAAAAA=`],_:[5,`AAAAAAAAAAAA+AA=`],"`":[3,`QGAAAAAAAAAAAAA=`],a:[6,`AAAAOEgcZMx0AAA=`],b:[7,`AEBAeERERER4AAA=`],c:[6,`AAAAOEzAwEw4AAA=`],d:[7,`AAQEPETExEQ8AAA=`],e:[6,`AAAAOET8wEw4AAA=`],f:[4,`IEBA4EBAQEBAAAA=`],g:[7,`AAAANEzExEw0BHg=`],h:[7,`AEBAeEREREREAAA=`],i:[3,`YAAAQEBAQEBAAAA=`],j:[4,`IAAAICAgICAgIOA=`],k:[6,`AEBASFBgUFhMAAA=`],l:[3,`AEBAQEBAQEBgAAA=`],m:[10,`AAAAAAAAe4BMgESARIBEgESAAAAAAA==`],n:[7,`AAAAeEREREREAAA=`],o:[7,`AAAAOETExEQ4AAA=`],p:[7,`AAAAeERERER4QEA=`],q:[8,`AAAAPETExEQ8BAc=`],r:[4,`AAAAcEBAQEBAAAA=`],s:[6,`AAAAcMhgGIh4AAA=`],t:[4,`AEBA4EBAQEBgAAA=`],u:[6,`AAAAREREREx0AAA=`],v:[5,`AAAAiEhQUDAgAAA=`],w:[8,`AAAAmZpaamYkAAA=`],x:[6,`AAAAyFAwMFDMAAA=`],y:[5,`AAAAiEhQUDAgIMA=`],z:[6,`AAAAeBgQIED4AAA=`],"{":[4,`ACBAQEBAgEBAQGA=`],"|":[3,`AEBAQEBAQEBAQEA=`],"}":[4,`AMAgICAgICAgIMA=`],"~":[7,`AAAAAABk3AAAAAA=`],"°":[4,`AGCQYAAAAAAAAAA=`],"±":[7,`AAAAEBB8EAB8AAA=`],µ:[7,`AAAAREREREx0QEA=`]},samples:{"-10.5":26,"21.9":21,1013:25,Temperature:66,"Living room":62,"48%":25,"°C":12}},"./fonts/font_body16.json":{id:`font_body16`,charset:`body`,size:16,height:17,baseline:14,maxWidth:16,errchar:`?`,glyphs:{" ":[5,`AAAAAAAAAAAAAAAAAAAAAAA=`],"!":[5,`AAAgICAgICAgIAAAYGAAAAA=`],'"':[5,`AABQUFBQAAAAAAAAAAAAAAA=`],"#":[11,`AAAAAAmACYAJAH/AGQAZABEAEwB/wBMAEgAyAAAAAAAAAA==`],$:[10,`CAAIAD8Aa4BIAGgAeAA+AAeACYAIgEiAe4AfAAgAAAAAAA==`],"%":[16,`AAAAADgYZDBGYEJAZsA9gAE8A2YGQgRCDGYYPAAAAAAAAA==`],"&":[12,`AAAAAB4AMwAxABMAHgA8QGZAQ8BBgEHAc2A+cAAAAAAAAA==`],"'":[3,`AABAQEBAAAAAAAAAAAAAAAA=`],"(":[5,`AAAwICBgQEBAQEBAYCAgMBg=`],")":[5,`AABgIDAQEBAQEBAQEDAgIEA=`],"*":[7,`AAAQVDw4LAAAAAAAAAAAAAA=`],"+":[10,`AAAAAAAAAAAAAAwADAAMAAwAf4AMAAwADAAMAAAAAAAAAA==`],",":[3,`AAAAAAAAAAAAAAAAYGBAQAA=`],"-":[6,`AAAAAAAAAAAAfAAAAAAAAAA=`],".":[3,`AAAAAAAAAAAAAAAAYGAAAAA=`],"/":[6,`AAAMDAgYEBAwICBgQMAAAAA=`],0:[11,`AAAAAB8AOYAwgHjAaMBswGbAYsBjwCGAMYAfAAAAAAAAAA==`],1:[7,`AAAIGHgICAgICAgICAgAAAA=`],2:[9,`AAAAAB4AMwBhAAEAAQADAAYADAAYADAAYAB/gAAAAAAAAA==`],3:[10,`AAAAAB4AcwBhAAEAAwAOAAMAAYABgEGAcwA+AAAAAAAAAA==`],4:[10,`AAAAAAMABwAPAAsAGwAzACMAQwB/wAMAAwADAAAAAAAAAA==`],5:[10,`AAAAAD8AIAAgACAAfgBzACGAAYABgGGAMwAeAAAAAAAAAA==`],6:[10,`AAAAAB4AM4AgAGAAfgBzAGGAYIBggGGAMwAeAAAAAAAAAA==`],7:[9,`AAAAAP8AAwADAAIABgAEAAwACAAYABAAMAAwAAAAAAAAAA==`],8:[10,`AAAAAA4AEwAxACEAMwAfADGAYIBggGCAM4AfAAAAAAAAAA==`],9:[10,`AAAAAB4AMwBhgGCAYIBhgDOAHwACAAYABAAMAAAAAAAAAA==`],":":[3,`AAAAAABgYAAAAAAAYGAAAAA=`],";":[3,`AAAAAABgYAAAAAAAYGBAQAA=`],"<":[9,`AAAAAAAAAAAAAAAAAYAPADgAYABwABwAB4AAgAAAAAAAAA==`],"=":[10,`AAAAAAAAAAAAAAAAAAAAAH+AAAAAAH+AAAAAAAAAAAAAAA==`],">":[9,`AAAAAAAAAAAAAAAAYAA4AA4AA4AHABwAcABAAAAAAAAAAA==`],"?":[9,`AAAAAD4AZwBDAAMAAwAGABgAGAAYAAAAGAAYAAAAAAAAAA==`],"@":[13,`AAAAAA+AGOAwIGeQTJBIkEiQSZBv4DAAGIAPgAAAAAAAAA==`],A:[11,`AAAAAAwADgAKABoAEwAxADGAIYB/gGDAQMDAQAAAAAAAAA==`],B:[11,`AAAAAH8AYYBggGCAYYB/AGGAYMBgwGDAYYB/AAAAAAAAAA==`],C:[11,`AAAAAA8AOcAwQGAAYABAAEAAYABgADBgOcAPAAAAAAAAAA==`],D:[11,`AAAAAH4AY4BgwGBAYEBgYGBgYEBgQGDAY4B+AAAAAAAAAA==`],E:[10,`AAAAAH+AYABgAGAAYAB+AGAAYABgAGAAYAB/gAAAAAAAAA==`],F:[9,`AAAAAH+AYABgAGAAYAB/gGAAYABgAGAAYABgAAAAAAAAAA==`],G:[12,`AAAAAA8AOcAwQGAAYABAAEPgYGBgYDBgOeAPIAAAAAAAAA==`],H:[12,`AAAAAGBAYEBgQGBAYEB/wGBAYEBgQGBAYEBgQAAAAAAAAA==`],I:[7,`AAB8EBAQEBAQEBAQEHwAAAA=`],J:[9,`AAAAAAIAAgACAAIAAgACAAIAAgDCAMIAZgA8AAAAAAAAAA==`],K:[11,`AAAAAGDAYYBjAGYAbAB8AHYAdgBjAGGAYYBgwAAAAAAAAA==`],L:[9,`AAAAAGAAYABgAGAAYABgAGAAYABgAGAAYAB/gAAAAAAAAA==`],M:[14,`AAAAAHA4cDh4eHh4aFhs2GzYZJhnmGeYYxhjGAAAAAAAAA==`],N:[12,`AAAAAHBAcEB4QGhAbEBkQGZAYkBjQGFAYcBgwAAAAAAAAA==`],O:[12,`AAAAAA+AOcAwYGBgYCBAMEAwYCBgYDBgOcAPgAAAAAAAAA==`],P:[10,`AAAAAH8AYYBggGDAYMBhgH8AYABgAGAAYABgAAAAAAAAAA==`],Q:[13,`AAAAAA+AOcAwYGBgYCBAMEMwY6Bh4DDgOfAPmAAQAAAAAA==`],R:[11,`AAAAAH8AYYBgwGDAYMBhgH8AZgBiAGMAYYBgwAAAAAAAAA==`],S:[10,`AAAAAB4Ac4BhAEAAYAA+AAeAAYAAgECAc4AeAAAAAAAAAA==`],T:[9,`AAAAAP+ADAAMAAwADAAMAAwADAAMAAwADAAMAAAAAAAAAA==`],U:[12,`AAAAAGBAYEBgQGBAYEBgQGBAYEBgQCDAOcAfAAAAAAAAAA==`],V:[10,`AAAAAMDAQIBhgGGAIQAzADMAEgAeAB4ADAAMAAAAAAAAAA==`],W:[14,`AAAAAMMMQwxDjGeIZphkmCSYNNA8cDxwGHAYYAAAAAAAAA==`],X:[11,`AAAAAODAYYAxgBsAHgAMAA4AHgATADGAYYDAwAAAAAAAAA==`],Y:[10,`AAAAAMDAYYAhgDMAEgAeAAwADAAMAAwADAAMAAAAAAAAAA==`],Z:[10,`AAAAAH+AAYABAAMABgAMAAwAGAAwACAAYAB/wAAAAAAAAA==`],"[":[5,`AAB4YGBgYGBgYGBgYGBgYHg=`],"\\":[6,`AADAQGAgIDAQEBgIDAwAAAA=`],"]":[5,`AABwEBAQEBAQEBAQEBAQEHA=`],"^":[9,`AAAIAAwAHAAWADIAIwBhAAAAAAAAAAAAAAAAAAAAAAAAAA==`],_:[7,`AAAAAAAAAAAAAAAAAAD+AAA=`],"`":[5,`AEBgMAAAAAAAAAAAAAAAAAA=`],a:[9,`AAAAAAAAAAAAAB4AdgAjAAMAPwBjAEMAZwA5AAAAAAAAAA==`],b:[10,`AAAAAGAAYABgAG4AcwBhgGGAYYBhgGGAcwBOAAAAAAAAAA==`],c:[9,`AAAAAAAAAAAAAB4AMwBiAEAAQABAAGAAMwAcAAAAAAAAAA==`],d:[10,`AAAAAAEAAQABAB0AcwBhAEEAQQBBAGEAc4AdgAAAAAAAAA==`],e:[9,`AAAAAAAAAAAAAB4AMwBhAEGAf4BAAEAAMwAeAAAAAAAAAA==`],f:[5,`ADggICD4ICAgICAgICAAAAA=`],g:[10,`AAAAAAAAAAAAAB0AdwBhAEEAQQBBAGEAdwA9AAEAYwA+AA==`],h:[9,`AAAAAGAAYABgAG4AcwBhAGEAYQBhAGEAYQBhAAAAAAAAAA==`],i:[5,`ADAwAABgICAgICAgICAAAAA=`],j:[5,`AAAwMAAQEBAQEBAQEBAQMOA=`],k:[8,`AABgYGBjZGx4eGxkZmMAAAA=`],l:[4,`AABgYGBgYGBgYGBgYDAAAAA=`],m:[14,`AAAAAAAAAAAAAE5wc5hjCGMIYwhjCGMIYwhjCAAAAAAAAA==`],n:[9,`AAAAAAAAAAAAAE4AcwBhAGEAYQBhAGEAYQBhAAAAAAAAAA==`],o:[9,`AAAAAAAAAAAAAB4AMwBhAEGAQYBBgGEAMwAeAAAAAAAAAA==`],p:[10,`AAAAAAAAAAAAAE4AcwBhgGGAYYBhgGGAcwBuAGAAYABgAA==`],q:[11,`AAAAAAAAAAAAAB0AcwBhAEEAQQBBAGEAcwAdAAEAAaAA4A==`],r:[6,`AAAAAABMcGBgYGBgYGAAAAA=`],s:[8,`AAAAAAA8ZkBgPgJDZjwAAAA=`],t:[6,`AAAAICD4ICAgICAgIDgAAAA=`],u:[9,`AAAAAAAAAAAAAGMAYwBjAGMAYwBjAGMAZwA9AAAAAAAAAA==`],v:[8,`AAAAAADDRkZkJCw4GBgAAAA=`],w:[11,`AAAAAAAAAAAAAMRgzmBKQEpAasB5wDGAMYAxgAAAAAAAAA==`],x:[8,`AAAAAADDZjw4GDwsZsMAAAA=`],y:[7,`AAAAAADCxkZkbCwoOBgQMGA=`],z:[8,`AAAAAAB+BgQIGDAgQH4AAAA=`],"{":[5,`AAA4ICAgICAgQGAgICAgIDg=`],"|":[4,`AABgYGBgYGBgYGBgYGBgYGA=`],"}":[5,`AABgMDAwMDAwGDAwMDAwMGA=`],"~":[9,`AAAAAAAAAAAAAAAAAAAAAHmATwAAAAAAAAAAAAAAAAAAAA==`],"°":[6,`AAAwSEhIeAAAAAAAAAAAAAA=`],"±":[10,`AAAAAAAAAAAAAAwADAAMAH+ADAAMAAwAAAB/gAAAAAAAAA==`],µ:[9,`AAAAAAAAAAAAAGEAYQBhAGEAYQBjAGMAdwB9gGAAYABgAA==`]},samples:{"-10.5":37,"21.9":29,1013:35,Temperature:96,"Living room":89,"48%":36,"°C":17}},"./fonts/font_body20.json":{id:`font_body20`,charset:`body`,size:20,height:19,baseline:15,maxWidth:19,errchar:`?`,glyphs:{" ":[6,`AAAAAAAAAAAAAAAAAAAAAAAAAA==`],"!":[6,`AAAwMDAwMDAwICAAMDAwAAAAAA==`],'"':[6,`AABISEhIAAAAAAAAAAAAAAAAAA==`],"#":[13,`AAAAAARADMAMwD/wTMAIwAiACIB/8BmAGYAZgBGAAAAAAAAAAAA=`],$:[12,`BAAGAD+AdMBkAGQAdAA+AA/ABOAEYCRgZGA9wB+ABAAAAAAAAAA=`],"%":[19,`AAAAAAAAPAYAdgwAQxgAQRAAYzAAPmAAAM8AAJmAAZDAAxDAAhDABh+ADA8AAAAAAAAAAAAAAAAA`],"&":[14,`AAAAAA+AHcAYwBjAGYAPAD8wY7Bh8GDgYPA7uB8cAAAAAAAAAAA=`],"'":[3,`AABAQEBAAAAAAAAAAAAAAAAAAA==`],"(":[6,`AAAYMCAgYGBgQGBgYCAgMBAYAA==`],")":[6,`AABgMBAQGBgICAgYGBAQMCBgAA==`],"*":[9,`AAAAAAgASgB+ABgANAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`],"+":[12,`AAAAAAAAAAAAAAYABgAGAAYAf+AGAAYABgAGAAYAAAAAAAAAAAA=`],",":[4,`AAAAAAAAAAAAAAAAAGBgIGBAAA==`],"-":[7,`AAAAAAAAAAAAfgAAAAAAAAAAAA==`],".":[4,`AAAAAAAAAAAAAAAAYGBgAAAAAA==`],"/":[8,`AAAGBgwMCBgYMDAgYGDAAAAAAA==`],0:[13,`AAAAAA+AHcAwYDhgbDBmMGIwYzBhsCCgMGAdwA+AAAAAAAAAAAA=`],1:[8,`AAAEHHwMDAwMDAwMDAwMAAAAAA==`],2:[11,`AAAAAB8AO4BgwCDAAMAAgAGAAwAGAAwAMABgAH/AAAAAAAAAAAA=`],3:[11,`AAAAAB8AO8BgwADAAYAPAAOAAMAAwGDAYMA7gB8AAAAAAAAAAAA=`],4:[12,`AAAAAAGAA4AHgA2ACYAZgDGAYYB/8AGAAYABgAGAAAAAAAAAAAA=`],5:[12,`AAAAAD/AMAAgACAALwA5wGDAAEAAQCBAYMA7gB8AAAAAAAAAAAA=`],6:[12,`AAAAAA+AH8AwACAAb4B5wHDAYGBgYGBgMMA/wA8AAAAAAAAAAAA=`],7:[10,`AAAAAP/AAMABgAGAAwADAAYABgAMAAwAGAAYADAAAAAAAAAAAAA=`],8:[12,`AAAAAA8AH4AQwBDAGYAfgDnAYGBgYGBgcGA/wA+AAAAAAAAAAAA=`],9:[12,`AAAAAA8AP8AwwGBgYGBgYCDAOcAfgAGAAwAGAA4AAAAAAAAAAAA=`],":":[4,`AAAAAABgYGAAAAAAYGBgAAAAAA==`],";":[4,`AAAAAABgYGAAAAAAAGBgIGBAAA==`],"<":[11,`AAAAAAAAAAAAAABAAcAHgBwAcABwADwAB4ABwABAAAAAAAAAAAA=`],"=":[12,`AAAAAAAAAAAAAAAAAAB/4AAAAAAAAH/gAAAAAAAAAAAAAAAAAAA=`],">":[11,`AAAAAAAAAAAAAEAAcAA8AAcAAcABwAeAPABwAEAAAAAAAAAAAAA=`],"?":[10,`AAAAAB8AP4BhgACAAYADAA4ADAAIAAAACAAcAAwAAAAAAAAAAAA=`],"@":[16,`AAAAAAfgD/A4GCPkZ2RMZkxmRORnvCAAMAAP4AfAAAAAAAAAAAA=`],A:[13,`AAAAAAcABwANAA2AGYAYgBjAMMA/4D/gYGBgMMAwAAAAAAAAAAA=`],B:[12,`AAAAAD+AIcAgYCBgIGAgwD/AIOAgYCAwIGAg4D/AAAAAAAAAAAA=`],C:[13,`AAAAAAfAH+AwMDAAYABgAGAAYABgADAAMDAf4A/AAAAAAAAAAAA=`],D:[13,`AAAAAD+AI+AgYCAwIDAgECAQIDAgMCAwIGAj4D+AAAAAAAAAAAA=`],E:[11,`AAAAAD/gIAAgACAAIAAgAD+AIAAgACAAIAAgAD/gAAAAAAAAAAA=`],F:[11,`AAAAAD/AIAAgACAAIAAgAD/AIAAgACAAIAAgACAAAAAAAAAAAAA=`],G:[14,`AAAAAAfAH+AwMDAAYABgAGH4YBhgGDAYMDgf+A/IAAAAAAAAAAA=`],H:[14,`AAAAACAwIDAgMCAwIDAgMD/wIDAgMCAwIDAgMCAwAAAAAAAAAAA=`],I:[8,`AAB+GBgYGBgYGBgYGBh+AAAAAA==`],J:[10,`AAAAAAGAAYABgAGAAYABgAGAAYABgMGAQwB3AD4AAAAAAAAAAAA=`],K:[13,`AAAAACBwIMAhgCOAJwAuAC4AOwAxgCHAIMAgYCAwAAAAAAAAAAA=`],L:[11,`AAAAACAAIAAgACAAIAAgACAAIAAgACAAIAA/4D/gAAAAAAAAAAA=`],M:[16,`AAAAADgOOB4oHiwWLDYkNiYmJmYiZiNGI8YhxiGGAAAAAAAAAAA=`],N:[14,`AAAAADgwODAsMCwwJjAmMCMwIzAhsCDwIPAgcCBwAAAAAAAAAAA=`],O:[15,`AAAAAAfAHvAwMDAYYBhgCGAMYAhgGDAYMDAe8AfAAAAAAAAAAAA=`],P:[12,`AAAAAD+AI+AgYCBgIGAg4D/AIAAgACAAIAAgACAAAAAAAAAAAAA=`],Q:[15,`AAAAAAfAHvAwMDAYYBhgCGEMYchg+DB4MDge/AfOAAQAAAAAAAA=`],R:[12,`AAAAAD+AI+AgYCBgIGAg4D/AIwAjgCGAIMAg4CBwAAAAAAAAAAA=`],S:[12,`AAAAAB8AP8BgwGAAYAA8AB+AAeAAYABgYGA/wB+AAAAAAAAAAAA=`],T:[11,`AAAAAP/gBgAGAAYABgAGAAYABgAGAAYABgAGAAYAAAAAAAAAAAA=`],U:[14,`AAAAACAwIDAgMCAwIDAgMCAwIDAgMDAwMDAd4A/AAAAAAAAAAAA=`],V:[12,`AAAAAMBwYGBgYGDAMMAwwDGAGYAZgAsADwAPAAYAAAAAAAAAAAA=`],W:[17,`AAAAAAAAwcOAYcMAYcMAYUMAY2YAM2YAMmYAMiYANiwAHjwAHDwAHBwAHBgAAAAAAAAAAAAAAAAA`],X:[12,`AAAAAOBwMGA4wBmAD4APAAYADwANgBnAMMBwYOAwAAAAAAAAAAA=`],Y:[12,`AAAAAOBwYGAwwDDAGYALAA8ABgAGAAYABgAGAAYAAAAAAAAAAAA=`],Z:[12,`AAAAAH/gAGAAwAGAA4ADAAYADAAYADgAMABgAH/gAAAAAAAAAAA=`],"[":[6,`AAA8ICAgICAgICAgICAgICA8AA==`],"\\":[8,`AADAYGAgMDAYGAgMDAYGAAAAAA==`],"]":[6,`AAB4GBgYGBgYGBgYGBgYGBh4AA==`],"^":[11,`AAAAAAYADgAbABsAMYAxgGDAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`],_:[8,`AAAAAAAAAAAAAAAAAAAA/wAAAA==`],"`":[5,`AEBgMAAAAAAAAAAAAAAAAAAAAA==`],a:[11,`AAAAAAAAAAAAAB8AP4BhgAGAD4A4gGCAYYB2gDzAAAAAAAAAAAA=`],b:[11,`AAAAAGAAYABgAG8Af4BwwGDAYGBgYGDAcMB/gG8AAAAAAAAAAAA=`],c:[10,`AAAAAAAAAAAAAB8AO4BggGAAYABgAGAAYIA7gB8AAAAAAAAAAAA=`],d:[11,`AAAAAADAAMAAwB7AO8BgwGDAYMBgwGDAYMA7wB5AAAAAAAAAAAA=`],e:[11,`AAAAAAAAAAAAAB8AO4BgwGDAf8BgAGAAYAA7wB8AAAAAAAAAAAA=`],f:[6,`ADwwMDD8MDAwMDAwMDAwAAAAAA==`],g:[11,`AAAAAAAAAAAAAB7AO8BgwGDAYMBgwGDAYMA7wB7AAMAQwDGAHwA=`],h:[11,`AAAAAGAAYABgAG8Af4BwgGDAYMBgwGDAYMBgwGDAAAAAAAAAAAA=`],i:[6,`ADAwAABwMDAwMDAwMDAwAAAAAA==`],j:[6,`ADgYAAAQEBAQEBAQEBAQEHDgAA==`],k:[10,`AAAAAGAAYABgAGGAYwBmAGwAfAB8AGYAYwBjAGHAAAAAAAAAAAA=`],l:[5,`AABgYGBgYGBgYGBgYHAwAAAAAA==`],m:[17,`AAAAAAAAAAAAAAAAAAAAbzwAe/4AccYAYIIAYIIAYIIAYIIAYIIAYIIAYIIAAAAAAAAAAAAAAAAA`],n:[11,`AAAAAAAAAAAAAG8Af4BwgGDAYMBgwGDAYMBgwGDAAAAAAAAAAAA=`],o:[11,`AAAAAAAAAAAAAB8AO4BgwGDAYMBgwGDAYMA7gB8AAAAAAAAAAAA=`],p:[11,`AAAAAAAAAAAAAG8Af4BwwGDAYGBgYGDAcMB/gG8AYABgAGAAAAA=`],q:[13,`AAAAAAAAAAAAAB5AO8BgwGDAYMBgwGDAYMA7wB7AAMAA6AB4AAA=`],r:[7,`AAAAAABmfHBgYGBgYGBgAAAAAA==`],s:[9,`AAAAAAAAAAAAAD4AdwBiAGAAPAAHAAGAQYB3AB4AAAAAAAAAAAA=`],t:[6,`AAAwMDD8MDAwMDAwMDAcAAAAAA==`],u:[11,`AAAAAAAAAAAAAGCAYIBggGCAYIBggGCAYYA/gB6AAAAAAAAAAAA=`],v:[9,`AAAAAAAAAAAAAMGAQQBjAGMAIgA2ADYAFAAcABgAAAAAAAAAAAA=`],w:[13,`AAAAAAAAAAAAAMMYxxhFEGUwbbAtsCigOOA44BhAAAAAAAAAAAA=`],x:[9,`AAAAAAAAAAAAAMGAYwA2AB4AHAAcABYANgBjAMGAAAAAAAAAAAA=`],y:[9,`AAAAAAAAAAAAAMGAQwBjAGIAJgA2ADQAHAAcABgAGAA4AHAAAAA=`],z:[9,`AAAAAAAAAAAAAH8AAwADAAYADAAYADAAMABgAH+AAAAAAAAAAAA=`],"{":[6,`AAAcODAwMDAwYDAwMDAwMDgcAA==`],"|":[5,`AAAgICAgICAgICAgICAgICAgAA==`],"}":[6,`AABwMBAQEBAYDBgQEBAQEDBwAA==`],"~":[11,`AAAAAAAAAAAAAAAAAAAAAAAAPEBnwAAAAAAAAAAAAAAAAAAAAAA=`],"°":[7,`AAA4bERkOAAAAAAAAAAAAAAAAA==`],"±":[12,`AAAAAAAAAAAAAAYABgAGAH/gBgAGAAYAAAAAAH/gAAAAAAAAAAA=`],µ:[11,`AAAAAAAAAAAAAGCAYIBggGCAYIBggGCAYYB/4H7gYABgAGAAAAA=`]},samples:{"-10.5":44,"21.9":35,1013:40,Temperature:114,"Living room":106,"48%":43,"°C":20}},"./fonts/font_body24.json":{id:`font_body24`,charset:`body`,size:24,height:25,baseline:20,maxWidth:23,errchar:`?`,glyphs:{" ":[7,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==`],"!":[7,`AAAAODg4ODg4GBAQEBAQAAA4ODgAAAAAAA==`],'"':[8,`AAAAZmRkZGRkAAAAAAAAAAAAAAAAAAAAAA==`],"#":[16,`AAAAAAAAAxgDGAYYBjA//j/+BjAGMAYwDjAMMH/+f/wMYAxgDGAcYAAAAAAAAAAAAAA=`],$:[15,`AQABAAOAH+A98HE4cQBxAHEAPQAfwAfwAXgBHAEcERxxHDk4H/AP4AEAAQAAAAAAAAA=`],"%":[23,`AAAAAAAAAAAAHwDgP4HAccGAYMMAYMYAYMYAccwAP5gADjjwADP4AGMcAOYMAMYMAYYMA4McAwP4BgDwAAAAAAAAAAAAAAAAAAAA`],"&":[18,`AAAAAAAAAAAAB8AAD/AADDAAHDAAHDAADHAABuAAB8AAH4YAOcYAcOYAYHwAYDwAcBwAMH4AP+cAD8OAAAAAAAAAAAAAAAAAAAAA`],"'":[4,`AAAAYGBgYGBgAAAAAAAAAAAAAAAAAAAAAA==`],"(":[8,`AAAADBgYMDAwIGBgYGBgYCAwMDAYGAwOAA==`],")":[8,`AAAAMBAYGAwMDAwMDAwMDAwMCBgYMDBgAA==`],"*":[11,`AAAAAAAABAAEADWAP4AOABoAEwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`],"+":[15,`AAAAAAAAAAAAAAAAAAABgAGAAYABgAGAAYB//H/8AYABgAGAAYABgAAAAAAAAAAAAAA=`],",":[5,`AAAAAAAAAAAAAAAAAAAAAABwcHAwIGAAAA==`],"-":[9,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/AH8AAAAAAAAAAAAAAAAAAAAAAAAAAAA=`],".":[5,`AAAAAAAAAAAAAAAAAAAAAABwcHAAAAAAAA==`],"/":[9,`AAAAAAAAAYADAAMAAwAGAAYADgAMAAwAGAAYADgAMAAwAHAAYADgAAAAAAAAAAAAAAA=`],0:[16,`AAAAAAAAB+AP8Bw4PBw+DDYMNw5zjnGOMM4w7jBsMDw4PBw4D/AH4AAAAAAAAAAAAAA=`],1:[10,`AAAAAAAAAwAHAH8AfwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAAAAAAAAAAAAAA=`],2:[14,`AAAAAAAAB8Af4DhwMDBQMAAwADAAcABgAMABgAMADgAcADgAf/h/+AAAAAAAAAAAAAA=`],3:[14,`AAAAAAAAD8Af4DhwcDAQMAAwAHAHwAfgAHAAOAAYIBhwODhwH+APwAAAAAAAAAAAAAA=`],4:[15,`AAAAAAAAAGAA4AHgAeADYAZgDmAMYBhgMGBwYH/8f/wAYABgAGAAYAAAAAAAAAAAAAA=`],5:[15,`AAAAAAAAH/Af8BAAMAAwADfAP+A4cDA4ABgAGAAYYBgwODhwH+APwAAAAAAAAAAAAAA=`],6:[15,`AAAAAAAAB+AP8Bw4GAAwADPAP/A8cHg4cBgwGDAYMBg4GBgwH/AHwAAAAAAAAAAAAAA=`],7:[13,`AAAAAAAA//D/8ABwAGAA4ADAAcABgAOAAwAHAAYADgAOAAwAHAA4AAAAAAAAAAAAAAA=`],8:[15,`AAAAAAAAA8AP4AxwGDAYMBgwDHAP4B/wODgwHDAMcAwwHDg4H/AH4AAAAAAAAAAAAAA=`],9:[15,`AAAAAAAAB8Af4BhwMBgwGHAYMBgwGDg4HHAP8AfgAOAAwAHAA4AHAAAAAAAAAAAAAAA=`],":":[5,`AAAAAAAAAHBwcAAAAAAAAABwcHAAAAAAAA==`],";":[5,`AAAAAAAAAHBwcAAAAAAAAABwcHAwIGAAAA==`],"<":[14,`AAAAAAAAAAAAAAAAAAAAAAAYAHgD4A+APgBwAHgAHwAHwAHwAHgACAAAAAAAAAAAAAA=`],"=":[15,`AAAAAAAAAAAAAAAAAAAAAAAAAAB//H/8AAAAAAAAf/x//AAAAAAAAAAAAAAAAAAAAAA=`],">":[14,`AAAAAAAAAAAAAAAAAAAAAGAAeAA/AAfAAfAAeAB4A+APgD4AcABAAAAAAAAAAAAAAAA=`],"?":[13,`AAAAAAAAD4A/4DBgYHAgMABwAGABwAOABwAGAAYAAAAAAA4ADgAOAAAAAAAAAAAAAAA=`],"@":[20,`AAAAAAAAAAAAAfgAB/4ADgcAGAOAMPjAM/jAYxhAYxhAZxhAZxjAYzjAM/+AMccAGAAADgQAB/gAAfgAAAAAAAAAAAAAAAAAAAAA`],A:[16,`AAAAAAAAA4ADwAPABsAGYA5gDHAMMBwwGDgYGD/4P/wwDHAMYA7gBgAAAAAAAAAAAAA=`],B:[15,`AAAAAAAAP+A/+DAYMBwwHDAcMBg/8D/4MBwwDDAMMA4wDDAcP/g/8AAAAAAAAAAAAAA=`],C:[16,`AAAAAAAAA/AP/B4eOAY4ADAAcABwAHAAcABwADAAOAA4Bh4OD/wD8AAAAAAAAAAAAAA=`],D:[17,`AAAAAAAAAAAAP8AAP/gAMDwAMAwAMA4AMAYAMAYAMAcAMAcAMAcAMAYAMAYAMA4AMAwAMDwAP/gAP8AAAAAAAAAAAAAAAAAAAAAA`],E:[14,`AAAAAAAAP/g/+DAAMAAwADAAMAA/4D/gMAAwADAAMAAwADAAP/g/+AAAAAAAAAAAAAA=`],F:[14,`AAAAAAAAP/g/+DAAMAAwADAAMAA/+D/4MAAwADAAMAAwADAAMAAwAAAAAAAAAAAAAAA=`],G:[18,`AAAAAAAAAAAAA/AAD/wAHh4AOAYAOAAAMAAAcAAAcAAAcH8AcH8AcAMAMAMAOAcAOAcAHA8AD/sAA/EAAAAAAAAAAAAAAAAAAAAA`],H:[17,`AAAAAAAAAAAAMAYAMAYAMAYAMAYAMAYAMAYAMAYAP/4AP/4AMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAAAAAAAAAAAAAAAAAAAAA`],I:[10,`AAAAAAAAP4A/gAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAP4A/gAAAAAAAAAAAAAA=`],J:[13,`AAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4CDg4OBg4HHAP8AfAAAAAAAAAAAAAAA=`],K:[16,`AAAAAAAAMB4wODAwMHAw4DHAM4A3gD+APcA44DBgMHAwODAcMBwwDgAAAAAAAAAAAAA=`],L:[13,`AAAAAAAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAP/g/+AAAAAAAAAAAAAA=`],M:[21,`AAAAAAAAAAAAPAHgPAPgPgPgNgPgNgfgNwbgMwbgMw7gM4zgMYzgMZzgMZjgMNjgMPjgMPDgMHDgMHDgAAAAAAAAAAAAAAAAAAAA`],N:[17,`AAAAAAAAAAAAPAYAPAYAPgYANgYANwYAMwYAM4YAMYYAMcYAMMYAMOYAMGYAMDYAMDYAMB4AMB4AMA4AAAAAAAAAAAAAAAAAAAAA`],O:[18,`AAAAAAAAAAAAA/AAD/wAHg4AGAcAOAMAMAOAcAOAcAOAcAGAcAOAcAOAMAOAOAMAGAcAHg4AD/wAA/AAAAAAAAAAAAAAAAAAAAAA`],P:[15,`AAAAAAAAP+A/+DAcMBwwDDAMMBwwHD/4P+AwADAAMAAwADAAMAAwAAAAAAAAAAAAAAA=`],Q:[19,`AAAAAAAAAAAAA/AAD/wAHg4AGAcAOAMAMAMAcAOAcAOAcGGAcPOAcHuAMD+AOB8AGAcAHg+AD/3AA/DgAABAAAAAAAAAAAAAAAAA`],R:[15,`AAAAAAAAP+A/+DAcMBwwDDAMMBwwPD/4P+AxwDDgMHAwcDA4MBwwHgAAAAAAAAAAAAA=`],S:[15,`AAAAAAAAD8Af8Dg4cBBwAHAAOAA/gA/wAPgAHAAcABxwHDg4H/APwAAAAAAAAAAAAAA=`],T:[14,`AAAAAAAA//z//AMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAAAAAAAAAAAAAA=`],U:[17,`AAAAAAAAAAAAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAOAYAOA4AHBwAD/wAB/AAAAAAAAAAAAAAAAAAAAAA`],V:[15,`AAAAAAAA4AxgHHAccBgwODg4ODAYcBxwHGAMYAzgDsAGwAfAB4ADgAAAAAAAAAAAAAA=`],W:[21,`AAAAAAAAAAAA4HA4YHAwYHAwcNhwcNhwMNhgMNhgOYzgOYzgGYzAGYzAGY3AHwfADweADweADweADgOAAAAAAAAAAAAAAAAAAAAA`],X:[16,`AAAAAAAAcA4wHDg4HDgOcA7gB8ADwAOAB8AH4A5gHHAcODgccBzgDgAAAAAAAAAAAAA=`],Y:[15,`AAAAAAAA4A5wHDAYODgYMBxgDOAGwAfAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAA=`],Z:[15,`AAAAAAAAf/x//AA4ADgAcADgAcABwAOABwAGAA4AHAA4ADAAf/x//AAAAAAAAAAAAAA=`],"[":[8,`AAAAPj4wMDAwMDAwMDAwMDAwMDAwMD4+AA==`],"\\":[9,`AAAAAAAA4ABgAHAAMAAwADgAGAAYAAwADAAOAAYABgADAAMAAwABgAAAAAAAAAAAAAA=`],"]":[8,`AAAAfHwMDAwMDAwMDAwMDAwMDAwMDHx8AA==`],"^":[14,`AAAAAAAAAwAHgAeADcAMwBjgGGAwcHAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`],_:[10,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/A/8AAAAAAAAA=`],"`":[7,`ACBwMBgAAAAAAAAAAAAAAAAAAAAAAAAAAA==`],a:[13,`AAAAAAAAAAAAAAAAAAAPgB/AOOAwYABgAeAf4DhgcGBgYHDwP7AfMAAAAAAAAAAAAAA=`],b:[14,`AAAAAAAAMAAwADAAMAAzwD/gOHA4ODAYMBgwGDAYMBgwODhwP+AjwAAAAAAAAAAAAAA=`],c:[13,`AAAAAAAAAAAAAAAAAAAPgB/gOHAwQGAAYABgAGAAYABwQDhwH+APgAAAAAAAAAAAAAA=`],d:[14,`AAAAAAAAADAAMAAwADAPsB/wOHBwMHAwYDBgMGAwcDBwMDhwH/gPGAAAAAAAAAAAAAA=`],e:[13,`AAAAAAAAAAAAAAAAAAAPgB/gOHAwMGA4f/h/+GAAYAAwADhwH+APwAAAAAAAAAAAAAA=`],f:[8,`AAAeHjg4OP7+ODg4ODg4ODg4ODgAAAAAAA==`],g:[14,`AAAAAAAAAAAAAAAAAAAPEB/wOHBwMGAwYDBgMGAwYDBwMDhwH/APMAAwADA4cB/gD8A=`],h:[14,`AAAAAAAAMAAwADAAMAAzwD/gOHAwMDAwMDAwMDAwMDAwMDAwMDAwMAAAAAAAAAAAAAA=`],i:[7,`AAAYOBgAAHh4GBgYGBgYGBgYGBgAAAAAAA==`],j:[7,`AAAYHBgAABgYGBgYGBgYGBgYGBgYGPjwAA==`],k:[12,`AAAAAAAAMAAwADAAMAAw4DDAMYAzADYAPgA+ADsAM4AxwDDAMOAwcAAAAAAAAAAAAAA=`],l:[6,`AAAAMDAwMDAwMDAwMDAwMDAwPDwAAAAAAA==`],m:[21,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAI8eAP+/AOHjgMHBgMHBgMHBgMHBgMHBgMHBgMHBgMHBgMHBgMHBgAAAAAAAAAAAAAAAAAAAA`],n:[14,`AAAAAAAAAAAAAAAAAAAjwD/gOHAwMDAwMDAwMDAwMDAwMDAwMDAwMAAAAAAAAAAAAAA=`],o:[14,`AAAAAAAAAAAAAAAAAAAPgB/gOHAwMGA4YBhgGGAYYDgwMDhwH+APgAAAAAAAAAAAAAA=`],p:[14,`AAAAAAAAAAAAAAAAAAAjwD/gOHA4ODAYMBgwGDAYMBgwODhwP+AzwDAAMAAwADAAAAA=`],q:[16,`AAAAAAAAAAAAAAAAAAAPEB/wOHBwMHAwYDBgMGAwcDBwMDhwH/APMAAwADgAHwAPAAA=`],r:[9,`AAAAAAAAAAAAAAAAAAAjADcAPAA4ADAAMAAwADAAMAAwADAAMAAwAAAAAAAAAAAAAAA=`],s:[12,`AAAAAAAAAAAAAAAAAAAfAD/AcMBgAHAAPgAfwAHgAGAgYHDgP8AfgAAAAAAAAAAAAAA=`],t:[8,`AAAAABgYGP7+GBgYGBgYGBgYHh4AAAAAAA==`],u:[13,`AAAAAAAAAAAAAAAAAAAwMDAwMDAwMDAwMDAwMDAwMHAwcDjwH7APMAAAAAAAAAAAAAA=`],v:[11,`AAAAAAAAAAAAAAAAAADAYGDgYMBgwDHAMYAxgBsAGwAbAA4ADgAOAAAAAAAAAAAAAAA=`],w:[16,`AAAAAAAAAAAAAAAAAADBg+HDY8djxmNGMmY2bjZsNiwcPBw4HDgcGAAAAAAAAAAAAAA=`],x:[12,`AAAAAAAAAAAAAAAAAADg4HDAMcAbgB8ADwAOAA8AHwA5gDHAYODgcAAAAAAAAAAAAAA=`],y:[11,`AAAAAAAAAAAAAAAAAADA4GDAYMBhwDGAMYAzgBsAGwAbAA4ADgAOAAwADAB4AHAAAAA=`],z:[12,`AAAAAAAAAAAAAAAAAAB/4H/gAMABgAOABwAGAAwAGAA4AHAAf+B/4AAAAAAAAAAAAAA=`],"{":[8,`AAAADh4YGBgYGBg4cHA4GBgYGBgYGB4OAA==`],"|":[6,`AAAAMDAwMDAwMDAwMDAwMDAwMDAwMDAwAA==`],"}":[8,`AAAAcHgYGBgYGBgcDg4cGBgYGBgYGHhwAA==`],"~":[14,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPhh/8GHgAAAAAAAAAAAAAAAAAAAAAAAAAAA=`],"°":[9,`AAAAABwAPgBjAGMAYwA+ABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`],"±":[14,`AAAAAAAAAAAAAAAAAAADAAMAAwADAH/4f/gDAAMAAwADAAAAf/h/+AAAAAAAAAAAAAA=`],µ:[14,`AAAAAAAAAAAAAAAAAAAwMDAwMDAwMDAwMDAwMDAwMHAwcDjwP7w/HDAAMAAwADAAAAA=`]},samples:{"-10.5":55,"21.9":44,1013:50,Temperature:140,"Living room":131,"48%":53,"°C":25}},"./fonts/font_digits16.json":{id:`font_digits16`,charset:`digits`,size:16,height:16,baseline:16,maxWidth:23,errchar:`?`,glyphs:{" ":[8,`AAAAAAAAAAAAAAAAAAAAAA==`],"%":[23,`HgHgP4HAf8OAcccAYccAcc4Af9wAP5zwHzn8AHP8APOOAOcOAcOOA4P8A4H8BwDw`],"+":[15,`AAAAAAAAAAADgAOAA4ADgAOAf/x//H/8A4ADgAOAA4A=`],"-":[9,`AAAAAAAAAAAAAAAAAAAAAAAAfwB/AH8AAAAAAAAAAAA=`],".":[6,`AAAAAAAAAAAAAAAweHh4MA==`],0:[16,`B+Af8B/4PDw+PH4efx57nnmeeN54/jh8PDwf+B/wB+A=`],1:[11,`BwAHAA8AfwB/AH8ABwAHAAcABwAHAAcABwAHAAcABwA=`],2:[14,`B8Af8D/4eHgIeAB4AHgA8AHwA+AHwB8APgB/+H/4f/g=`],3:[15,`D8A/8H/4eHgAeAB4B/AH4AfwAPgAeBA4eHh/+D/wD8A=`],4:[15,`APAB8APwA/AH8A/wDvAc8DzwePB//H/8f/wA8ADwAPA=`],5:[15,`P/g/+D/4OAA4AH/Af/B/+Dh4ADgAPBA4eHg/+B/wD8A=`],6:[15,`B+AP8B/4PAA4ADvgf/B/+Hx8eDx4PDg8PHg/+B/wB8A=`],7:[13,`//D/8P/wAPAA8AHgAeADwAPAB4AHgA8ADwAeAB4APAA=`],8:[15,`B8AP4B/wHHAccBxwH/Af8D/4eDx4PHg8eDw/+B/wD+A=`],9:[13,`D4Af4D/gePBwcHBwcHB48D/wH+AP4APAA8AHgAeADwA=`],":":[6,`AAAAADB4eHgwAAAweHh4MA==`],"?":[15,`D+A/8H/4eDwAOAD4A/AHwAeADwAAAAcADwAPgA8ABwA=`]},samples:{"-10.5":57,"21.9":44,1013:53,Temperature:165,"Living room":158,"48%":53,"°C":30}},"./fonts/font_digits24.json":{id:`font_digits24`,charset:`digits`,size:24,height:24,baseline:24,maxWidth:34,errchar:`?`,glyphs:{" ":[11,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA`],"%":[34,`B8AB8AAf8APgAD/4B8AAP/wHgAB8fA8AAHg+HwAAeD4eAAB4PjwAAHx8fAAAP/x4AAA/+PD4AB/x8/4AB+Hn/wAAA8//AAAHz4+AAA+PB4AADw8HgAAfDweAAD4PB4AAPA+PgAB8D/8AAPgH/wAA8AP+AAHgAPgA`],"+":[22,`AAAAAAAAAAAAAAAAAAAAAAAAAHgAAHgAAHgAAHgAAHgAAHgAAHgAP//wP//wP//wP//wAHgAAHgAAHgAAHgAAHgAAHgAAHgA`],"-":[13,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/wf/B/8H/wAAAAAAAAAAAAAAAA`],".":[9,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAfgB/AH8AfwB+ABwA`],0:[23,`AP4AA/+AB//AD//gH8fwH4PwP8H4P8H4P+D4PvD4PvD8Pnj8Pjz8Phz8Ph74Pg/4Pwf4PwP4H4PwH8fwD//gB//AA/+AAP4A`],1:[16,`APAA8AHwA/A/8D/wP/A/8AHwAfAB8AHwAfAB8AHwAfAB8AHwAfAB8AHwAfAB8AHw`],2:[21,`AfwAB/8AD/+AH//AP4/gPwfgBgPgAAPgAAfgAAfgAA/AAB/AAD+AAH8AAP4AAfwAA/gAD/AAH8AAP4AAf//gf//gf//gf//g`],3:[21,`AfwAD/+AH//AP//gPw/gXgfgAAPgAAfgAB/AAf+AAf8AAf+AAf/AAB/gAAfgAAPgAAPgDAPgfgfgPw/gP//AH/+AD/8AAfwA`],4:[22,`AA/AAB/AAD/AAD/AAH/AAP/AAf/AAf/AA+/AB+/AB8/AD4/AHw/APw/APg/Af//4f//4f//4f//4AA/AAA/AAA/AAA/AAA/A`],5:[21,`H//gH//gH//gH//gHgAAPgAAPgAAPgAAPv4AP/+AP//AP//gPw/gDgPgAAPwAAPwAAPwBAPwfgfgPw/gP//AH/+AB/8AAfwA`],6:[22,`AH4AAf+AB//AD//gD8eAH4AAHwAAPwAAPn8AP/+AP//AP//gP4fwPwPwPwHwPgHwPgHwPwHwHwPwH8fgD//gD//AA/+AAPwA`],7:[19,`f//Af//Af//Af//AAA/AAA+AAB+AAB+AAD8AAD8AAH4AAH4AAPwAAPwAAfgAAfgAA/AAA/AAA/AAB+AAB+AAD8AAD8AAH4AA`],8:[22,`APwAAf4AA/8AB/+AD8+AD4fAD4fAD4fAD8+AB/+AB/+AD//AH//gP4fwPgPwfgHwfgH4fgHwPwPwP4fwH//gH//AB/+AAf4A`],9:[20,`AfAAB/wAD/8AH/8APx+APg/APAfAfAfAfAfAfAfAPAfAPg+APx+AH/+AD/8AB/8AAf4AAH4AAHwAAPwAAPgAAfgAAfAAA/AA`],":":[9,`AAAAAAAAAAAAAAAAHAB+AH8AfwB/AH4APAAAAAAAAAAAABwAfgB/AH8AfwB+ABwA`],"?":[21,`Af4AD/+AH//AP//gf4fwHgPwAgPwAAfwAB/gAH/AAP+AAf4AAfgAAfAAAfAAAAAAAAAAAeAAA/AAA/gAA/gAA/gAA/AAAeAA`]},samples:{"-10.5":82,"21.9":66,1013:76,Temperature:231,"Living room":221,"48%":78,"°C":42}},"./fonts/font_digits32.json":{id:`font_digits32`,charset:`digits`,size:32,height:32,baseline:31,maxWidth:43,errchar:`?`,glyphs:{" ":[14,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==`],"%":[43,`AEAAAAAAA/wAB+AAD/4AD8AAH/8AH4AAP/+AHwAAP//APwAAfw/AfgAAfgfAfAAAfAfA+AAAfAfB+AAAfgfD8AAAfg/D4AAAP5/H4AAAP/+PwAAAH/+Pg/gAD/8fj/4AB/4/H/8AAfg+P/8AAAB+P/+AAAD8fx+AAAD4fA/AAAH4fAfAAAPwfAfAAAPgfAfAAAfAfA/AAA/Afh+AAA+Af/+AAB8AP/8AAD8AH/8AAH4AD/4AAPwAB/gAAAAAAEAA`],"+":[27,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB8AAAAfAAAAHwAAAB8AAAAfAAAAHwAAAB8AAAAfAAA///+AP///gD///4A///+AP///gAAfAAAAHwAAAB8AAAAfAAAAHwAAAB8AAAAfAAAAHwAAAB8AAAAAAAA=`],"-":[16,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/5//n/+f/5//gAAAAAAAAAAAAAAAAAAAAAAAA==`],".":[11,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAB8AP4B/gH/Af8B/gD+AHwAEAA==`],0:[29,`AAIAAAB/8AAB//wAA//+AAf//wAH//+AD/B/gB/gP8Af8B/AH/gfwB/4D+A//A/gP74P4D+/D+A/nw/gP4+P4D+Pz+A/h8/gP4Pv4D+B/+A/gf/gH8D/4B/Af8AfwH/AD+A/wA/wf4AH//+AB///AAP//gAA//wAAH/wAAACAAA=`],1:[20,`AAAAAD4AAD4AAH4AAP4AB/4AP/4AP/4AP/4AP/4AP/4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAH4AAAAA`],2:[26,`AAQAAAD/4AAD//gAB//8AA///gAf//4AH+D/AB/AfwAHgH8AAIB/AAAAfwAAAH8AAAD+AAAA/gAAAf4AAAP8AAAH+AAAD/gAAB/wAAA/4AAA/4AAAf8AAAP+AAAP+AAAH/AAAD/AAAB///8Af///AH///wB///8Af///AAAAAAA=`],3:[27,`AAgAAAH/4AAH//gAD//8AB///gAf//4AP8D/AB+AfwADAH8AAAB/AAAAfwAAAP4AAA/8AAB//AAAf/gAAH/4AAB//AAAf/4AAAP+AAAA/wAAAH8AAAB/AAEAfwAPAH8Af4B/AD/A/wA///4AH//+AA///AAH//AAAf/AAAAIAAA=`],4:[28,`AAAAAAAB/AAAA/wAAAf8AAAH/AAAD/wAAB/8AAA//AAAP/wAAH/8AAD//AAB/fwAAf38AAP5/AAH8fwAD+H8AA/B/AAfgfwAP4H8AH///8B////Af///wH///8B////Af///wAAB/AAAAfwAAAH8AAAB/AAAAfwAAAH8AAAAAAA=`],5:[27,`AAAAAA///wAP//8AD///AB///wAf//8AH4AAAB+AAAAfgAAAH4AAAB+AAAAfv+AAP//4AD///AA///4AP//+AD/B/wAPgH8AAQB/gAAAP4AAAD+AAAA/gAAAP4AHAH+AP4B/AD/A/wAf//4AD//+AA///AAD//AAAP/AAAAIAAA=`],6:[28,`AAIAAAA/8AAA//wAAf/+AAP//wAH//4AB/BwAA/gAAAPwAAAH8AAAB+AAAAfn/AAH7/4AD///gA///4AP///AD/w/4A/4D+AP8A/gD/AH4A/gB+AH4AfgB+AH4AfwD+AH8A/gA/wfwAP//8AB//+AAP//AAB//gAAH/gAAAGAAA=`],7:[24,`AAAAf//+f//+f//+f//+f//+AAH+AAH8AAP8AAP4AAP4AAfwAAfwAA/gAA/gAB/AAB/AAD/AAD+AAH+AAH8AAP8AAP4AAf4AAfwAA/wAA/gAB/gAB/gAD/AAD/AAAAAA`],8:[28,`AAQAAAA/wAAA/+AAAf/wAAP/+AAD//wAA/D8AAfg/AAH4HwAB+B8AAfg/AAD8fwAA//4AAH/+AAH//wAD//+AB///wAf8f+AP8A/gD+AP8A/gB/AP4AfwD+AH8A/gB/AP8A/gD/gf4Af//+AD///AAf//gAD//wAAP/wAAAEAAA=`],9:[25,`AAgAAAD/gAAD/8AAB//gAA//8AAf//gAH//8AD+B/AA/APwAPwB+AD8AfgA/AH4APwB+AD8A/AA/gPwAH8P8AB//+AAP//gAB//wAAP/8AAA/+AAAA/gAAAP4AAAH8AAAB/AAAA/gAAAP4AAAH8AAAB/AAAA/gAAAf4AAAAAAAA=`],":":[11,`AAAAAAAAAAAAAAAAAAAAAAQAHwA/gH+Af8B/wH+AP4AfAAQAAAAAAAAAAAAEAB8AP4B/gH/Af8B/gD+AHwAEAA==`],"?":[27,`AAQAAAD/8AAH//wAD//+AB///wA///8AP8B/gA+AP4ADAD+AAAA/gAAA/wAAA/8AAA/+AAAf/AAAP/gAAH/gAAB/gAAA/wAAAP4AAAD+AAAAAAAAAAAAAAAQAAAAfAAAAP4AAAD/AAAB/wAAAf8AAAD/AAAA/gAAAHwAAAAQAAA=`]},samples:{"-10.5":103,"21.9":82,1013:96,Temperature:297,"Living room":284,"48%":99,"°C":54}},"./fonts/font_digits48.json":{id:`font_digits48`,charset:`digits`,size:48,height:47,baseline:46,maxWidth:65,errchar:`?`,glyphs:{" ":[21,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA`],"%":[65,`AB/AAAAAAAAAAH/4AAAP+AAAAf/8AAAf8AAAA///AAA/4AAAB///gAA/wAAAD///gAB/wAAAD///wAD/gAAAH///4AD/AAAAH/B/4AH+AAAAP+Af4AP+AAAAP8Af8AP8AAAAP8AP8Af4AAAAP8AP8A/4AAAAP8AP8B/wAAAAP8AP8B/gAAAAP8AP8D/gAAAAP8Af8H/AAAAAP+Af4H+AAAAAP/B/4P8AAAAAH///4f8AAAAAH///wf4AAAAAD///g/wB/AAAB///h/wP/4AAA///D/gf/8AAAf/+D/A///AAAH/4H/B///gAAB/AP+D///gAAAAAP8H///wAAAAAf8H///4AAAAA/4P/B/4AAAAA/wP+A/4AAAAB/gP8Af8AAAAD/gP8AP8AAAAD/Af4AP8AAAAH+Af4AP8AAAAP+AP8AP8AAAAf8AP8Af8AAAAf4AP+A/4AAAA/4AP/B/4AAAB/wAH///4AAAB/gAH///wAAAD/AAD///gAAAH/AAB///gAAAH+AAA///AAAAP8AAAf/8AAAAf8AAAP/4AAAAAAAAAB/AAA`],"+":[41,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAD/////wAD/////wAD/////wAD/////wAD/////wAD/////wAD/////wAD/////wAD/////wAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAD/gAAAAAAAAAAA`],"-":[25,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD///gA///4AP//+AD///gA///4AP//+AD///gA///4AP//+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`],".":[16,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4A/wH/g//D/8P/4//j/+P/w//B/4D/AD4A==`],0:[44,`AAB/4AAAAAP//AAAAA///wAAAB///8AAAH///+AAAH////AAAP////gAAf////gAA//gf/wAA//AH/4AB/+AD/4AB//AD/4AB//gB/8AD//gB/8AD//wA/8AD//4A/+AD//4A/+AH//8A/+AH/3+Af+AH/z+Af+AH/z/Af+AH/x/gf+AH/g/wf+AH/g/wf+AH/gf4f+AH/wP8f+AH/wH8f+AH/wH+f+AH/wD/f+AH/wB//+AD/wB//+AD/wA//+AD/4Af/8AD/4Af/8AB/4AP/8AB/8AH/4AB/+AD/4AA//AH/wAA//gf/wAAf////gAAP////gAAH////AAAD///+AAAB///8AAAA///wAAAAP//AAAAAB/4AAA`],1:[30,`AAAAAAAA/gAAAf4AAAH+AAAD/gAAB/4AAA/+AAA//gAf//4AH//+AB///gAf//4AH//+AB///gAf//4AH//+AAAH/gAAB/4AAAf+AAAH/gAAB/4AAAf+AAAH/gAAB/4AAAf+AAAH/gAAB/4AAAf+AAAH/gAAB/4AAAf+AAAH/gAAB/4AAAf+AAAH/gAAB/4AAAf+AAAH/gAAB/4AAAf+AAAH/gAAB/4AAAf+AAAH/gAAB/4AAAf+AAAAAAA=`],2:[39,`AAD/gAAAB//4AAAf//4AAH///wAA////gAH////AA////+AH////4Af/gf/wD/4Af/AP/gB/8AH8AD/wADwAP/AACAA/8AAAAD/wAAAAP/AAAAA/8AAAAH/wAAAAf/AAAAD/4AAAAf/gAAAD/8AAAAf/wAAAB/+AAAAP/wAAAD/+AAAAf/4AAAD//AAAAf/wAAAD/+AAAA//wAAAH/+AAAA//wAAAH/8AAAB//gAAAP/4AAAB//AAAAf/wAAAD/////4P/////g/////+D/////4P/////g/////+D/////4P/////gAAAAAAA==`],3:[41,`AAH/gAAAAB//8AAAAH///AAAAP///wAAA////4AAB////8AAB////+AAD////+AAH/8D//AAH/wA//AAH/gAf/AAA/gAP/AAAHAAP/AAABAAP/AAAAAAP/AAAAAAP/AAAAAAf/AAAAAA/+AAAAAB/+AAAAAP/8AAAAP//4AAAAP//wAAAAP//gAAAAP//gAAAAP//4AAAAP//8AAAAP//+AAAAAP/+AAAAAB//AAAAAAf/AAAAAAP/gAAAAAP/gAAAAAH/gAABAAH/gAAPAAH/gAA/AAP/gAP/gAP/gAH/wAf/gAH/8B//AAD/////AAD////+AAB////8AAA////4AAAf///wAAAH///AAAAB//8AAAAAH/AAAA`],4:[42,`AAAAAAAAAAAB/8AAAAAD/8AAAAAH/8AAAAAH/8AAAAAP/8AAAAAf/8AAAAA//8AAAAA//8AAAAB//8AAAAD//8AAAAH//8AAAAH//8AAAAP//8AAAAf//8AAAA///8AAAA/9/8AAAB/5/8AAAD/x/8AAAH/x/8AAAP/h/8AAAP/B/8AAAf+B/8AAA/8B/8AAB/4B/8AAB/4B/8AAD/wB/8AAH/gB/8AAP/////8AP/////8AP/////8AP/////8AP/////8AP/////8AP/////8AP/////8AP/////8AAAAB/8AAAAAB/8AAAAAB/8AAAAAB/8AAAAAB/8AAAAAB/8AAAAAB/8AAAAAB/8AAAAAB/8AAAAAAAAAA`],5:[41,`AAAAAAAAA/////AAA/////AAA/////AAB/////AAB/////AAB/////AAB/////AAB/////AAB/wAAAAAB/wAAAAAB/wAAAAAD/wAAAAAD/wAAAAAD/wAAAAAD/wAAAAAD/g/wAAAD/n/+AAAD////gAAD////4AAD////8AAH////+AAH////+AAH/////AAH/8B//AAB/wAf/gAAPgAP/gAABAAP/gAAAAAH/wAAAAAH/wAAAAAH/wAAAAAH/wAAAAAH/wAAAAAH/wAAHAAH/wAA/AAP/gAH/gAP/gAH/wAf/gAD/8B//AAD/////AAB////+AAA////8AAAf///4AAAP///wAAAD///AAAAA//8AAAAAH/gAAA`],6:[42,`AAA/8AAAAAH//AAAAAf//wAAAA///8AAAB///+AAAD////AAAH////AAAP///+AAAf/gfwAAAf+AHAAAA/8AAAAAA/8AAAAAA/4AAAAAB/4AAAAAB/4AAAAAB/wAAAAAD/wf8AAAD/x//AAAD/3//wAAD////8AAD////+AAD////+AAH/////AAH/////gAH//Af/gAH/+AP/wAH/8AH/wAH/4AD/wAD/4AD/4AD/wAD/4AD/wAD/4AD/wAD/4AD/wAD/4AD/wAD/4AB/4AD/wAB/4AD/wAB/8AH/wAA/+AP/gAA//Af/gAAf////AAAf////AAAP///+AAAH///8AAAD///4AAAB///gAAAAf/+AAAAAD/wAAA`],7:[36,`AAAAAAB/////4H/////gf////+B/////4H/////gf////+B/////4H/////gAAAB/8AAAAH/wAAAA/+AAAAD/4AAAAf/AAAAB/8AAAAP/gAAAA/+AAAAH/4AAAAf/AAAAB/8AAAAP/gAAAA/+AAAAH/wAAAAf/AAAAD/4AAAAP/gAAAB/8AAAAH/wAAAA/+AAAAD/4AAAAf/AAAAB/8AAAAP/wAAAA/+AAAAH/4AAAAf/AAAAD/8AAAAP/gAAAB/+AAAAH/wAAAA//AAAAD/4AAAAf/gAAAB/8AAAAP/wAAAA//AAAAAAAAAAA==`],8:[42,`AAB/gAAAAAH/4AAAAAf/+AAAAA///AAAAB///gAAAD///wAAAD///wAAAH///4AAAH/h/4AAAP/A/4AAAP+Af8AAAP+Af8AAAP8Af8AAAP8Af8AAAP+Af8AAAP+Af8AAAP/A/4AAAH/h/4AAAH///4AAAD///wAAAD///wAAAH///4AAAf///+AAA/////AAB/////gAD/////gAD/+Af/wAH/4AP/4AH/wAD/4AH/wAD/4AH/gAB/4AH/gAB/4AH/gAB/4AH/gAB/4AH/gAD/4AH/wAD/4AH/4AH/4AH/8AP/wAD/+A//wAD/////gAB/////gAA/////AAAf///+AAAP///8AAAD///wAAAA///AAAAAH/wAAA`],9:[38,`AAP8AAAAD/+AAAA//+AAAH//8AAA///8AAH///4AA////gAH////AAf///+AD/8H/4AP/AH/wB/4AP/AH/gAf8Af8AB/wB/wAH/AH/AAf+Af8AA/4B/wAH/gH/AAf8Af8AB/wB/4AP/AH/gA/8AP/AH/gA//B/+AD////wAH////AAP///4AA////gAB///8AAD///wAAD//+AAAH//4AAAD//gAAAA/8AAAAD/wAAAAf+AAAAB/4AAAAP/AAAAA/8AAAAH/gAAAAf+AAAAD/wAAAAf/AAAAB/4AAAAP/gAAAB/8AAAAAAAAAA==`],":":[16,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AP8B/4P/w//D/+P/4//j/8P/wf+A/wA+AAAAAAAAAAAAAAAAAAAAAAAAAD4A/wH/g//D/8P/4//j/+P/w//B/4D/AD4A==`],"?":[41,`AAH/wAAAAA///AAAAH///wAAAP///4AAA////+AAB/////AAD/////AAD/////gAH/+A//gAH/wAP/wAB/gAH/wAAfgAH/wAADAAH/wAAAAAH/wAAAAAP/gAAAAA//gAAAAD//gAAAAP//AAAAA///AAAAB//8AAAAD//4AAAAH//wAAAAP//AAAAAP/8AAAAAf/wAAAAAf/gAAAAAf/AAAAAAf+AAAAAA/+AAAAAA/+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHwAAAAAAf8AAAAAAf+AAAAAA//AAAAAB//AAAAAB//AAAAAB//AAAAAB//AAAAAB//AAAAAA/+AAAAAAf+AAAAAAP8AAAAAAHwAAAA`]},samples:{"-10.5":156,"21.9":123,1013:145,Temperature:451,"Living room":431,"48%":149,"°C":82}},"./fonts/font_digits64.json":{id:`font_digits64`,charset:`digits`,size:64,height:64,baseline:63,maxWidth:90,errchar:`?`,glyphs:JSON.parse(`{" ":[29,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="],"%":[90,"AAD/gAAAAAAAAAAAAAf/4AAAAA//AAAAAB//+AAAAA/+AAAAAD///gAAAB/+AAAAAH///wAAAD/8AAAAAf///4AAAH/4AAAAAf///8AAAH/4AAAAA////+AAAP/wAAAAB/////AAAf/gAAAAD/////AAAf/AAAAAD/////gAA//AAAAAH/+B//gAB/+AAAAAH/8Af/gAB/8AAAAAH/4AP/wAD/8AAAAAH/wAH/wAH/4AAAAAP/wAH/wAH/wAAAAAP/gAH/wAP/wAAAAAP/gAD/wAf/gAAAAAP/gAD/wA//AAAAAAP/gAD/wA/+AAAAAAP/gAH/wB/+AAAAAAP/wAH/wD/8AAAAAAH/wAP/wD/4AAAAAAH/4AP/wH/4AAAAAAH/8Af/gP/wAAAAAAD//B//gP/gAAAAAAD/////gf/gAAAAAAD/////A//AAAAAAAB/////A/+AB/wAAAA////+B/+AP/+AAAAf///8D/8A///gAAAf///4H/4B///wAAAH///wH/wD///8AAAD///gP/wP///+AAAB//+Af/gP////AAAAf/4Af/Af////AAAAD/AA//A/////gAAAAAAB/+B/////wAAAAAAB/8B/////wAAAAAAD/8B//g//4AAAAAAH/4D/+AP/4AAAAAAH/wD/8AH/4AAAAAAP/wD/4AD/4AAAAAAf/gD/4AD/8AAAAAA//AH/wAB/8AAAAAA/+AH/wAB/8AAAAAB/+AH/wAB/8AAAAAD/8AH/wAB/8AAAAAD/4AD/4AD/4AAAAAH/4AD/4AD/4AAAAAP/wAD/8AH/4AAAAAP/gAD/+AP/4AAAAAf/gAB//gf/wAAAAA//AAB/////wAAAAA/+AAA/////gAAAAB/8AAA/////gAAAAD/8AAAf////AAAAAH/4AAAP///+AAAAAH/wAAAH///+AAAAAP/wAAAD///4AAAAAf/gAAAB///wAAAAAf/AAAAA///gAAAAA//AAAAAP/+AAAAAAAAAAAAAB/wAAA"],"+":[57,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/AAAAAAAAB/8AAAAAAAAH/wAAAAAAAAf/AAAAAAAAB/8AAAAAAAAH/wAAAAAAAAf/AAAAAAAAB/8AAAAAAAAH/wAAAAAAAAf/AAAAAAAAB/8AAAAAAAAH/wAAAAAAAAf/AAAAAAAAB/8AAAAAAAAH/wAAAAAAAAf/AAAAAAAAB/8AAAAAH///////wAAf///////AAB///////8AAH///////wAAf///////AAB///////8AAH///////wAAf///////AAB///////8AAH///////wAAf///////AAB///////8AAAAAH/wAAAAAAAAf/AAAAAAAAB/8AAAAAAAAH/wAAAAAAAAf/AAAAAAAAB/8AAAAAAAAH/wAAAAAAAAf/AAAAAAAAB/8AAAAAAAAH/wAAAAAAAAf/AAAAAAAAB/8AAAAAAAAH/wAAAAAAAAf/AAAAAAAAB/8AAAAAAAAH/wAAAAAAAAf/AAAAAAAAAAAAAAAA="],"-":[34,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/////AD////8AP////wA/////AD////8AP////wA/////AD////8AP////wA/////AD////8AP////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="],".":[22,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPwAA/8AB/+AD//AH//gH//gP//wP//wP//wP//wP//wH//wH//gH//gD//AB/+AA/8AAPwA"],"0":[60,"AAAAf/AAAAAAAAf//wAAAAAAP///4AAAAAD////4AAAAAf////wAAAAD/////gAAAAf/////AAAAD/////+AAAAf/////8AAAD//////4AAAf//////wAAB//+A///AAAP//gA//+AAA//8AB//4AAH//gAD//wAAf//AAH//AAD//+AAf/8AAP//8AA//4AA///wAD//gAD///gAH/+AAf///AAf/8AB///8AB//wAH///4AH//AAf///wAP/8AB//v/AA//wAP/+f+AD//AA//5/8AP/+AD//j/wA//4AP/+H/gD//gA//4f/AP/+AD//g/+A//4AP/8B/4D//gA//wD/wP/+AD//AP/g//4AP/+Af+D//gA//4A/8P/+AD//gD/4//4AP/+AH/j//gA//4AP/P/8AB//gAf+//wAH/+AB////AAf/4AD///8AB//wAH///wAH//AAf///AAP/8AA///4AA//wAB///gAD//gAD//+AAH/+AAP//wAAf/8AAf//AAB//4AA//8AAD//wAH//gAAP//gA//+AAAf//gP//wAAA//////+AAAD//////4AAAH//////AAAAP/////4AAAAf/////AAAAA/////4AAAAB/////AAAAAB////wAAAAAD///8AAAAAAB///AAAAAAAAf/AAAAA="],"1":[41,"AAAAAAAAAAAH/wAAAAAH/wAAAAAH/wAAAAAP/wAAAAAP/wAAAAAf/wAAAAA//wAAAAB//wAAAAD//wAAAAf//wAAD////wAAD////wAAD////wAAD////wAAD////wAAD////wAAD////wAAD////wAAD////wAAD////wAAD////wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAA//wAAAAAAAAAA"],"2":[54,"AAAD/8AAAAAAH//8AAAAAP///wAAAAP////AAAAH////8AAAH/////gAAD/////8AAB//////gAA//////4AAP//////AAH//////4AD//8B//+AA//8AH//gAf/+AA//8AB//AAH//AAD/gAA//wAAH4AAP/8AAAMAAD//AAAAAAA//wAAAAAAP/8AAAAAAD//AAAAAAB//wAAAAAAf/8AAAAAAH/+AAAAAAD//gAAAAAB//4AAAAAAf/8AAAAAAP//AAAAAAH//gAAAAAD//4AAAAAB//8AAAAAA//+AAAAAAf//gAAAAAP//wAAAAAH//4AAAAAD//8AAAAAB//+AAAAAB///AAAAAA///gAAAAAf//wAAAAAP//wAAAAAP//4AAAAAH//8AAAAAD//8AAAAAD//+AAAAAB///AAAAAB///AAAAAA///gAAAAAf//gAAAAAf//wAAAAAP//wAAAAAH///////wB///////8Af///////AH///////wB///////8Af///////AH///////wB///////8Af///////AH///////wB///////8Af///////AAAAAAAAAAA=="],"3":[56,"AAAH/4AAAAAAf//8AAAAAf///wAAAAf////AAAAf////8AAAP/////gAAP/////8AAH//////gAB//////8AA///////AAf//////4AH//wD//+AD//wAH//wA//4AA//8AH/8AAH//AAP+AAB//wAAfgAAP/8AAAwAAD//AAAAAAA//wAAAAAAP/8AAAAAAH/+AAAAAAB//gAAAAAA//4AAAAAA//8AAAAAA//+AAAAAD///gAAAB////wAAAAf///4AAAAH///8AAAAB///+AAAAAf///AAAAAH///8AAAAB////gAAAAf///8AAAAH////gAAAB////8AAAAAP///gAAAAAH//4AAAAAAf//AAAAAAD//wAAAAAAf/8AAAAAAD//gAAAAAA//4AAAAAAP/+AAAAAAB//gAAEAAAf/4AAPAAAH/+AAf4AAD//gA/+AAA//4B//wAAf/8Af/+AAH//AD//wAH//wA///gH//4AH//////+AA///////AAP//////wAB//////4AAP/////8AAB/////+AAAH////+AAAA/////AAAAD////AAAAAH//+AAAAAAH/4AAAA=="],"4":[58,"AAAAAAAAAAAAAAAA//wAAAAAAAH//AAAAAAAA//8AAAAAAAH//wAAAAAAAf//AAAAAAAD//8AAAAAAAf//wAAAAAAD///AAAAAAAf//8AAAAAAB///wAAAAAAP///AAAAAAB///8AAAAAAP///wAAAAAA////AAAAAAH///8AAAAAA////wAAAAAH////AAAAAAf///8AAAAAD////wAAAAAf/7//AAAAAD//v/8AAAAAP/8//wAAAAB//j//AAAAAP/8P/8AAAAB//g//wAAAAP/+D//AAAAA//wP/8AAAAH/+A//wAAAA//wD//AAAAH/+AP/8AAAAf/4A//wAAAD//AD//AAAAf/4AP/8AAAD//AA//wAAAP/4AD//AAAB//gAP/8AAAP/8AA//wAAB////////wAH////////AA////////8AD////////wAP////////AA////////8AD////////wAP////////AA////////8AD////////wAP////////AA////////8AAAAAAD//AAAAAAAAP/8AAAAAAAA//wAAAAAAAD//AAAAAAAAP/8AAAAAAAA//wAAAAAAAD//AAAAAAAAP/8AAAAAAAA//wAAAAAAAD//AAAAAAAAP/8AAAAAAAA//wAAAAAAAD//AAAAAAAAAAAAAA="],"5":[56,"AAAAAAAAAAD//////4AA//////+AAP//////gAD//////4AB//////+AAf//////gAH//////4AB//////+AAf//////gAH//////4AB//////+AAf/wAAAAAAH/4AAAAAAD/+AAAAAAA//gAAAAAAP/4AAAAAAD/+AAAAAAA//gAAAAAAP/4AAAAAAD/+AAAAAAA//gP+AAAAf/w//+AAAH/8///4AAB//////gAAf/////8AAH//////gAB//////+AAf//////gAH//////8AD///////gA///////4AP//4B///AD//4AH//wAH/4AA//+AAP8AAH//gAAeAAA//4AAAgAAH//AAAAAAB//wAAAAAAf/8AAAAAAH//AAAAAAB//wAAAAAAP/8AAAAAAH//AAAAAAB//wAAAAAAf/8AAHAAAH//AAP4AAB//gAf+AAA//4Af/wAAf/+AP/+AAP//gB//wAH//wAf//AH//8AD//////+AA///////AAH//////wAA//////4AAH/////8AAA/////+AAAD////+AAAAf////AAAAB////AAAAAD//+AAAAAAH/4AAAA=="],"6":[58,"AAAAP/gAAAAAAAP//4AAAAAAD///4AAAAAA////4AAAAAH////wAAAAB/////gAAAAP/////AAAAB/////+AAAAP/////8AAAA//////AAAAH//gP/gAAAA//4AP4AAAAD//AAcAAAAAf/4AAAAAAAB//AAAAAAAAP/4AAAAAAAA//gAAAAAAAH/8AAAAAAAAf/wAAAAAAAB//AAAAAAAAP/8AAAAAAAA//wD/gAAAAD/+D//wAAAAP/4///wAAAA//n///wAAAH/+////gAAAf//////gAAB///////AAAH//////+AAAf//////4AAB///////wAAH///////gAAf//8B//+AAB///AB//8AAH//4AD//wAAf//AAH//AAB//4AAP/+AAH//AAA//4AAf/8AAD//gAB//wAAH/+AAH//AAAf/4AAf/8AAB//gAB//wAAH/+AAH//AAAf/4AAP/8AAB//gAA//wAAH/+AAD//AAAf/4AAP/8AAD//gAAf/4AAP/8AAB//wAB//wAAH//AAP//AAAP//AB//4AAA///Af//gAAB//////8AAAH//////gAAAP/////+AAAAf/////wAAAA/////+AAAAB/////wAAAAD////8AAAAAD////gAAAAAH///4AAAAAAD//+AAAAAAAB/+AAAAA="],"7":[50,"AAAAAAAAAH///////gB///////4Af//////+AH///////gB///////4Af//////+AH///////gB///////4Af//////+AH///////gB///////4Af//////+AAAAAAD//gAAAAAA//4AAAAAAf/8AAAAAAH//AAAAAAD//gAAAAAA//4AAAAAAf/8AAAAAAH//AAAAAAD//gAAAAAA//4AAAAAAf/8AAAAAAH//AAAAAAD//gAAAAAA//4AAAAAAf/+AAAAAAH//AAAAAAD//wAAAAAA//4AAAAAAf/+AAAAAAH//AAAAAAD//wAAAAAA//4AAAAAAf/+AAAAAAH//AAAAAAD//wAAAAAA//4AAAAAAf/+AAAAAAH//AAAAAAD//wAAAAAA//4AAAAAAf/+AAAAAAH//AAAAAAD//wAAAAAA//8AAAAAAf/+AAAAAAH//gAAAAAD//wAAAAAA//8AAAAAAf/+AAAAAAH//gAAAAAD//wAAAAAA//8AAAAAAf/+AAAAAAH//gAAAAAD//wAAAAAA//8AAAAAAf/+AAAAAAH//gAAAAAD//wAAAAAA//8AAAAAAAAAAAAAAA=="],"8":[58,"AAAA/4AAAAAAAAf/8AAAAAAAH//8AAAAAAA///8AAAAAAH///4AAAAAA////wAAAAAH////gAAAAA////+AAAAAD////8AAAAAf////wAAAAB/////gAAAAP////+AAAAA//wf/8AAAAD/+Af/wAAAAf/wA//AAAAB/+AD/8AAAAH/4AH/wAAAAf/gAf/AAAAB/8AB/8AAAAH/wAH/wAAAAf/gAf/AAAAB/+AD/8AAAAH/8AP/wAAAAP/4B//AAAAA//wf/4AAAAD/////gAAAAH////+AAAAAf////wAAAAA/////AAAAAH////+AAAAB/////8AAAAP/////8AAAD//////4AAAf//////wAAB///////gAAP///////AAB///gH//8AAH//wAD//4AA//8AAH//gAD//gAAP/+AAP/+AAAf/8AA//wAAB//wAD//AAAH//AAf/8AAAP/8AB//wAAA//wAD//AAAH//AAP/8AAAf/8AA//4AAB//wAD//wAAP//AAP//gAB//4AA///AAf//gAB///gH//+AAH///////wAAP///////AAA///////4AAB///////AAAD//////4AAAH//////gAAAP/////4AAAAP/////AAAAAf////wAAAAAf///8AAAAAAP//+AAAAAAAD/+AAAAA="],"9":[52,"AAAH/AAAAAAAf/+AAAAAAf//8AAAAAf///gAAAAP///+AAAAH////wAAAD////+AAAB/////wAAA/////+AAAf/////gAAH/////8AAD//////gAA//8D//4AAf/8AH//AAH/+AA//wAD//AAH/8AA//gAA//gAP/4AAP/4AD/8AAB/+AA//AAAf/gAP/wAAH/4AH/8AAB/+AB//AAAf/gAP/wAAH/4AD/8AAB/+AA//AAA//gAP/4AAP/4AD/+AAH/+AA//wAB//AAH/+AA//wAB//wAf/8AAP//gf/+AAD//////gAAf/////wAAH/////8AAA//////AAAH/////gAAA/////4AAAH////8AAAA/////AAAAH////gAAAAf///4AAAAB///8AAAAAD///AAAAAAB//gAAAAAAf/4AAAAAAP/8AAAAAAD//AAAAAAB//gAAAAAAf/4AAAAAAP/8AAAAAAD//AAAAAAB//gAAAAAAf/4AAAAAAP/8AAAAAAD//AAAAAAB//gAAAAAAf/4AAAAAAP/+AAAAAAD//AAAAAAB//wAAAAAA//4AAAAAAP/+AAAAAAAAAAAAAA=="],":":[22,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPwAA/8AB/+AD//AH//gH//gH//wP//wP//wP//wP//wP//wH//wH//gD//AB/+AA/8AAPwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPwAA/8AB/+AD//AH//gH//gP//wP//wP//wP//wP//wH//wH//gH//gD//AB/+AA/8AAPwA"],"?":[56,"AAAD/+AAAAAAf//+AAAAAf///8AAAA/////wAAAf/////AAAf/////4AAP//////AAH//////4AD///////AA///////wAf//////+AP//4Af//gD//4AB//8Af/4AAP//AA/8AAB//wAD+AAAf/8AAHgAAD//AAAIAAB//wAAAAAAf/8AAAAAAP//AAAAAAP//gAAAAAP//4AAAAAP//+AAAAAP///AAAAAP///gAAAAH///wAAAAH///4AAAAD///8AAAAB///+AAAAA///+AAAAAf//+AAAAAH//+AAAAAD//+AAAAAA///AAAAAAP//AAAAAAH//gAAAAAB//wAAAAAAf/8AAAAAAH//AAAAAAB//gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB+AAAAAAAB/4AAAAAAA//gAAAAAAf/4AAAAAAP//AAAAAAD//4AAAAAA//+AAAAAAf//gAAAAAH//4AAAAAB//+AAAAAAf//gAAAAAD//4AAAAAA//+AAAAAAH//AAAAAAB//gAAAAAAP/wAAAAAAB/4AAAAAAAH4AAAAA=="]}`),samples:{"-10.5":213,"21.9":169,1013:198,Temperature:616,"Living room":589,"48%":206,"°C":112}},"./fonts/font_seg748.json":{id:`font_seg748`,charset:`seg7`,size:48,height:48,baseline:48,maxWidth:39,errchar:`?`,glyphs:{" ":[10,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA`],"-":[39,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//8AAAP//4AAB///wAAH///AAAP//4AAAf//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA`],".":[6,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAePz8/Px4`],0:[39,`AP///gAB////AAL///4AB3///MAHv//5wAff//PAB+AAB8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAAfAB8AAA8AHgAABwAcAAADABwAAAAAHgAABwAfAAAPAB+AAB8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAAfAB9//88AHv//5wAd///zAAv///gAB////AAD///4A`],1:[39,`AAAAAAAAAAAAAAAAAAAAAAAAAMAAAAABwAAAAAPAAAAAB8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAAfAAAAAA8AAAAABwAAAAADAAAAAAAAAAAABwAAAAAPAAAAAB8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAAfAAAAAA8AAAAABwAAAAADAAAAAAAAAAAAAAAAAAAAA`],2:[39,`AP///gAB////AAD///4AAH///MAAP//5wAAf//PAAAAAB8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAAfAAB//88AAP//5wAB///zAB3///AAHv//4AAff//AAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB9//8AAHv//4AAd///wAAv///gAB////AAD///4A`],3:[39,`AP///gAB////AAD///4AAH///MAAP//5wAAf//PAAAAAB8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAAfAAB//88AAP//5wAB///zAAH///AAAP//5wAAf//PAAAAAB8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAAfAAB//88AAP//5wAB///zAAP///gAB////AAD///4A`],4:[39,`AAAAAAAAAAAAAAIAAAAABwAAAMAHgAABwAfAAAPAB+AAB8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAAfAB9//88AHv//5wAd///zAAH///AAAP//5wAAf//PAAAAAB8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAAfAAAAAA8AAAAABwAAAAADAAAAAAAAAAAAAAAAAAAAA`],5:[39,`AP///gAB////AAL///4AB3///AAHv//4AAff//AAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB9//8AAHv//4AAd///wAAH///AAAP//5wAAf//PAAAAAB8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAAfAAB//88AAP//5wAB///zAAP///gAB////AAD///4A`],6:[39,`AP///gAB////AAL///4AB3///AAHv//4AAff//AAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB+AAAAAH4AAAAAfgAAAAB9//8AAHv//4AAd///wAB3///AAHv//5wAff//PAB+AAB8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAAfAB9//88AHv//5wAd///zAAv///gAB////AAD///4A`],7:[39,`AP///gAB////AAL///4AB3///MAHv//5wAff//PAB+AAB8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAAfAB8AAA8AHgAABwAcAAADAAAAAAAAAAAABwAAAAAPAAAAAB8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAAfAAAAAA8AAAAABwAAAAADAAAAAAAAAAAAAAAAAAAAA`],8:[39,`AP///gAB////AAL///4AB3///MAHv//5wAff//PAB+AAB8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAAfAB9//88AHv//5wAd///zAB3///AAHv//5wAff//PAB+AAB8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAAfAB9//88AHv//5wAd///zAAv///gAB////AAD///4A`],9:[39,`AP///gAB////AAL///4AB3///MAHv//5wAff//PAB+AAB8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAA/AB+AAD8AH4AAPwAfgAAfAB9//88AHv//5wAd///zAAH///AAAP//5wAAf//PAAAAAB8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAA/AAAAAD8AAAAAPwAAAAAfAAB//88AAP//5wAB///zAAP///gAB////AAD///4A`],":":[10,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgA+AD8APwA+AAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4APwA/AD8AHgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA`],"?":[17,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/4AP/4AMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAMAYAP/4AP/4A`]},samples:{"-10.5":162,"21.9":123,1013:156,Temperature:187,"Living room":180,"48%":95,"°C":34}},"./fonts/font_seg764.json":{id:`font_seg764`,charset:`seg7`,size:64,height:64,baseline:64,maxWidth:52,errchar:`?`,glyphs:{" ":[13,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`],"-":[52,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB///4AAAAA////AAAAAf///4AAAAP////AAAAD////4AAAAf///8AAAAD///+AAAAAf///AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==`],".":[8,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8fv////9+PA==`],0:[52,`AB/////AAAA/////4AAAP////+AAAJ/////YAAHP////vAAD5////3wAA/P///78AAP5///9/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP4AAAB/AAD8AAAAPwAA+AAAAB8AAAAAAAAAAAAAAAAAAAAA+AAAAB8AAPwAAAA/AAD+AAAAfwAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD+f///fwAA/P///78AAPn////fAABz////7wAAJ/////YAAA/////4AAAP////+AAAB/////AAA==`],1:[52,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYAAAAAAAAPAAAAAAAAHwAAAAAAAD8AAAAAAAB/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAB/AAAAAAAAPwAAAAAAAB8AAAAAAAAAAAAAAAAAAAAAAAAAAB8AAAAAAAA/AAAAAAAAfwAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAAfwAAAAAAAD8AAAAAAAAfAAAAAAAADwAAAAAAAAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==`],2:[52,`AB/////AAAA/////4AAAP////+AAAB/////YAAAP////vAAAB////3wAAAP///78AAAB///9/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAB///5/AAAA////PwAAAf///58AAAP////AAAAD////4AAA+f///8AAAPz///+AAAD+f///AAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD+f///AAAA/P///4AAAPn////AAABz////4AAAJ/////AAAA/////4AAAP////+AAAB/////AAA==`],3:[52,`AB/////AAAA/////4AAAP////+AAAB/////YAAAP////vAAAB////3wAAAP///78AAAB///9/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAB///5/AAAA////PwAAAf///58AAAP////AAAAD////4AAAAf///98AAAD///+/AAAAf///fwAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAf///fwAAAP///78AAAH////fAAAD////7wAAB/////YAAA/////4AAAP////+AAAB/////AAA==`],4:[52,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAYAAHAAAAAPAAD4AAAAHwAA/AAAAD8AAP4AAAB/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP5///5/AAD8////PwAA+f///58AAAP////AAAAD////4AAAAf///98AAAD///+/AAAAf///fwAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAAfwAAAAAAAD8AAAAAAAAfAAAAAAAADwAAAAAAAAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==`],5:[52,`AB/////AAAA/////4AAAP////+AAAJ/////AAAHP////gAAD5////wAAA/P///4AAAP5///8AAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP5///4AAAD8////AAAA+f///4AAAAP////AAAAD////4AAAAf///98AAAD///+/AAAAf///fwAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAf///fwAAAP///78AAAH////fAAAD////7wAAB/////YAAA/////4AAAP////+AAAB/////AAA==`],6:[52,`AB/////AAAA/////4AAAP////+AAAJ/////AAAHP////gAAD5////wAAA/P///4AAAP5///8AAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP5///4AAAD8////AAAA+f///4AAAAP////AAAAD////4AAA+f///98AAPz///+/AAD+f///fwAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD+f///fwAA/P///78AAPn////fAABz////7wAAJ/////YAAA/////4AAAP////+AAAB/////AAA==`],7:[52,`AB/////AAAA/////4AAAP////+AAAJ/////YAAHP////vAAD5////3wAA/P///78AAP5///9/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP4AAAB/AAD8AAAAPwAA+AAAAB8AAAAAAAAAAAAAAAAAAAAAAAAAAB8AAAAAAAA/AAAAAAAAfwAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAAfwAAAAAAAD8AAAAAAAAfAAAAAAAADwAAAAAAAAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==`],8:[52,`AB/////AAAA/////4AAAP////+AAAJ/////YAAHP////vAAD5////3wAA/P///78AAP5///9/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP5///5/AAD8////PwAA+f///58AAAP////AAAAD////4AAA+f///98AAPz///+/AAD+f///fwAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD+f///fwAA/P///78AAPn////fAABz////7wAAJ/////YAAA/////4AAAP////+AAAB/////AAA==`],9:[52,`AB/////AAAA/////4AAAP////+AAAJ/////YAAHP////vAAD5////3wAA/P///78AAP5///9/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP8AAAD/AAD/AAAA/wAA/wAAAP8AAP5///5/AAD8////PwAA+f///58AAAP////AAAAD////4AAAAf///98AAAD///+/AAAAf///fwAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAAAAA/wAAAAAAAP8AAAAAAAD/AAAAf///fwAAAP///78AAAH////fAAAD////7wAAB/////YAAA/////4AAAP////+AAAB/////AAA==`],":":[13,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPgB/AH8A/wB/AH8APgAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAfgB/AP8A/wB/AH8APAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`],"?":[23,`AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//gP//gMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgMABgP//gP//g`]},samples:{"-10.5":216,"21.9":164,1013:208,Temperature:253,"Living room":243,"48%":127,"°C":46}},"./fonts/font_seg796.json":{id:`font_seg796`,charset:`seg7`,size:96,height:96,baseline:96,maxWidth:78,errchar:`?`,glyphs:JSON.parse(`{" ":[19,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"],"-":[78,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/////wAAAAAAB/////+AAAAAAA//////wAAAAAAf/////+AAAAAAP//////wAAAAAH//////+AAAAAB///////gAAAAAP//////wAAAAAB//////4AAAAAAP/////8AAAAAAB/////+AAAAAAAP/////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"],".":[12,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADwA/wH/gf+D/8P/w//D/8H/gf+A/wA8A"],"0":[78,"AAD///////wAAAAB///////+AAAAA////////wAAAAP///////8AAAAJ///////+AAAAHP///////GAAAD5///////jwAAB/P//////x+AAAf5//////4/gAAH/P/////8f4AAB/5/////+P+AAAf/P/////H/gAAH/4AAAAAD/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAP/gAAH/wAAAAAB/4AAB/4AAAAAAP+AAAf8AAAAAAB/gAAH+AAAAAAAP4AAB/AAAAAAAB+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/AAAAAAAB+AAAf4AAAAAAA/gAAH/AAAAAAAf4AAB/4AAAAAAP+AAAf/AAAAAAH/gAAH/4AAAAAD/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAP/gAAH/z/////x/4AAB/5/////+P+AAAf8//////x/gAAH+f/////+P4AAB/P//////x+AAAPn//////+PAAABz///////xgAAAJ///////+AAAAA////////wAAAAP///////8AAAAB///////+AAAAAP///////AAA"],"1":[78,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGAAAAAAAAAAAADwAAAAAAAAAAAB+AAAAAAAAAAAA/gAAAAAAAAAAAf4AAAAAAAAAAAP+AAAAAAAAAAAH/gAAAAAAAAAAD/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAP/gAAAAAAAAAAB/4AAAAAAAAAAAP+AAAAAAAAAAAB/gAAAAAAAAAAAP4AAAAAAAAAAAB+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB+AAAAAAAAAAAA/gAAAAAAAAAAAf4AAAAAAAAAAAP+AAAAAAAAAAAH/gAAAAAAAAAAD/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAP/gAAAAAAAAAAB/4AAAAAAAAAAAP+AAAAAAAAAAAB/gAAAAAAAAAAAP4AAAAAAAAAAAB+AAAAAAAAAAAAPAAAAAAAAAAAABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"],"2":[78,"AAD///////wAAAAB///////+AAAAA////////wAAAAP///////8AAAAB///////+AAAAAP///////GAAAAB///////jwAAAAP//////x+AAAAB//////4/gAAAAP/////8f4AAAAB/////+P+AAAAAP/////H/gAAAAAAAAAAD/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAP/gAAAAD/////x/4AAAAB/////+P+AAAAA//////x/gAAAAf/////+P4AAAAP//////x+AAAAH//////+AAAAAB///////gAAAB/P//////wAAAAf5//////4AAAAH/P/////8AAAAB/5/////+AAAAAf/P/////AAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/z/////wAAAAB/5/////+AAAAAf8//////wAAAAH+f/////+AAAAB/P//////wAAAAPn//////+AAAABz///////wAAAAJ///////+AAAAA////////wAAAAP///////8AAAAB///////+AAAAAP///////AAA"],"3":[78,"AAD///////wAAAAB///////+AAAAA////////wAAAAP///////8AAAAB///////+AAAAAP///////GAAAAB///////jwAAAAP//////x+AAAAB//////4/gAAAAP/////8f4AAAAB/////+P+AAAAAP/////H/gAAAAAAAAAAD/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAP/gAAAAD/////x/4AAAAB/////+P+AAAAA//////x/gAAAAf/////+P4AAAAP//////x+AAAAH//////+AAAAAB///////gAAAAAP//////x+AAAAB//////4/gAAAAP/////8f4AAAAB/////+P+AAAAAP/////H/gAAAAAAAAAAD/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAP/gAAAAD/////x/4AAAAB/////+P+AAAAA//////x/gAAAAf/////+P4AAAAP//////x+AAAAH//////+PAAAAD///////xgAAAB///////+AAAAA////////wAAAAP///////8AAAAB///////+AAAAAP///////AAA"],"4":[78,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAAHAAAAAAAAGAAAD4AAAAAAADwAAB/AAAAAAAB+AAAf4AAAAAAA/gAAH/AAAAAAAf4AAB/4AAAAAAP+AAAf/AAAAAAH/gAAH/4AAAAAD/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAP/gAAH/z/////x/4AAB/5/////+P+AAAf8//////x/gAAH+f/////+P4AAB/P//////x+AAAAH//////+AAAAAB///////gAAAAAP//////x+AAAAB//////4/gAAAAP/////8f4AAAAB/////+P+AAAAAP/////H/gAAAAAAAAAAD/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAP/gAAAAAAAAAAB/4AAAAAAAAAAAP+AAAAAAAAAAAB/gAAAAAAAAAAAP4AAAAAAAAAAAB+AAAAAAAAAAAAPAAAAAAAAAAAABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"],"5":[78,"AAD///////wAAAAB///////+AAAAA////////wAAAAP///////8AAAAJ///////+AAAAHP///////AAAAD5///////gAAAB/P//////wAAAAf5//////4AAAAH/P/////8AAAAB/5/////+AAAAAf/P/////AAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/z/////wAAAAB/5/////+AAAAAf8//////wAAAAH+f/////+AAAAB/P//////wAAAAAH//////+AAAAAB///////gAAAAAP//////x+AAAAB//////4/gAAAAP/////8f4AAAAB/////+P+AAAAAP/////H/gAAAAAAAAAAD/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAP/gAAAAD/////x/4AAAAB/////+P+AAAAA//////x/gAAAAf/////+P4AAAAP//////x+AAAAH//////+PAAAAD///////xgAAAB///////+AAAAA////////wAAAAP///////8AAAAB///////+AAAAAP///////AAA"],"6":[78,"AAD///////wAAAAB///////+AAAAA////////wAAAAP///////8AAAAJ///////+AAAAHP///////AAAAD5///////gAAAB/P//////wAAAAf5//////4AAAAH/P/////8AAAAB/5/////+AAAAAf/P/////AAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/z/////wAAAAB/5/////+AAAAAf8//////wAAAAH+f/////+AAAAB/P//////wAAAAAH//////+AAAAAB///////gAAAB/P//////x+AAAf5//////4/gAAH/P/////8f4AAB/5/////+P+AAAf/P/////H/gAAH/4AAAAAD/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAP/gAAH/z/////x/4AAB/5/////+P+AAAf8//////x/gAAH+f/////+P4AAB/P//////x+AAAPn//////+PAAABz///////xgAAAJ///////+AAAAA////////wAAAAP///////8AAAAB///////+AAAAAP///////AAA"],"7":[78,"AAD///////wAAAAB///////+AAAAA////////wAAAAP///////8AAAAJ///////+AAAAHP///////GAAAD5///////jwAAB/P//////x+AAAf5//////4/gAAH/P/////8f4AAB/5/////+P+AAAf/P/////H/gAAH/4AAAAAD/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAP/gAAH/wAAAAAB/4AAB/4AAAAAAP+AAAf8AAAAAAB/gAAH+AAAAAAAP4AAB/AAAAAAAB+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB+AAAAAAAAAAAA/gAAAAAAAAAAAf4AAAAAAAAAAAP+AAAAAAAAAAAH/gAAAAAAAAAAD/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAP/gAAAAAAAAAAB/4AAAAAAAAAAAP+AAAAAAAAAAAB/gAAAAAAAAAAAP4AAAAAAAAAAAB+AAAAAAAAAAAAPAAAAAAAAAAAABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"],"8":[78,"AAD///////wAAAAB///////+AAAAA////////wAAAAP///////8AAAAJ///////+AAAAHP///////GAAAD5///////jwAAB/P//////x+AAAf5//////4/gAAH/P/////8f4AAB/5/////+P+AAAf/P/////H/gAAH/4AAAAAD/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAP/gAAH/z/////x/4AAB/5/////+P+AAAf8//////x/gAAH+f/////+P4AAB/P//////x+AAAAH//////+AAAAAB///////gAAAB/P//////x+AAAf5//////4/gAAH/P/////8f4AAB/5/////+P+AAAf/P/////H/gAAH/4AAAAAD/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAP/gAAH/z/////x/4AAB/5/////+P+AAAf8//////x/gAAH+f/////+P4AAB/P//////x+AAAPn//////+PAAABz///////xgAAAJ///////+AAAAA////////wAAAAP///////8AAAAB///////+AAAAAP///////AAA"],"9":[78,"AAD///////wAAAAB///////+AAAAA////////wAAAAP///////8AAAAJ///////+AAAAHP///////GAAAD5///////jwAAB/P//////x+AAAf5//////4/gAAH/P/////8f4AAB/5/////+P+AAAf/P/////H/gAAH/4AAAAAD/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAf/gAAH/4AAAAAH/4AAB/+AAAAAB/+AAAf/gAAAAAP/gAAH/z/////x/4AAB/5/////+P+AAAf8//////x/gAAH+f/////+P4AAB/P//////x+AAAAH//////+AAAAAB///////gAAAAAP//////x+AAAAB//////4/gAAAAP/////8f4AAAAB/////+P+AAAAAP/////H/gAAAAAAAAAAD/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAf/gAAAAAAAAAAH/4AAAAAAAAAAB/+AAAAAAAAAAAP/gAAAAD/////x/4AAAAB/////+P+AAAAA//////x/gAAAAf/////+P4AAAAP//////x+AAAAH//////+PAAAAD///////xgAAAB///////+AAAAA////////wAAAAP///////8AAAAB///////+AAAAAP///////AAA"],":":[19,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/gAB/wAD/4AD/4AD/4AD/8AD/4AD/4AD/4AB/wAA/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPAAA/gAB/wAD/4AD/4AD/8AD/8AD/4AD/4AB/wAA/wAAfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"],"?":[35,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB////AAH///8AAf///wABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAHAAAcAAcAABwABwAAHAAH///8AAf///wAB////AA"]}`),samples:{"-10.5":324,"21.9":246,1013:312,Temperature:385,"Living room":369,"48%":191,"°C":70}}})).map(e=>[e.id,e]));function ol(){return[...al.keys()].sort()}function sl(e){let t=al.get(e);if(!t)throw Error(`unknown font "${e}" (known: ${ol().join(`, `)})`);return t}function cl(e,t){return e.glyphs[t]??e.glyphs[e.errchar]}function ll(e,t){let n=sl(e),r=0;for(let e of t)r+=cl(n,e)[0];return r}function ul(e,t){let n=sl(e),r=[];for(let e of t)!(e in n.glyphs)&&!r.includes(e)&&r.push(e);return r}var dl=`0123456789`;function fl(e,t){return ll(e,t)}function pl(e,t){return e.toFixed(t)}function ml(e,t,n,r){let i=0;for(let t of dl)i=Math.max(i,fl(e,t));let a=0;for(let o of[t,n]){let t=0;for(let n of pl(o,r))t+=dl.includes(n)?i:fl(e,n);a=Math.max(a,t)}return Math.max(a,ll(e,`--`))}var hl=`thingstudio/gui_screen`,gl=`thingstudio/gui_modal`,_l=`thingstudio/gui_button`,vl={"thingstudio/gui_label":`label`,"thingstudio/gui_readout":`readout`,"thingstudio/gui_bar":`bar`,"thingstudio/gui_trend":`trend`,"thingstudio/gui_led":`led`,"thingstudio/gui_button":`button`};function yl(e){return e in vl}function bl(e){let t=e=>typeof e==`string`?e.trim():``,n=t(e.properties.label)||t(e.properties.name);return n?`"${n}"`:`${e.type.replace(`thingstudio/`,``)} ${e.id.slice(0,6)}`}function z(e){return JSON.stringify(e)}function xl(e){if(!Number.isFinite(e))throw Error(`not a finite number: ${e}`);return String(e)}function Sl(e,t){let n=Number(e);return e==null||e===``||!Number.isFinite(n)?t:n}function Cl(e,t){let n=Math.max(2,Math.round(Sl(e.properties.gridColumns,12))),r=Math.round(Sl(e.properties.gridRows,0));return{columns:n,rows:r>0?r:Math.max(1,Math.round(n*t.height/Math.max(1,t.width)))}}var wl=e=>[...e].sort((e,t)=>sl(t).height-sl(e).height),Tl=wl(ol().filter(e=>e.startsWith(`font_body`))),El=wl(ol().filter(e=>e.startsWith(`font_digits`)));function Dl(e,t,n,r){if(r){if(sl(r).height<=e&&(!n||n(r)))return r;throw Error(`the chosen font ${r} does not fit its cells`)}for(let r of t)if(sl(r).height<=e&&(!n||n(r)))return r;throw Error(`does not fit its cells (no font fits ${e}px high)`)}function Ol(e,t,n){let r=[],i=[],a=new Set,o=new Map,s=new Map,c=[],l=new Map(t.map(e=>[e.id,e])),u=new Map;for(let[t,i]of Object.entries(e)){let e=l.get(t);if(!e||e.type!==`thingstudio/gui_screen`){r.push(`screens: "${t}" isn't a GUI screen node in this flow`);continue}let d=bl(e),f=n(e),{columns:p,rows:m}=Cl(e,f),h=new Set;for(let e of i.pages)h.has(e.name)&&r.push(`screen ${d}: two pages are called "${e.name}"`),h.add(e.name);for(let e of i.pages)e.parent!==void 0&&!h.has(e.parent)&&r.push(`screen ${d}: page "${e.name}" has unknown parent "${e.parent}"`);let g=i.carousel??i.pages.filter(e=>e.parent===void 0).map(e=>e.name);g.length===0&&r.push(`screen ${d} has no pages`);for(let e of g)h.has(e)||r.push(`screen ${d}: carousel names unknown page "${e}"`);let _=0,v=[],y=new Map,b=f.width/p,x=f.height/m,S=Math.max(0,Math.round(.1*Math.min(b,x))),ee=Math.round,C=e=>({rs:Math.max(1,Math.round(Sl(e.rowSpan,1))),cs:Math.max(1,Math.round(Sl(e.colSpan,1)))}),w=e=>{let{rs:t,cs:n}=C(e),r=ee(e.col*b)+S,i=ee(e.row*x)+S,a=ee((e.col+n)*b)-S,o=ee((e.row+t)*x)-S;return{x:r,y:i,width:Math.max(1,a-r),height:Math.max(1,o-i)}},te=e=>{if(e.card)return`panel at row ${e.row}, column ${e.col}`;if(e.kind===`text`)return`text "${e.text??``}"`;if(e.kind===`pagedots`)return`page dots`;let t=e.node?l.get(e.node):void 0;return t?`widget ${bl(t)}`:`widget "${e.node??`?`}"`},T=(e,t)=>{let n=new Map,i=new Map;for(let a of e){let{rs:e,cs:o}=C(a),s=te(a);if(!Number.isInteger(a.row)||!Number.isInteger(a.col)||a.row<0||a.col<0){r.push(`${s} ${t}: row and column must be whole cells, got row ${String(a.row)}, column ${String(a.col)}`);continue}if(a.row+e>m||a.col+o>p){r.push(`${s} ${t}: ${e}x${o} cells at row ${a.row}, column ${a.col} goes outside the ${m}x${p} grid`);continue}let c=a.card?i:n;for(let n=a.row;n<a.row+e;n++)for(let e=a.col;e<a.col+o;e++){let i=`${n},${e}`,a=c.get(i);if(a){r.push(`${s} ${t} overlaps ${a} at row ${n}, column ${e}`);break}c.set(i,s)}}},ne=(e,t,n,i)=>{let c=vl[e.type],l=bl(e),u=e.properties,d=t.width,f=t.height,p;try{switch(c){case`label`:{let e=Dl(f,Tl,e=>ll(e,`--`)<=d,typeof u.font==`string`?u.font:void 0);p=`tsgui_label.make(${e}, None, ${z(i)})`,a.add(e);break}case`readout`:{let e=typeof u.units==`string`?u.units:``,t=typeof u.caption==`string`?u.caption.trim():``,n=Math.max(0,Math.round(Sl(u.decimals,1))),r=Sl(u.lo,0),i=Sl(u.hi,100);if(i<r)throw Error(`range low ${r} is above high ${i}`);let o=Math.max(2,Math.round(Math.min(d,f)*.05)),s=t?Dl(Math.max(1,Math.floor(f/3)),Tl,e=>ll(e,t)<=d&&ul(e,t).length===0):void 0,c=s?sl(s).height+2:0,l=Dl(f-c,El,t=>{let a=ml(t,r,i,n);return e?Tl.some(t=>sl(t).height<=f-c&&a+o+ll(t,e)<=d):a<=d},typeof u.font==`string`&&u.font!==``?u.font:void 0),m=ml(l,r,i,n),h=e?Dl(f-c,Tl,t=>m+o+ll(t,e)<=d&&ul(t,e).length===0):void 0;p=`tsgui_readout.make(${l}, ${h??`None`}, ${z(e)}, ${n}, ${xl(r)}, ${xl(i)}, ${o}`+(s?`, ${z(t)}, ${s})`:`)`),a.add(l),h&&a.add(h),s&&a.add(s);break}case`bar`:{let e=Sl(u.lo,0),t=Sl(u.hi,100);if(t<=e)throw Error(`range low ${e} must be below high ${t}`);p=u.style===`segments`?`tsgui_bar.make(${xl(e)}, ${xl(t)}, "segments", ${Math.max(1,Math.round(Sl(u.segments,10)))})`:`tsgui_bar.make(${xl(e)}, ${xl(t)})`;break}case`trend`:{let t=Sl(u.lo,0),n=Sl(u.hi,100);if(n<=t)throw Error(`range low ${t} must be below high ${n}`);let r=Math.max(1,Math.round(b/8));p=`tsgui_trend.make(${xl(t)}, ${xl(n)}, ${r})`,s.set(e.id,Math.max(0,Math.floor((d-4)/r)));break}case`button`:{let e=Math.max(2,Math.round(Math.min(d,f)/8)),t=u.style===`switch`?`switch`:u.style===`filled`?`filled`:`box`;if(t===`switch`&&u.mode!==`toggle`)throw Error(`a switch style needs a toggle button (set mode to toggle)`);if(u.mode===`toggle`){let n=typeof u.onText==`string`&&u.onText!==``?u.onText:`ON`,r=typeof u.offText==`string`&&u.offText!==``?u.offText:`OFF`,i=[n,r,`--`].reduce((e,t)=>ll(`font_body16`,t)>ll(`font_body16`,e)?t:e),o=Dl(f-2*e,Tl,t=>ll(t,i)<=d-2*e&&ul(t,i).length===0);p=`tsgui_button.make(${o}, None, ${z(n)}, ${z(r)}${t===`box`?``:`, ${z(t)}`})`,a.add(o);break}let n=[u.text,u.label].map(e=>typeof e==`string`?e.trim():``).find(e=>e!==``)||void 0,r=Dl(f-2*e,Tl,t=>ll(t,n??`--`)<=d-2*e&&ul(t,n??`--`).length===0);p=`tsgui_button.make(${r}, ${n===void 0?`None`:z(n)}${t===`box`?``:`, None, None, ${z(t)}`})`,a.add(r);break}case`led`:{let e=Math.max(2,Math.min(d,f));if(u.style===`chip`){let t=typeof u.onText==`string`&&u.onText!==``?u.onText:`On`,n=typeof u.offText==`string`&&u.offText!==``?u.offText:`Off`,r=[t,n,`--`].reduce((e,t)=>ll(`font_body12`,t)>ll(`font_body12`,e)?t:e),i=Dl(f-4,Tl,e=>ll(e,r)<=d-8&&ul(e,r).length===0);p=`tsgui_led.make(${e}, "chip", ${z(t)}, ${z(n)}, ${i})`,a.add(i)}else p=`tsgui_led.make(${e})`;break}}}catch(e){return r.push(`widget ${l}: ${e instanceof Error?e.message:String(e)} ${n}`),null}a.add(`tsgui_${c}`);let m=o.get(e.id);return m!==void 0&&m!==p?(r.push(`widget ${l} is drawn differently on two pages; give it the same size on each`),null):(o.set(e.id,p),p)},re=(e,n)=>{T(e,n);let i=[],o=[],s=new Map,c=new Set;for(let d of e){let e=w(d);if(d.card){o.push(e);continue}if(d.kind===`text`){let o=`${t.slice(0,8)}_s${_++}`;s.set(o,e);let c=d.text??``,l;try{l=Dl(e.height,Tl,t=>ll(t,c)<=e.width&&ul(t,c).length===0)}catch(e){r.push(`${n}: text "${c}" ${e instanceof Error?e.message:String(e)}`);continue}a.add(l),a.add(`tsgui_label`),v.push(`_gui.widget(${z(o)}, tsgui_label.make(${l}, ${z(c)}, ${z(d.align??`left`)}))`),i.push([o,e]);continue}if(d.kind===`pagedots`){let n=`${t.slice(0,8)}_s${_++}`;s.set(n,e);let r=Math.max(2,Math.round(Math.min(b,x)/4)),o=Math.max(1,Math.round(r/2));a.add(`tsgui_pagedots`),v.push(`_gui.widget(${z(n)}, tsgui_pagedots.make(${r}, ${o}))`),i.push([n,e]);continue}let f=d.node?l.get(d.node):void 0;if(!f||!yl(f.type)){r.push(`${n}: "${d.node??`?`}" isn't a GUI widget node in this flow`);continue}if(c.has(f.id)){r.push(`"${f.id}" appears twice ${n}`);continue}c.add(f.id);let p=u.get(f.id);p&&p.screen!==t?r.push(`widget ${bl(f)} is placed on two screens (${p.where} and ${n}); a widget belongs to one screen`):(p||u.set(f.id,{screen:t,where:n}),ne(f,e,n,d.align??`left`)!==null&&(s.set(f.id,e),i.push([f.id,e])))}return{leaves:i,cards:o,rects:s}},ie=([e,t])=>`(${z(e)}, (${t.x}, ${t.y}, ${t.width}, ${t.height}))`,ae=e=>`[${e.map(e=>`(${e.x}, ${e.y}, ${e.width}, ${e.height})`).join(`, `)}]`,oe=i.pages.map(e=>{let t=`on page "${e.name}" of screen ${d}`,n=re(e.elements,t);return y.set(e.name,n.rects),`${z(e.name)}: {"parent": ${e.parent===void 0?`None`:z(e.parent)}, "widgets": [${n.leaves.map(ie).join(`, `)}], "cards": ${ae(n.cards)}}`}),se=[],ce=new Set;for(let e of i.modals??[]){let t=l.get(e.node);if(!t||t.type!==`thingstudio/gui_modal`){r.push(`screen ${d}: modal "${e.node}" isn't a GUI modal node in this flow`);continue}let n=kl(t);(ce.has(n)||h.has(n))&&r.push(`screen ${d}: two pages or modals are called "${n}"`),ce.add(n);let i=re(e.elements,`in modal "${n}" of screen ${d}`);y.set(n,i.rects);let a=Math.round(Sl(t.properties.priority,0)),o=Math.round(Sl(t.properties.timeout,0)*1e3);se.push(`${z(n)}: {"widgets": [${i.leaves.map(ie).join(`, `)}], "cards": ${ae(i.cards)}, "priority": ${a}, "timeout_ms": ${o}}`)}c.push({screen:t,pagesPy:`{${oe.join(`, `)}}`,carouselPy:`[${g.map(z).join(`, `)}]`,modalsPy:`{${se.join(`, `)}}`,staticRegistrations:v,rects:y})}for(let e of t)yl(e.type)&&!u.has(e.id)&&i.push(`widget ${bl(e)} isn't placed on any screen, so nothing shows it`);return{surfaces:c,widgetDraws:o,trendColumns:s,imports:a,errors:r,warnings:i}}function kl(e){return(typeof e.properties.name==`string`?e.properties.name.trim():``)||`modal_${e.id.slice(0,6)}`}function Al(e){return typeof e==`number`?String(e):Ts(e)}function jl(e,t,n,r){e.claimResource?.(t,n,typeof r==`string`?r:bl(r))}function Ml(e){return e===`none`?`no pull`:`pull-${e}`}function Nl(e,t,n=`none`){let r=Al(e),i=t===`out`?`machine.Pin.OUT`:`machine.Pin.IN${n===`up`?`, machine.Pin.PULL_UP`:n===`down`?`, machine.Pin.PULL_DOWN`:``}`;return`runtime.shared('pin', ${r}, ${t===`out`?`('out', 'none')`:`('in', '${n}')`}, lambda: machine.Pin(${r}, ${i}))`}function Pl(e,t,n,r,i,a){let o=Al(r),s=Al(i);jl(e,`SPI bus ${n}`,`SCK ${r}, MOSI ${i} at ${a} Hz`,t),jl(e,hc(r),`SPI bus ${n} SCK`,t),jl(e,hc(i),`SPI bus ${n} MOSI`,t);let c=`_spi_bus_${n}`;return{varName:c,statement:{key:c,code:`${c} = runtime.shared('spi', ${n}, (${o}, ${s}, ${a}), lambda: machine.SPI(${n}, baudrate=${a}, polarity=0, phase=0, sck=machine.Pin(${o}), mosi=machine.Pin(${s})))`}}}var Fl=`thingstudio/config/i2c-bus`,Il=[`thingstudio/display_i2c`,`thingstudio/bme280`,`thingstudio/i2c`],Ll=`thingstudio/config/touch-panel`,Rl=[`thingstudio/gui_screen`,`thingstudio/touch_i2c`],zl=1e5;function Bl(e){return e==null||e===``?NaN:Number(e)}function Vl(e,t){let n=Bl(t.bus);if(!Number.isInteger(n)||n<0)throw new L(`I2C bus "${String(t.bus)}" must be a whole number, 0 or more`);let r=`I2C bus ${n}`;if(t.scl===null||t.scl===void 0||t.scl===``)throw new L(`${r} has no SCL pin set`);if(t.sda===null||t.sda===void 0||t.sda===``)throw new L(`${r} has no SDA pin set`);let i=$c(e,`${r} scl pin`,t.scl,`bidirectional`),a=$c(e,`${r} sda pin`,t.sda,`bidirectional`);if(i===a)throw new L(`${r} uses pin ${i} for both SCL and SDA`);jl(e,hc(i),`${r} SCL`,r),jl(e,hc(a),`${r} SDA`,r),il(e,r,n,{scl:i,sda:a});let o=t.freq===null||t.freq===void 0||t.freq===``?zl:Number(t.freq);if(!Number.isInteger(o)||o<=0)throw new L(`${r} frequency "${String(t.freq)}" must be a whole number of Hz above 0`);let s=Al(i),c=Al(a),l=`_i2c_bus_${n}`;return{varName:l,bus:n,statement:{key:l,code:`${l} = runtime.shared('i2c', ${n}, (${s}, ${c}, ${o}), lambda: machine.I2C(${n}, scl=machine.Pin(${s}), sda=machine.Pin(${c}), freq=${o}))`}}}function Hl(e,t,n){if(typeof n!=`string`||n===``)throw new L(`${t} has no I2C bus. Pick one, or add one with +.`);let r=Vl(e,e.resolveConfig(n)),i=new Set;for(let t of Il)for(let n of e.findNodesOfType?.(t)??[])typeof n.properties.i2cConfigId==`string`&&i.add(n.properties.i2cConfigId);let a=e.findConfigsOfType?.(Ll)??[];for(let t of Rl)for(let n of e.findNodesOfType?.(t)??[]){let e=a.find(e=>e.id===n.properties.touchPanelConfigId);e&&typeof e.properties.i2cConfigId==`string`&&i.add(e.properties.i2cConfigId)}if((e.findConfigsOfType?.(`thingstudio/config/i2c-bus`)??[]).find(e=>e.id!==n&&i.has(e.id)&&Number(e.properties.bus)===r.bus))throw new L(`Two I2C bus settings both say bus ${r.bus}. Give one a different bus number, or pick the same one on every node.`);return r}function Ul(e,t,n){let r=[...t],i=[],a=0,o=e=>r.find(t=>t.type===`thingstudio/config/i2c-bus`&&Number(t.properties.bus)===e);return{nodes:e.map(e=>{let t=e.properties;if(e.type!==`thingstudio/display_i2c`||typeof t.i2cConfigId==`string`&&t.i2cConfigId!==``||t.scl===void 0&&t.sda===void 0)return e;let s=Number(t.i2cBus??0),c={scl:t.scl??null,sda:t.sda??null,freq:t.freq??4e5},l=o(s);l?(l.properties.scl!==c.scl||l.properties.sda!==c.sda)&&i.push(`display_i2c #${e.id.slice(0,6)} had SCL ${String(c.scl)}/SDA ${String(c.sda)} on bus ${s}, but the bus is already SCL ${String(l.properties.scl)}/SDA ${String(l.properties.sda)}; it now uses the bus's pins.`):(l={id:n(),type:Fl,properties:{bus:s,...c}},r.push(l));let{i2cBus:u,scl:d,sda:f,freq:p,...m}=t;return a++,{...e,properties:{...m,i2cConfigId:l.id}}}),configs:r,moved:a,notes:i}}function Wl(e,t,n){return e.replace(/\{pin\}/g,hc(n)).replace(/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/g,(e,n)=>String(t.properties[n]??``))}function Gl(e,t){let n=Math.round(Number(e));if(e==null||e===``||!Number.isFinite(n))throw new L(`${t} must be a whole number`);return n}function Kl(e,t,n,r){let i=Gl(t.properties[r.bus],`${n} spiBus`);if(i<0)throw new L(`${n} spiBus ${i} must be 0 or more`);let a=$c(e,`${n} sck pin`,t.properties[r.sck],`output`),o=$c(e,`${n} mosi pin`,t.properties[r.mosi],`output`),s=Gl(t.properties[r.baudrate],`${n} baudrate`);if(s<=0)throw new L(`${n} baudrate ${s} must be above 0`);rl(e,n,i,{sck:a,mosi:o},s),Pl(e,t,i,a,o,s)}function ql(e,t){return e===`output`?`output`:`input, ${Ml(t)}`}var Jl=[`thingstudio/wifi_status`,`thingstudio/wifi_gate`,`thingstudio/mqtt_publish`,`thingstudio/mqtt_subscribe`,`thingstudio/http_request`,`thingstudio/http_in`,`thingstudio/http_response`,`thingstudio/udp_send`,`thingstudio/udp_receive`];function Yl(e){return e.findNodesOfType?Jl.some(t=>(e.findNodesOfType(t)?.length??0)>0):!1}function Xl(e,t,n,r){if(r.optional){let e=t.properties[r.property];if(e==null||e===``||Number(e)<0)return}let i=r.pullProperty?t.properties[r.pullProperty]:r.pull,a=i==null||i===``?`none`:String(i);if(a!==`none`&&a!==`up`&&a!==`down`)throw new L(`${n} pin pull "${String(i)}" must be "none", "up", or "down"`);let o=$c(e,`${n} pin`,t.properties[r.property],r.direction,{pull:r.direction===`input`&&a!==`none`});if(r.noAdc2WithWifi&&e.target?.processor.adc2.has(o)&&Yl(e))throw new L(`${n} pin ${o} is an ADC2 pin on ${e.target.label} and the flow uses WiFi, which makes ADC2 unusable. Use an ADC1 pin, or drop the flow's network nodes.`);jl(e,hc(o),Wl(r.use??ql(r.direction,a),t,o),t),r.claim&&jl(e,Wl(r.claim.resource,t,o),Wl(r.claim.use,t,o),t)}function Zl(e,t,n){let r=n.resources;if(!r||r.length===0)return;let i=n.paletteId??n.type;for(let n of r)if(n.kind===`i2c`){let r=t.properties[n.config];if(n.nestedField!==void 0){let t=(typeof r==`string`&&r!==``?e.resolveConfig(r):void 0)?.[n.nestedField];r=typeof t==`string`?t:``}let a=n.fallback,o=a!==void 0&&(t.properties[a.scl]!==void 0||t.properties[a.sda]!==void 0);(typeof r!=`string`||r===``)&&o?Vl(e,{bus:t.properties[a.bus]??0,scl:t.properties[a.scl],sda:t.properties[a.sda],freq:t.properties[a.freq]??4e5}):Hl(e,i,r)}else n.kind===`spi`?Kl(e,t,i,n):Xl(e,t,i,n)}var Ql=class extends Error{};function $l(e){return`custom_`+e.replace(/[^a-zA-Z0-9_]/g,`_`)}function eu(e,t){if(typeof e!=`boolean`)throw new L(`${t} must be a boolean, got ${JSON.stringify(e)}`);return e?`True`:`False`}function tu(e,t){let n=Number(e);if(!Number.isFinite(n))throw new L(`${t} must be a finite number, got ${JSON.stringify(e)}`);return String(n)}function nu(e,t){if(e==null)return`None`;if(typeof e==`boolean`)return e?`True`:`False`;if(typeof e==`number`){if(!Number.isFinite(e))throw new L(`${t} is not a finite number: ${JSON.stringify(e)}`);return String(e)}if(typeof e==`string`)return Ts(e);if(Array.isArray(e))return`[${e.map(e=>nu(e,t)).join(`, `)}]`;if(typeof e==`object`){let n=e;return`{${Object.keys(n).sort().map(e=>`${Ts(e)}: ${nu(n[e],`${t}[${e}]`)}`).join(`, `)}}`}throw new L(`${t} has a value this cannot render: ${JSON.stringify(e)}`)}function ru(e,t,n){if(Number.isFinite(t)){if(e.min!==void 0&&t<e.min)throw new L(`${n} ${t} is below its minimum, ${e.min}`);if(e.max!==void 0&&t>e.max)throw new L(`${n} ${t} is above its maximum, ${e.max}`)}}function iu(e,t,n){let r=t==null?``:String(t).trim();if(r===``){if(e.optional)return`None`;throw new L(`${n} must be a whole number (decimal or 0x hex)`)}let i;if(/^0x[0-9a-f]+$/i.test(r))i=parseInt(r,16);else if(/^[+-]?\d+$/.test(r))i=parseInt(r,10);else throw new L(`${n} "${r}" must be a whole number (decimal or 0x hex)`);if(e.min!==void 0&&i<e.min)throw new L(`${n} "${r}" is below its minimum, ${e.min}`);if(e.max!==void 0&&i>e.max)throw new L(`${n} "${r}" is above its maximum, ${e.max}`);return String(i)}function au(e,t,n,r,i){let a=(e.properties??[]).filter(e=>e.name!==void 0);return`{${a.map(e=>{let o=e.name in n?n[e.name]:e.default,s=`${r} property "${e.name}"`,c;switch(e.kind){case`number`:{let t=Number(o);if(ru(e,t,s),e.lessThan!==void 0){let r=a.find(t=>t.name===e.lessThan),i=r&&e.lessThan in n?n[e.lessThan]:r?.default,o=Number(i);if(Number.isFinite(t)&&Number.isFinite(o)&&!(t<o))throw new L(`${s} ${t} must be less than ${e.lessThan} (${o})`)}c=tu(o,s);break}case`pin`:c=ou(t,e,o,s,i);break;case`boolean`:c=eu(o,s);break;case`select`:{let t=(e.options??[]).find(e=>e.value===o);if(t===void 0)throw new L(`${s} value ${JSON.stringify(o)} is not one of the declared options`);c=typeof t.value==`number`?String(t.value):Ts(t.value);break}case`configRef`:if(e.singleton)c=su(e,s,i);else{let e=o==null?``:String(o);c=e===``?`None`:nu(i.resolveConfig(e),s)}break;case`target`:c=cu(i);break;case`nodeId`:c=Ts(t.id);break;case`text`:c=e.integer?iu(e,o,s):Ts(String(o));break;default:c=Ts(String(o))}return`${Ts(e.name)}: ${c}`}).join(`, `)}}`}function ou(e,t,n,r,i){let a=t.pinUse!==void 0,o=t.pinUse??`input`,s=t.pinPull??`none`,c=t.optional?el(i,r,n,o):$c(i,r,n,o,{pull:a&&o===`input`&&s!==`none`});return c===null?`None`:(a&&jl(i,hc(c),o===`output`?`output`:`input, ${Ml(s)}`,e),Al(c))}function su(e,t,n){let r=e.configType,i=n.findConfigsOfType;if(!i)throw new L(`${t}: this compiler context can't look up the flow's config (findConfigsOfType missing) -- internal error, not a flow-authoring mistake`);let a=i(r);if(a.length===0)throw new L(`${t}: needs a "${r}" config -- add one to the flow`);if(a.length>1)throw new L(`${t}: the flow has ${a.length} "${r}" configs, but a singleton reference needs exactly one -- pick one in the field to keep just that one`);return nu(a[0].properties,t)}function cu(e){let t=e.target;return t?`{${[`"boardId": ${t.board?Ts(t.board.id):`None`}`,`"boardName": ${t.board?Ts(t.board.name):`None`}`,`"processorId": ${Ts(t.processor.id)}`,`"processorName": ${Ts(t.processor.name)}`,`"label": ${Ts(t.label)}`,`"capabilities": [${[...t.capabilities].sort().map(Ts).join(`, `)}]`].join(`, `)}}`:`None`}function lu(e,t,n){let r=e.properties?.find(e=>e.name===`intervalMs`),i=`intervalMs`in t?t.intervalMs:r?.default,a=Number(i);if(!Number.isFinite(a)||a<=0)throw new L(`${n} "intervalMs" must be a positive number, got ${JSON.stringify(i)}`);if(!Number.isInteger(a))throw new L(`${n} "intervalMs" must be a whole number of milliseconds, got ${JSON.stringify(i)}`);return a}function uu(e){return e?.map(e=>({name:e.name,type:e.type}))}var du=new WeakMap;function fu(e,t,n){let r=e.kind===`source`?`emit`:`run`,i=$l(e.type);function a(r,a,o){Zl(a,r,e);let s=a.hookResult?.(r.id);if(n!==void 0&&s===void 0)throw new L(`${e.type} (node ${r.id}) has a compile hook that was not run -- compile through the async hook pre-pass first`);for(let e of s?.claims??[])a.claimResource&&a.claimResource(e.resource,e.use,r.id);let c=a.uniqueName(`${i}_props`),l=a.uniqueName(`${i}_setup`),u=o.map(e=>a.uniqueName(`${i}_${e}`)),d=au(e,r,r.properties,`node ${r.id} (${e.type})`,a),f=s&&Object.keys(s.properties).length>0?nu(s.properties,`node ${r.id} (${e.type})`):null,p=t.split(`
`).map(e=>e.length?`    `+e:e).join(`
`);return{vars:u,propsVar:c,statements:[{key:l,code:[`def ${l}(properties):`,p,`    return ${o.join(`, `)}`,`${c} = ${d}`,...f===null?[]:[`${c}.update(${f})`],`${u.join(`, `)} = ${l}(${c})`].join(`
`)}]}}function o(e,t,n){let r=du.get(t);r===void 0&&(r=new Map,du.set(t,r));let i=`${e.id}|${n.join(`,`)}`,o=r.get(i);if(o!==void 0)return o;let s=a(e,t,n);return r.set(i,s),s}let s={};if(e.kind===`source`&&e.eventSource)s.codegenEventSource=(e,t)=>{let{vars:n,propsVar:r,statements:i}=a(e,t,[`wait`,`emit`]);return{statements:i,waitStatement:`await ${n[0]}(${r})`,buildMsg:`msg = await ${n[1]}(${r})`}};else if(e.kind===`source`)s.codegenSource=(t,n)=>{let{vars:i,propsVar:o,statements:s}=a(t,n,[r]),c=n.hookResult?.(t.id)?.properties,l=c?{...t.properties,...c}:t.properties,u=e.runOnce?0:lu(e,l,`node ${t.id} (${e.type})`);return{statements:s,buildMsg:`msg = await ${i[0]}(${o})`,repeatMs:u}};else if(e.kind===`transform`)s.codegenTransform=(e,t)=>{let{vars:n,propsVar:o,statements:s}=a(e,t,[r]);return{statements:s,functionName:t.uniqueName(`${i}_call`),functionBody:`return await ${n[0]}(msg, ${o})`}};else if(e.eventSource){let e=[`run`,`wait`,`emit`];s.codegenSink=(t,n)=>{let r=o(t,n,e);return{statements:r.statements,functionName:n.uniqueName(`${i}_call`),functionBody:`await ${r.vars[0]}(msg, ${r.propsVar})`}},s.codegenEventSource=(t,n)=>{let r=o(t,n,e);return{statements:r.statements,waitStatement:`await ${r.vars[1]}(${r.propsVar})`,buildMsg:`msg = await ${r.vars[2]}(${r.propsVar})`}}}else s.codegenSink=(e,t)=>{let{vars:n,propsVar:o,statements:s}=a(e,t,[r]);return{statements:s,functionName:t.uniqueName(`${i}_call`),functionBody:`await ${n[0]}(msg, ${o})`}};return s}function pu(e,t){let n={type:e.type,kind:e.kind,ports:{inputs:uu(e.ports?.inputs),outputs:uu(e.ports?.outputs)}};return e.description!==void 0&&(n.description=e.description),e.requires!==void 0&&(n.requires=e.requires),{...n,...fu(e,t)}}function mu(e,t,n){let r={...e,...fu(e,t,n)};return n!==void 0&&(r.compileHook=n),r}function hu(e,t){let n=new Map(e);for(let e of t){if(n.has(e.type))throw new Ql(`custom node type "${e.type}" collides with an already-registered node type -- pick a different type id`);n.set(e.type,e)}return n}var gu={type:`thingstudio/i2c`,kind:`transform`,paletteId:`i2c`,label:`i2c device`,group:`hardware`,priority:45,color:`#2e3f8a`,bgcolor:`#1f2a4a`,icon:`⇄`,width:90,description:`One transfer per incoming message. Read puts the bytes in msg.payload; scan puts the list of addresses that answer. Hex (0x29) or decimal both work.`,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},resources:[{kind:`i2c`,config:`i2cConfigId`}],properties:[{name:`i2cConfigId`,label:`I2C bus`,kind:`configRef`,configType:`thingstudio/config/i2c-bus`,default:``},{name:`operation`,label:`operation`,kind:`select`,default:`read`,options:[{value:`read`,label:`read bytes`},{value:`write`,label:`write msg.payload`},{value:`scan`,label:`scan the bus`}]},{name:`address`,label:`address`,kind:`text`,default:``,placeholder:`e.g. 0x29`,integer:!0,min:0,max:127,optional:!0,visibleWhen:{field:`operation`,notEquals:`scan`}},{name:`register`,label:`register`,kind:`text`,default:``,placeholder:`none`,integer:!0,min:0,max:255,optional:!0,visibleWhen:{field:`operation`,notEquals:`scan`}},{name:`length`,label:`length (bytes)`,kind:`number`,default:1,min:1,max:256,visibleWhen:{field:`operation`,equals:`read`}},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},_u=`import machine

_bus = properties['i2cConfigId']
_op = str(properties['operation'])
_node_id = properties['nodeId']
_address = properties['address']
_register = properties['register']
_length = properties['length']
_state = None

if _bus is None:
    raise ValueError('i2c: pick an I2C bus in the node properties')

_bus_num = int(_bus['bus'])
if _bus.get('scl') is None or _bus.get('sda') is None:
    raise ValueError('i2c: set the SCL and SDA pins on the I2C bus config')

# The same shared bus object Thingstudio's other I2C nodes use, keyed by bus id.
_i2c = runtime.shared('i2c', _bus_num, (_bus['scl'], _bus['sda'], _bus['freq']),
                      lambda: machine.I2C(_bus_num, scl=machine.Pin(_bus['scl']),
                                          sda=machine.Pin(_bus['sda']), freq=_bus['freq']))


def _to_bytes(v):
    if isinstance(v, (bytes, bytearray)):
        return v
    if isinstance(v, bool):
        raise ValueError('i2c write needs bytes, a list of 0-255, or one 0-255, got bool')
    if isinstance(v, int):
        v = [v]
    if isinstance(v, (list, tuple)):
        for b in v:
            if isinstance(b, bool) or not isinstance(b, int) or b < 0 or b > 255:
                raise ValueError('i2c write needs values 0-255, got %r' % (b,))
        return bytes(v)
    raise ValueError('i2c write needs bytes, a list of 0-255, or one 0-255, got %s' % type(v).__name__)


def _status(state, text):
    nonlocal _state
    if _state != (state, text):
        _state = (state, text)
        runtime.report_status(_node_id, state, text)


async def run(msg, properties):
    if _op == 'scan':
        try:
            msg['payload'] = _i2c.scan()
        except OSError:
            _status('disconnected', 'I2C bus %d not responding' % _bus_num)
            return None
        _status('connected', None)
        return msg

    if _address is None:
        raise ValueError('i2c: set the device address (7-bit, e.g. 0x29)')
    where = 'at 0x%02x on I2C bus %d' % (_address, _bus_num)

    if _op == 'read':
        try:
            if _register is None:
                msg['payload'] = _i2c.readfrom(_address, _length)
            else:
                msg['payload'] = _i2c.readfrom_mem(_address, _register, _length)
        except OSError:
            _status('disconnected', 'no reply %s' % where)
            return None
        _status('connected', None)
        return msg

    if _op == 'write':
        try:
            buf = _to_bytes(msg.get('payload'))
            if _register is None:
                _i2c.writeto(_address, buf)
            else:
                _i2c.writeto_mem(_address, _register, buf)
        except OSError:
            _status('disconnected', 'no reply %s' % where)
            return None
        except ValueError as e:
            _status('error', str(e))
            return None
        _status('connected', None)
        return msg

    raise ValueError('i2c: unknown operation "%s"' % _op)
`,vu={type:`thingstudio/eswitch`,kind:`source`,eventSource:!0,paletteId:`eswitch`,label:`eswitch`,group:`hardware`,priority:11,color:`#a67c3f`,bgcolor:`#4a3a1f`,icon:`○`,width:104,description:`Sends a message each time the switch opens or closes. msg.payload is true when closed. Set pull to use the pin's own pull resistor, or leave it at none if the switch has one.`,ports:{outputs:[{name:`msg`,type:`bool`}]},resources:[{kind:`pin`,property:`pin`,direction:`input`,pullProperty:`pull`,claim:{resource:`{pin} eswitch`,use:`open level {lopen}, debounce {debounceMs} ms`}}],properties:[{name:`pin`,label:`pin`,kind:`pin`,default:4},{name:`pull`,label:`pull`,kind:`select`,default:`none`,options:[{value:`none`,label:`none -- external pull or self-pulling switch (default)`},{value:`up`,label:`up -- enable the pin's internal pull-up`},{value:`down`,label:`down -- enable the pin's internal pull-down`}]},{name:`lopen`,label:`open level (lopen)`,kind:`select`,default:1,options:[{value:1,label:`1 -- switch to gnd, pulled up (default)`},{value:0,label:`0 -- switch to 3V3, pulled down`}]},{name:`debounceMs`,label:`debounce (ms)`,kind:`number`,default:50,min:1}]},yu=`import machine
from events import ESwitch, WaitAny

_pin_num = properties['pin']
_pull = str(properties['pull'])
_lopen = properties['lopen']
_debounce_ms = properties['debounceMs']

if _pull == 'up':
    _pull_mode = machine.Pin.PULL_UP
elif _pull == 'down':
    _pull_mode = machine.Pin.PULL_DOWN
else:
    _pull_mode = None


def _make_pin():
    if _pull_mode is None:
        return machine.Pin(_pin_num, machine.Pin.IN)
    return machine.Pin(_pin_num, machine.Pin.IN, _pull_mode)


def _make_driver():
    # ESwitch.debounce_ms is a class attribute, read once in __init__ -- set it just before constructing this one
    # (eswitch.ts's header / the vendored README have the full trace).
    ESwitch.debounce_ms = _debounce_ms
    return ESwitch(_pin, lopen=_lopen)


_pin = runtime.shared('pin', _pin_num, ('in', _pull), _make_pin)
_es = runtime.shared('eswitch', _pin_num, (_debounce_ms, int(_lopen), _pull), _make_driver)
_wait = WaitAny([_es.close, _es.open])
_trig = None


async def wait(properties):
    nonlocal _trig
    _trig = await _wait.wait()


async def emit(properties):
    # Clear only the event that fired, not every event WaitAny watches (events.py's own WaitAny.clear() would).
    _is_close = _trig is _es.close
    _trig.clear()
    return {'payload': _is_close, 'topic': ''}
`,bu={type:`thingstudio/ebutton`,kind:`source`,eventSource:!0,paletteId:`ebutton`,label:`ebutton`,group:`hardware`,priority:12,color:`#a6633f`,bgcolor:`#4a2e1f`,icon:`⏺`,width:104,description:`Sends a message on each press, release, long press and double click. msg.payload is "press", "release", "long" or "double". Set pull to use the pin's own pull resistor, or leave it at none if the button has one. Double click must be shorter than long press.`,ports:{outputs:[{name:`msg`,type:`string`}]},resources:[{kind:`pin`,property:`pin`,direction:`input`,pullProperty:`pull`,claim:{resource:`{pin} ebutton`,use:`sense {senseMode}, suppress {suppress}, debounce {debounceMs} ms, long press {longPressMs} ms, double click {doubleClickMs} ms`}}],properties:[{name:`pin`,label:`pin`,kind:`pin`,default:5},{name:`pull`,label:`pull`,kind:`select`,default:`none`,options:[{value:`none`,label:`none -- external pull or self-pulling button (default)`},{value:`up`,label:`up -- enable the pin's internal pull-up`},{value:`down`,label:`down -- enable the pin's internal pull-down`}]},{name:`senseMode`,label:`sense`,kind:`select`,default:`auto`,options:[{value:`auto`,label:`auto -- assume not pressed at boot (default)`},{value:`0`,label:`0 -- unpressed reads as gnd`},{value:`1`,label:`1 -- unpressed reads as 3V3`}]},{name:`suppress`,label:`suppress (delay/suppress release in favor of double/long)`,kind:`boolean`,default:!1},{name:`debounceMs`,label:`debounce (ms)`,kind:`number`,default:50,min:1},{name:`longPressMs`,label:`long press (ms)`,kind:`number`,default:1e3,min:1},{name:`doubleClickMs`,label:`double click (ms)`,kind:`number`,default:400,min:1,lessThan:`longPressMs`}]},xu=`import machine
from events import EButton, WaitAny

_pin_num = properties['pin']
_pull = str(properties['pull'])
_sense = str(properties['senseMode'])
_suppress = properties['suppress']
_debounce_ms = properties['debounceMs']
_long_press_ms = properties['longPressMs']
_double_click_ms = properties['doubleClickMs']

if _pull == 'up':
    _pull_mode = machine.Pin.PULL_UP
elif _pull == 'down':
    _pull_mode = machine.Pin.PULL_DOWN
else:
    _pull_mode = None


def _make_pin():
    if _pull_mode is None:
        return machine.Pin(_pin_num, machine.Pin.IN)
    return machine.Pin(_pin_num, machine.Pin.IN, _pull_mode)


def _make_driver():
    # EButton.debounce_ms/long_press_ms/double_click_ms are class attributes, read once in __init__ -- set them
    # just before constructing this one (ebutton.ts's header / the vendored README have the full trace).
    EButton.debounce_ms = _debounce_ms
    EButton.long_press_ms = _long_press_ms
    EButton.double_click_ms = _double_click_ms
    if _sense == 'auto':
        return EButton(_pin, suppress=_suppress)
    return EButton(_pin, suppress=_suppress, sense=int(_sense))


_pin = runtime.shared('pin', _pin_num, ('in', _pull), _make_pin)
_btn = runtime.shared('ebutton', _pin_num, (_debounce_ms, _long_press_ms, _double_click_ms, _suppress, _sense, _pull), _make_driver)
_wait = WaitAny([_btn.press, _btn.release, _btn.long, _btn.double])
_trig = None


async def wait(properties):
    nonlocal _trig
    _trig = await _wait.wait()


async def emit(properties):
    if _trig is _btn.press:
        _event = 'press'
    elif _trig is _btn.release:
        _event = 'release'
    elif _trig is _btn.long:
        _event = 'long'
    else:
        _event = 'double'
    # Clear ONLY the event that fired -- a rapid second click can set both press and double; clearing every event
    # would silently drop the loser (ebutton.ts's header has the full trace).
    _trig.clear()
    return {'payload': _event, 'topic': ''}
`,Su={type:`thingstudio/adc`,kind:`source`,eventSource:!0,paletteId:`adc`,label:`adc`,group:`hardware`,priority:13,color:`#6e8a2e`,bgcolor:`#3a4a1f`,icon:`∼`,width:110,description:`Reads an analog pin and sends {raw, volts, percent} when the reading crosses the bounds, and at each poll if poll is set. raw runs from 0 to 65535.`,resources:[{kind:`pin`,property:`pin`,direction:`input`,use:`ADC input`,noAdc2WithWifi:!0}],ports:{outputs:[{name:`msg`,type:`any`}]},properties:[{name:`pin`,label:`pin`,kind:`pin`,default:34,help:`On ESP32, an ADC2 pin can't be used in a flow with WiFi: Deploy refuses it.`},{name:`mode`,label:`mode`,kind:`select`,default:`relative`,options:[{value:`relative`,label:`relative -- fire when it moves by delta from the last message`},{value:`absolute`,label:`absolute -- fire outside lower..upper`}]},{name:`delta`,label:`delta (counts)`,kind:`number`,default:2e3,min:1,visibleWhen:{field:`mode`,equals:`relative`}},{name:`lower`,label:`lower`,kind:`number`,default:0,min:0,max:65535,visibleWhen:{field:`mode`,equals:`absolute`}},{name:`upper`,label:`upper`,kind:`number`,default:5e4,min:0,max:65535,visibleWhen:{field:`mode`,equals:`absolute`}},{name:`sense`,label:`sense`,kind:`select`,default:`outside`,options:[{value:`outside`,label:`outside -- fire when it leaves the bounds (default)`},{value:`inside`,label:`inside -- fire when it returns to them`}]},{name:`pollMs`,label:`poll (ms)`,kind:`number`,default:0,min:0,help:`0 sends only when the reading crosses the bounds.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Cu=`def _adc_whole(properties, name, default):
    raw = properties.get(name)
    if raw is None:
        raw = default
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None

def compile(ctx, properties):
    mode = str(properties.get('mode') or 'relative')
    if mode not in ('relative', 'absolute'):
        return {'errors': ['adc mode "%s" must be relative or absolute' % mode]}
    delta = _adc_whole(properties, 'delta', 2000)
    if delta is None or delta <= 0:
        return {'errors': ['adc delta "%s" must be more than 0' % properties.get('delta')]}
    lower = _adc_whole(properties, 'lower', 0)
    upper = _adc_whole(properties, 'upper', 50000)
    if lower is None or upper is None:
        return {'errors': ['adc lower and upper must be whole numbers']}
    if lower < 0 or upper > 65535:
        return {'errors': ['adc lower/upper must be within 0..65535']}
    if mode == 'absolute' and lower >= upper:
        return {'errors': ['adc lower (%d) must be less than upper (%d)' % (lower, upper)]}
    sense = str(properties.get('sense') or 'outside')
    if sense not in ('outside', 'inside'):
        return {'errors': ['adc sense "%s" must be outside or inside' % sense]}
    poll = _adc_whole(properties, 'pollMs', 0)
    if poll is None or poll < 0:
        return {'errors': ['adc pollMs "%s" must be 0 or more' % properties.get('pollMs')]}
    return {'properties': {'mode': mode, 'delta': delta, 'lower': lower, 'upper': upper,
                           'senseInside': sense == 'inside', 'pollMs': poll}}
`,wu=`import asyncio
import machine
import runtime
from aadc import AADC

_pin = properties['pin']
_adc = runtime.shared('adc', _pin, (), lambda: machine.ADC(machine.Pin(_pin)))
_aadc = AADC(_adc)
_normal = not properties['senseInside']
_aadc.sense(_normal)
_mode = properties['mode']
_delta = properties['delta']
_lower = properties['lower']
_upper = properties['upper']
_poll = properties['pollMs']
_node_id = properties['nodeId']
_last_error = [None]
# Absolute mode sends once per crossing (Mike, 2026-11-04): after a message, wait for the reading to go back to the
# other side of the bounds before waiting for the sense side again. Without this, AADC answers at once while the
# reading stays on the sense side, and the node sends on every poll of the pin.
_armed = [True]


async def _rearm():
    _aadc.sense(not _normal)
    try:
        await _aadc(_lower, _upper)
    finally:
        _aadc.sense(_normal)
    _armed[0] = True


async def _bounds():
    if _mode == 'absolute':
        if not _armed[0]:
            await _rearm()
        await _aadc(_lower, _upper)
        _armed[0] = False
    else:
        await _aadc(_delta)


async def wait(properties):
    if _poll > 0:
        try:
            await asyncio.wait_for(_bounds(), _poll / 1000)
        except asyncio.TimeoutError:
            pass
    else:
        await _bounds()


async def emit(properties):
    try:
        _raw = _adc.read_u16()
    except Exception as _e:
        _message = str(_e)
        if _last_error[0] != _message:
            _last_error[0] = _message
            runtime.report_status(_node_id, 'error', _message)
        return None
    _last_error[0] = None
    try:
        _volts = _adc.read_uv() / 1000000
    except AttributeError:
        _volts = _raw * 3.3 / 65535
    return {'payload': {'raw': _raw, 'volts': round(_volts, 3), 'percent': round(_raw * 100 / 65535, 1)}, 'topic': ''}
`,Tu={type:`thingstudio/encoder`,kind:`source`,eventSource:!0,paletteId:`encoder`,label:`encoder`,group:`hardware`,priority:14,color:`#8a3f7a`,bgcolor:`#4a1f42`,icon:`⟳`,width:110,description:`Reads a rotary encoder and sends its value each time it turns. msg.delta is the change since the last message.`,ports:{outputs:[{name:`msg`,type:`number`}]},resources:[{kind:`pin`,property:`pinX`,direction:`input`,pull:`up`,use:`encoder x input, pull-up`},{kind:`pin`,property:`pinY`,direction:`input`,pull:`up`,use:`encoder y input, pull-up`,claim:{resource:`{pinX},{pinY} encoder`,use:`v {value}, div {div}, vmin {vmin}, vmax {vmax}, mod {mod}, delay {delay}`}}],properties:[{name:`pinX`,label:`pin x`,kind:`pin`,default:10},{name:`pinY`,label:`pin y`,kind:`pin`,default:11},{name:`div`,label:`divide by (div)`,kind:`number`,default:1,min:1,help:`Pulses per detent: 4 or 2 for a knob that clicks.`},{name:`value`,label:`start value`,kind:`number`,default:0},{name:`vmin`,label:`lowest (blank for none)`,kind:`text`,default:``,integer:!0,optional:!0},{name:`vmax`,label:`highest (blank for none)`,kind:`text`,default:``,integer:!0,optional:!0},{name:`mod`,label:`wrap at (blank for none)`,kind:`text`,default:``,integer:!0,optional:!0},{name:`delay`,label:`settle (ms)`,kind:`number`,default:100,min:0}]},Eu=`import machine
from encoder import Encoder

_pin_x = properties['pinX']
_pin_y = properties['pinY']
_div = properties['div']
_value = properties['value']
_vmin = properties['vmin']
_vmax = properties['vmax']
_mod = properties['mod']
_delay = properties['delay']

_px = runtime.shared('pin', _pin_x, ('in', 'up'), lambda: machine.Pin(_pin_x, machine.Pin.IN, machine.Pin.PULL_UP))
_py = runtime.shared('pin', _pin_y, ('in', 'up'), lambda: machine.Pin(_pin_y, machine.Pin.IN, machine.Pin.PULL_UP))


def _make_encoder():
    _kw = {'v': _value, 'div': _div}
    if _vmin is not None:
        _kw['vmin'] = _vmin
    if _vmax is not None:
        _kw['vmax'] = _vmax
    if _mod is not None:
        _kw['mod'] = _mod
    _kw['delay'] = _delay
    return Encoder(_px, _py, **_kw)


_enc = runtime.shared('encoder', (_pin_x, _pin_y), (_value, _div, _vmin, _vmax, _mod, _delay), _make_encoder)
_prev = _value
_enc_val = None


async def wait(properties):
    nonlocal _enc_val
    _enc_val = await _enc.__anext__()


async def emit(properties):
    nonlocal _prev
    _enc_delta = _enc_val - _prev
    _prev = _enc_val
    return {'payload': _enc_val, 'topic': '', 'delta': _enc_delta}
`,Du={type:`thingstudio/neopixel`,kind:`sink`,paletteId:`neopixel`,label:`neopixel`,group:`hardware`,priority:42,color:`#8a2e5a`,bgcolor:`#4a1f30`,icon:`✦`,width:110,description:`Drives a WS2812 / NeoPixel strip. Payload is a colour 0xRRGGBB for the whole strip, a list of colours for one per pixel, or {index, colour} for one pixel. RGBW strips take 0xWWRRGGBB.`,ports:{inputs:[{name:`msg`,type:`any`}]},resources:[{kind:`pin`,property:`pin`,direction:`output`,use:`output`,claim:{resource:`{pin} neopixel`,use:`count {count}, order {order}`}}],properties:[{name:`pin`,label:`pin`,kind:`pin`,default:13},{name:`count`,label:`count`,kind:`number`,default:8,min:1},{name:`order`,label:`order`,kind:`select`,default:`GRB`,options:[{value:`GRB`,label:`GRB -- most WS2812 strips (default)`},{value:`RGB`,label:`RGB`},{value:`RGBW`,label:`RGBW -- with a white channel`},{value:`GRBW`,label:`GRBW -- with a white channel`}]},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Ou=`import machine
import neopixel

_pin = properties['pin']
_count = properties['count']
_order = str(properties['order'])
_node_id = properties['nodeId']
_bpp = 4 if _order.endswith('W') else 3

_gpio = runtime.shared('pin', _pin, ('out', 'none'), lambda: machine.Pin(_pin, machine.Pin.OUT))
_neo = neopixel.NeoPixel(_gpio, _count, bpp=_bpp)


def _colour(_c):
    _r = (_c >> 16) & 0xff
    _g = (_c >> 8) & 0xff
    _b = _c & 0xff
    _w = (_c >> 24) & 0xff
    if _order == 'RGB':
        return (_r, _g, _b)
    if _order == 'GRB':
        return (_g, _r, _b)
    if _order == 'RGBW':
        return (_r, _g, _b, _w)
    return (_g, _r, _b, _w)


async def run(msg, properties):
    try:
        _p = msg.get('payload')
        if isinstance(_p, dict):
            _neo[int(_p.get('index', 0))] = _colour(int(_p.get('colour', _p.get('color', 0))))
        elif isinstance(_p, (list, tuple)):
            for _i in range(min(len(_p), _count)):
                _neo[_i] = _colour(int(_p[_i]))
        else:
            _col = _colour(int(_p))
            for _i in range(_count):
                _neo[_i] = _col
        _neo.write()
    except Exception as _e:
        runtime.report_status(_node_id, 'error', str(_e))
`,ku=`_flow_vars`,Au=`${ku} = runtime.shared('flow_vars', 'v1', 'v1', lambda: {})`,ju=`class _Store:
    def __init__(self, d):
        self._d = d
    def get(self, key, default=None):
        return self._d.get(key, default)
    def set(self, key, value):
        self._d[key] = value`;function Mu(e){let t=e.split(`
`),n=null;for(let r of t){if(r.trim()===``)continue;let t=/^[ \t]*/.exec(r)[0];if(n===null)n=t;else{let e=0;for(;e<n.length&&e<t.length&&n[e]===t[e];)e++;n=n.slice(0,e)}if(n===``)return e}return n?t.map(e=>e.startsWith(n)?e.slice(n.length):e.trim()===``?``:e).join(`
`):e}var Nu={type:`thingstudio/function`,kind:`transform`,paletteId:`function`,label:`function`,group:`general`,priority:30,color:`#6e5b2e`,bgcolor:`#3f341f`,icon:`ƒ`,width:100,description:"The body of a MicroPython function: `msg` in, return the message, None, or a list with one entry per output. `context` (this node only) and `flow` (shared flow-wide) hold state between messages; `settings` is saved on the board and survives a reboot.",ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},dynamicOutputs:{property:`outputCount`,min:1,max:10,namePrefix:`out`,rowHeightPx:18},properties:[{name:`code`,label:`code`,kind:`textarea`,rows:10,default:`msg['payload'] = msg['payload']
return msg
`},{name:`outputCount`,label:`outputs`,kind:`number`,default:1,min:1,max:10,help:"Return an array to route to multiple outputs, Node-RED style: e.g. `return [msg, null]` sends to output 1 only. A plain `return msg` still works and always targets output 1."}],codegenTransform(e,t){let n=Mu(String(e.properties.code??``).replace(/\r\n/g,`
`));if(!n.trim())throw new L(`function node's code is empty`);let r=t.uniqueName(`ctx`);return{statements:[{key:`context-store-class`,code:ju},{key:`flow-vars-dict`,code:Au},{key:`flow-context-obj`,code:`_flow_ctx = _Store(${ku})`},{key:r,code:`${r} = _Store({})`}],functionName:t.uniqueName(`function`),functionBody:`context = ${r}\nflow = _flow_ctx\nsettings = runtime.settings\n${n}`}}},Pu={type:`thingstudio/gpio_out`,kind:`sink`,paletteId:`gpio_out`,label:`gpio out`,group:`hardware`,priority:20,color:`#6e3b3b`,bgcolor:`#3f1f1f`,icon:`■`,width:104,description:`Sets a pin high or low from each message.`,ports:{inputs:[{name:`signal`,type:`bool`}]},properties:[{name:`pin`,label:`pin`,kind:`pin`,default:12,pinUse:`output`}]},Fu=`import machine

# The pin is a keyed singleton (hardware-shared.ts), shared with any other node on it.
_pin = runtime.shared('pin', properties['pin'], ('out', 'none'), lambda: machine.Pin(properties['pin'], machine.Pin.OUT))


async def run(msg, properties):
    _pin.value(1 if msg.get('payload') else 0)
`,Iu=`def _ts_wifi(ctx):
    configs = [c for c in ctx['flow']['configs'] if c['type'] == 'thingstudio/config/wifi']
    if not configs:
        return None, 'needs a WiFi network -- set "WiFi" in its properties (every WiFi node in a flow shares one)'
    if len(configs) > 1:
        return None, 'this flow has %d WiFi configs, but a flow can only have one -- pick the network in the WiFi field of any node to keep just that one' % len(configs)
    wifi = (ctx.get('referencedConfigs') or {}).get(configs[0]['id'])
    if wifi is None:
        return None, 'could not resolve the WiFi config -- reopen the flow in the editor'

    security = wifi.get('security')
    if security not in ('open', 'unmanaged'):
        security = 'password'
    ssid = str(wifi.get('ssid') or '').strip()
    password = str(wifi.get('password') or '')
    if security != 'unmanaged' and not ssid:
        return None, 'the WiFi config has no network name (SSID) -- pick a saved WiFi credential, or set security to "unmanaged"'
    if security == 'password' and not password:
        return None, 'WiFi config for ssid "' + ssid + '" has no password but security is "password"'

    mqtt = any(n['type'] in ('thingstudio/mqtt_publish', 'thingstudio/mqtt_subscribe') for n in ctx['flow']['nodes'])
    return {'ssid': ssid, 'password': password, 'security': security, 'deferToMqtt': mqtt}, None
`,Lu=`${Iu}
def _ts_mqtt_broker(ctx, properties, label):
    # One broker per flow (2026-10-29), like WiFi: the flow's one config, whatever the node's own brokerConfigId says.
    configs = [c for c in ctx['flow']['configs'] if c['type'] == 'thingstudio/config/mqtt-broker']
    if not configs:
        return None, label + ' needs an MQTT broker -- set "MQTT Broker" in its properties (every MQTT node in a flow shares one)'
    if len(configs) > 1:
        return None, 'this flow has %d MQTT broker configs, but a flow can only have one -- pick the broker in the MQTT Broker field of any MQTT node to keep just that one' % len(configs)
    cfg = (ctx.get('referencedConfigs') or {}).get(configs[0]['id'])
    if cfg is None:
        return None, 'could not resolve the MQTT broker config -- reopen the flow in the editor'
    broker = str(cfg.get('broker') or '').strip()
    if not broker:
        return None, label + "'s referenced broker config has no \\"broker\\" hostname/IP set"
    try:
        port = int(cfg.get('port') or 1883)
    except (TypeError, ValueError):
        port = 0
    if port < 1 or port > 65535:
        return None, label + "'s referenced broker config has an invalid port -- must be 1-65535"
    return {
        'broker': broker,
        'port': port,
        'username': str(cfg.get('username') or ''),
        'brokerPassword': str(cfg.get('password') or ''),
    }, None

def _ts_mqtt(ctx, properties, label):
    wifi, err = _ts_wifi(ctx)
    if err:
        return None, err
    if wifi['security'] == 'unmanaged':
        return None, label + "'s WiFi config has security \\"unmanaged\\", which is not supported here -- mqtt_as manages its own WiFi connection and needs real credentials to do so"
    broker, err = _ts_mqtt_broker(ctx, properties, label)
    if err:
        return None, err
    settings = dict(wifi)
    settings['wifiPassword'] = settings.pop('password')
    settings.update(broker)
    return settings, None
`,Ru={type:`thingstudio/http_in`,kind:`source`,eventSource:!0,paletteId:`http_in`,label:`http in`,group:`network`,priority:40,color:`#a67c1f`,bgcolor:`#4a3a1f`,icon:`↙`,width:120,description:`Sends a message for each request to this path (exact match). The flow must reach an http response node, or the request times out with a 500.`,ports:{outputs:[{name:`msg`,type:`any`}]},properties:[{name:`port`,label:`port`,kind:`number`,default:8080,min:1,max:65535},{name:`path`,label:`path`,kind:`text`,default:`/`,placeholder:`/status`},{name:`method`,label:`method`,kind:`select`,default:`GET`,options:[{value:`GET`,label:`GET`},{value:`POST`,label:`POST`}]},{name:`responseTimeoutMs`,label:`response timeout (ms)`,kind:`number`,default:1e4,min:1},{name:`wifiConfigId`,label:`WiFi`,kind:`configRef`,configType:`thingstudio/config/wifi`,singleton:!0,default:``,help:`One WiFi network per flow: every WiFi node shares this setting.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},zu=`${Iu}
def _http_route(node):
    props = node.get('properties') or {}
    try:
        port = int(props.get('port'))
    except (TypeError, ValueError):
        return None, 'http_in node %s: port must be a number between 1 and 65535' % node.get('id')
    if port < 1 or port > 65535:
        return None, 'http_in node %s: port must be a number between 1 and 65535' % node.get('id')
    path = str(props.get('path') or '')
    if not path.startswith('/'):
        return None, 'http_in node %s: path "%s" must start with "/"' % (node.get('id'), path)
    method = str(props.get('method') or 'GET').upper()
    if method not in ('GET', 'POST'):
        return None, 'http_in node %s: method "%s" must be "GET" or "POST"' % (node.get('id'), props.get('method'))
    raw_timeout = props.get('responseTimeoutMs')
    if raw_timeout is None:
        raw_timeout = 10000
    try:
        timeout = int(raw_timeout)
    except (TypeError, ValueError):
        timeout = 0
    if timeout <= 0:
        return None, 'http_in node %s: responseTimeoutMs must be a positive number' % node.get('id')
    return {'id': node.get('id'), 'port': port, 'path': path, 'method': method, 'timeoutS': timeout / 1000}, None

def compile(ctx, properties):
    wifi, err = _ts_wifi(ctx)
    if err:
        return {'errors': [err]}

    own, err = _http_route(ctx['node'])
    if err:
        return {'errors': [err]}
    port = own['port']

    siblings = ctx.get('nodesOfType') or [n for n in ctx['flow']['nodes'] if n['type'] == ctx['node']['type']]
    routes = []
    seen = {}
    for sibling in siblings:
        route, err = _http_route(sibling)
        if err:
            return {'errors': [err]}
        if route['port'] != port:
            continue
        key = route['method'] + ' ' + route['path']
        if key in seen:
            return {'errors': ['http_in: nodes %s and %s both claim %s on port %d -- exact (method, path) must be unique per port' % (seen[key], route['id'], key, port)]}
        seen[key] = route['id']
        routes.append(route)
    routes.sort(key=lambda r: r['id'])

    out = dict(wifi)
    out['port'] = port
    out['routes'] = routes
    return {'properties': out}
`,Bu=`import runtime
import ts_wifi
import ts_http_server

ts_wifi.ensure_station(properties['ssid'], properties['password'], properties['security'], properties['deferToMqtt'])

_port = int(properties['port'])
_routes = properties['routes']
_queues = runtime.shared('http_in_queues', _port, 'v1', lambda: {})
_queue = ts_http_server.Queue()
_queues[properties['nodeId']] = _queue
_server = runtime.shared('http_server', _port, 'v1', lambda: ts_http_server.Server(_port, _routes, _queues))


class _In:
    def __init__(self):
        self.msg = None

    async def wait(self):
        await _server.ensure()
        self.msg = await _queue.get()

    def emit(self):
        return self.msg


_in = _In()


async def wait(properties):
    await _in.wait()


async def emit(properties):
    return _in.emit()
`,Vu={type:`thingstudio/http_request`,kind:`transform`,paletteId:`http_request`,label:`http request`,group:`network`,priority:41,color:`#8a6e1f`,bgcolor:`#4a3a1f`,icon:`⇄`,width:130,description:`Makes one HTTP request per message and sends the response on. http:// only, not https://.`,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},properties:[{name:`url`,label:`url`,kind:`text`,default:``,placeholder:`http://host:port/path`},{name:`method`,label:`method`,kind:`select`,default:`GET`,options:[{value:`GET`,label:`GET`},{value:`POST`,label:`POST`}]},{name:`timeoutMs`,label:`timeout (ms)`,kind:`number`,default:5e3,min:1},{name:`wifiConfigId`,label:`WiFi`,kind:`configRef`,configType:`thingstudio/config/wifi`,singleton:!0,default:``,help:`One WiFi network per flow: every WiFi node shares this setting.`}]},Hu=`${Iu}
import re

def compile(ctx, properties):
    url = str(properties.get('url') or '')
    match = re.match(r'^http://([^/:]+)(?::([0-9]+))?(/.*)?$', url)
    if not match:
        return {'errors': ['http_request url "' + url + '" must be a plain http://host[:port][/path] URL -- https/TLS is not supported in v1']}
    host = match.group(1)
    port = int(match.group(2)) if match.group(2) else 80
    path = match.group(3) if match.group(3) else '/'

    method = str(properties.get('method', 'GET')).upper()
    if method not in ('GET', 'POST'):
        return {'errors': ['http_request method "' + str(properties.get('method')) + '" must be "GET" or "POST" -- v1 supports no other methods']}
    try:
        timeout = int(properties.get('timeoutMs', 5000))
    except (TypeError, ValueError):
        return {'errors': ['http_request timeoutMs must be a positive number']}
    if timeout <= 0:
        return {'errors': ['http_request timeoutMs must be a positive number']}

    wifi, err = _ts_wifi(ctx)
    if err:
        return {'errors': [err]}
    wifi['host'] = host
    wifi['port'] = port
    wifi['path'] = path
    wifi['method'] = method
    wifi['timeoutS'] = timeout / 1000
    return {'properties': wifi}
`,Uu=`import ts_wifi

ts_wifi.ensure_station(properties['ssid'], properties['password'], properties['security'], properties['deferToMqtt'])

_host = properties['host']
_port = int(properties['port'])
_path = properties['path']
_method = properties['method']
_timeout = float(properties['timeoutS'])


async def run(msg, properties):
    try:
        _reader, _writer = await asyncio.wait_for(asyncio.open_connection(_host, _port), _timeout)
    except OSError as _e:
        raise OSError("http_request to %s:%s: connect failed: %r" % (_host, _port, _e))
    try:
        _payload = msg.get('payload')
        if _method == 'POST':
            if isinstance(_payload, (bytes, bytearray)):
                _body = bytes(_payload)
            elif isinstance(_payload, str):
                _body = _payload.encode()
            else:
                _body = str(_payload).encode()
        else:
            _body = b''
        _req = (_method + ' ' + _path + ' HTTP/1.1\\r\\nHost: ' + _host + '\\r\\nConnection: close\\r\\nContent-Length: ' + str(len(_body)) + '\\r\\n\\r\\n').encode()
        _writer.write(_req)
        if _body:
            _writer.write(_body)
        await asyncio.wait_for(_writer.drain(), _timeout)
        _status_line = await asyncio.wait_for(_reader.readline(), _timeout)
        _status_parts = _status_line.split(b' ')
        _status = int(_status_parts[1]) if len(_status_parts) > 1 else 0
        _content_length = None
        while True:
            _hline = await asyncio.wait_for(_reader.readline(), _timeout)
            if _hline in (b'\\r\\n', b'\\n', b''):
                break
            if _hline.lower().startswith(b'content-length:'):
                _content_length = int(_hline.split(b':', 1)[1].strip())
        if _content_length is not None:
            _resp_body = await asyncio.wait_for(_reader.readexactly(_content_length), _timeout)
        else:
            _resp_body = b''
            while True:
                _chunk = await asyncio.wait_for(_reader.read(512), _timeout)
                if not _chunk:
                    break
                _resp_body += _chunk
        msg['payload'] = _resp_body.decode()
        msg['status'] = _status
    except OSError as _e:
        raise OSError("http_request to %s:%s: request failed: %r" % (_host, _port, _e))
    finally:
        _writer.close()
    return msg
`,Wu={type:`thingstudio/http_response`,kind:`sink`,paletteId:`http_response`,label:`http response`,group:`network`,priority:42,color:`#6e5216`,bgcolor:`#3a2c14`,icon:`↗`,width:130,description:`Replies to a request that came from an http in node: msg.payload is the body, msg.statusCode the status (200 if unset).`,ports:{inputs:[{name:`msg`,type:`any`}]}},Gu=`async def run(msg, properties):
    _conn = msg.get('_http_conn')
    if _conn is None:
        raise RuntimeError("http_response: msg did not come from an http_in node (no request to respond to)")
    _payload = msg.get('payload')
    if isinstance(_payload, (bytes, bytearray)):
        _body = bytes(_payload)
    elif isinstance(_payload, str):
        _body = _payload.encode()
    elif _payload is None:
        _body = b''
    else:
        _body = str(_payload).encode()
    _conn['status'] = int(msg.get('statusCode', 200))
    _conn['body'] = _body
    _conn['done'].set()
`,Ku={property:`payloadType`,map:{bool:`bool`,number:`number`,string:`string`},default:`bool`},qu={property:`payloadType`,map:{bool:`bool`,number:`number`,string:`string`,reason:`string`},default:`bool`},Ju={type:`thingstudio/inject`,kind:`source`,eventSource:!0,paletteId:`inject`,label:`inject`,group:`general`,priority:10,color:`#2e5c2e`,bgcolor:`#1f3f1f`,icon:`▶`,width:96,description:`Sends one message with a fixed payload when you click its ▶ on the canvas while connected to a board.`,ports:{outputs:[{name:`msg`,type:Ku}]},properties:[{name:`payloadType`,label:`payload type`,kind:`select`,default:`bool`,options:[{value:`bool`,label:`bool`},{value:`number`,label:`number`},{value:`string`,label:`string`}],retype:!0},{name:`payloadValue`,label:`value`,kind:`text`,default:`true`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Yu=`from threadsafe_event import ThreadSafeEvent
import runtime

_evt = ThreadSafeEvent()
runtime.register_trigger(properties['nodeId'], _evt)
_payload_type = properties['payloadType']
_raw_value = properties['payloadValue']


async def wait(properties):
    await _evt.wait()
    _evt.clear()


async def emit(properties):
    if _payload_type == 'bool':
        _payload = _raw_value == 'true'
    elif _payload_type == 'number':
        try:
            _number = float(_raw_value if _raw_value not in (None, '') else 0)
        except (TypeError, ValueError):
            raise ValueError("inject value %r is not a valid number" % (_raw_value,))
        _payload = int(_number) if _number == int(_number) else _number
    else:
        _payload = str(_raw_value if _raw_value is not None else '')
    return {'payload': _payload, 'topic': ''}
`,Xu={type:`thingstudio/interrupt`,kind:`source`,eventSource:!0,paletteId:`interrupt`,label:`interrupt`,group:`hardware`,priority:10,color:`#8a5a1f`,bgcolor:`#3f2e14`,icon:`⚡`,width:104,description:`Sends a message the moment a pin changes state. Needs an external pull resistor. For a button or switch, use ebutton or eswitch, which debounce it.`,ports:{outputs:[{name:`msg`,type:`bool`}]},resources:[{kind:`pin`,property:`pin`,direction:`input`,claim:{resource:`{pin} interrupt`,use:`{edge} edge`}}],properties:[{name:`pin`,label:`pin`,kind:`pin`,default:4},{name:`edge`,label:`edge`,kind:`select`,default:`rising`,options:[{value:`rising`,label:`rising`},{value:`falling`,label:`falling`},{value:`both`,label:`both`}]}]},Zu=`import machine
from threadsafe_event import ThreadSafeEvent

_pin_num = properties['pin']
_edge = str(properties['edge'])

_pin = runtime.shared('pin', _pin_num, ('in', 'none'), lambda: machine.Pin(_pin_num, machine.Pin.IN))
_evt = ThreadSafeEvent()


def _handler(pin):
    _evt.set()


if _edge == 'rising':
    _trigger = machine.Pin.IRQ_RISING
elif _edge == 'falling':
    _trigger = machine.Pin.IRQ_FALLING
else:
    _trigger = machine.Pin.IRQ_RISING | machine.Pin.IRQ_FALLING
_pin.irq(trigger=_trigger, handler=_handler)


async def wait(properties):
    await _evt.wait()
    _evt.clear()


async def emit(properties):
    return {'payload': bool(_pin.value()), 'topic': ''}
`,Qu={type:`thingstudio/mqtt_publish`,kind:`sink`,paletteId:`mqtt_publish`,label:`mqtt publish`,group:`network`,priority:31,color:`#8a3b6e`,bgcolor:`#4a1f3a`,icon:`⇧`,width:128,description:`Publishes msg.payload to an MQTT topic on the chosen broker.`,ports:{inputs:[{name:`msg`,type:`any`}]},properties:[{name:`topic`,label:`topic`,kind:`text`,default:``},{name:`retain`,label:`retain`,kind:`boolean`,default:!1},{name:`qos`,label:`qos`,kind:`select`,default:0,options:[{value:0,label:`0`},{value:1,label:`1`}]},{name:`brokerConfigId`,label:`MQTT Broker`,kind:`configRef`,configType:`thingstudio/config/mqtt-broker`,singleton:!0,default:``,help:`One MQTT broker per flow: every MQTT node shares this setting.`},{name:`wifiConfigId`,label:`WiFi`,kind:`configRef`,configType:`thingstudio/config/wifi`,singleton:!0,default:``,help:`One WiFi network per flow: every WiFi node shares this setting. With MQTT nodes in the flow, MQTT manages the connection, so "unmanaged" isn't accepted.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},$u=`${Lu}
def compile(ctx, properties):
    settings, err = _ts_mqtt(ctx, properties, 'mqtt_publish')
    if err:
        return {'errors': [err]}

    topic = str(properties.get('topic') or '').strip()
    if not topic:
        return {'errors': ['mqtt_publish requires a non-empty "topic"']}
    try:
        qos = int(properties.get('qos', 0))
    except (TypeError, ValueError):
        qos = -1
    if qos not in (0, 1):
        return {'errors': ['mqtt_publish qos "' + str(properties.get('qos')) + '" must be 0 or 1 -- qos 2 is not supported (mqtt_as limitation)']}

    settings['topic'] = topic
    settings['qos'] = qos
    settings['retain'] = bool(properties.get('retain', False))
    return {'properties': settings}
`,ed=`import ts_wifi
import ts_mqtt

ts_wifi.ensure_station(properties['ssid'], properties['wifiPassword'], properties['security'], properties['deferToMqtt'])

_broker = ts_mqtt.ensure_client(
    properties['broker'], properties['port'], properties['ssid'], properties['wifiPassword'],
    properties['security'], properties['username'], properties['brokerPassword'])
_topic = properties['topic']
_retain = bool(properties['retain'])
_qos = int(properties['qos'])
_node_id = properties['nodeId']


async def run(msg, properties):
    _payload = msg.get('payload')
    if isinstance(_payload, (bytes, bytearray)):
        _body = bytes(_payload)
    elif isinstance(_payload, str):
        _body = _payload.encode()
    else:
        _body = str(_payload).encode()
    await _broker.publish(_node_id, _topic, _body, _retain, _qos)
`,td={type:`thingstudio/mqtt_subscribe`,kind:`sink`,eventSource:!0,paletteId:`mqtt_subscribe`,label:`mqtt subscribe`,group:`network`,priority:30,color:`#6e3b8a`,bgcolor:`#3a1f4a`,icon:`⇩`,width:132,description:`Subscribes to an MQTT topic and sends on everything the broker delivers for it. msg.payload is the content decoded as UTF-8 text, msg.topic the topic it arrived on, and msg.retained whether the broker held it as a retained message.`,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},properties:[{name:`topic`,label:`topic`,kind:`text`,default:``},{name:`qos`,label:`qos`,kind:`select`,default:0,options:[{value:0,label:`0`},{value:1,label:`1`}]},{name:`dynamic`,label:`dynamic subscription`,kind:`boolean`,default:!1,help:`Lets an input message change the subscription while the flow runs: msg.action is subscribe or unsubscribe, msg.topic the topic.`},{name:`brokerConfigId`,label:`MQTT Broker`,kind:`configRef`,configType:`thingstudio/config/mqtt-broker`,singleton:!0,default:``,help:`One MQTT broker per flow: every MQTT node shares this setting.`},{name:`wifiConfigId`,label:`WiFi`,kind:`configRef`,configType:`thingstudio/config/wifi`,singleton:!0,default:``,help:`One WiFi network per flow: every WiFi node shares this setting. With MQTT nodes in the flow, MQTT manages the connection, so "unmanaged" isn't accepted.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},nd=`${Lu}
def compile(ctx, properties):
    settings, err = _ts_mqtt(ctx, properties, 'mqtt_subscribe')
    if err:
        return {'errors': [err]}

    topic = str(properties.get('topic') or '').strip()
    if not topic:
        return {'errors': ['mqtt_subscribe requires a non-empty "topic"']}
    try:
        qos = int(properties.get('qos', 0))
    except (TypeError, ValueError):
        qos = -1
    if qos not in (0, 1):
        return {'errors': ['mqtt_subscribe qos "' + str(properties.get('qos')) + '" must be 0 or 1 -- qos 2 is not supported (mqtt_as limitation)']}

    settings['topic'] = topic
    settings['qos'] = qos
    return {'properties': settings}
`,rd=`import ts_wifi
import ts_mqtt

ts_wifi.ensure_station(properties['ssid'], properties['wifiPassword'], properties['security'], properties['deferToMqtt'])

_broker = ts_mqtt.ensure_client(
    properties['broker'], properties['port'], properties['ssid'], properties['wifiPassword'],
    properties['security'], properties['username'], properties['brokerPassword'])
_topic = properties['topic']
_qos = int(properties['qos'])
_node_id = properties['nodeId']
_dynamic = bool(properties['dynamic'])


class _Sub:
    def __init__(self):
        self.ready = False
        self.last = None

    async def wait(self):
        if not self.ready:
            await _broker.ensure_connected(_node_id)
            await _broker.subscribe(_node_id, _topic, _qos)
            self.ready = True
        self.last = await _broker.wait_message(_node_id)

    def emit(self):
        _topic_in, _payload, _retained = self.last
        return {
            'payload': _payload.decode() if isinstance(_payload, (bytes, bytearray)) else _payload,
            'topic': _topic_in.decode() if isinstance(_topic_in, (bytes, bytearray)) else _topic_in,
            'retained': bool(_retained),
        }


_sub = _Sub()


async def run(msg, properties):
    if not _dynamic:
        raise OSError("mqtt_subscribe: dynamic subscription is off -- turn it on to use this node's input")
    action = msg.get('action')
    topic = msg.get('topic')
    if topic is None or topic == '':
        raise OSError("mqtt_subscribe: an action message needs a topic")
    topics = topic if isinstance(topic, (list, tuple)) else [topic]
    parsed = []
    for entry in topics:
        if isinstance(entry, dict):
            name = entry.get('topic')
            try:
                entry_qos = int(entry.get('qos', _qos))
            except (TypeError, ValueError):
                entry_qos = -1
            if entry_qos not in (0, 1):
                raise OSError("mqtt_subscribe: topic %r has qos %r -- use 0 or 1" % (name, entry.get('qos')))
        else:
            name = entry
            entry_qos = _qos
        if name is None or name == '':
            raise OSError("mqtt_subscribe: an action message needs a topic")
        parsed.append((str(name), entry_qos))
    await _broker.ensure_connected(_node_id)
    if action == 'subscribe':
        for name, entry_qos in parsed:
            await _broker.subscribe(_node_id, name, entry_qos)
    elif action == 'unsubscribe':
        for name, _entry_qos in parsed:
            await _broker.unsubscribe(_node_id, name)
    else:
        raise OSError("mqtt_subscribe: unknown action %r -- use subscribe or unsubscribe" % (action,))


async def wait(properties):
    await _sub.wait()


async def emit(properties):
    msg = _sub.emit()
    # The old built-in's repeatMs. A burst of queued messages would otherwise run back to back with no yield,
    # the non-yielding-event-loop hazard the source model guards against.
    await asyncio.sleep_ms(10)
    return msg
`,id={type:`thingstudio/pwm_out`,kind:`sink`,paletteId:`pwm_out`,label:`pwm out`,group:`hardware`,priority:30,color:`#1f5c8a`,bgcolor:`#12334a`,icon:`∿`,width:104,description:`Drives a PWM signal on a pin, for dimming an LED or setting a motor's speed.`,ports:{inputs:[{name:`duty`,type:`number`}]},resources:[{kind:`pin`,property:`pin`,direction:`output`,use:`PWM at {freq} Hz`}],properties:[{name:`pin`,label:`pin`,kind:`pin`,default:12},{name:`freq`,label:`frequency (Hz)`,kind:`number`,default:1e3,min:1}]},ad=`import machine

_pin = properties['pin']
_freq = properties['freq']

_pwm = runtime.shared('pwm', _pin, (_freq,),
                      lambda: machine.PWM(machine.Pin(_pin, machine.Pin.OUT), freq=_freq))


async def run(msg, properties):
    _pwm.duty_u16(int(max(0.0, min(1.0, msg.get('payload', 0))) * 65535))
`,od={type:`thingstudio/startup`,kind:`source`,runOnce:!0,paletteId:`startup`,label:`startup`,group:`general`,priority:11,color:`#5c5c2e`,bgcolor:`#3a3a1f`,icon:`⏻`,width:104,description:`Sends one message when the flow starts: after Deploy, and each time the board restarts, even with the editor closed. Use it for setup, such as putting an output in a known state. msg.reason says why the flow started: deploy, power on, the reset button, a software reboot, a watchdog reset or waking from deep sleep.`,ports:{outputs:[{name:`msg`,type:qu}]},properties:[{name:`payloadType`,label:`payload type`,kind:`select`,default:`bool`,options:[{value:`bool`,label:`bool`},{value:`number`,label:`number`},{value:`string`,label:`string`},{value:`reason`,label:`start reason`}],retype:!0},{name:`payloadValue`,label:`value`,kind:`text`,default:`true`,visibleWhen:{field:`payloadType`,notEquals:`reason`}}]},sd=`import runtime

_REASON = getattr(runtime, 'start_reason', 'unknown')
_payload_type = properties['payloadType']
_raw_value = properties['payloadValue']


async def emit(properties):
    if _payload_type == 'reason':
        _payload = _REASON
    elif _payload_type == 'bool':
        _payload = _raw_value == 'true'
    elif _payload_type == 'number':
        try:
            _number = float(_raw_value if _raw_value not in (None, '') else 0)
        except (TypeError, ValueError):
            raise ValueError("startup value %r is not a valid number" % (_raw_value,))
        _payload = int(_number) if _number == int(_number) else _number
    else:
        _payload = str(_raw_value if _raw_value is not None else '')
    return {'payload': _payload, 'topic': '', 'reason': _REASON}
`,cd={type:`thingstudio/timer`,kind:`source`,paletteId:`timer`,label:`timer`,group:`general`,priority:20,color:`#5b3b6e`,bgcolor:`#331f3f`,icon:`◷`,width:84,description:`Sends an increasing count at a fixed interval.`,ports:{outputs:[{name:`msg`,type:`int`}]},properties:[{name:`intervalMs`,label:`interval (ms)`,kind:`number`,default:1e3,min:1}]},ld=`_count = 0


async def emit(properties):
    nonlocal _count
    _count += 1
    return {'payload': _count, 'topic': ''}
`,ud={type:`thingstudio/udp_receive`,kind:`source`,paletteId:`udp_receive`,label:`udp receive`,group:`network`,priority:20,color:`#3b8a6e`,bgcolor:`#1f4a3a`,icon:`↓`,width:110,description:`Listens on a UDP port and sends one message per datagram received.`,ports:{outputs:[{name:`msg`,type:`bytes`}]},properties:[{name:`port`,label:`port`,kind:`number`,default:9998,min:1,max:65535},{name:`pollMs`,label:`poll interval (ms)`,kind:`number`,default:20,min:1},{name:`wifiConfigId`,label:`WiFi`,kind:`configRef`,configType:`thingstudio/config/wifi`,singleton:!0,default:``,help:`One WiFi network per flow: every WiFi node shares this setting.`}]},dd=`${Iu}
def compile(ctx, properties):
    try:
        port = int(properties.get('port'))
    except (TypeError, ValueError):
        return {'errors': ['udp_receive port must be a valid port number (1-65535)']}
    if port <= 0 or port > 65535:
        return {'errors': ['udp_receive port must be a valid port number (1-65535)']}
    try:
        poll = int(properties.get('pollMs', 20))
    except (TypeError, ValueError):
        return {'errors': ['udp_receive pollMs must be a positive number']}
    if poll <= 0:
        return {'errors': ['udp_receive pollMs must be a positive number']}

    wifi, err = _ts_wifi(ctx)
    if err:
        return {'errors': [err]}
    # The loop yield is the fixed mandatory 10 ms; pollMs is the EAGAIN retry inside emit().
    wifi['intervalMs'] = 10
    return {'properties': wifi}
`,fd=`import socket
import errno
import ts_wifi

_port = int(properties['port'])
_poll = int(properties.get('pollMs', 20))


def _make_sock():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setblocking(False)
    s.bind(('0.0.0.0', _port))
    return s


_sock = runtime.shared('udp_receive_sock', _port, ('udp', _port), _make_sock)
runtime.register_cleanup('udp-receive-%d' % _port, lambda: _sock.close())

ts_wifi.ensure_station(properties['ssid'], properties['password'], properties['security'], properties['deferToMqtt'])


async def emit(properties):
    while True:
        try:
            _data, _addr = _sock.recvfrom(1472)
            break
        except OSError as _e:
            if _e.errno != errno.EAGAIN:
                raise OSError("udp_receive on port %d failed: %r" % (_port, _e))
            await asyncio.sleep_ms(_poll)
    return {'payload': _data, 'topic': '', 'host': _addr[0], 'port': _addr[1]}
`,pd={type:`thingstudio/udp_send`,kind:`sink`,paletteId:`udp_send`,label:`udp send`,group:`network`,priority:21,color:`#3b5c8a`,bgcolor:`#1f2e4a`,icon:`↑`,width:110,description:`Sends msg.payload as a UDP datagram to a fixed host and port.`,ports:{inputs:[{name:`msg`,type:`any`}]},properties:[{name:`host`,label:`host`,kind:`text`,default:``},{name:`port`,label:`port`,kind:`number`,default:9999,min:1,max:65535},{name:`timeoutMs`,label:`timeout (ms)`,kind:`number`,default:2e3,min:1},{name:`wifiConfigId`,label:`WiFi`,kind:`configRef`,configType:`thingstudio/config/wifi`,singleton:!0,default:``,help:`One WiFi network per flow: every WiFi node shares this setting.`}]},md=`${Iu}
def compile(ctx, properties):
    host = str(properties.get('host') or '').strip()
    if not host:
        return {'errors': ['udp_send requires a non-empty "host"']}
    try:
        port = int(properties.get('port'))
    except (TypeError, ValueError):
        return {'errors': ['udp_send port must be a valid port number (1-65535)']}
    if port <= 0 or port > 65535:
        return {'errors': ['udp_send port must be a valid port number (1-65535)']}
    try:
        timeout = int(properties.get('timeoutMs', 2000))
    except (TypeError, ValueError):
        return {'errors': ['udp_send timeoutMs must be a positive number']}
    if timeout <= 0:
        return {'errors': ['udp_send timeoutMs must be a positive number']}

    wifi, err = _ts_wifi(ctx)
    if err:
        return {'errors': [err]}
    return {'properties': wifi}
`,hd=`import socket
import errno
import ts_wifi


def _make_sock():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setblocking(False)
    return s


_sock = runtime.shared('udp_send_sock', 'udp_send', (), _make_sock)
runtime.register_cleanup('udp-send-sock', lambda: _sock.close())

ts_wifi.ensure_station(properties['ssid'], properties['password'], properties['security'], properties['deferToMqtt'])

_host = str(properties['host']).strip()
_port = int(properties['port'])
_timeout = int(properties.get('timeoutMs', 2000)) / 1000
_SEND_RETRY_MS = 10


async def run(msg, properties):
    _payload = msg.get('payload')
    if isinstance(_payload, (bytes, bytearray)):
        _body = bytes(_payload)
    elif isinstance(_payload, str):
        _body = _payload.encode()
    else:
        _body = str(_payload).encode()

    try:
        _target = socket.getaddrinfo(_host, _port)[0][-1]
    except OSError as _e:
        raise OSError("udp_send: could not resolve %s:%s: %r" % (_host, _port, _e))

    async def _send():
        while True:
            try:
                _sock.sendto(_body, _target)
                return
            except OSError as _e:
                if _e.errno != errno.EAGAIN:
                    raise OSError("udp_send to %s:%s failed: %r" % (_host, _port, _e))
                await asyncio.sleep_ms(_SEND_RETRY_MS)

    await asyncio.wait_for(_send(), _timeout)
`,gd={type:`thingstudio/ntp`,kind:`sink`,eventSource:!0,paletteId:`ntp`,label:`ntp`,group:`network`,priority:15,color:`#1f5c6e`,bgcolor:`#12343f`,icon:`◷`,width:84,description:`Sets the board's clock from the internet and sends the time. Sends once after each sync, and again for each message that arrives. For a clock that ticks, wire a timer in: every second if the format shows seconds, otherwise every few seconds. Nothing is sent before the first sync.`,allowUnwired:!0,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},properties:[{name:`server`,label:`NTP server`,kind:`text`,default:`pool.ntp.org`},{name:`utcOffset`,label:`UTC offset (hours)`,kind:`number`,default:0,min:-12,max:14,step:.5,help:`Your standard time, e.g. 1 for central Europe. Daylight saving adds the summer hour.`},{name:`dst`,label:`daylight saving`,kind:`select`,default:`eu`,options:[{value:`eu`,label:`UK / EU: automatic`},{value:`none`,label:`none`}]},{name:`format`,label:`format`,kind:`select`,default:`time`,options:[{value:`time`,label:`time (14:05)`},{value:`time_seconds`,label:`time with seconds (14:05:09)`},{value:`time_12h`,label:`12-hour time (2:05 pm)`},{value:`date`,label:`date (Wed 14 Oct)`},{value:`date_iso`,label:`ISO date (2026-10-14)`},{value:`iso`,label:`ISO date and time`},{value:`unix`,label:`Unix time (seconds)`}],help:`What goes in msg.payload. Every message also carries each format as a field of the same name.`},{name:`wifiConfigId`,label:`WiFi`,kind:`configRef`,configType:`thingstudio/config/wifi`,singleton:!0,default:``,help:`One WiFi network per flow: every WiFi node shares this setting.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},_d=`${Iu}
import re

def compile(ctx, properties):
    server = str(properties.get('server') or '').strip() or 'pool.ntp.org'
    if not re.match(r'^[A-Za-z0-9.-]+$', server):
        return {'errors': ['ntp server "' + server + '" must be a host name such as pool.ntp.org']}
    try:
        offset = float(properties.get('utcOffset', 0) or 0)
    except (TypeError, ValueError):
        return {'errors': ['ntp UTC offset must be a number']}
    if offset < -12 or offset > 14:
        return {'errors': ['ntp UTC offset must be hours from -12 to 14']}
    dst = str(properties.get('dst') or 'eu')
    if dst not in ('eu', 'none'):
        return {'errors': ['ntp daylight saving must be eu or none']}
    fmt = str(properties.get('format') or 'time')
    if fmt not in ('unix', 'time', 'time_seconds', 'time_12h', 'date', 'date_iso', 'iso'):
        return {'errors': ['ntp format "' + fmt + '" is not recognised']}

    wifi, err = _ts_wifi(ctx)
    if err:
        return {'errors': [err]}
    wifi['server'] = server
    wifi['offsetSeconds'] = int(round(offset * 3600))
    wifi['dstIsEu'] = dst == 'eu'
    wifi['format'] = fmt
    warnings = []
    if not ctx['node'].get('wired', {}).get('outputs', [True])[0]:
        warnings.append('sends the time nowhere: wire its output to something')
    return {'properties': wifi, 'warnings': warnings}
`,vd=`import time
import network
import ts_wifi

try:
    import ntptime
except ImportError:
    ntptime = None

_NTP_DAYS = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
_NTP_MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
# Seconds to add to time.time() for Unix time: 0 where the board's epoch is 1970, 946684800 where it is 2000.
_NTP_UNIX = 946684800 - time.mktime((2000, 1, 1, 0, 0, 0, 0, 0, 0))

def _ntp_last_sunday(y, m):
    wd = time.localtime(time.mktime((y, m, 31, 1, 0, 0, 0, 0, 0)))[6]
    return 31 - (wd + 1) % 7

def _ntp_eu_dst(utc):
    y = time.localtime(utc)[0]
    start = time.mktime((y, 3, _ntp_last_sunday(y, 3), 1, 0, 0, 0, 0, 0))
    end = time.mktime((y, 10, _ntp_last_sunday(y, 10), 1, 0, 0, 0, 0, 0))
    return start <= utc < end

class _Ntp:
    def __init__(self, nid, host, offset, dst):
        self.nid = nid
        self.host = host
        self.offset = offset
        self.dst = dst
        self.synced = False
        self.failing = False
        self.due = None
        self.shown = None
        self.evt = None

    def _status(self, state, text):
        if self.shown != (state, text):
            self.shown = (state, text)
            runtime.report_status(self.nid, state, text)

    def poke(self):
        if self.evt is None:
            self.evt = asyncio.Event()
        self.evt.set()

    def _sync(self):
        now = time.ticks_ms()
        if not network.WLAN(network.STA_IF).isconnected():
            self.due = time.ticks_add(now, 2000)
            if not self.synced:
                self._status('connecting', 'waiting for WiFi')
            return False
        try:
            if ntptime is None:
                raise OSError("this firmware has no ntptime module")
            ntptime.host = self.host
            ntptime.settime()
        except Exception as e:
            self.due = time.ticks_add(now, 30000)
            if not self.failing:
                self.failing = True
                runtime._report_error(self.nid, OSError("NTP from %s failed: %r" % (self.host, e)))
            self._status('error', "NTP from %s failed" % self.host)
            return False
        self.synced = True
        self.failing = False
        self.due = time.ticks_add(now, 3600000)
        self._status('connected', 'synced')
        return True

    async def wait(self):
        if self.evt is None:
            self.evt = asyncio.Event()
        while True:
            left = 0 if self.due is None else time.ticks_diff(self.due, time.ticks_ms())
            if left <= 0:
                if self._sync():
                    return
                continue
            try:
                await asyncio.wait_for(self.evt.wait(), left / 1000)
            except asyncio.TimeoutError:
                continue
            self.evt.clear()
            if self.synced:
                return

    def msg(self, fmt):
        t = int(time.time())
        loc = t + self.offset + (3600 if self.dst and _ntp_eu_dst(t) else 0)
        lt = time.localtime(loc)
        o = loc - t
        hm = "%02d:%02d" % (lt[3], lt[4])
        m = {
            'unix': t + _NTP_UNIX,
            'time': hm,
            'time_seconds': hm + ":%02d" % lt[5],
            'time_12h': "%d:%02d %s" % (lt[3] % 12 or 12, lt[4], "am" if lt[3] < 12 else "pm"),
            'date': "%s %d %s" % (_NTP_DAYS[lt[6]], lt[2], _NTP_MONTHS[lt[1] - 1]),
            'date_iso': "%04d-%02d-%02d" % (lt[0], lt[1], lt[2]),
            'iso': "%04d-%02d-%02dT%02d:%02d:%02d%s%02d:%02d" % (
                lt[0], lt[1], lt[2], lt[3], lt[4], lt[5], "-" if o < 0 else "+", abs(o) // 3600, abs(o) % 3600 // 60),
        }
        m['payload'] = m[fmt]
        m['topic'] = ''
        return m


_N = _Ntp(properties['nodeId'], properties['server'], properties['offsetSeconds'], properties['dstIsEu'])

ts_wifi.ensure_station(properties['ssid'], properties['password'], properties['security'], properties['deferToMqtt'])


async def run(msg, properties):
    _N.poke()


async def wait(properties):
    await _N.wait()


async def emit(properties):
    return _N.msg(properties['format'])
`,yd={type:`thingstudio/wifi_gate`,kind:`transform`,paletteId:`wifi_gate`,label:`wifi gate`,group:`network`,priority:11,color:`#1f8a5a`,bgcolor:`#123f2a`,icon:`⊘`,width:110,description:`Passes a message on unchanged if WiFi is connected when it arrives, and drops it if not.`,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},properties:[{name:`wifiConfigId`,label:`WiFi`,kind:`configRef`,configType:`thingstudio/config/wifi`,singleton:!0,default:``,help:`One WiFi network per flow: every WiFi node shares this setting.`}]},bd=`${Iu}
def compile(ctx, properties):
    wifi, err = _ts_wifi(ctx)
    if err:
        return {'errors': [err]}
    return {'properties': wifi}
`,xd=`import ts_wifi

_sta = ts_wifi.ensure_station(properties['ssid'], properties['password'], properties['security'], properties['deferToMqtt'])


async def run(msg, properties):
    return msg if _sta.isconnected() else None
`,Sd={type:`thingstudio/wifi_status`,kind:`source`,paletteId:`wifi_status`,label:`wifi status`,group:`network`,priority:10,color:`#1f6e6e`,bgcolor:`#123f3f`,icon:`◉`,width:120,description:`Reports the board's WiFi connection state. With no other WiFi node in the flow, it also brings the connection up.`,ports:{outputs:[{name:`msg`,type:`bool`}]},properties:[{name:`pollMs`,label:`poll interval (ms)`,kind:`number`,default:5e3,min:1},{name:`wifiConfigId`,label:`WiFi`,kind:`configRef`,configType:`thingstudio/config/wifi`,singleton:!0,default:``,help:`One WiFi network per flow: every WiFi node shares this setting. Pick "unmanaged" if the board joins WiFi some other way (e.g. its setup AP).`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Cd=`${Iu}
def compile(ctx, properties):
    wifi, err = _ts_wifi(ctx)
    if err:
        return {'errors': [err]}

    poll = properties.get('pollMs', 5000)
    try:
        poll = int(poll)
    except (TypeError, ValueError):
        return {'errors': ['pollMs must be a positive number']}
    if poll <= 0:
        return {'errors': ['pollMs must be a positive number']}

    wifi['intervalMs'] = poll
    return {'properties': wifi}
`,wd=`import ts_wifi

_node_id = properties['nodeId']

# Shared, idempotent bring-up: the same call the built-in network nodes emit, so wifi_status plus mqtt_as (or
# any other WiFi node) bring the station interface up exactly once.
_sta = ts_wifi.ensure_station(properties['ssid'], properties['password'], properties['security'], properties['deferToMqtt'])

_last = None


async def emit(properties):
    nonlocal _last
    connected = bool(_sta.isconnected())
    if connected:
        ifcfg = _sta.ifconfig()
        ip = ifcfg[0]
        subnet = ifcfg[1]
        gateway = ifcfg[2]
        dns = ifcfg[3]
        try:
            rssi = _sta.status('rssi')
        except (OSError, AttributeError):
            rssi = None
    else:
        ip = ''
        subnet = ''
        gateway = ''
        dns = ''
        rssi = None

    state = (connected, ip, subnet, gateway, dns)
    if state == _last:
        return None
    _last = state
    runtime.report_status(_node_id, 'connected' if connected else 'disconnected', ip if connected else None)
    return {'payload': connected, 'topic': '', 'ip': ip, 'subnet': subnet, 'gateway': gateway, 'dns': dns, 'rssi': rssi}
`,Td={type:`thingstudio/ble_scan`,kind:`source`,eventSource:!0,paletteId:`ble_scan`,label:`ble scan`,group:`network`,priority:60,color:`#2f5fa8`,bgcolor:`#1a3560`,icon:`ᛒ`,width:96,description:`Listens for Bluetooth LE advertisements and sends one message per advertisement that passes the filters. msg.payload is the advertising data (bytes); msg.addr, msg.rssi, msg.name, msg.mfrId, msg.mfr, msg.svcData and msg.services say who sent it and what it holds.`,requires:{capabilities:[`ble`]},ports:{outputs:[{name:`msg`,type:`bytes`}]},properties:[{name:`namePrefix`,label:`name starts with`,kind:`text`,default:``,help:`Only devices whose name starts with this. Many devices send their name only to an active scan.`},{name:`addr`,label:`address`,kind:`text`,default:``,placeholder:`aa:bb:cc:dd:ee:ff`,help:`Only this device.`},{name:`mfrId`,label:`manufacturer id`,kind:`text`,default:``,placeholder:`0x0499`,help:`Only advertisements with this manufacturer id: hex with 0x, or decimal.`},{name:`serviceUuid`,label:`service UUID`,kind:`text`,default:``,placeholder:`fcd2`,help:`Only advertisements that list this service or carry data for it (fcd2 is BTHome).`},{name:`active`,label:`active scan`,kind:`boolean`,default:!1,help:`Also ask each device for its scan response, which usually holds its name.`},{name:`repeatMs`,label:`repeat window (ms)`,kind:`number`,default:1e3,min:0,help:`Drops an advertisement identical to the last one from the same device within this time. 0 sends every one.`},{name:`scanIntervalMs`,label:`scan interval (ms)`,kind:`number`,default:320,min:2.5,max:10240,step:.625,help:`How often the radio starts listening. Every ble scan node in a flow shares one scan.`},{name:`scanWindowMs`,label:`scan window (ms)`,kind:`number`,default:30,min:2.5,max:10240,step:.625,help:`How long it listens each time. A longer window misses fewer advertisements and leaves WiFi less time.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Ed=`import re


def _addr(text):
    hexs = ''.join(c for c in str(text).lower() if c not in ':-. ')
    if len(hexs) != 12 or re.match('^[0-9a-f]+$', hexs) is None:
        return None
    return ':'.join(hexs[i:i + 2] for i in range(0, 12, 2))


def _uuid(text):
    t = str(text).strip().lower()
    if t.startswith('0x'):
        t = t[2:]
    hexs = t.replace('-', '')
    if len(hexs) not in (4, 32) or re.match('^[0-9a-f]+$', hexs) is None:
        return None
    return hexs


def _num(properties, name, default):
    try:
        return float(properties.get(name, default))
    except (TypeError, ValueError):
        return None


def _scan_settings(properties):
    return (_num(properties, 'scanIntervalMs', 320), _num(properties, 'scanWindowMs', 30), bool(properties.get('active', False)))


def compile(ctx, properties):
    errors = []
    out = {}

    addr = str(properties.get('addr') or '').strip()
    if addr:
        a = _addr(addr)
        if a is None:
            errors.append('ble_scan address "' + addr + '" is not a Bluetooth address: six bytes, like aa:bb:cc:dd:ee:ff')
        out['addr'] = a or ''
    else:
        out['addr'] = ''

    mfr = str(properties.get('mfrId') or '').strip()
    out['mfrId'] = None
    if mfr:
        try:
            v = int(mfr, 16) if mfr.lower().startswith('0x') else int(mfr)
        except ValueError:
            v = -1
        if v < 0 or v > 0xFFFF:
            errors.append('ble_scan manufacturer id "' + mfr + '" must be 0-65535, or hex like 0x0499')
        else:
            out['mfrId'] = v

    svc = str(properties.get('serviceUuid') or '').strip()
    out['serviceUuid'] = ''
    if svc:
        u = _uuid(svc)
        if u is None:
            errors.append('ble_scan service UUID "' + svc + '" must be 16-bit (fcd2) or 128-bit hex')
        else:
            out['serviceUuid'] = u

    repeat = _num(properties, 'repeatMs', 1000)
    if repeat is None or repeat < 0:
        errors.append('ble_scan repeat window must be 0 or more milliseconds')
    out['repeatMs'] = int(repeat or 0)

    interval, window, active = _scan_settings(properties)
    if interval is None or not (2.5 <= interval <= 10240):
        errors.append('ble_scan scan interval must be 2.5-10240 ms (Bluetooth limits)')
    elif window is None or not (2.5 <= window <= interval):
        shown = str(int(interval)) if interval == int(interval) else str(interval)
        errors.append('ble_scan scan window must be 2.5 ms up to the scan interval (' + shown + ' ms)')

    mine = _scan_settings(properties)
    for other in ctx['nodesOfType']:
        if other['id'] != ctx['node']['id'] and _scan_settings(other['properties']) != mine:
            errors.append(
                'ble_scan nodes ' + ctx['node']['id'] + ' and ' + other['id'] + ' ask for different scan settings '
                '(interval, window, active): the board has one scan, so give them the same settings')
            break

    out['scanIntervalMs'] = interval
    out['scanWindowMs'] = window
    out['active'] = active
    out['namePrefix'] = str(properties.get('namePrefix') or '')
    if errors:
        return {'errors': errors}
    return {'properties': out}
`,Dd=`import ts_ble

_scanner = ts_ble.radio().scan(
    properties['nodeId'], properties['scanIntervalMs'], properties['scanWindowMs'], properties['active'],
    name_prefix=properties['namePrefix'], addr=properties['addr'], mfr_id=properties['mfrId'],
    svc_uuid=properties['serviceUuid'], repeat_ms=properties['repeatMs'])
_msg = None


async def wait(properties):
    nonlocal _msg
    _msg = await _scanner.next()


async def emit(properties):
    # A burst of queued advertisements would otherwise run back to back with no yield.
    await asyncio.sleep_ms(0)
    return _msg
`,Od=`thingstudio/config/ble`,kd=`import re

_BLE_NAME_DEFAULT = 'thingstudio'
_BLE_NAME_MAX = 26


def _ble_name(ctx):
    configs = [c for c in ctx['flow']['configs'] if c['type'] == '${Od}']
    if len(configs) > 1:
        return None, 'this flow has %d BLE configs, but a board has one radio -- keep one (any ble node\\'s BLE field)' % len(configs)
    name = _BLE_NAME_DEFAULT
    if configs:
        name = str(configs[0]['properties'].get('name') or '')
    if len(name.encode()) > _BLE_NAME_MAX:
        return None, 'BLE name "' + name + '" is ' + str(len(name.encode())) + ' bytes; ' + str(_BLE_NAME_MAX) + ' is the most an advertisement holds'
    return name, None


def _ble_uuid(text):
    t = str(text or '').strip().lower()
    if t.startswith('0x'):
        t = t[2:]
    hexs = t.replace('-', '')
    if len(hexs) not in (4, 32) or re.match('^[0-9a-f]+$', hexs) is None:
        return None
    if len(hexs) == 4:
        return hexs
    return hexs[0:8] + '-' + hexs[8:12] + '-' + hexs[12:16] + '-' + hexs[16:20] + '-' + hexs[20:32]
`,Ad=`${kd}
_NUS = '6e400001-b5a3-f393-e0a9-e50e24dcca9e'
_NUS_RX = '6e400002-b5a3-f393-e0a9-e50e24dcca9e'
_NUS_TX = '6e400003-b5a3-f393-e0a9-e50e24dcca9e'
_F_READ = 0x02
_F_WRITE_NR = 0x04
_F_WRITE = 0x08
_F_NOTIFY = 0x10
_CHAR_IN = 'thingstudio/ble_characteristic_in'
_CHAR_OUT = 'thingstudio/ble_characteristic_out'
_UART = ('thingstudio/ble_uart_in', 'thingstudio/ble_uart_out')
ENCODINGS = ('bytes', 'text', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'float32')


def _ble_gatt(ctx):
    flags = {}
    encoding = {}
    writer = {}
    errors = []
    uart = False
    for n in ctx['flow']['nodes']:
        t = n['type']
        p = n['properties']
        if t in _UART:
            uart = True
            continue
        if t not in (_CHAR_IN, _CHAR_OUT):
            continue
        svc = _ble_uuid(p.get('serviceUuid'))
        char = _ble_uuid(p.get('charUuid'))
        if svc is None or char is None:
            continue  # that node's own hook names the bad UUID
        key = (svc, char)
        enc = p.get('encoding', 'bytes')
        if key in encoding and encoding[key][0] != enc:
            errors.append(
                'ble characteristic nodes ' + encoding[key][1] + ' and ' + n['id'] + ' share ' + char + ' but encode it as ' +
                encoding[key][0] + ' and ' + enc + ': give them the same encoding')
        encoding.setdefault(key, (enc, n['id']))
        f = flags.get(key, 0)
        if t == _CHAR_IN:
            f |= _F_WRITE | _F_WRITE_NR
        else:
            f |= _F_READ
            if p.get('notify', True):
                f |= _F_NOTIFY
            if key in writer:
                errors.append(
                    'ble characteristic out nodes ' + writer[key] + ' and ' + n['id'] + ' both set ' + char +
                    ': a characteristic has one value, so use one node')
            writer[key] = n['id']
        flags[key] = f
    if uart:
        flags[(_NUS, _NUS_RX)] = flags.get((_NUS, _NUS_RX), 0) | _F_WRITE | _F_WRITE_NR
        flags[(_NUS, _NUS_TX)] = flags.get((_NUS, _NUS_TX), 0) | _F_NOTIFY
    services = {}
    for (svc, char), f in flags.items():
        services.setdefault(svc, {})[char] = f
    table = [[svc, [[char, services[svc][char]] for char in sorted(services[svc])]] for svc in sorted(services)]
    return table, errors
`,jd={name:`bleConfigId`,label:`BLE`,kind:`configRef`,configType:Od,default:``,optional:!0,help:`The board's Bluetooth name, shared by every ble node. Without one, the board is called thingstudio.`},Md=[{value:`bytes`,label:`bytes, as they are`},{value:`text`,label:`text (UTF-8)`},{value:`int8`,label:`int8`},{value:`uint8`,label:`uint8`},{value:`int16`,label:`int16, little-endian`},{value:`uint16`,label:`uint16, little-endian`},{value:`int32`,label:`int32, little-endian`},{value:`uint32`,label:`uint32, little-endian`},{value:`float32`,label:`float32, little-endian`}],Nd={bytes:`bytes`,text:`string`,int8:`int`,uint8:`int`,int16:`int`,uint16:`int`,int32:`int`,uint32:`int`,float32:`number`},Pd={name:`peerConfigId`,label:`BLE peer`,kind:`configRef`,configType:`thingstudio/config/ble-peer`,default:``,help:`The device to connect to, by address or name. Nodes that name the same peer share one connection.`},Fd=`${kd}

def _ble_addr(text):
    hexs = ''.join(c for c in str(text or '').lower() if c not in ':-. ')
    if len(hexs) != 12 or re.match('^[0-9a-f]+$', hexs) is None:
        return None
    return ':'.join(hexs[i:i + 2] for i in range(0, 12, 2))


def _ble_peer(ctx, properties, label):
    pid = properties.get('peerConfigId') or ''
    cfg = (ctx.get('referencedConfigs') or {}).get(pid)
    if not pid or cfg is None:
        return None, label + ' needs a BLE peer: pick or add one in its "BLE peer" field (the device to connect to)'
    raw_addr = str(cfg.get('addr') or '').strip()
    prefix = str(cfg.get('namePrefix') or '').strip()
    addr = ''
    if raw_addr:
        addr = _ble_addr(raw_addr)
        if addr is None:
            return None, 'BLE peer address "' + raw_addr + '" is not a Bluetooth address: six bytes, like aa:bb:cc:dd:ee:ff'
    if not addr and not prefix:
        return None, 'the BLE peer config needs an address or a name to find the device by'
    try:
        timeout = int(cfg.get('timeoutMs') or 10000)
    except (TypeError, ValueError):
        timeout = -1
    if timeout < 1000 or timeout > 60000:
        return None, 'BLE peer timeout must be 1000-60000 ms'
    return {'peerKey': pid, 'peerAddr': addr, 'peerName': prefix, 'peerTimeoutMs': timeout}, None
`,Id={type:`thingstudio/ble_advertise`,kind:`sink`,paletteId:`ble_advertise`,label:`ble advertise`,group:`network`,priority:61,color:`#2f5fa8`,bgcolor:`#1a3560`,icon:`ᛒ`,width:116,description:`Advertises over Bluetooth LE: the board's name from flow start, and msg.payload as manufacturer or service data. Phones, computers and other boards (a ble scan node) see it without connecting. Name and payload share 31 bytes.`,requires:{capabilities:[`ble`]},allowUnwired:!0,ports:{inputs:[{name:`msg`,type:`any`}]},properties:[{name:`field`,label:`payload goes in`,kind:`select`,default:`manufacturer`,options:[{value:`manufacturer`,label:`manufacturer data`},{value:`service`,label:`service data`},{value:`none`,label:`nothing (name only)`}]},{name:`mfrId`,label:`manufacturer id`,kind:`text`,default:`0xFFFF`,help:`Hex with 0x, or decimal. 0xFFFF is reserved for testing; a product uses its maker's Bluetooth SIG id.`,visibleWhen:{field:`field`,equals:`manufacturer`}},{name:`serviceUuid`,label:`service UUID`,kind:`text`,default:`fcd2`,help:`16-bit (fcd2 is BTHome) or 128-bit.`,visibleWhen:{field:`field`,equals:`service`}},{name:`advIntervalMs`,label:`interval (ms)`,kind:`number`,default:500,min:20,max:10240,help:`How often the advertisement is sent. Shorter is found faster and uses more power.`},{...jd,help:`The board's Bluetooth name, which other devices show when they find it. Every byte of it is a byte less for the payload. Without one, the board is called thingstudio.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Ld=`${kd}
_LIMIT = 31


def compile(ctx, properties):
    errors = []
    others = [n['id'] for n in ctx['nodesOfType'] if n['id'] != ctx['node']['id']]
    if others:
        errors.append('only one ble_advertise per flow: the board sends one advertisement (also: ' + ', '.join(others) + ')')

    name, err = _ble_name(ctx)
    if err:
        return {'errors': [err]}
    field = properties.get('field', 'manufacturer')
    if field not in ('manufacturer', 'service', 'none'):
        errors.append('ble_advertise "payload goes in" must be manufacturer, service or none')
    out = {'bleName': name, 'field': field, 'mfrId': None, 'serviceUuid': None}

    header = 0
    if field == 'manufacturer':
        raw = str(properties.get('mfrId') or '').strip()
        try:
            v = int(raw, 16) if raw.lower().startswith('0x') else int(raw)
        except ValueError:
            v = -1
        if v < 0 or v > 0xFFFF:
            errors.append('ble_advertise manufacturer id "' + raw + '" must be 0-65535, or hex like 0xFFFF')
        out['mfrId'] = v
        header = 4
    elif field == 'service':
        raw = str(properties.get('serviceUuid') or '').strip()
        u = _ble_uuid(raw)
        if u is None:
            errors.append('ble_advertise service UUID "' + raw + '" must be 16-bit (fcd2) or 128-bit hex')
            return {'errors': errors}
        out['serviceUuid'] = u
        header = 2 + (2 if len(u) == 4 else 16)

    used = 3 + (2 + len(name.encode()) if name else 0) + header
    if used > _LIMIT:
        errors.append(
            'ble_advertise: the BLE name "' + name + '" leaves no room: ' + str(used) + ' of ' + str(_LIMIT) +
            ' bytes before any payload. Shorten the name in the BLE config')
    out['payloadRoom'] = _LIMIT - used

    try:
        interval = float(properties.get('advIntervalMs', 500))
    except (TypeError, ValueError):
        interval = -1
    if not (20 <= interval <= 10240):
        errors.append('ble_advertise interval must be 20-10240 ms (Bluetooth limits)')
    out['advIntervalMs'] = interval

    if errors:
        return {'errors': errors}
    return {'properties': out}
`,Rd=`import ts_ble

_radio = ts_ble.radio()
_node_id = properties['nodeId']
_name = properties['bleName']
_field = properties['field']
_mfr_id = properties['mfrId']
_svc_uuid = properties['serviceUuid']
_interval = properties['advIntervalMs']


def _adv(payload):
    if _field == 'manufacturer':
        return ts_ble.build_adv(_name, mfr_id=_mfr_id, mfr=payload)
    if _field == 'service':
        return ts_ble.build_adv(_name, svc_uuid=_svc_uuid, svc=payload)
    return ts_ble.build_adv(_name)


_radio.advertise(_node_id, _interval, _adv(b''))
runtime.report_status(_node_id, 'connected', 'advertising, %d bytes free for the payload' % properties['payloadRoom'])


async def run(msg, properties):
    p = msg.get('payload')
    if isinstance(p, (bytes, bytearray)):
        data = bytes(p)
    elif isinstance(p, str):
        data = p.encode()
    else:
        runtime._report_error(_node_id, ValueError(
            'ble_advertise: payload is %s, not bytes or text; pack a number first (struct.pack in a function node)' % type(p).__name__))
        return
    try:
        adv = _adv(data)
    except ValueError as e:
        runtime._report_error(_node_id, ValueError('ble_advertise: %s' % e))
        return
    _radio.advertise(_node_id, _interval, adv)
`,zd={type:`thingstudio/ble_characteristic_in`,kind:`source`,eventSource:!0,paletteId:`ble_characteristic_in`,label:`ble characteristic in`,title:`ble char in`,group:`network`,priority:62,color:`#2f5fa8`,bgcolor:`#1a3560`,icon:`ᛒ`,width:116,description:`Sends a message each time a connected device (a phone, a computer, another board) writes this Bluetooth LE characteristic. msg.payload is the value, decoded by the encoding. The board accepts connections from anyone in range: no pairing.`,requires:{capabilities:[`ble`]},ports:{outputs:[{name:`msg`,type:{property:`encoding`,map:Nd,default:`bytes`}}]},properties:[{name:`serviceUuid`,label:`service UUID`,kind:`text`,default:``,placeholder:`128-bit, or 16-bit like 181a`,help:`The service this characteristic belongs to. Use the same one on the nodes for its other characteristics.`},{name:`charUuid`,label:`characteristic UUID`,kind:`text`,default:``,placeholder:`128-bit, or 16-bit like 2a6e`},{name:`encoding`,label:`encoding`,kind:`select`,default:`bytes`,options:Md,retype:!0,help:`How the bytes a connected device writes become msg.payload.`},jd,{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Bd=`${Ad}

def compile(ctx, properties):
    errors = []
    name, err = _ble_name(ctx)
    if err:
        errors.append(err)
    svc = _ble_uuid(properties.get('serviceUuid'))
    char = _ble_uuid(properties.get('charUuid'))
    if svc is None:
        errors.append('ble_characteristic_in needs a service UUID: 16-bit (181a) or 128-bit, got "' + str(properties.get('serviceUuid') or '') + '"')
    if char is None:
        errors.append('ble_characteristic_in needs a characteristic UUID: 16-bit (2a6e) or 128-bit, got "' + str(properties.get('charUuid') or '') + '"')
    if properties.get('encoding', 'bytes') not in ENCODINGS:
        errors.append('ble_characteristic_in encoding must be one of ' + ', '.join(ENCODINGS))
    table, gatt_errors = _ble_gatt(ctx)
    errors.extend(gatt_errors)
    if errors:
        return {'errors': errors}
    return {'properties': {'bleName': name, 'serviceUuid': svc, 'charUuid': char, 'gattTable': table}}
`,Vd=`import ts_ble
import ts_ble.server

_node_id = properties['nodeId']
_encoding = properties['encoding']
_gatt = ts_ble.server.gatt(ts_ble.radio(), properties['gattTable'], properties['bleName'])
_writes = _gatt.on_writes(_node_id, properties['serviceUuid'], properties['charUuid'])
_msg = None


async def wait(properties):
    nonlocal _msg
    while True:
        data, conn = await _writes.next()
        try:
            value = ts_ble.decode_value(_encoding, data)
        except ValueError as e:
            runtime._report_error(_node_id, ValueError('ble_characteristic_in: a connected device wrote %s' % e))
            continue
        _msg = {'payload': value, 'topic': '', 'conn': conn, 'uuid': properties['charUuid']}
        return


async def emit(properties):
    await asyncio.sleep_ms(0)
    return _msg
`,Hd={type:`thingstudio/ble_characteristic_out`,kind:`sink`,paletteId:`ble_characteristic_out`,label:`ble characteristic out`,title:`ble char out`,group:`network`,priority:63,color:`#2f5fa8`,bgcolor:`#1a3560`,icon:`ᛒ`,width:116,description:`Sets a Bluetooth LE characteristic to msg.payload, which a connected device can read, and notifies the devices subscribed to it. The board accepts connections from anyone in range: no pairing.`,requires:{capabilities:[`ble`]},ports:{inputs:[{name:`msg`,type:`any`}]},properties:[{name:`serviceUuid`,label:`service UUID`,kind:`text`,default:``,placeholder:`128-bit, or 16-bit like 181a`,help:`The service this characteristic belongs to. Use the same one on the nodes for its other characteristics.`},{name:`charUuid`,label:`characteristic UUID`,kind:`text`,default:``,placeholder:`128-bit, or 16-bit like 2a6e`},{name:`encoding`,label:`encoding`,kind:`select`,default:`bytes`,options:Md,help:`How msg.payload becomes the bytes a connected device reads.`},{name:`notify`,label:`notify`,kind:`boolean`,default:!0,help:`Also push each new value to the devices subscribed to it.`},jd,{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Ud=`${Ad}

def compile(ctx, properties):
    errors = []
    name, err = _ble_name(ctx)
    if err:
        errors.append(err)
    svc = _ble_uuid(properties.get('serviceUuid'))
    char = _ble_uuid(properties.get('charUuid'))
    if svc is None:
        errors.append('ble_characteristic_out needs a service UUID: 16-bit (181a) or 128-bit, got "' + str(properties.get('serviceUuid') or '') + '"')
    if char is None:
        errors.append('ble_characteristic_out needs a characteristic UUID: 16-bit (2a6e) or 128-bit, got "' + str(properties.get('charUuid') or '') + '"')
    if properties.get('encoding', 'bytes') not in ENCODINGS:
        errors.append('ble_characteristic_out encoding must be one of ' + ', '.join(ENCODINGS))
    table, gatt_errors = _ble_gatt(ctx)
    errors.extend(gatt_errors)
    if errors:
        return {'errors': errors}
    return {'properties': {'bleName': name, 'serviceUuid': svc, 'charUuid': char, 'gattTable': table}}
`,Wd=`import ts_ble
import ts_ble.server

_node_id = properties['nodeId']
_encoding = properties['encoding']
_notify = bool(properties['notify'])
_svc = properties['serviceUuid']
_char = properties['charUuid']
_gatt = ts_ble.server.gatt(ts_ble.radio(), properties['gattTable'], properties['bleName'])
_gatt.attach(_node_id)


async def run(msg, properties):
    try:
        data = ts_ble.encode(_encoding, msg.get('payload'))
    except ValueError as e:
        runtime._report_error(_node_id, ValueError('ble_characteristic_out: %s' % e))
        return
    _gatt.write(_node_id, _svc, _char, data, _notify)
`,Gd={type:`thingstudio/ble_uart_in`,kind:`source`,eventSource:!0,paletteId:`ble_uart_in`,label:`ble uart in`,group:`network`,priority:64,color:`#2f5fa8`,bgcolor:`#1a3560`,icon:`ᛒ`,width:96,description:`Receives text from a connected device over Bluetooth LE, through the Nordic UART Service that terminal apps (nRF Connect, Serial Bluetooth Terminal) use. One message per line. The board accepts connections from anyone in range.`,requires:{capabilities:[`ble`]},ports:{outputs:[{name:`msg`,type:`string`}]},properties:[{name:`lines`,label:`one message per line`,kind:`boolean`,default:!0,help:`Off: one message per write the connected device makes, as it arrives.`},jd,{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Kd=`${Ad}

def compile(ctx, properties):
    name, err = _ble_name(ctx)
    table, errors = _ble_gatt(ctx)
    if err:
        errors.insert(0, err)
    if errors:
        return {'errors': errors}
    return {'properties': {'bleName': name, 'gattTable': table}}
`,qd=`import ts_ble
import ts_ble.server

_node_id = properties['nodeId']
_lines = bool(properties['lines'])
_gatt = ts_ble.server.gatt(ts_ble.radio(), properties['gattTable'], properties['bleName'])
_writes = _gatt.on_writes(_node_id, ts_ble.server.NUS_SERVICE, ts_ble.server.NUS_RX)
_partial = {}  # conn -> bytes of a line not yet ended
_ready = []  # (bytes, conn) waiting to be sent
_LINE_MAX = 512
_msg = None


def _split(data, conn):
    if not _lines:
        _ready.append((data, conn))
        return
    buf = _partial.get(conn, b'') + data
    while b'\\n' in buf:
        line, buf = buf.split(b'\\n', 1)
        _ready.append((line.rstrip(b'\\r'), conn))
    if len(buf) > _LINE_MAX:  # a phone that never sends a newline: pass the text on rather than grow without bound
        _ready.append((buf, conn))
        buf = b''
    _partial[conn] = buf


async def wait(properties):
    nonlocal _msg
    while True:
        while not _ready:
            data, conn = await _writes.next()
            _split(data, conn)
        data, conn = _ready.pop(0)
        try:
            text = data.decode()
        except UnicodeError:
            runtime._report_error(_node_id, ValueError('ble_uart_in: a connected device sent %d bytes that aren\\'t UTF-8 text' % len(data)))
            continue
        _msg = {'payload': text, 'topic': '', 'conn': conn}
        return


async def emit(properties):
    await asyncio.sleep_ms(0)
    return _msg
`,Jd={type:`thingstudio/ble_uart_out`,kind:`sink`,paletteId:`ble_uart_out`,label:`ble uart out`,group:`network`,priority:65,color:`#2f5fa8`,bgcolor:`#1a3560`,icon:`ᛒ`,width:96,description:`Sends msg.payload as text to the devices connected over Bluetooth LE, through the Nordic UART Service that terminal apps use. The board accepts connections from anyone in range.`,requires:{capabilities:[`ble`]},ports:{inputs:[{name:`msg`,type:`any`}]},properties:[{name:`newline`,label:`end with a newline`,kind:`boolean`,default:!0},jd,{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Yd=`${Ad}

def compile(ctx, properties):
    name, err = _ble_name(ctx)
    table, errors = _ble_gatt(ctx)
    if err:
        errors.insert(0, err)
    if errors:
        return {'errors': errors}
    return {'properties': {'bleName': name, 'gattTable': table}}
`,Xd=`import ts_ble
import ts_ble.server

_node_id = properties['nodeId']
_newline = bool(properties['newline'])
_gatt = ts_ble.server.gatt(ts_ble.radio(), properties['gattTable'], properties['bleName'])
_gatt.attach(_node_id)


async def run(msg, properties):
    p = msg.get('payload')
    data = bytes(p) if isinstance(p, (bytes, bytearray)) else str(p).encode()
    if _newline:
        data += b'\\n'
    _gatt.send_chunks(_node_id, ts_ble.server.NUS_SERVICE, ts_ble.server.NUS_TX, data)
`,Zd={type:`thingstudio/ble_read`,kind:`transform`,paletteId:`ble_read`,label:`ble read`,group:`network`,priority:66,color:`#2f5fa8`,bgcolor:`#1a3560`,icon:`ᛒ`,width:84,description:`Reads a characteristic of another Bluetooth LE device (a BLE peer) for each message that arrives, and sends the value on as msg.payload. The board connects to the peer itself and reconnects if the link drops.`,requires:{capabilities:[`ble`]},ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:{property:`encoding`,map:Nd,default:`bytes`}}]},properties:[Pd,{name:`serviceUuid`,label:`service UUID`,kind:`text`,default:``,placeholder:`128-bit, or 16-bit like 181a`},{name:`charUuid`,label:`characteristic UUID`,kind:`text`,default:``,placeholder:`128-bit, or 16-bit like 2a6e`},{name:`encoding`,label:`encoding`,kind:`select`,default:`bytes`,options:Md,retype:!0,help:`How the bytes read become msg.payload.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},Qd=e=>`${Fd}

ENCODINGS = ('bytes', 'text', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'float32')


def compile(ctx, properties):
    errors = []
    peer, err = _ble_peer(ctx, properties, '${e}')
    if err:
        errors.append(err)
    svc = _ble_uuid(properties.get('serviceUuid'))
    char = _ble_uuid(properties.get('charUuid'))
    if svc is None:
        errors.append('${e} needs a service UUID: 16-bit (181a) or 128-bit, got "' + str(properties.get('serviceUuid') or '') + '"')
    if char is None:
        errors.append('${e} needs a characteristic UUID: 16-bit (2a6e) or 128-bit, got "' + str(properties.get('charUuid') or '') + '"')
    if properties.get('encoding', 'bytes') not in ENCODINGS:
        errors.append('${e} encoding must be one of ' + ', '.join(ENCODINGS))
    if errors:
        return {'errors': errors}
    out = dict(peer)
    out['serviceUuid'] = svc
    out['charUuid'] = char
    return {'properties': out}
`,$d=Qd(`ble_read`),ef=`import ts_ble
import ts_ble.central

_node_id = properties['nodeId']
_encoding = properties['encoding']
_svc = properties['serviceUuid']
_char = properties['charUuid']
_peer = ts_ble.central.peer(ts_ble.radio(), properties['peerKey'], properties['peerAddr'], properties['peerName'], properties['peerTimeoutMs'])
_peer.need(_node_id, _svc, _char)


async def run(msg, properties):
    try:
        data = await _peer.read(_svc, _char)
        msg['payload'] = ts_ble.decode_value(_encoding, data)
    except ts_ble.central.PeerError as e:
        runtime._report_error(_node_id, e)
        return None
    except ValueError as e:
        runtime._report_error(_node_id, ValueError('ble_read: %s read %s' % (_peer.label, e)))
        return None
    return msg
`,tf={type:`thingstudio/ble_write`,kind:`sink`,paletteId:`ble_write`,label:`ble write`,group:`network`,priority:67,color:`#2f5fa8`,bgcolor:`#1a3560`,icon:`ᛒ`,width:84,description:`Writes msg.payload to a characteristic of another Bluetooth LE device (a BLE peer). The board connects to the peer itself; a message that arrives while it isn't connected is reported and dropped.`,requires:{capabilities:[`ble`]},ports:{inputs:[{name:`msg`,type:`any`}]},properties:[Pd,{name:`serviceUuid`,label:`service UUID`,kind:`text`,default:``,placeholder:`128-bit, or 16-bit like 181a`},{name:`charUuid`,label:`characteristic UUID`,kind:`text`,default:``,placeholder:`128-bit, or 16-bit like 2a6e`},{name:`encoding`,label:`encoding`,kind:`select`,default:`bytes`,options:Md,help:`How msg.payload becomes the bytes written.`},{name:`response`,label:`wait for the peer's response`,kind:`boolean`,default:!0,help:`Off: write without response, faster, and the peer must allow it.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},nf=Qd(`ble_write`),rf=`import ts_ble
import ts_ble.central

_node_id = properties['nodeId']
_encoding = properties['encoding']
_svc = properties['serviceUuid']
_char = properties['charUuid']
_response = bool(properties['response'])
_peer = ts_ble.central.peer(ts_ble.radio(), properties['peerKey'], properties['peerAddr'], properties['peerName'], properties['peerTimeoutMs'])
_peer.need(_node_id, _svc, _char)


async def run(msg, properties):
    try:
        data = ts_ble.encode(_encoding, msg.get('payload'))
    except ValueError as e:
        runtime._report_error(_node_id, ValueError('ble_write: %s' % e))
        return
    try:
        await _peer.write(_svc, _char, data, _response)
    except ts_ble.central.PeerError as e:
        runtime._report_error(_node_id, e)
`,af={type:`thingstudio/ble_notify`,kind:`source`,eventSource:!0,paletteId:`ble_notify`,label:`ble notify`,group:`network`,priority:68,color:`#2f5fa8`,bgcolor:`#1a3560`,icon:`ᛒ`,width:92,description:`Subscribes to a characteristic of another Bluetooth LE device (a BLE peer) and sends a message each time it notifies a new value. The board connects to the peer itself and subscribes again after a reconnect.`,requires:{capabilities:[`ble`]},ports:{outputs:[{name:`msg`,type:{property:`encoding`,map:Nd,default:`bytes`}}]},properties:[Pd,{name:`serviceUuid`,label:`service UUID`,kind:`text`,default:``,placeholder:`128-bit, or 16-bit like 181a`},{name:`charUuid`,label:`characteristic UUID`,kind:`text`,default:``,placeholder:`128-bit, or 16-bit like 2a6e`},{name:`encoding`,label:`encoding`,kind:`select`,default:`bytes`,options:Md,retype:!0,help:`How each notified value becomes msg.payload.`},{name:`nodeId`,label:`node id`,kind:`nodeId`,default:``}]},of=Qd(`ble_notify`),sf=`import ts_ble
import ts_ble.central

_node_id = properties['nodeId']
_encoding = properties['encoding']
_peer = ts_ble.central.peer(ts_ble.radio(), properties['peerKey'], properties['peerAddr'], properties['peerName'], properties['peerTimeoutMs'])
_values = _peer.notifications(_node_id, properties['serviceUuid'], properties['charUuid'])
_msg = None


async def wait(properties):
    nonlocal _msg
    _peer.start()
    while True:
        data, _conn = await _values.next()
        try:
            value = ts_ble.decode_value(_encoding, data)
        except ValueError as e:
            runtime._report_error(_node_id, ValueError('ble_notify: %s sent %s' % (_peer.label, e)))
            continue
        _msg = {'payload': value, 'topic': '', 'peer': _peer.label, 'uuid': properties['charUuid']}
        return


async def emit(properties):
    await asyncio.sleep_ms(0)
    return _msg
`;function cf(e,t){return`page`in t?e.pages.find(e=>e.name===t.page)?.elements:e.modals?.find(e=>e.node===t.modal)?.elements}function lf(e,t,n){return`page`in t?{...e,pages:e.pages.map(e=>e.name===t.page?{...e,elements:n}:e)}:{...e,modals:(e.modals??[]).map(e=>e.node===t.modal?{...e,elements:n}:e)}}function uf(e,t,n){let r=cf(e,t);if(!r)return e;try{let i=n(r);return i?lf(e,t,i):e}catch{return e}}function df(e,t,n,r){return uf(e,t,e=>[...e,n])}function ff(e,t,n){return uf(e,t,e=>n>=0&&n<e.length?e.filter((e,t)=>t!==n):null)}function pf(e,t,n,r){return uf(e,t,e=>{let t=n+r;if(n<0||n>=e.length||t<0||t>=e.length)return null;let i=e.slice(),[a]=i.splice(n,1);return i.splice(t,0,a),i})}function mf(e,t,n,r){return uf(e,t,e=>{if(n<0||n>=e.length)return null;let t={...e[n]};for(let[e,n]of Object.entries(r))n===void 0?delete t[e]:t[e]=n;let i=e.slice();return i[n]=t,i})}function hf(e){let t=new Set;for(let n of e.pages)for(let e of n.elements)!e.card&&e.node&&t.add(e.node);for(let n of e.modals??[])for(let e of n.elements)!e.card&&e.node&&t.add(e.node);return t}function gf(e,t,n){if(e.pages.some(e=>e.name===t))return e;let r={name:t,...n?{parent:n}:{},elements:[]};return{...e,pages:[...e.pages,r]}}function _f(e,t){return{...e,pages:e.pages.filter(e=>e.name!==t)}}function vf(e,t,n){let r=e.pages.filter(e=>e.parent===void 0).map(e=>e.name),i=r.indexOf(t),a=i+n;if(i<0||a<0||a>=r.length)return e;let o=r.slice();[o[i],o[a]]=[o[a],o[i]];let s=[...e.pages].sort((e,t)=>(e.parent===void 0?o.indexOf(e.name):999)-(t.parent===void 0?o.indexOf(t.name):999));return{...e,pages:s,carousel:o}}function yf(e,t){if((e.modals??[]).some(e=>e.node===t))return e;let n={node:t,elements:[]};return{...e,modals:[...e.modals??[],n]}}function bf(e,t){return{...e,modals:(e.modals??[]).filter(e=>e.node!==t)}}function xf(e,t){let n=e=>!(e.node&&!e.card&&t.has(e.node));return{...e,pages:e.pages.map(e=>({...e,elements:e.elements.filter(n)})),...e.modals?{modals:e.modals.map(e=>({...e,elements:e.elements.filter(n)}))}:{}}}var Sf=`thingstudio/display_spi`;function Cf(e,t,n){return n===90||n===270?{width:t,height:e}:{width:e,height:t}}function wf(e,t,n,r){switch(r){case 0:return e;case 90:return{x:e.y,y:t-1-e.x};case 180:return{x:t-1-e.x,y:n-1-e.y};case 270:return{x:n-1-e.y,y:e.x}}}function Tf(e,t){return[{x:0,y:0},{x:e-1,y:0},{x:0,y:t-1},{x:1,y:2},{x:e-2,y:3}]}var Ef=(e,t)=>e.x===t.x&&e.y===t.y;function Df(e,t,n,r){let i=t.x,a=t.y,o=n,s=r;return e.swapXY&&([i,a]=[a,i],[o,s]=[s,o]),e.flipX&&(i=o-1-i),e.flipY&&(a=s-1-a),{x:i,y:a}}function Of(e,t,n,r){let i=e.swapXY?{width:r,height:n}:{width:n,height:r};for(let a=0;a<8;a++){let o={swapXY:!!(a&1),flipX:!!(a&2),flipY:!!(a&4)};if(Tf(n,r).every(a=>{let s=wf(Df(e,a,n,r),i.width,i.height,t);return Ef(Df(o,a,n,r),s)}))return o}throw new L(`no touch orientation matches a turn of ${t} degrees`)}function kf(e,t,n){let r=t;t.type!==Sf&&(r=e.findWiredTargets?.(t.id).find(e=>e.type===Sf));let i=r?.properties.orientation;if(i==null||i===``)return null;let a=Number(i);if(a!==0&&a!==90&&a!==180&&a!==270)throw new L(`${n}: orientation "${String(i)}" must be 0, 90, 180 or 270`);return a}var Af=[`thingstudio/gui_screen`,`thingstudio/touch_i2c`];function jf(e,t,n,r,i){let a=e[t],o=a==null||a===``?n:Number(a);if(!Number.isInteger(o)||o<r)throw new L(`touch panel ${i} "${String(a)}" must be a whole number, ${r} or more`);return o}function Mf(e,t,n){let r=[];for(let i of Af)for(let a of e.findNodesOfType?.(i)??[])a.id!==t.id&&a.properties.touchPanelConfigId===n&&r.push(a);return r}function Nf(e,t){let n=bl(t),r=t.properties.touchPanelConfigId;if(typeof r!=`string`||r===``)throw new L(`${n} has no touch panel. Pick one, or add one with +.`);let i=Mf(e,t,r)[0];if(i)throw new L(`${n} and ${bl(i)} both use the same touch panel. A panel feeds one gui screen or one touch node, not both.`);let a=e.resolveConfig(r),o=String(a.controller??`ft6336u`);if(o!==`ft6336u`)throw new L(`touch panel controller "${o}" isn't supported yet (FT6336U only)`);let s=Hl(e,`touch panel for ${n}`,a.i2cConfigId),c=jf(a,`address`,56,8,`address`);if(c>119)throw new L(`touch panel address "${String(a.address)}" must be 0x08 to 0x77`);let l=jf(a,`pollMs`,20,5,`poll interval`),u=jf(a,`width`,320,1,`width`),d=jf(a,`height`,480,1,`height`),f={swapXY:a.swapXY===!0,flipX:a.flipX===!0,flipY:a.flipY===!0};if(t.type===`thingstudio/gui_screen`){let n=kf(e,t,`GUI screen ${bl(t)}`);n!==null&&(f=Of(f,n,u,d))}let p=e=>e?`True`:`False`,m=a.rstPin,h=m!=null&&m!==``,g=`None`;if(h){let n=$c(e,`touch panel reset pin`,m,`output`);jl(e,hc(n),`output`,t),g=Nl(n,`out`)}return{bus:s,pollMs:l,where:`FT6336U at ${`0x${c.toString(16)}`} on I2C bus ${s.bus}`,makeDevice:`ft6336u.FT6336U(${s.varName}, ${c}, ${g}, ${u}, ${d}, ${p(f.swapXY)}, ${p(f.flipX)}, ${p(f.flipY)})`,imports:[`import machine`,`import ft6336u`]}}var Pf={gs4:`GS4_HMSB`,gs2:`GS2_HMSB`,mono:`MONO_HMSB`,rgb565:`RGB565`},Ff=`thingstudio/display_spi`,If={width:320,height:240,format:`gs4`};function Lf(e,t,n){return Math.max(1,Math.min(t,Math.floor(5120/Rf(e,1,n))))}function Rf(e,t,n){switch(n){case`gs4`:return Math.ceil(e/2)*t;case`gs2`:return Math.ceil(e/4)*t;case`mono`:return Math.ceil(e/8)*t;case`rgb565`:return e*t*2}}function zf(e,t){let n=t.findWiredTargets?.(e.id).find(e=>e.type===Ff),r,i,a;if(n){if(r=Math.round(Number(n.properties.width??If.width)),i=Math.round(Number(n.properties.height??If.height)),a=String(n.properties.frameFormat??If.format),!(r>0&&i>0))throw new L(`GUI screen ${bl(e)}: the display it is wired to (${bl(n)}) has no size (${String(n.properties.width)}x${String(n.properties.height)})`)}else if(r=Math.round(Number(e.properties.width??If.width)),i=Math.round(Number(e.properties.height??If.height)),a=String(e.properties.frameFormat??If.format),!(r>0&&i>0))throw new L(`GUI screen ${bl(e)}: width and height must be positive, got ${String(e.properties.width)}x${String(e.properties.height)}`);let o=kf(t,e,`GUI screen ${bl(e)}`);if(o!==null&&({width:r,height:i}=Cf(r,i,o)),!(a in Pf))throw new L(`GUI screen ${bl(e)}: the display's frameFormat "${a}" must be one of ${Object.keys(Pf).join(`, `)}`);return{width:r,height:i,format:a}}var Bf=new WeakMap;function Vf(e){if(!e.findNodesOfType)throw new L(`GUI nodes need findNodesOfType in the codegen context`);return[hl,gl,...Object.keys(vl),`thingstudio/gui_navigator`].flatMap(t=>e.findNodesOfType(t))}function Hf(e){let t=Bf.get(e);if(!t){let n=Vf(e);if(t=Ol(e.screens??{},n,t=>zf(t,e)),t.errors.length>0)throw new L(`GUI layout:\n  ${t.errors.join(`
  `)}`);for(let n of t.warnings)e.warn?.(n);for(let n of e.findNodesOfType?.(`thingstudio/journal`)??[]){let r=Math.round(Number(n.properties.rows??60));if(r>0)for(let i of e.findWiredTargets?.(n.id)??[]){let a=t.trendColumns.get(i.id);a===void 0||a<=r||e.warn?.(`journal ${bl(n)} keeps ${r} rows but histogram ${bl(i)} shows ${a} columns, so the left of it stays empty -- raise rows kept to ${a}`)}}Bf.set(e,t)}return t}var Uf=[`next`,`prev`,`back`,`home`];function Wf(e){let t=e.properties,n=`button ${bl(e)}`,r=String(t.mode??`momentary`);if(r!==`momentary`&&r!==`toggle`&&r!==`navigate`)throw new L(`${n}: mode must be momentary, toggle or navigate, not "${r}"`);let i=String(t.valueType??`bool`);if(i!==`bool`&&i!==`string`&&i!==`number`)throw new L(`${n}: value type must be bool, string or number, not "${i}"`);let a=String(t.fireOn??`release`);if(a!==`release`&&a!==`press`)throw new L(`${n}: send on must be release or press, not "${a}"`);let o=Number(t.pendingTimeout??5);if(!(o>=5))throw new L(`${n}: the wait for confirmation must be 5 s or more, not "${String(t.pendingTimeout)}"`);let s=typeof t.target==`string`?t.target.trim():``;if(r===`navigate`&&!s)throw new L(`${n}: choose where it goes (next, prev, back, home or a page name)`);let c={bool:[`true`,`false`],string:[`ON`,`OFF`],number:[`1`,`0`]}[i],l=(e,r)=>Es(i,t[e]===void 0||t[e]===``?r:t[e],`${n} ${e}`);return{mode:r,send:r===`momentary`?l(`value`,c[0]):`None`,onVal:l(`onValue`,c[0]),offVal:l(`offValue`,c[1]),onPress:a===`press`,target:s,pendingS:o,initial:t.initial===!0,onText:typeof t.onText==`string`&&t.onText!==``?t.onText:`ON`,offText:typeof t.offText==`string`&&t.offText!==``?t.offText:`OFF`}}function Gf(e,t){let n=Wf(e),r=n.mode===`toggle`&&t.isInputWired?.(e.id)===!0;return`_gui.button(${z(e.id)}, ${z(n.mode)}, controlled=${r?`True`:`False`}, send=${n.send}, on_val=${n.onVal}, off_val=${n.offVal}, on_press=${n.onPress?`True`:`False`}, target=${z(n.target)}, pending_ms=${Math.round(n.pendingS*1e3)}, initial=${n.initial?`True`:`False`})`}function Kf(e){let t=Hf(e),n=[`_gui = thingstudio_gui.GUI(on_error=runtime._report_error)`];for(let r of Vf(e)){if(!yl(r.type))continue;let i=Math.max(0,Math.round(Number(r.properties.staleAfter??0)*1e3))||0,a=t.widgetDraws.get(r.id)??`lambda _s, _r, _v, _st: None`;n.push(`_gui.widget(${z(r.id)}, ${a}, ${i}${r.type===`thingstudio/gui_button`?`, True`:``})`),r.type===`thingstudio/gui_button`&&n.push(Gf(r,e))}return n.push(`runtime.spawn(_gui.run(), None)`),{imports:[`import thingstudio_gui`,`import framebuf`,...[...t.imports].sort().map(e=>`import ${e}`)],statements:[{key:`gui_core`,code:n.join(`
`)}]}}function qf(e,t,n=`screen`){let r=e.findNodesOfType?.(`thingstudio/gui_screen`)??[],i=typeof t.properties[n]==`string`?t.properties[n].trim():``;if(i){let e=r.filter(e=>e.id===i||e.properties.name===i);if(e.length===1)return e[0].id;throw new L(`${bl(t)}: ${e.length===0?`no GUI screen is called "${i}"`:`two GUI screens are called "${i}"`}`)}if(r.length===1)return r[0].id;throw new L(`${bl(t)}: choose which GUI screen it acts on (the flow has ${r.length})`)}var Jf={type:hl,kind:`source`,paletteId:`gui_screen`,label:`screen`,title:`screen`,group:`GUI`,priority:10,color:`#3f6e5c`,bgcolor:`#1f3a30`,icon:`▣`,width:110,screenOutline:!0,presetType:`gui_theme`,description:`One per display: takes its size (the panel's own width and height) and frame format from the display this screen is wired to, so set them once on the display, not here. Rotation is the display's setting too. Sends a frame each time the screen changes. Wire it to a display node.`,ports:{outputs:[{name:`frame`,type:`bytes`}]},properties:[{name:`name`,label:`name`,kind:`text`,default:`screen`},{name:`width`,label:`width (px)`,kind:`number`,default:320,min:1,hidden:!0},{name:`height`,label:`height (px)`,kind:`number`,default:240,min:1,hidden:!0},{name:`frameFormat`,label:`frame format`,kind:`select`,default:`gs4`,hidden:!0,options:[{value:`gs4`,label:`gs4 (16 greys)`},{value:`gs2`,label:`gs2 (4 greys)`},{value:`mono`,label:`mono`},{value:`rgb565`,label:`rgb565 (colour)`}]},{name:`minInterval`,label:`fastest redraw (ms)`,kind:`number`,default:200,min:0},{name:`wrap`,label:`next/prev wrap round`,kind:`boolean`,default:!0},{name:`gridColumns`,label:`grid columns`,kind:`number`,default:12,min:2,max:48},{name:`gridRows`,label:`grid rows (0 = from the display's shape)`,kind:`number`,default:0,min:0,max:64},{name:`touchPanelConfigId`,label:`touch panel (blank: no touch)`,kind:`configRef`,configType:`thingstudio/config/touch-panel`,default:``},{name:`themeConfigId`,label:`shared theme config (older flows)`,kind:`configRef`,configType:Fs,default:``,help:`Only used when the theme fields below are empty. Kept so a flow saved with a shared theme still renders; the screen's own colours win.`},{name:`themePreset`,label:`theme`,kind:`select`,default:``,options:Rs(),help:`A starting point replaces the colours below; editing a colour makes the theme custom.`},...Is.map(e=>({name:e,label:Ls[e],kind:`colour`}))],codegenEventSource(e,t){let{width:n,height:r,format:i}=zf(e,t),a=Hs(Ks(t,e),i),o=typeof e.properties.themeConfigId==`string`&&e.properties.themeConfigId!==``,s=i===`rgb565`||Gs(e.properties)||o,c=Kf(t),l=Hf(t).surfaces.find(t=>t.screen===e.id);if(!l)throw new L(`GUI screen ${bl(e)} has no pages yet: lay it out in the GUI view`);let u=t.uniqueName(`gui_screen`),d=`framebuf.${Pf[i]}`,f=Math.max(0,Math.round(Number(e.properties.minInterval??200))),p=e.properties.wrap===!1?`False`:`True`,m=Rf(n,1,i),h=Lf(n,r,i),g=[...l.staticRegistrations,`${u}_s = _gui.add_surface(thingstudio_gui.BandSurface(${z(e.id)}, ${n}, ${r}, ${d}, ${l.pagesPy}, ${l.carouselPy}, ${l.modalsPy}, ${p}, ${f}, ${h}, ${m}${s?`, theme=${Us(a.values,i===`rgb565`)}`:``}))`].join(`
`),_=typeof e.properties.name==`string`&&e.properties.name?e.properties.name:e.id,v=[...c.imports],y=[...c.statements,{key:`gui_screen_${e.id}`,code:g}],b=t.screens?.[e.id];if(typeof e.properties.touchPanelConfigId==`string`&&e.properties.touchPanelConfigId!==``){let n=Nf(t,e);v.push(...n.imports),y.push(n.bus.statement,{key:`gui_touch_${e.id}`,code:`runtime.spawn(_gui.poll_touch(${z(e.id)}, lambda: ${n.makeDevice}, ${n.pollMs}, lambda st, text: runtime.report_status(${z(e.id)}, st, text), ${z(n.where)}), ${z(e.id)})`})}else b&&(t.findNodesOfType?.(`thingstudio/gui_button`)??[]).filter(e=>hf(b).has(e.id)).length>0&&t.warn?.(`GUI screen ${bl(e)} has buttons but no touch panel, so they can't be pressed. Pick a touch panel in its properties.`);return{imports:v,statements:y,waitStatement:`_band_y, _band_rows = await ${u}_s.next_band()`,buildMsg:`msg = {'payload': memoryview(${u}_s.band_buf)[:_band_rows * ${m}], 'topic': ${z(_)}, 'y': _band_y}`}}};function Yf(e){return{type:e,kind:`sink`,ports:{inputs:[{name:`msg`,type:`any`}]},codegenSink(t,n){let r=Kf(n);return{imports:r.imports,statements:r.statements,functionName:n.uniqueName(e.replace(`thingstudio/`,``)),functionBody:`_gui.set_value(${z(t.id)}, msg.get('payload'))`}}}}var Xf={...Yf(`thingstudio/gui_label`),paletteId:`gui_label`,label:`label`,title:`show text`,group:`GUI`,priority:41,color:`#4a6e3f`,bgcolor:`#2a3a1f`,icon:`T`,width:100,properties:[{name:`name`,label:`name`,kind:`text`,default:``},{name:`font`,label:`font (blank = fit the cells)`,kind:`select`,default:``,options:[{value:``,label:`auto (the largest that fits)`},...ol().map(e=>({value:e,label:e.replace(/^font_/,``)}))]},{name:`maxChars`,label:`room for (characters)`,kind:`number`,default:8,min:1},{name:`staleAfter`,label:`stale after (s, 0 = never)`,kind:`number`,default:0,min:0}]},Zf={...Yf(`thingstudio/gui_readout`),paletteId:`gui_readout`,label:`readout`,title:`show number`,group:`GUI`,priority:40,color:`#4a6e3f`,bgcolor:`#2a3a1f`,icon:`#`,width:110,description:`Shows msg.payload. Its space is sized for the lowest to highest value.`,properties:[{name:`name`,label:`name`,kind:`text`,default:``},{name:`font`,label:`font (blank = fit the cells)`,kind:`select`,default:``,options:[{value:``,label:`auto (the largest that fits)`},...ol().map(e=>({value:e,label:e.replace(/^font_/,``)}))]},{name:`caption`,label:`caption (above the number)`,kind:`text`,default:``,help:`Static text above the value, in the theme's muted colour.`},{name:`units`,label:`units`,kind:`text`,default:``},{name:`decimals`,label:`decimals`,kind:`number`,default:1,min:0,max:6},{name:`lo`,label:`lowest value`,kind:`number`,default:0},{name:`hi`,label:`highest value`,kind:`number`,default:100},{name:`staleAfter`,label:`stale after (s, 0 = never)`,kind:`number`,default:0,min:0}]},Qf={...Yf(`thingstudio/gui_bar`),paletteId:`gui_bar`,label:`bar`,title:`show level`,group:`GUI`,priority:42,color:`#4a6e3f`,bgcolor:`#2a3a1f`,icon:`▬`,width:90,properties:[{name:`name`,label:`name`,kind:`text`,default:``},{name:`style`,label:`style`,kind:`select`,default:`solid`,options:[{value:`solid`,label:`solid (outline and fill)`},{value:`segments`,label:`segments (cells)`}]},{name:`segments`,label:`cells`,kind:`number`,default:10,min:1,max:40,visibleWhen:{field:`style`,equals:`segments`}},{name:`lo`,label:`empty at`,kind:`number`,default:0},{name:`hi`,label:`full at`,kind:`number`,default:100},{name:`staleAfter`,label:`stale after (s, 0 = never)`,kind:`number`,default:0,min:0}]},$f={...Yf(`thingstudio/gui_trend`),paletteId:`gui_trend`,label:`histogram`,title:`show history`,group:`GUI`,priority:45,color:`#4a6e3f`,bgcolor:`#2a3a1f`,icon:`▁▃▆`,width:100,description:`A histogram of the series a journal sends, newest on the right, or any list of numbers (None is a gap). A wider space shows more history.`,properties:[{name:`name`,label:`name`,kind:`text`,default:``},{name:`lo`,label:`bottom at`,kind:`number`,default:0,step:`any`},{name:`hi`,label:`top at`,kind:`number`,default:100,step:`any`},{name:`columns`,label:`columns (natural width)`,kind:`number`,default:60,min:1},{name:`colWidth`,label:`column width (px)`,kind:`number`,default:3,min:1},{name:`height`,label:`height (px)`,kind:`number`,default:48,min:8},{name:`staleAfter`,label:`stale after (s, 0 = never)`,kind:`number`,default:0,min:0}]},ep={...Yf(`thingstudio/gui_led`),paletteId:`gui_led`,label:`light`,title:`status light`,group:`GUI`,priority:43,color:`#4a6e3f`,bgcolor:`#2a3a1f`,icon:`●`,width:90,description:`On when msg.payload is true, off when false.`,properties:[{name:`name`,label:`name`,kind:`text`,default:``},{name:`style`,label:`style`,kind:`select`,default:`light`,options:[{value:`light`,label:`light (circle)`},{value:`chip`,label:`chip (text pill)`}]},{name:`onText`,label:`chip when on`,kind:`text`,default:`On`,visibleWhen:{field:`style`,equals:`chip`}},{name:`offText`,label:`chip when off`,kind:`text`,default:`Off`,visibleWhen:{field:`style`,equals:`chip`}},{name:`staleAfter`,label:`stale after (s, 0 = never)`,kind:`number`,default:0,min:0}]},tp={...Yf(_l),paletteId:`gui_button`,label:`button`,title:`touch button`,group:`GUI`,priority:44,color:`#4a6e3f`,bgcolor:`#2a3a1f`,icon:`▭`,width:100,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},properties:[{name:`name`,label:`topic`,kind:`text`,default:``},{name:`mode`,label:`mode`,kind:`select`,default:`momentary`,options:[{value:`momentary`,label:`momentary: sends a value`},{value:`toggle`,label:`toggle: sends the opposite of its state`},{value:`navigate`,label:`navigate: changes page`}]},{name:`style`,label:`style`,kind:`select`,default:`box`,options:[{value:`box`,label:`box (outline and text)`},{value:`filled`,label:`filled (solid)`},{value:`switch`,label:`switch (a toggle)`}],help:`A switch style needs a toggle button.`},{name:`valueType`,label:`value type`,kind:`select`,default:`bool`,visibleWhen:{field:`mode`,notEquals:`navigate`},options:[{value:`bool`,label:`true / false`},{value:`string`,label:`text`},{value:`number`,label:`number`}]},{name:`fireOn`,label:`send on`,kind:`select`,default:`release`,visibleWhen:{field:`mode`,notEquals:`navigate`},options:[{value:`release`,label:`release (inside the button)`},{value:`press`,label:`press`}]},{name:`text`,label:`board label (drawn on the button)`,kind:`text`,default:``,visibleWhen:{field:`mode`,equals:`momentary`},help:`What is drawn on the button; blank uses the flow label.`},{name:`value`,label:`sends (the payload)`,kind:`text`,default:``,visibleWhen:{field:`mode`,equals:`momentary`},placeholderWhen:[{when:{field:`valueType`,equals:`string`},text:`ON`},{when:{field:`valueType`,equals:`number`},text:`1`},{text:`true`}],help:`Sends this when tapped (the topic is above). The board label is what is drawn on the button (blank: the flow label); a msg.payload on its input replaces it.`},{name:`maxChars`,label:`room for (characters, if no text)`,kind:`number`,default:8,min:1,visibleWhen:{field:`mode`,equals:`momentary`}},{name:`onValue`,label:`on sends`,kind:`text`,default:``,visibleWhen:{field:`mode`,equals:`toggle`},placeholderWhen:[{when:{field:`valueType`,equals:`string`},text:`ON`},{when:{field:`valueType`,equals:`number`},text:`1`},{text:`true`}],help:`Wire its input to the real state (a plug's MQTT status) and the flow owns it: it shows -- until the first report, a tap shows the requested state hollow until the input confirms it, and with no answer it goes back and flags the failure. Unwired, it keeps its own state. Its output sends the new state; wire it to whatever switches the device.`},{name:`offValue`,label:`off sends`,kind:`text`,default:``,visibleWhen:{field:`mode`,equals:`toggle`},placeholderWhen:[{when:{field:`valueType`,equals:`string`},text:`OFF`},{when:{field:`valueType`,equals:`number`},text:`0`},{text:`false`}]},{name:`onText`,label:`on shows`,kind:`text`,default:`ON`,visibleWhen:{field:`mode`,equals:`toggle`}},{name:`offText`,label:`off shows`,kind:`text`,default:`OFF`,visibleWhen:{field:`mode`,equals:`toggle`}},{name:`initial`,label:`starts on (when nothing is wired in)`,kind:`boolean`,default:!1,visibleWhen:{field:`mode`,equals:`toggle`}},{name:`pendingTimeout`,label:`wait for confirmation (s, 5 or more)`,kind:`number`,default:5,min:5,visibleWhen:{field:`mode`,equals:`toggle`}},{name:`target`,label:`goes to`,kind:`text`,default:``,visibleWhen:{field:`mode`,equals:`navigate`},placeholder:`next, prev, back, home or a page name`,help:`Acts on its own screen; needs no wires.`}],codegenEventSource(e,t){let n=Kf(t),r=Wf(e),i=typeof e.properties.name==`string`&&e.properties.name?e.properties.name:e.id;if(r.mode===`navigate`){let n=Object.values(t.screens??{}).find(t=>hf(t).has(e.id));if(n&&!Uf.includes(r.target)&&!n.pages.some(e=>e.name===r.target))throw new L(`button ${bl(e)}: "${r.target}" isn't next, prev, back, home or a page on its screen`)}else t.isOutputWired?.(e.id)===!1&&t.warn?.(`button ${bl(e)} sends ${r.mode===`toggle`?`its state`:`its value`} nowhere: wire its output to something.`);return{imports:n.imports,statements:n.statements,waitStatement:`_btn = await _gui.event(${z(e.id)})`,buildMsg:`msg = {'payload': _btn, 'topic': ${z(i)}}`}}},np={type:`thingstudio/gui_navigator`,kind:`transform`,paletteId:`gui_navigator`,label:`navigator`,title:`change page`,group:`GUI`,priority:20,color:`#3f5c6e`,bgcolor:`#1f303a`,icon:`⇆`,width:120,hidden:!0,description:`msg.payload: next, prev, back, home or a page name. Sends the new page when it changes.`,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`page`,type:`string`}]},properties:[{name:`name`,label:`name`,kind:`text`,default:`navigator`},{name:`screen`,label:`screen`,kind:`text`,default:``,placeholder:`only needed with two screens`}],codegenTransform(e,t){let n=Kf(t),r=qf(t,e),i=typeof e.properties.name==`string`&&e.properties.name?e.properties.name:`navigator`;return{imports:n.imports,statements:n.statements,functionName:t.uniqueName(`gui_navigator`),functionBody:[`_cmd = msg.get('payload')`,`if not isinstance(_cmd, str):`,`    raise ValueError('navigator wants next, prev, back, home or a page name, got %r' % (_cmd,))`,`_before = _gui.surfaces[${z(r)}].page`,`_after = _gui.navigate(${z(r)}, _cmd)`,`_page = _gui.surfaces[${z(r)}].page`,`if _page == _before:`,`    return None`,`return {'topic': ${z(i)}, 'payload': _page}`].join(`
`)}}},rp={type:gl,kind:`sink`,paletteId:`gui_modal`,label:`modal`,title:`pop-up alert`,group:`GUI`,priority:30,color:`#6e3f3f`,bgcolor:`#3a1f1f`,icon:`!`,width:100,description:`Opens with msg.payload as its content; a payload of None closes it. The output sends how it closed: ack, timeout or closed.`,ports:{inputs:[{name:`msg`,type:`any`}],outputs:[{name:`msg`,type:`any`}]},properties:[{name:`name`,label:`name`,kind:`text`,default:``},{name:`screen`,label:`screen`,kind:`text`,default:``,placeholder:`only needed with two screens`},{name:`priority`,label:`priority`,kind:`number`,default:0},{name:`timeout`,label:`close after (s, 0 = never)`,kind:`number`,default:0,min:0}],codegenSink(e,t){let n=Kf(t),r=qf(t,e);return ip(t,e),{imports:n.imports,statements:n.statements,functionName:t.uniqueName(`gui_modal`),functionBody:`_gui.open_modal(${z(r)}, ${z(kl(e))}, msg.get('payload'))`}},codegenEventSource(e,t){let n=Kf(t),r=qf(t,e);ip(t,e);let i=kl(e);return{imports:n.imports,statements:[...n.statements,{key:`gui_modal_watch_${e.id}`,code:`_gui.watch_modal(${z(r)}, ${z(i)})`}],waitStatement:`_reason = await _gui.modal_closed(${z(r)}, ${z(i)})`,buildMsg:`msg = {'payload': _reason, 'topic': ${z(i)}}`}}};function ip(e,t){if(!Hf(e).surfaces.some(e=>e.modalsPy.includes(z(kl(t))+`:`)))throw new L(`modal ${bl(t)} isn't laid out on its screen yet: add it in the GUI view`)}var ap=[Jf,Xf,Zf,Qf,$f,ep,tp,np,rp];function op(e,t,n){return mu(e,t,n)}function sp(){let e=new Map;for(let t of[mu(Ju,Yu),mu(od,sd),Nu,mu(Pu,Fu),mu(js,Ms),mu(Xu,Zu),mu(vu,yu),mu(bu,xu),op(Su,wu,Cu),mu(Tu,Eu),mu(Du,Ou),op(Ys,ec,$s),mu(Ns,Ps),mu(id,ad),mu(cd,ld),op(Sd,wd,Cd),op(yd,xd,bd),op(Vu,Uu,Hu),op(Ru,Bu,zu),mu(Wu,Gu),op(Qu,ed,$u),op(td,rd,nd),op(pd,hd,md),op(ud,fd,dd),op(gd,vd,_d),op(Td,Dd,Ed),op(Id,Rd,Ld),op(zd,Vd,Bd),op(Hd,Wd,Ud),op(Gd,qd,Kd),op(Jd,Xd,Yd),op(Zd,ef,$d),op(tf,rf,nf),op(af,sf,of),op(tc,rc,nc),mu(ic,ac),mu(oc,sc),mu(cc,lc),mu(uc,dc),op(fc,mc,pc),mu(gu,_u),...ap])e.set(t.type,t);return e}function cp(e,t,n){let r=Array(t.ports?.inputs?.length??0).fill(!1),i=Array(t.ports?.outputs?.length??0).fill(!1);for(let[,t,a,o,s]of n.links)t===e.id&&a>=0&&a<i.length&&(i[a]=!0),o===e.id&&s>=0&&s<r.length&&(r[s]=!0);return{inputs:r,outputs:i}}function lp(e){return e?{boardId:e.board?e.board.id:null,boardName:e.board?e.board.name:null,processorId:e.processor.id,processorName:e.processor.name,label:e.label,capabilities:[...e.capabilities].sort()}:null}function up(e,t,n){let r={};for(let i of e.properties??[]){if(i.kind!==`configRef`||!i.name)continue;let e=i.configType,a;if(i.singleton&&e){let t=n.filter(t=>t.type===e);t.length===1&&(a=t[0])}else{let e=t.properties[i.name];typeof e==`string`&&e!==``&&(a=n.find(t=>t.id===e))}a&&(r[a.id]={...a.properties})}return r}function dp(e){let{graphData:t,node:n,descriptor:r,target:i,redactConfig:a}=e,o=t.configs??[],s=a??(e=>e.properties);return{version:1,node:{id:n.id,type:n.type,properties:{...n.properties},wired:cp(n,r,t)},flow:{nodes:t.nodes.map(e=>({id:e.id,type:e.type,properties:{...e.properties}})),configs:o.map(e=>({id:e.id,type:e.type,properties:s(e)})),links:t.links.map(([,e,t,n,r])=>[e,t,n,r])},nodesOfType:t.nodes.filter(e=>e.type===n.type).map(e=>({id:e.id,type:e.type,properties:{...e.properties}})),referencedConfigs:up(r,n,o),target:lp(i)}}var fp={propertiesBytes:65536,claims:64,warnings:32,errors:32,hookWallMs:1e3,compileWallMs:5e3},pp=new Set([`properties`,`claims`,`warnings`,`errors`]);function mp(e){return typeof e==`object`&&!!e&&!Array.isArray(e)&&Object.getPrototypeOf(e)===Object.prototype}function hp(e,t,n){if(e!==null&&typeof e!=`boolean`&&typeof e!=`string`){if(typeof e==`number`){if(!Number.isFinite(e))throw new L(`${t} is ${String(e)}; numbers must be finite`)}else{if(typeof e!=`object`)throw new L(`${t} is ${typeof e}; only JSON values are allowed`);if(n.has(e))throw new L(`${t} contains a cycle`);if(n.add(e),Array.isArray(e))e.forEach((e,r)=>hp(e,`${t}[${r}]`,n));else if(mp(e))for(let[r,i]of Object.entries(e))hp(i,`${t}.${r}`,n);else throw new L(`${t} is not a plain object or array`);n.delete(e)}}}function gp(e,t,n,r){if(e===void 0)return[];if(!Array.isArray(e))throw new L(`${r}: compile hook "${t}" must be a list of strings`);if(e.length>n)throw new L(`${r}: compile hook returned ${e.length} ${t}, limit is ${n}`);return e.map((e,n)=>{if(typeof e!=`string`)throw new L(`${r}: compile hook ${t}[${n}] must be a string`);return e})}function _p(e,t){if(e==null)return{properties:{},claims:[],warnings:[],errors:[]};if(!mp(e))throw new L(`${t}: compile hook must return a dict, not ${Array.isArray(e)?`a list`:typeof e}`);for(let n of Object.keys(e))if(!pp.has(n))throw new L(`${t}: compile hook returned unknown key "${n}" (allowed: ${[...pp].join(`, `)})`);let n={};if(e.properties!==void 0){if(!mp(e.properties))throw new L(`${t}: compile hook "properties" must be a dict`);hp(e.properties,`${t} compile hook properties`,new Set);let r=new TextEncoder().encode(JSON.stringify(e.properties)).length;if(r>fp.propertiesBytes)throw new L(`${t}: compile hook properties are ${r} bytes, limit is ${fp.propertiesBytes}`);n=e.properties}let r=[];if(e.claims!==void 0){if(!Array.isArray(e.claims))throw new L(`${t}: compile hook "claims" must be a list`);if(e.claims.length>fp.claims)throw new L(`${t}: compile hook returned ${e.claims.length} claims, limit is ${fp.claims}`);r=e.claims.map((e,n)=>{if(!mp(e)||typeof e.resource!=`string`||e.resource===``||typeof e.use!=`string`||e.use===``)throw new L(`${t}: compile hook claims[${n}] must be {"resource": non-empty string, "use": non-empty string}`);for(let r of Object.keys(e))if(r!==`resource`&&r!==`use`)throw new L(`${t}: compile hook claims[${n}] has unknown key "${r}"`);return{resource:e.resource,use:e.use}})}return{properties:n,claims:r,warnings:gp(e.warnings,`warnings`,fp.warnings,t),errors:gp(e.errors,`errors`,fp.errors,t)}}function vp(e,t){if(e.errors.length!==0)throw new L(`${t}: ${e.errors.join(`; `)}`)}function yp(e){return`${e.type} (node ${e.id})`}async function bp(e,t,n,r={}){let i=new Map,a=[],o=Date.now(),s=r.compileTimeoutMs??fp.compileWallMs;for(let c of e.nodes){let l=t.get(c.type);if(!l||l.compileHook===void 0)continue;let u=yp(c);if(Date.now()-o>=s)throw new L(`${u}: package compile hooks exceeded the ${s} ms compile budget`);let d=dp({graphData:e,node:c,descriptor:l,target:r.target,redactConfig:r.redactConfig}),f;try{f=await n.run(l.compileHook,d,{...c.properties},u)}catch(e){throw e instanceof L?e:new L(`${u}: compile hook failed: ${e instanceof Error?e.message:String(e)}`)}let p=_p(f,u);vp(p,u);for(let e of p.warnings)a.push(`${u}: ${e}`);i.set(c.id,p)}return{results:i,warnings:a}}function xp(e){let t=Promise.resolve(),n=0,r;function i(e){let n=t.then(e,e);return t=n.then(()=>void 0,()=>void 0),n}return{latest(){let t=++n;return i(async()=>(t!==n&&r!==void 0||(r=await e()),r))},now(){return i(async()=>(r=await e(),r))}}}function Sp(e){return typeof e==`object`&&!!e}function Cp(e){let t=e.wasmUrl??`/vendor/micropython-wasi/micropython-wasi.wasm`,n=e.timeoutMs??1e3,r=e.initTimeoutMs??1e4,i=1,a=null,o=null,s=new Map;function c(e){for(let t of s.values())clearTimeout(t.timer),t.reject(Error(e));s.clear()}function l(e){c(e),a?.terminate(),a=null,o=null}function u(){if(o)return o;a=e.createWorker(t);let n=a;return o=new Promise((e,t)=>{let i=setTimeout(()=>{t(Error(`compile-hook worker did not start within ${r} ms`)),l(`compile-hook worker did not start within ${r} ms`)},r);n.onError(e=>{clearTimeout(i),t(Error(`compile-hook worker failed to start: ${e instanceof Error?e.message:String(e)}`)),l(`compile-hook worker failed to start`)}),n.onMessage(n=>{if(Sp(n)){if(n.type===`ready`)clearTimeout(i),e();else if(n.type===`init-error`)clearTimeout(i),t(Error(String(n.error??`compile-hook interpreter failed to load`))),l(`compile-hook interpreter failed to load`);else if(n.type===`result`&&typeof n.id==`number`){let e=s.get(n.id);if(!e)return;s.delete(n.id),clearTimeout(e.timer),n.ok?e.resolve(n.value):e.reject(Error(String(n.error??`compile hook failed`)))}}})}),o.catch(()=>{a===n&&(a=null,o=null)}),o}return{async run(e,t,r){await u();let o=a;if(!o)throw Error(`compile-hook worker is not running`);let c=i++;return new Promise((i,a)=>{let u=setTimeout(()=>{l(`compile hook timed out after ${n} ms`)},n);s.set(c,{resolve:i,reject:a,timer:u}),o.postMessage({type:`run`,id:c,hookSource:e,context:t,properties:r})})}}}function wp(){return e=>{let t=new Worker(new URL(`/assets/hook-worker-BRSYdYD8.js`,``+import.meta.url),{type:`module`});return t.postMessage({type:`init`,wasmUrl:e}),{postMessage:e=>t.postMessage(e),onMessage:e=>{t.onmessage=t=>e(t.data)},onError:e=>{t.onerror=t=>{let n=t.message||(t.filename?`${t.filename}: load failed`:`worker script failed to load`);e(Error(n))},t.onmessageerror=t=>e(Error(`compile-hook worker message failed to deserialise: ${String(t.data)}`))},terminate:()=>t.terminate()}}}var Tp=[`Object`,`RegExp`,`Date`,`Error`,`Map`,`Set`,`WeakMap`,`WeakSet`,`ArrayBuffer`,`SharedArrayBuffer`,`DataView`,`Promise`,`URL`,`HTMLElement`,`Int8Array`,`Uint8ClampedArray`,`Int16Array`,`Uint16Array`,`Int32Array`,`Uint32Array`,`Float32Array`,`Float64Array`,`BigInt64Array`,`BigUint64Array`,`Tagged`];function Ep(e){if(e===null)return`null`;if(e===void 0)return`undefined`;if(e===!0||e===!1)return`boolean`;let t=typeof e;return t===`string`||t===`number`||t===`bigint`||t===`symbol`?t:t===`function`?`Function`:Array.isArray(e)?`Array`:e instanceof Uint8Array?`Uint8Array`:e.constructor===Object?`Object`:Dp(e)||`Object`}function Dp(e){let t=Object.prototype.toString.call(e).slice(8,-1);if(Tp.includes(t))return t}var B=class{constructor(e,t,n){this.major=e,this.majorEncoded=e<<5,this.name=t,this.terminal=n}toString(){return`Type[${this.major}].${this.name}`}compare(e){return this.major<e.major?-1:+(this.major>e.major)}static equals(e,t){return e===t||e.major===t.major&&e.name===t.name}};B.uint=new B(0,`uint`,!0),B.negint=new B(1,`negint`,!0),B.bytes=new B(2,`bytes`,!0),B.string=new B(3,`string`,!0),B.array=new B(4,`array`,!1),B.map=new B(5,`map`,!1),B.tag=new B(6,`tag`,!1),B.float=new B(7,`float`,!0),B.false=new B(7,`false`,!0),B.true=new B(7,`true`,!0),B.null=new B(7,`null`,!0),B.undefined=new B(7,`undefined`,!0),B.break=new B(7,`break`,!0);var V=class{constructor(e,t,n){this.type=e,this.value=t,this.encodedLength=n,this.encodedBytes=void 0,this.byteValue=void 0}toString(){return`Token[${this.type}].${this.value}`}},Op=globalThis.process&&!globalThis.process.browser&&globalThis.Buffer&&typeof globalThis.Buffer.isBuffer==`function`,kp=new TextEncoder;function Ap(e){return Op&&globalThis.Buffer.isBuffer(e)}function jp(e){return e instanceof Uint8Array?Ap(e)?new Uint8Array(e.buffer,e.byteOffset,e.byteLength):e:Uint8Array.from(e)}var Mp=24,Np=200,Pp=Op?e=>e.length>=Mp?globalThis.Buffer.from(e):Bp(e):e=>e.length>=Np?kp.encode(e):Bp(e),Fp=e=>Uint8Array.from(e),Ip=Op?(e,t,n)=>Ap(e)?new Uint8Array(e.subarray(t,n)):e.slice(t,n):(e,t,n)=>e.slice(t,n),Lp=Op?(e,t)=>(e=e.map(e=>e instanceof Uint8Array?e:globalThis.Buffer.from(e)),jp(globalThis.Buffer.concat(e,t))):(e,t)=>{let n=new Uint8Array(t),r=0;for(let t of e)r+t.length>n.length&&(t=t.subarray(0,n.length-r)),n.set(t,r),r+=t.length;return n},Rp=Op?e=>globalThis.Buffer.allocUnsafe(e):e=>new Uint8Array(e);function zp(e,t){if(Ap(e)&&Ap(t))return e.compare(t);for(let n=0;n<e.length;n++)if(e[n]!==t[n])return e[n]<t[n]?-1:1;return 0}function Bp(e){let t=[],n=0;for(let r=0;r<e.length;r++){let i=e.charCodeAt(r);i<128?t[n++]=i:i<2048?(t[n++]=i>>6|192,t[n++]=i&63|128):(i&64512)==55296&&r+1<e.length&&(e.charCodeAt(r+1)&64512)==56320?(i=65536+((i&1023)<<10)+(e.charCodeAt(++r)&1023),t[n++]=i>>18|240,t[n++]=i>>12&63|128,t[n++]=i>>6&63|128,t[n++]=i&63|128):(i>=55296&&i<=57343&&(i=65533),t[n++]=i>>12|224,t[n++]=i>>6&63|128,t[n++]=i&63|128)}return t}var Vp=256,Hp=class{constructor(e=Vp){this.chunkSize=e,this.cursor=0,this.maxCursor=-1,this.chunks=[],this._initReuseChunk=null}reset(){this.cursor=0,this.maxCursor=-1,this.chunks.length&&(this.chunks=[]),this._initReuseChunk!==null&&(this.chunks.push(this._initReuseChunk),this.maxCursor=this._initReuseChunk.length-1)}pushByte(e){let t=this.chunks[this.chunks.length-1];this.cursor>this.maxCursor&&(t=Rp(this.chunkSize),this.chunks.push(t),this.maxCursor+=t.length,this._initReuseChunk===null&&(this._initReuseChunk=t));let n=t.length-(this.maxCursor-this.cursor)-1;t[n]=e,this.cursor++}push(e){let t=this.chunks[this.chunks.length-1];if(this.cursor+e.length<=this.maxCursor+1){let n=t.length-(this.maxCursor-this.cursor)-1;t.set(e,n)}else{if(t){let e=t.length-(this.maxCursor-this.cursor)-1;e<t.length&&(this.chunks[this.chunks.length-1]=t.subarray(0,e),this.maxCursor=this.cursor-1)}e.length<64&&e.length<this.chunkSize?(t=Rp(this.chunkSize),this.chunks.push(t),this.maxCursor+=t.length,this._initReuseChunk===null&&(this._initReuseChunk=t),t.set(e,0)):(this.chunks.push(e),this.maxCursor+=e.length)}this.cursor+=e.length}toBytes(e=!1){let t;if(this.chunks.length===1){let n=this.chunks[0];e&&this.cursor>n.length/2?(t=this.cursor===n.length?n:n.subarray(0,this.cursor),this._initReuseChunk=null,this.chunks=[]):t=Ip(n,0,this.cursor)}else t=Lp(this.chunks,this.cursor);return e&&this.reset(),t}},Up=class{constructor(e){this.dest=e,this.cursor=0,this.chunks=[e]}reset(){this.cursor=0}pushByte(e){if(this.cursor>=this.dest.length)throw Error(`write out of bounds, destination buffer is too small`);this.dest[this.cursor++]=e}push(e){if(this.cursor+e.length>this.dest.length)throw Error(`write out of bounds, destination buffer is too small`);this.dest.set(e,this.cursor),this.cursor+=e.length}toBytes(e=!1){let t=this.dest.subarray(0,this.cursor);return e&&this.reset(),t}},Wp=`CBOR decode error:`,Gp=`CBOR encode error:`;function Kp(e,t,n){if(e.length-t<n)throw Error(`${Wp} not enough data for type`)}var qp=[24,256,65536,4294967296,BigInt(`18446744073709551616`)];function Jp(e,t,n){Kp(e,t,1);let r=e[t];if(n.strict===!0&&r<qp[0])throw Error(`${Wp} integer encoded in more bytes than necessary (strict decode)`);return r}function Yp(e,t,n){Kp(e,t,2);let r=e[t]<<8|e[t+1];if(n.strict===!0&&r<qp[1])throw Error(`${Wp} integer encoded in more bytes than necessary (strict decode)`);return r}function Xp(e,t,n){Kp(e,t,4);let r=e[t]*16777216+(e[t+1]<<16)+(e[t+2]<<8)+e[t+3];if(n.strict===!0&&r<qp[2])throw Error(`${Wp} integer encoded in more bytes than necessary (strict decode)`);return r}function Zp(e,t,n){Kp(e,t,8);let r=e[t]*16777216+(e[t+1]<<16)+(e[t+2]<<8)+e[t+3],i=e[t+4]*16777216+(e[t+5]<<16)+(e[t+6]<<8)+e[t+7],a=(BigInt(r)<<BigInt(32))+BigInt(i);if(n.strict===!0&&a<qp[3])throw Error(`${Wp} integer encoded in more bytes than necessary (strict decode)`);if(a<=2**53-1)return Number(a);if(n.allowBigInt===!0)return a;throw Error(`${Wp} integers outside of the safe integer range are not supported`)}function Qp(e,t,n,r){return new V(B.uint,Jp(e,t+1,r),2)}function $p(e,t,n,r){return new V(B.uint,Yp(e,t+1,r),3)}function em(e,t,n,r){return new V(B.uint,Xp(e,t+1,r),5)}function tm(e,t,n,r){return new V(B.uint,Zp(e,t+1,r),9)}function nm(e,t){return rm(e,0,t.value)}function rm(e,t,n){if(n<qp[0]){let r=Number(n);e.pushByte(t|r)}else if(n<qp[1]){let r=Number(n);e.push([t|24,r])}else if(n<qp[2]){let r=Number(n);e.push([t|25,r>>>8,r&255])}else if(n<qp[3]){let r=Number(n);e.push([t|26,r>>>24&255,r>>>16&255,r>>>8&255,r&255])}else{let r=BigInt(n);if(r<qp[4]){let n=[t|27,0,0,0,0,0,0,0],i=Number(r&BigInt(4294967295)),a=Number(r>>BigInt(32)&BigInt(4294967295));n[8]=i&255,i>>=8,n[7]=i&255,i>>=8,n[6]=i&255,i>>=8,n[5]=i&255,n[4]=a&255,a>>=8,n[3]=a&255,a>>=8,n[2]=a&255,a>>=8,n[1]=a&255,e.push(n)}else throw Error(`${Wp} encountered BigInt larger than allowable range`)}}nm.encodedSize=function(e){return rm.encodedSize(e.value)},rm.encodedSize=function(e){return e<qp[0]?1:e<qp[1]?2:e<qp[2]?3:e<qp[3]?5:9},nm.compareTokens=function(e,t){return e.value<t.value?-1:+(e.value>t.value)};function im(e,t,n,r){return new V(B.negint,-1-Jp(e,t+1,r),2)}function am(e,t,n,r){return new V(B.negint,-1-Yp(e,t+1,r),3)}function om(e,t,n,r){return new V(B.negint,-1-Xp(e,t+1,r),5)}var sm=BigInt(-1),cm=BigInt(1);function lm(e,t,n,r){let i=Zp(e,t+1,r);if(typeof i!=`bigint`){let e=-1-i;if(e>=-(2**53-1))return new V(B.negint,e,9)}if(r.allowBigInt!==!0)throw Error(`${Wp} integers outside of the safe integer range are not supported`);return new V(B.negint,sm-BigInt(i),9)}function um(e,t){let n=t.value,r=typeof n==`bigint`?n*sm-cm:n*-1-1;rm(e,t.type.majorEncoded,r)}um.encodedSize=function(e){let t=e.value,n=typeof t==`bigint`?t*sm-cm:t*-1-1;return n<qp[0]?1:n<qp[1]?2:n<qp[2]?3:n<qp[3]?5:9},um.compareTokens=function(e,t){return e.value<t.value?1:e.value>t.value?-1:0};function dm(e,t,n,r){Kp(e,t,n+r);let i=e.slice(t+n,t+n+r);return new V(B.bytes,i,n+r)}function fm(e,t,n,r){return dm(e,t,1,n)}function pm(e,t,n,r){return dm(e,t,2,Jp(e,t+1,r))}function mm(e,t,n,r){return dm(e,t,3,Yp(e,t+1,r))}function hm(e,t,n,r){return dm(e,t,5,Xp(e,t+1,r))}function gm(e,t,n,r){let i=Zp(e,t+1,r);if(typeof i==`bigint`)throw Error(`${Wp} 64-bit integer bytes lengths not supported`);return dm(e,t,9,i)}function _m(e){return e.encodedBytes===void 0&&(e.encodedBytes=B.equals(e.type,B.string)?Pp(e.value):e.value),e.encodedBytes}function vm(e,t){let n=_m(t);rm(e,t.type.majorEncoded,n.length),e.push(n)}vm.encodedSize=function(e){let t=_m(e);return rm.encodedSize(t.length)+t.length},vm.compareTokens=function(e,t){return ym(_m(e),_m(t))};function ym(e,t){return e.length<t.length?-1:e.length>t.length?1:zp(e,t)}var bm=new TextDecoder,xm=32;function Sm(e,t,n){if(n-t<xm){let r=``;for(let i=t;i<n;i++){let a=e[i];if(a&128)return bm.decode(e.subarray(t,n));r+=String.fromCharCode(a)}return r}return bm.decode(e.subarray(t,n))}function Cm(e,t,n,r,i){let a=n+r;Kp(e,t,a);let o=new V(B.string,Sm(e,t+n,t+a),a);return i.retainStringBytes===!0&&(o.byteValue=e.slice(t+n,t+a)),o}function wm(e,t,n,r){return Cm(e,t,1,n,r)}function Tm(e,t,n,r){return Cm(e,t,2,Jp(e,t+1,r),r)}function Em(e,t,n,r){return Cm(e,t,3,Yp(e,t+1,r),r)}function Dm(e,t,n,r){return Cm(e,t,5,Xp(e,t+1,r),r)}function Om(e,t,n,r){let i=Zp(e,t+1,r);if(typeof i==`bigint`)throw Error(`${Wp} 64-bit integer string lengths not supported`);return Cm(e,t,9,i,r)}var km=vm;function Am(e,t,n,r){return new V(B.array,r,n)}function jm(e,t,n,r){return Am(e,t,1,n)}function Mm(e,t,n,r){return Am(e,t,2,Jp(e,t+1,r))}function Nm(e,t,n,r){return Am(e,t,3,Yp(e,t+1,r))}function Pm(e,t,n,r){return Am(e,t,5,Xp(e,t+1,r))}function Fm(e,t,n,r){let i=Zp(e,t+1,r);if(typeof i==`bigint`)throw Error(`${Wp} 64-bit integer array lengths not supported`);return Am(e,t,9,i)}function Im(e,t,n,r){if(r.allowIndefinite===!1)throw Error(`${Wp} indefinite length items not allowed`);return Am(e,t,1,1/0)}function Lm(e,t){rm(e,B.array.majorEncoded,t.value)}Lm.compareTokens=nm.compareTokens,Lm.encodedSize=function(e){return rm.encodedSize(e.value)};function Rm(e,t,n,r){return new V(B.map,r,n)}function zm(e,t,n,r){return Rm(e,t,1,n)}function Bm(e,t,n,r){return Rm(e,t,2,Jp(e,t+1,r))}function Vm(e,t,n,r){return Rm(e,t,3,Yp(e,t+1,r))}function Hm(e,t,n,r){return Rm(e,t,5,Xp(e,t+1,r))}function Um(e,t,n,r){let i=Zp(e,t+1,r);if(typeof i==`bigint`)throw Error(`${Wp} 64-bit integer map lengths not supported`);return Rm(e,t,9,i)}function Wm(e,t,n,r){if(r.allowIndefinite===!1)throw Error(`${Wp} indefinite length items not allowed`);return Rm(e,t,1,1/0)}function Gm(e,t){rm(e,B.map.majorEncoded,t.value)}Gm.compareTokens=nm.compareTokens,Gm.encodedSize=function(e){return rm.encodedSize(e.value)};function Km(e,t,n,r){return new V(B.tag,n,1)}function qm(e,t,n,r){return new V(B.tag,Jp(e,t+1,r),2)}function Jm(e,t,n,r){return new V(B.tag,Yp(e,t+1,r),3)}function Ym(e,t,n,r){return new V(B.tag,Xp(e,t+1,r),5)}function Xm(e,t,n,r){return new V(B.tag,Zp(e,t+1,r),9)}function Zm(e,t){rm(e,B.tag.majorEncoded,t.value)}Zm.compareTokens=nm.compareTokens,Zm.encodedSize=function(e){return rm.encodedSize(e.value)};function Qm(e,t,n,r){if(r.allowUndefined===!1)throw Error(`${Wp} undefined values are not supported`);return r.coerceUndefinedToNull===!0?new V(B.null,null,1):new V(B.undefined,void 0,1)}function $m(e,t,n,r){if(r.allowIndefinite===!1)throw Error(`${Wp} indefinite length items not allowed`);return new V(B.break,void 0,1)}function eh(e,t,n){if(n){if(n.allowNaN===!1&&Number.isNaN(e))throw Error(`${Wp} NaN values are not supported`);if(n.allowInfinity===!1&&(e===1/0||e===-1/0))throw Error(`${Wp} Infinity values are not supported`)}return new V(B.float,e,t)}function th(e,t,n,r){return eh(lh(e,t+1),3,r)}function nh(e,t,n,r){return eh(dh(e,t+1),5,r)}function rh(e,t,n,r){return eh(ph(e,t+1),9,r)}function ih(e,t,n){let r=t.value;if(r===!1)e.pushByte(B.float.majorEncoded|20);else if(r===!0)e.pushByte(B.float.majorEncoded|21);else if(r===null)e.pushByte(B.float.majorEncoded|22);else if(r===void 0)e.pushByte(B.float.majorEncoded|23);else{let t,i=!1;n&&n.float64===!0||(ch(r),t=lh(sh,1),r===t||Number.isNaN(r)?(sh[0]=249,e.push(sh.slice(0,3)),i=!0):(uh(r),t=dh(sh,1),r===t&&(sh[0]=250,e.push(sh.slice(0,5)),i=!0))),i||(fh(r),t=ph(sh,1),sh[0]=251,e.push(sh.slice(0,9)))}}ih.encodedSize=function(e,t){let n=e.value;if(n===!1||n===!0||n==null)return 1;if(!t||t.float64!==!0){ch(n);let e=lh(sh,1);if(n===e||Number.isNaN(n))return 3;if(uh(n),e=dh(sh,1),n===e)return 5}return 9};var ah=new ArrayBuffer(9),oh=new DataView(ah,1),sh=new Uint8Array(ah,0);function ch(e){if(e===1/0)oh.setUint16(0,31744,!1);else if(e===-1/0)oh.setUint16(0,64512,!1);else if(Number.isNaN(e))oh.setUint16(0,32256,!1);else{oh.setFloat32(0,e);let t=oh.getUint32(0),n=(t&2139095040)>>23,r=t&8388607;if(n===255)oh.setUint16(0,31744,!1);else if(n===0)oh.setUint16(0,(t&2147483648)>>16|r>>13,!1);else{let e=n-127;e<-24?oh.setUint16(0,0):e<-14?oh.setUint16(0,(t&2147483648)>>16|1<<24+e,!1):oh.setUint16(0,(t&2147483648)>>16|e+15<<10|r>>13,!1)}}}function lh(e,t){if(e.length-t<2)throw Error(`${Wp} not enough data for float16`);let n=(e[t]<<8)+e[t+1];if(n===31744)return 1/0;if(n===64512)return-1/0;if(n===32256)return NaN;let r=n>>10&31,i=n&1023,a;return a=r===0?i*2**-24:r===31?i===0?1/0:NaN:(i+1024)*2**(r-25),n&32768?-a:a}function uh(e){oh.setFloat32(0,e,!1)}function dh(e,t){if(e.length-t<4)throw Error(`${Wp} not enough data for float32`);let n=(e.byteOffset||0)+t;return new DataView(e.buffer,n,4).getFloat32(0,!1)}function fh(e){oh.setFloat64(0,e,!1)}function ph(e,t){if(e.length-t<8)throw Error(`${Wp} not enough data for float64`);let n=(e.byteOffset||0)+t;return new DataView(e.buffer,n,8).getFloat64(0,!1)}function mh(e,t){let n=e.value;if(n===!1)return Uint8Array.of(B.float.majorEncoded|20);if(n===!0)return Uint8Array.of(B.float.majorEncoded|21);if(n===null)return Uint8Array.of(B.float.majorEncoded|22);if(n===void 0)return Uint8Array.of(B.float.majorEncoded|23);if(!t){if(ch(n),n===lh(sh,1)||Number.isNaN(n))return sh[0]=249,sh.slice(0,3);if(uh(n),n===dh(sh,1))return sh[0]=250,sh.slice(0,5)}return fh(n),sh[0]=251,sh.slice(0,9)}function hh(e,t){let n=e,r=t?.float64===!0,i=r?n._keyBytesFloat64:n._keyBytes;if(i!==void 0)return i;let a=mh(e,r);return r?n._keyBytesFloat64=a:n._keyBytes=a,a}ih.compareTokens=function(e,t,n){let r=hh(e,n),i=hh(t,n);return r.length===i.length?zp(r,i):r.length<i.length?-1:1};function H(e,t,n){throw Error(`${Wp} encountered invalid minor (${n}) for major ${e[t]>>>5}`)}function gh(e){return()=>{throw Error(`${Wp} ${e}`)}}var U=[];for(let e=0;e<=23;e++)U[e]=H;U[24]=Qp,U[25]=$p,U[26]=em,U[27]=tm,U[28]=H,U[29]=H,U[30]=H,U[31]=H;for(let e=32;e<=55;e++)U[e]=H;U[56]=im,U[57]=am,U[58]=om,U[59]=lm,U[60]=H,U[61]=H,U[62]=H,U[63]=H;for(let e=64;e<=87;e++)U[e]=fm;U[88]=pm,U[89]=mm,U[90]=hm,U[91]=gm,U[92]=H,U[93]=H,U[94]=H,U[95]=gh(`indefinite length bytes/strings are not supported`);for(let e=96;e<=119;e++)U[e]=wm;U[120]=Tm,U[121]=Em,U[122]=Dm,U[123]=Om,U[124]=H,U[125]=H,U[126]=H,U[127]=gh(`indefinite length bytes/strings are not supported`);for(let e=128;e<=151;e++)U[e]=jm;U[152]=Mm,U[153]=Nm,U[154]=Pm,U[155]=Fm,U[156]=H,U[157]=H,U[158]=H,U[159]=Im;for(let e=160;e<=183;e++)U[e]=zm;U[184]=Bm,U[185]=Vm,U[186]=Hm,U[187]=Um,U[188]=H,U[189]=H,U[190]=H,U[191]=Wm;for(let e=192;e<=215;e++)U[e]=Km;U[216]=qm,U[217]=Jm,U[218]=Ym,U[219]=Xm,U[220]=H,U[221]=H,U[222]=H,U[223]=H;for(let e=224;e<=243;e++)U[e]=gh(`simple values are not supported`);U[244]=H,U[245]=H,U[246]=H,U[247]=Qm,U[248]=gh(`simple values are not supported`),U[249]=th,U[250]=nh,U[251]=rh,U[252]=H,U[253]=H,U[254]=H,U[255]=$m;var _h=[];for(let e=0;e<24;e++)_h[e]=new V(B.uint,e,1);for(let e=-1;e>=-24;e--)_h[31-e]=new V(B.negint,e,1);_h[64]=new V(B.bytes,new Uint8Array,1),_h[96]=new V(B.string,``,1),_h[128]=new V(B.array,0,1),_h[160]=new V(B.map,0,1),_h[244]=new V(B.false,!1,1),_h[245]=new V(B.true,!0,1),_h[246]=new V(B.null,null,1);function vh(e){switch(e.type){case B.false:return Fp([244]);case B.true:return Fp([245]);case B.null:return Fp([246]);case B.bytes:return e.value.length?void 0:Fp([64]);case B.string:return e.value===``?Fp([96]):void 0;case B.array:return e.value===0?Fp([128]):void 0;case B.map:return e.value===0?Fp([160]):void 0;case B.uint:return e.value<24?Fp([Number(e.value)]):void 0;case B.negint:if(e.value>=-24)return Fp([31-Number(e.value)])}}var yh=Object.freeze({mapSorter:Oh,quickEncodeToken:vh});function bh(){let e=[];return e[B.uint.major]=nm,e[B.negint.major]=um,e[B.bytes.major]=vm,e[B.string.major]=km,e[B.array.major]=Lm,e[B.map.major]=Gm,e[B.tag.major]=Zm,e[B.float.major]=ih,e}var xh=bh(),Sh=new Hp,Ch=class e{constructor(e,t){this.obj=e,this.parent=t}includes(e){let t=this;do if(t.obj===e)return!0;while(t=t.parent);return!1}static createCheck(t,n){if(t&&t.includes(n))throw Error(`${Gp} object contains circular references`);return new e(n,t)}},wh={null:new V(B.null,null),undefined:new V(B.undefined,void 0),true:new V(B.true,!0),false:new V(B.false,!1),emptyArray:new V(B.array,0),emptyMap:new V(B.map,0)},Th={number(e,t,n,r){return!Number.isInteger(e)||!Number.isSafeInteger(e)?new V(B.float,e):e>=0?new V(B.uint,e):new V(B.negint,e)},bigint(e,t,n,r){return e>=BigInt(0)?new V(B.uint,e):new V(B.negint,e)},Uint8Array(e,t,n,r){return new V(B.bytes,e)},string(e,t,n,r){return new V(B.string,e)},boolean(e,t,n,r){return e?wh.true:wh.false},null(e,t,n,r){return wh.null},undefined(e,t,n,r){return wh.undefined},ArrayBuffer(e,t,n,r){return new V(B.bytes,new Uint8Array(e))},DataView(e,t,n,r){return new V(B.bytes,new Uint8Array(e.buffer,e.byteOffset,e.byteLength))},Array(e,t,n,r){if(!e.length)return n.addBreakTokens===!0?[wh.emptyArray,new V(B.break)]:wh.emptyArray;r=Ch.createCheck(r,e);let i=[],a=0;for(let t of e)i[a++]=Eh(t,n,r);return n.addBreakTokens?[new V(B.array,e.length),i,new V(B.break)]:[new V(B.array,e.length),i]},Object(e,t,n,r){let i=t!==`Object`,a=i?e.keys():Object.keys(e),o=i?e.size:a.length,s;if(o){s=Array(o),r=Ch.createCheck(r,e);let t=!i&&n.ignoreUndefinedProperties,c=0;for(let o of a){let a=i?e.get(o):e[o];t&&a===void 0||(s[c++]=[Eh(o,n,r),Eh(a,n,r)])}c<o&&(s.length=c)}return s?.length?(Dh(s,n),n.addBreakTokens?[new V(B.map,s.length),s,new V(B.break)]:[new V(B.map,s.length),s]):n.addBreakTokens===!0?[wh.emptyMap,new V(B.break)]:wh.emptyMap},Tagged(e,t,n,r){return[new V(B.tag,e.tag),Eh(e.value,n,r)]}};Th.Map=Th.Object,Th.Buffer=Th.Uint8Array;for(let e of`Uint8Clamped Uint16 Uint32 Int8 Int16 Int32 BigUint64 BigInt64 Float32 Float64`.split(` `))Th[`${e}Array`]=Th.DataView;function Eh(e,t={},n){let r=Ep(e),i=t&&t.typeEncoders&&t.typeEncoders[r]||Th[r];if(typeof i==`function`){let a=i(e,r,t,n);if(a!=null)return a}let a=Th[r];if(!a)throw Error(`${Gp} unsupported type: ${r}`);return a(e,r,t,n)}function Dh(e,t){let n=t.mapSorter;n&&e.sort((e,r)=>n(e,r,t))}function Oh(e,t){if(e[0]instanceof V&&t[0]instanceof V){let n=e[0],r=t[0];return n._keyBytes||=kh(n.value),r._keyBytes||=kh(r.value),zp(n._keyBytes,r._keyBytes)}throw Error(`rfc8949MapSorter: complex key types are not supported yet`)}function kh(e){return jh(e,xh,yh)}function Ah(e,t,n,r){if(Array.isArray(t))for(let i of t)Ah(e,i,n,r);else n[t.type.major](e,t,r)}B.uint.majorEncoded,B.negint.majorEncoded,B.bytes.majorEncoded,B.string.majorEncoded,B.array.majorEncoded,B.map.majorEncoded,B.float.majorEncoded|20,B.float.majorEncoded|21,B.float.majorEncoded|22,B.float.majorEncoded|23;function jh(e,t,n,r){let i=r instanceof Uint8Array,a=i?new Up(r):Sh,o=Eh(e,n);if(!Array.isArray(o)&&n.quickEncodeToken){let e=n.quickEncodeToken(o);if(e)return i?(a.push(e),a.toBytes()):e;let r=t[o.type.major];if(r.encodedSize){let e=r.encodedSize(o,n);if(i||(a=new Hp(e)),r(a,o,n),a.chunks.length!==1)throw Error(`Unexpected error: pre-calculated length for ${o} was wrong`);return i?a.toBytes():jp(a.chunks[0])}}return a.reset(),Ah(a,o,t,n),a.toBytes(!0)}Object.defineProperty(class e{constructor(e,t){if(typeof e!=`number`||!Number.isInteger(e)||e<0)throw TypeError(`Tagged: tag must be a non-negative integer`);this.tag=e,this.value=t}static decoder(t){return n=>new e(t,n())}static preserve(...t){let n={};for(let r of t)n[r]=e.decoder(r);return n}}.prototype,Symbol.toStringTag,{value:`Tagged`});var W={HELLO:1,DEPLOY:2,DEPLOY_ACK:3,DEPLOY_ERROR:4,VALUE_STREAM:5,NODE_ERROR:6,STATE_READ:7,STATE_WRITE:8,TRIGGER:9,HELLO_REQUEST:10,NODE_STATUS:11,EXEC:12,STOP_TO_PROMPT:13,SET_BOARD_SETTINGS:14,BOARD_SETTINGS_RESULT:15,DEP_PUT:16,DEP_RESULT:17,DEP_COMMIT:18,RESTART:19,DEP_ACK:20,FLOW_PUT:21,FLOW_COMMIT:22,FLOW_ACK:23};W.HELLO,W.DEPLOY,W.DEPLOY_ACK,W.DEPLOY_ERROR,W.VALUE_STREAM,W.NODE_ERROR,W.STATE_READ,W.STATE_WRITE,W.TRIGGER,W.HELLO_REQUEST,W.NODE_STATUS,W.EXEC,W.STOP_TO_PROMPT,W.SET_BOARD_SETTINGS,W.BOARD_SETTINGS_RESULT,W.DEP_PUT,W.DEP_RESULT,W.DEP_COMMIT,W.RESTART,W.DEP_ACK,W.FLOW_PUT,W.FLOW_COMMIT,W.FLOW_ACK,W.HELLO,W.DEPLOY,W.DEPLOY_ACK,W.DEPLOY_ERROR,W.VALUE_STREAM,W.NODE_ERROR,W.STATE_READ,W.STATE_WRITE,W.TRIGGER,W.HELLO_REQUEST,W.NODE_STATUS,W.EXEC,W.STOP_TO_PROMPT,W.SET_BOARD_SETTINGS,W.BOARD_SETTINGS_RESULT,W.DEP_PUT,W.DEP_RESULT,W.DEP_COMMIT,W.RESTART,W.DEP_ACK,W.FLOW_PUT,W.FLOW_COMMIT,W.FLOW_ACK;var Mh={label:`Installing MicroPython`,path:`installing-micropython/`},Nh={label:`Board won't connect`,path:`debugging/#board-wont-connect`},Ph={silent:{text:`No reply; probably no MicroPython yet, install it first. If it has, press reset while Install runtime waits.`,doc:Mh},micropython:{text:`MicroPython replied but didn't enter install mode. Press reset and try again.`,doc:Nh},circuitpython:{text:`Board runs CircuitPython; install MicroPython first.`,doc:Mh},esp_rom:{text:`Board is in its bootloader, not MicroPython. Press reset (not BOOT); if it repeats, install MicroPython.`,doc:Mh},other:{text:`Board replied, but not as MicroPython (other firmware?). Install MicroPython first.`,doc:Mh},stalled:{text:`Install stalled. Replug the board, ⟳ the port list, try again; if it repeats, restart the backend.`,doc:Nh}},Fh=` Disconnect before flashing.`;``+Fh,Ih(Ph.circuitpython),Ih(Ph.esp_rom),Ih(Ph.other);function Ih(e){return{...e,text:e.text+Fh}}var Lh=[`normal`,`info`,`debug`];function Rh(e,t){return Lh.indexOf(e)<=Lh.indexOf(t)}var zh=[`NET_INFO `,`NET_LISTENING `,`NET_SESSION_OPEN `,`NET_SESSION_CLOSED `,`NET_STOPPED `,`LISTENER_BOOTING `,`LISTENER_BOOT `,`LISTENER_READY`],Bh=[`[board] Target:`,`[version check]`,`[memory]`,`[libraries]`],Vh=/^\[install runtime\] \d+\/\d+ /,Hh=[`[runtime build check]`,`[compile] targeting`,`[compiled --`,`[mpy-cross]`,`[mpy-cross WASM ready]`],Uh=/^(ets [A-Z][a-z]{2} |rst:0x|configsip:|clk_drv:|mode:[A-Z]+, clock div|load:0x|entry 0x|ho \d+ tail|I \(\d+\) )/,Wh=/^\[([A-Z_]+)\] \{/;function Gh(e,t){if(t===`err`)return`normal`;let n=Wh.exec(e);return n?n[1]===`NODE_ERROR`?`normal`:`debug`:e.startsWith(`NODE_STATUS node=`)||Uh.test(e)||Hh.some(t=>e.startsWith(t))||e.startsWith(`[backend] `)&&t!==`ok`?`debug`:zh.some(t=>e.startsWith(t))||Bh.some(t=>e.startsWith(t))||Vh.test(e)?`info`:`normal`}function Kh(e,t){return e===`normal`||e===`info`||e===`debug`?e:t===`1`?`debug`:`normal`}var qh=[{value:`xtensawin`,label:`xtensawin — ESP32 / ESP32-S3 (Xtensa)`},{value:`rv32imc`,label:`rv32imc — ESP32-C3 / C5 / C6 (RISC-V)`},{value:`armv6m`,label:`armv6m — RP2040 (Cortex-M0+)`},{value:`armv7emsp`,label:`armv7emsp — STM32F4 (Cortex-M4F); RP2350 (Cortex-M33, FPU), not hardware-verified`},{value:`armv7m`,label:`armv7m — RP2350, no-FPU fallback`}];function Jh(e){let t=e.toLowerCase();return/esp32-?c[356]/.test(t)?{arch:`rv32imc`,confirmed:!0}:t.includes(`esp32`)?{arch:`xtensawin`,confirmed:!0}:t.includes(`rp2040`)?{arch:`armv6m`,confirmed:!0}:t.includes(`rp2350`)?{arch:`armv7emsp`,confirmed:!1}:t.includes(`stm32f4`)?{arch:`armv7emsp`,confirmed:!0}:{arch:`xtensawin`,confirmed:!1}}var Yh={name:`ESP32-C3`,match:[`ESP32C3`],flash:{tool:`esptool`,chip:`esp32c3`,address:0},nativeArch:`rv32imc`,capabilities:[`wifi`,`ble`,`espnow`],adc2:[5],gpio:[`0-21`],reserved:{"12-17":`Wired to the flash chip. Using them crashes the board.`},avoid:{2:`Strapping pin. Must be high at reset for a normal boot.`,8:`Strapping pin. Must be high at reset to flash the board.`,9:`Strapping pin, usually the BOOT button. Held low at reset, the board starts in download mode.`,"18-19":`Native USB D- and D+. On boards that use native USB for serial, using them cuts the link to Thingstudio.`,"20-21":`UART0 RX and TX. On boards with a USB-serial chip, these carry the link to Thingstudio.`},spi:{maxHz:8e7,buses:{1:{fastPins:{sck:6,mosi:7,miso:2}}}},i2c:{buses:{0:{}}},notes:`ESP32-C3 (single-core RISC-V). Has one SPI bus (1) and one I2C bus (0) for user code.`},Xh={name:`ESP32-C5`,match:[`ESP32C5`],flash:{tool:`esptool`,chip:`esp32c5`,address:8192},nativeArch:`rv32imc`,capabilities:[`wifi`,`ble`,`espnow`],gpio:[`0-28`],reserved:{"16-22":`Wired to the flash chip and PSRAM. Using them crashes the board.`},avoid:{2:`Strapping pin. Its level at reset helps set the boot mode; check the board's wiring before using it.`,7:`Strapping pin. Its level at reset helps set the boot mode; check the board's wiring before using it.`,"11-12":`UART0 TX and RX. On boards with a USB-serial chip, these carry the link to Thingstudio.`,"13-14":`Native USB D- and D+. On boards that use native USB for serial, using them cuts the link to Thingstudio.`,25:`Strapping pin. Its level at reset helps set the boot mode; check the board's wiring before using it.`,"27-28":`Strapping pins. Their level at reset helps set the boot mode; check the board's wiring before using them.`},spi:{maxHz:8e7,buses:{1:{fastPins:{sck:6,mosi:7,miso:2}}}},i2c:{buses:{0:{}}},notes:`ESP32-C5 (single-core RISC-V, dual-band WiFi 6, Bluetooth LE 5). One SPI bus (1) and one I2C bus (0) for user code. ADC inputs: 1-6, all on ADC1, so WiFi doesn't block them. Images start at 0x2000, not 0.`},Zh={name:`ESP32-S2`,match:[`ESP32S2`],flash:{tool:`esptool`,chip:`esp32s2`,address:4096},nativeArch:`xtensawin`,capabilities:[`wifi`,`espnow`],adc2:[11,12,13,14,15,16,17,18,19,20],gpio:[`0-21`,`26-46`],inputOnly:[46],reserved:{"27-32":`Wired to the flash chip. Using them crashes the board.`},avoid:{0:`Strapping pin. Held low at reset, the board starts in download mode.`,"19-20":`Native USB D- and D+. On boards that use native USB for serial, using them cuts the link to Thingstudio.`,26:`PSRAM chip select on chips and modules with PSRAM.`,45:`Strapping pin. Sets flash voltage at reset.`,46:`Strapping pin. Sets boot mode at reset.`},spi:{maxHz:8e7,buses:{1:{fastPins:{sck:12,mosi:11,miso:13}},2:{}}},i2c:{buses:{0:{},1:{}}},notes:`ESP32-S2 (single-core Xtensa LX7).`},Qh={name:`ESP32-S3`,match:[`ESP32S3`],flash:{tool:`esptool`,chip:`esp32s3`,address:0},nativeArch:`xtensawin`,capabilities:[`wifi`,`ble`,`espnow`],adc2:[11,12,13,14,15,16,17,18,19,20],gpio:[`0-21`,`26-48`],reserved:{"27-32":`Wired to the flash chip. Using them crashes the board.`},avoid:{0:`Strapping pin. Held low at reset, the board starts in download mode.`,3:`Strapping pin. Selects the JTAG source at reset.`,"19-20":`Native USB D- and D+. On boards that use native USB for serial, using them cuts the link to Thingstudio.`,26:`PSRAM chip select on chips and modules with PSRAM.`,"33-37":`Used by octal flash or PSRAM on modules that have it (for example N8R8, N16R8).`,"43-44":`UART0 TX and RX. On boards with a USB-serial chip, these carry the link to Thingstudio.`,45:`Strapping pin. Sets flash voltage at reset.`,46:`Strapping pin. Sets boot mode at reset.`},spi:{maxHz:8e7,buses:{1:{fastPins:{sck:12,mosi:11,miso:13}},2:{}}},i2c:{buses:{0:{},1:{}}},notes:`ESP32-S3 (dual-core Xtensa LX7).`},$h={name:`ESP32`,match:[`ESP32`],flash:{tool:`esptool`,chip:`esp32`,address:4096},nativeArch:`xtensawin`,capabilities:[`wifi`,`ble`,`espnow`],adc2:[0,2,4,12,13,14,15,25,26,27],gpio:[`0-19`,`21-23`,`25-27`,`32-39`],inputOnly:[`34-39`],noPull:[`34-39`],reserved:{1:`UART0 TX. Carries the USB serial link to Thingstudio.`,3:`UART0 RX. Carries the USB serial link to Thingstudio.`,"6-11":`Wired to the flash chip. Using them crashes the board.`},avoid:{0:`Strapping pin. Held low at reset, the board starts in download mode.`,2:`Strapping pin. Must be low or floating at reset to flash the board.`,5:`Strapping pin. Sets flash timing at reset.`,12:`Strapping pin. High at reset selects 1.8 V flash, and most boards then fail to boot.`,15:`Strapping pin. Low at reset silences the boot log.`,"16-17":`Wired to PSRAM on WROVER modules.`},spi:{maxHz:8e7,otherPinsMaxHz:27e6,buses:{1:{fastPins:{sck:14,mosi:13,miso:12}},2:{fastPins:{sck:18,mosi:23,miso:19}}}},i2c:{buses:{0:{},1:{}}},notes:`Classic ESP32 (Xtensa LX6). On pins other than the bus's fast pins, SPI tops out near 27 MHz (ESP-IDF rounds 27 MHz down to 26.7 MHz). Asking for more makes ESP-IDF refuse the setting, and the board crashes.`},eg={name:`nRF52840`,match:[`NRF52840`],flash:{tool:`uf2`},nativeArch:`armv7emsp`,nativeArchConfirmed:!1,gpio:[`0-47`],avoid:{"9-10":`NFC antenna pins by default. Usable as GPIO only after the chip's UICR NFCPINS setting is changed.`,18:`The reset pin on most boards.`},spi:{maxHz:8e6,buses:{2:{},3:{}}},i2c:{buses:{0:{},1:{}}},notes:`Cortex-M4F. Pins are numbered port*32 + pin: P0.00-P0.31 are 0-31, P1.00-P1.15 are 32-47. Any pin can be routed to SPI or I2C. SPI 0 and 1 share hardware with I2C 0 and 1, so SPI is offered on buses 2 and 3 only. SPI runs at up to 8 MHz (bus 3 alone can reach 32 MHz, not offered here). ADC inputs: 2, 3, 4, 5, 28, 29, 30, 31. Has BLE, but MicroPython's nRF port drives it through ubluepy, not the bluetooth module, so no ble capability is listed. Native arch armv7emsp is not yet checked on hardware.`},tg={name:`RP2040`,match:[`RP2040`],flash:{tool:`uf2`},nativeArch:`armv6m`,capabilities:[`pio`],gpio:[`0-29`],spi:{maxHz:625e5,buses:{0:{pins:{sck:[2,6,18,22],mosi:[3,7,19,23],miso:[0,4,16,20]}},1:{pins:{sck:[10,14,26],mosi:[11,15,27],miso:[8,12,24,28]}}}},i2c:{buses:{0:{pins:{sda:[0,4,8,12,16,20,24,28],scl:[1,5,9,13,17,21,25,29]}},1:{pins:{sda:[2,6,10,14,18,22,26],scl:[3,7,11,15,19,23,27]}}}},notes:`RP2040 (dual Cortex-M0+). Each SPI and I2C bus can only use certain pins.`},ng={name:`RP2350`,match:[`RP2350`],flash:{tool:`uf2`},nativeArch:`armv7emsp`,capabilities:[`pio`],nativeArchConfirmed:!1,gpio:[`0-47`],spi:{maxHz:75e6,buses:{0:{pins:{sck:[2,6,18,22,34,38],mosi:[3,7,19,23,35,39],miso:[0,4,16,20,32,36]}},1:{pins:{sck:[10,14,26,30,42,46],mosi:[11,15,27,31,43,47],miso:[8,12,24,28,40,44]}}}},i2c:{buses:{0:{pins:{sda:[0,4,8,12,16,20,24,28,32,36,40,44],scl:[1,5,9,13,17,21,25,29,33,37,41,45]}},1:{pins:{sda:[2,6,10,14,18,22,26,30,34,38,42,46],scl:[3,7,11,15,19,23,27,31,35,39,43,47]}}}},notes:`RP2350 in Arm mode (dual Cortex-M33). GPIO 30-47 exist only on the larger RP2350B; boards with the RP2350A narrow this to 0-29. Native arch armv7emsp is community-sourced, not yet checked on hardware.`},rg={name:`STM32F405 (pyboard)`,match:[`STM32F405`],nativeArch:`armv7emsp`,nativeArchConfirmed:!0,gpio:`X1.X2.X3.X4.X5.X6.X7.X8.X9.X10.X11.X12.X17.X18.X19.X20.X21.X22.Y1.Y2.Y3.Y4.Y5.Y6.Y7.Y8.Y9.Y10.Y11.Y12.A13.A14.A15.B4`.split(`.`),spi:{maxHz:21e6,buses:{1:{pins:{sck:[`X6`],mosi:[`X8`],miso:[`X7`]}},2:{pins:{sck:[`Y6`],mosi:[`Y8`],miso:[`Y7`]}}}},i2c:{buses:{1:{pins:{scl:[`X9`,`Y3`],sda:[`X10`,`Y4`]}},2:{pins:{scl:[`Y9`],sda:[`Y10`]}}}},notes:`Pins are named, not numbered: X1-X12 and X17-X22 (left), Y1-Y12 (right), as printed on the board. X13-X16 are reset, ground and power, not GPIO. The four LEDs are also pins: A13 (red), A14 (green), A15 (yellow), B4 (blue) -- the same four pyb.LED(1-4) drives. SPI and I2C pins are the pyboard's own hardware mappings; SPI is limited to 21 MHz (SPI2's limit -- SPI1 can go faster).`},ig={name:`CYD (ESP32-2432S028, ST7789)`,processor:`esp32`,variant:`thingstudio-classic-esp32`,wifi:!0,match:[],pins:{TFT_SCK:14,TFT_MOSI:13,TFT_MISO:12,TFT_CS:15,TFT_DC:2,BACKLIGHT:21,LED_RED:4,LED_GREEN:16,LED_BLUE:17,TOUCH_CLK:25,TOUCH_MOSI:32,TOUCH_MISO:39,TOUCH_CS:33,TOUCH_IRQ:36,SD_SCK:18,SD_MOSI:23,SD_MISO:19,SD_CS:5,LDR:34,SPEAKER:26,BOOT:0},notes:`Reports itself as a generic ESP32, so pick it by hand in the Board menu. Display pins are tested on real units; touch, SD, LED, LDR and speaker pins are from community pinouts. The RGB LED is active low. Units vary: check your own board.`},ag={name:`ESP32-C5-340X`,processor:`esp32-c5`,variant:`thingstudio-esp32-c5`,wifi:!0,match:[],pins:{RGB_LED:27,BOOT:28},gpio:[`0-14`,`23-28`],avoid:{3:`Strapping pin on this board (product manual). Check its level at reset before wiring it.`,26:`Strapping pin on this board (product manual). Check its level at reset before wiring it.`},headerOrder:`down`,usb:`bottom`,header:{1:`3V3`,2:`EN`,3:2,4:3,5:0,6:1,7:6,8:7,9:8,10:9,11:10,12:25,13:26,14:`5V`,15:`GND`,16:`NC`,17:`GND`,18:11,19:12,20:24,21:23,22:`NC`,23:27,24:4,25:5,26:`NC`,27:28,28:`GND`,29:14,30:13,31:`GND`,32:`NC`},notes:`Silkscreen ESP32-C5-KITC-A V1.2. Reports itself as a generic ESP32-C5, so pick it by hand in the Board menu. Two USB-C ports: the left (UART) goes through a CH340E to GPIO 11 and 12, the right (USB) is native USB on GPIO 13 and 14. The CH340E's RTS drives EN but not BOOT, so if flashing doesn't start, hold BOOT, press and release RESET, then release BOOT. A WS2812 RGB LED is on GPIO 27, which is also a strapping pin: don't pull it low at reset. BOOT is GPIO 28, low when pressed. The header pin marked NC/IO15 is left out: the maker says not to connect it. The C5-FH4 module has no PSRAM, so the generic C5 build prints PSRAM errors at boot and carries on without it. Install MicroPython at 0x2000 (Thonny writes at 0 and the board won't boot). Pins are from the maker's product manual PS-C5-340X-001 V1.0.`},og={name:`Freenove ESP32-S3 Display 4.0" (FNK0104S, ST7796)`,processor:`esp32-s3`,variant:`esp32-s3-spiram-oct`,wifi:!0,match:[],pins:{TFT_SCK:12,TFT_MOSI:11,TFT_CS:10,TFT_DC:46,BACKLIGHT:45,TOUCH_SDA:16,TOUCH_SCL:15,TOUCH_INT:17,TOUCH_RST:18},notes:`Reports itself as a generic ESP32-S3, so pick it by hand in the Board menu. 320x480 ST7796 over SPI, no reset pin, backlight on high, colours inverted. Touch is an FT6336U on I2C. Pins are from Freenove's own TFT_eSPI setup and touch example; check your own unit. Use SPI bus 1 for the display's fast pins. Display rotation 1 is portrait; rotation 4 is landscape with the USB socket on the right (rotation 7 puts it on the left).`},sg={name:`Kitchen sink (LuatOS ESP32C3-CORE)`,processor:`esp32-c3`,variant:`thingstudio-esp32-c3`,wifi:!0,match:[],pins:{LED_D4:12,LED_D5:13,BOOT:9,POT:0,BUTTON:3,PIXEL:6},gpio:[`0-13`,`18-21`],free:[`12-13`,`18-19`],reserved:{11:`Powers the flash chip (VDD_SPI). It only becomes a GPIO after a one-way eFuse burn.`},headerOrder:`down`,usb:`bottom`,header:{1:`GND`,2:0,3:1,4:12,5:18,6:19,7:`GND`,8:20,9:21,10:13,11:`NC`,12:`RST`,13:`3V3`,14:`GND`,15:`PWB`,16:`5V`,17:`GND`,18:`3V3`,19:2,20:3,21:10,22:6,23:7,24:11,25:`GND`,26:`3V3`,27:5,28:4,29:8,30:9,31:`5V`,32:`GND`},notes:`A LuatOS ESP32C3-CORE (classic version, CH343 USB-serial chip on GPIO 20 and 21) with a potentiometer on GPIO 0, a push button to GND on GPIO 3 and one WS2812 on GPIO 6. The board's own LEDs are D4 on GPIO 12 and D5 on GPIO 13, and BOOT is GPIO 9. Pick it by hand. Wiring: the Kitchen-sink board page in the user guide.`},cg={name:`LOLIN S2 Mini`,processor:`esp32-s2`,variant:`esp32-s2-generic`,wifi:!0,match:[`LOLIN_S2_MINI`],pins:{LED:15,BUTTON:0},reserved:{"19-20":`Native USB. Carries the serial link to Thingstudio.`,26:`Wired to the built-in PSRAM.`},notes:`The onboard LED is GPIO 15. The button labelled 0 is GPIO 0.`},lg={name:`LuatOS ESP32C3-CORE`,processor:`esp32-c3`,variant:`thingstudio-esp32-c3`,wifi:!0,match:[],pins:{LED_D4:12,LED_D5:13,BOOT:9},gpio:[`0-13`,`18-21`],free:[`12-13`],reserved:{11:`Powers the flash chip (VDD_SPI). It only becomes a GPIO after a one-way eFuse burn.`},headerOrder:`down`,usb:`bottom`,header:{1:`GND`,2:0,3:1,4:12,5:18,6:19,7:`GND`,8:20,9:21,10:13,11:`NC`,12:`RST`,13:`3V3`,14:`GND`,15:`PWB`,16:`5V`,17:`GND`,18:`3V3`,19:2,20:3,21:10,22:6,23:7,24:11,25:`GND`,26:`3V3`,27:5,28:4,29:8,30:9,31:`5V`,32:`GND`},notes:`Reports itself as a generic ESP32-C3, so pick it by hand in the Board menu. Two LEDs, D4 on GPIO 12 and D5 on GPIO 13, both on when high. The BOOT button is GPIO 9, low when pressed. The flash runs in DIO mode, so GPIO 12 and 13 aren't flash pins on this board. The classic version has a CH343 USB-serial chip on GPIO 20 and 21. The newer version uses native USB on GPIO 18 and 19. Boards sold without external flash can't use GPIO 11-13. Pins are from the LuatOS wiki.`},ug={name:`Raspberry Pi Pico 2`,processor:`rp2350`,variant:`rpi-pico2`,wifi:!1,match:[`Raspberry Pi Pico2`],gpio:[`0-29`],pins:{LED:25},avoid:{23:`Controls the power supply mode (SMPS).`,24:`Senses USB power (VBUS).`,29:`Measures the supply voltage (VSYS).`},usb:`top`,header:{1:0,2:1,3:`GND`,4:2,5:3,6:4,7:5,8:`GND`,9:6,10:7,11:8,12:9,13:`GND`,14:10,15:11,16:12,17:13,18:`GND`,19:14,20:15,21:16,22:17,23:`GND`,24:18,25:19,26:20,27:21,28:`GND`,29:22,30:`RUN`,31:26,32:27,33:`AGND`,34:28,35:`ADC_VREF`,36:`3V3(OUT)`,37:`3V3_EN`,38:`GND`,39:`VSYS`,40:`VBUS`},notes:`RP2350A, so GPIO 0-29 only. The onboard LED is GPIO 25.`},dg={name:`Raspberry Pi Pico W`,processor:`rp2040`,variant:`rpi-pico-w`,wifi:!0,match:[`Raspberry Pi Pico W`],pins:{},reserved:{23:`Wired to the WiFi chip.`,24:`Wired to the WiFi chip.`,25:`Wired to the WiFi chip.`,29:`Wired to the WiFi chip.`},usb:`top`,header:{1:0,2:1,3:`GND`,4:2,5:3,6:4,7:5,8:`GND`,9:6,10:7,11:8,12:9,13:`GND`,14:10,15:11,16:12,17:13,18:`GND`,19:14,20:15,21:16,22:17,23:`GND`,24:18,25:19,26:20,27:21,28:`GND`,29:22,30:`RUN`,31:26,32:27,33:`AGND`,34:28,35:`ADC_VREF`,36:`3V3(OUT)`,37:`3V3_EN`,38:`GND`,39:`VSYS`,40:`VBUS`},notes:`The onboard LED is on the WiFi chip, not a GPIO, so gpio_out can't drive it. Use an external LED on a free pin.`},fg={name:`Raspberry Pi Pico`,processor:`rp2040`,variant:`rpi-pico`,wifi:!1,match:[`Raspberry Pi Pico`],pins:{LED:25},avoid:{23:`Controls the power supply mode (SMPS).`,24:`Senses USB power (VBUS).`,29:`Measures the supply voltage (VSYS).`},usb:`top`,header:{1:0,2:1,3:`GND`,4:2,5:3,6:4,7:5,8:`GND`,9:6,10:7,11:8,12:9,13:`GND`,14:10,15:11,16:12,17:13,18:`GND`,19:14,20:15,21:16,22:17,23:`GND`,24:18,25:19,26:20,27:21,28:`GND`,29:22,30:`RUN`,31:26,32:27,33:`AGND`,34:28,35:`ADC_VREF`,36:`3V3(OUT)`,37:`3V3_EN`,38:`GND`,39:`VSYS`,40:`VBUS`},notes:`The onboard LED is GPIO 25.`},pg={name:`Pyboard v1.0`,processor:`stm32f405`,match:[`PYBv1.0`],pins:{LED_RED:`A13`,LED_GREEN:`A14`,LED_YELLOW:`A15`,LED_BLUE:`B4`,SW:`X17`},wifi:!1,notes:`The micro-USB port talks to Thingstudio. The board's filesystem is mounted at /flash. The four onboard LEDs are on pins A13/A14/A15/B4 (LED_RED/LED_GREEN/LED_YELLOW/LED_BLUE), the same four pyb.LED(1-4) drives; the user switch SW is on X17 (PB3). X23/X24 don't exist on v1.0.`},mg={name:`Wemos D1 R32`,processor:`esp32`,variant:`thingstudio-classic-esp32`,match:[],wifi:!0,pins:{D0:3,D1:1,D2:26,D3:25,D4:17,D5:16,D6:27,D7:14,D8:12,D9:13,D10:5,D11:23,D12:19,D13:18,A0:2,A1:4,A2:35,A3:34,A4:36,A5:39,SDA:21,SCL:22,LED:2},free:[`16-17`],avoid:{2:`Strapping pin, and the onboard LED. Must be low or floating at reset to flash the board.`,5:`Strapping pin. Sets flash timing at reset.`,12:`Strapping pin. High at reset selects 1.8 V flash and the board won't boot, so a shield mustn't pull it high.`},notes:`Arduino Uno layout with an ESP32-WROOM-32. Pins are labelled by their Arduino names: D0 and D1 are the USB serial link. A2-A5 (GPIO 35, 34, 36, 39) are input only, so a shield that drives them, such as an MCUFRIEND parallel TFT, needs wires to spare GPIOs (usually 15, 33 and 32). The onboard LED is on GPIO 2 — A0 on the Uno header's silk, LED in the pin list here; blue, on when the pin is on. The silkscreen on some boards mislabels A2 and A4. Pick this board by hand: MicroPython reports a generic ESP32.`},hg={name:`Seeed XIAO nRF52840 (Sense)`,processor:`nrf52840`,variant:`seeed-xiao-nrf52840`,match:[`XIAO nRF52840 Sense`],wifi:!1,gpio:[2,3,4,5,6,7,9,10,11,13,14,16,17,`20-32`,40,42,`43-47`],pins:{D0:2,D1:3,D2:28,D3:29,D4:4,D5:5,D6:43,D7:44,D8:45,D9:46,D10:47,LED_RED:26,LED_GREEN:30,LED_BLUE:6,CHG_LED:17,NFC1:9,NFC2:10,VBAT_ADC:31,VBAT_ENABLE:14,HICHG:13,IMU_SDA:7,IMU_SCL:27,IMU_INT1:11,IMU_PWR:40,PDM_CLK:32,PDM_DATA:16,MIC_PWR:42},reserved:{"20-25":`Wired to the 2 MB QSPI flash chip.`},avoid:{14:`Battery-read enable. Drive it low to read the battery on 31. Never set it high while charging: that can damage pin 31.`,31:`Battery voltage divider, read only with the ADC. Never drive it.`,13:`Sets the battery charge current (low: 100 mA, high: 50 mA).`,17:`Charge LED, also driven by the charger chip. Read it to see whether the battery is charging; don't drive it.`},usb:`top`,header:{1:2,2:3,3:28,4:29,5:4,6:5,7:43,8:44,9:45,10:46,11:47,12:`3V3`,13:`GND`,14:`5V`},notes:`The plain XIAO nRF52840 and the Sense run the same MicroPython firmware and both report XIAO nRF52840 Sense. D0-D5 are also A0-A5; D4/D5 are the usual I2C SDA/SCL, D6/D7 UART TX/RX, D8-D10 SPI SCK/MISO/MOSI. The RGB LED is active low: value 0 turns it on. NFC1/NFC2 are pads on the back. IMU (LSM6DS3TR-C) and microphone pins exist on the Sense only; set IMU_PWR or MIC_PWR high before using them. Files live under /flash. Bluetooth is through ubluepy only.`},gg=Object.assign({"./processors/esp32-c3.json":Yh,"./processors/esp32-c5.json":Xh,"./processors/esp32-s2.json":Zh,"./processors/esp32-s3.json":Qh,"./processors/esp32.json":$h,"./processors/nrf52840.json":eg,"./processors/rp2040.json":tg,"./processors/rp2350.json":ng,"./processors/stm32f405.json":rg}),_g=Object.assign({"./boards/cyd.json":ig,"./boards/esp32-c5-340x.json":ag,"./boards/freenove-s3-4in.json":og,"./boards/kitchen-sink-c3.json":sg,"./boards/lolin-s2-mini.json":cg,"./boards/luatos-esp32c3-core.json":lg,"./boards/pico-2.json":ug,"./boards/pico-w.json":dg,"./boards/pico.json":fg,"./boards/pyboard-v10.json":pg,"./boards/wemos-d1-r32.json":mg,"./boards/xiao-nrf52840.json":hg});function vg(e){return e.replace(/^.*\//,``).replace(/\.json$/,``)}var yg=[...Object.entries(gg).map(([e,t])=>({kind:`processor`,id:vg(e),source:`built-in`,data:t})),...Object.entries(_g).map(([e,t])=>({kind:`board`,id:vg(e),source:`built-in`,data:t}))];function bg(e,t){let n=t?.gpio??e.gpio,r=new Map,i=new Map,a=t?.free??new Set;for(let[t,r]of e.avoid)n.has(t)&&!a.has(t)&&i.set(t,r);for(let[e,n]of t?.avoid??[])i.set(e,n);for(let[t,i]of e.reserved)n.has(t)&&!a.has(t)&&r.set(t,i);for(let[e,n]of t?.reserved??[])r.set(e,n);let o=new Map;for(let[e,n]of t?.pins??[])o.has(n)||o.set(n,[]),o.get(n).push(e);for(let e of o.keys())t?.avoid.has(e)||i.delete(e);for(let e of r.keys())i.delete(e);return{processor:e,board:t,label:t?`${t.name} (${e.name})`:e.name,gpio:n,inputOnly:new Set([...e.inputOnly].filter(e=>n.has(e))),noPull:new Set([...e.noPull].filter(e=>n.has(e))),reserved:r,avoid:i,pinLabels:o,capabilities:xg(e,t)}}function xg(e,t){let n=new Set(e.capabilities);for(let e of t?.capabilities??[])n.add(e);return t&&(t.wifi===!1?n.delete(`wifi`):t.wifi===!0&&n.add(`wifi`)),n}function Sg(e){return e.toLowerCase().replace(/[^a-z0-9]/g,``)}function Cg(e){let t=e.lastIndexOf(` with `);return t<0?{boardPart:e.trim(),mcuPart:e.trim()}:{boardPart:e.slice(0,t).trim(),mcuPart:e.slice(t+6).trim()}}function wg(e,t){let{boardPart:n,mcuPart:r}=Cg(t),i=n.toLowerCase();for(let t of e.boards.values())if(t.match.some(e=>e.toLowerCase()===i))return{board:t,processor:e.processors.get(t.processor)??null};let a=Sg(r),o=null,s=0;for(let t of e.processors.values())for(let e of t.match){let n=Sg(e);n!==``&&a.includes(n)&&n.length>s&&(o=t,s=n.length)}return{board:null,processor:o}}function Tg(e,t,n){let r=n?wg(e,n):{board:null,processor:null};if(t!==`auto`){let[i,a]=t.split(`:`,2),o=null;if(i===`board`&&a&&e.boards.has(a)){let t=e.boards.get(a),n=e.processors.get(t.processor);n&&(o=bg(n,t))}else i===`processor`&&a&&e.processors.has(a)&&(o=bg(e.processors.get(a),null));if(o){let e=r.processor&&r.processor.id!==o.processor.id?`The Board menu says ${o.label}, but the connected board reports "${n}" (${r.processor.name}).`:null;return{target:o,how:`manual`,note:`Target: ${o.label} (picked in the Board menu).`,mismatch:e}}let s=Tg(e,`auto`,n);return{...s,note:`The Board menu's choice "${t}" isn't defined any more. ${s.note}`}}if(r.processor){let e=bg(r.processor,r.board);return{target:e,how:`detected`,note:`Target: ${e.label} (detected from "${n}").`,mismatch:null}}return n?{target:null,how:`none`,note:`The connected board reports "${n}", which matches no processor definition. Pick your board in the Board menu.`,mismatch:null}:{target:null,how:`none`,note:`No board connected and none picked in the Board menu.`,mismatch:null}}function Eg(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function Dg(e,t){return typeof e==`number`&&typeof t==`number`?e-t:typeof e==`number`?-1:typeof t==`number`?1:e.localeCompare(t)}function Og(e,t){let n=e.reserved.get(t);if(n!==void 0)return{kind:`reserved`,status:`Reserved: the compile stops`,why:n};let r=e.avoid.get(t),i=[];if(e.inputOnly.has(t)&&i.push(`input only`),e.noPull.has(t)&&i.push(`no internal pull-up or pull-down`),r!==void 0)return{kind:`avoid`,status:`Avoid: the compile warns`,why:[r,...i.map(e=>`Also ${e}.`)].join(` `)};if(i.length>0){let e=i.join(`, `);return{kind:`limited`,status:e.charAt(0).toUpperCase()+e.slice(1),why:``}}return{kind:`free`,status:`Free`,why:``}}function kg(e){return/GND/i.test(e)?`ground`:/^(VBUS|VSYS|VIN|VCC|VDD|5V|3V3|3\.3V)\b/i.test(e)||/^3V3\(OUT\)$/i.test(e)?`power`:`other`}function Ag(e){let t=new Map;for(let[n,r]of e.board?.header??[])(typeof r!=`string`||e.gpio.has(r))&&(t.has(r)||t.set(r,[]),t.get(r).push(n));return t}function jg(e){if(e.length<4||e.length%2!=0)return null;let t=e.map(e=>/^\d+$/.test(e)?Number(e):NaN),n=new Set(t);for(let t=1;t<=e.length;t++)if(!n.has(t))return null;return e.length}function Mg(e,t,n){if(t===void 0)return`<td class="${n}"></td>`;if(typeof t==`string`&&!e.gpio.has(t))return`<td class="${n} ${kg(t)}">${Eg(t)}</td>`;let r=Og(e,t),i=e.pinLabels.get(t)??[],a=hc(t)+(i.length?` · ${i.join(`, `)}`:``);return`<td class="${n} ${r.kind}" title="${Eg(r.status+(r.why?`. ${r.why}`:``))}">${Eg(a)}</td>`}function Ng(e){let t=e.board;if(!t||t.header.size===0)return``;let n=[...t.header.keys()],r=`<p><strong>Red pins are power, grey pins are ground.</strong> Never wire a power pin to ground or to a GPIO: it can destroy the board. Pink pins control the board itself, such as RUN, which resets it.</p>`,i=jg(n);if(i!==null){let n=t.headerOrder===`down`,a=[],o=`<tr><td></td><td class="num usb" colspan="2">USB</td><td></td></tr>`;t.usb===`top`&&a.push(o);for(let r=1;r<=i/2;r++){let o=n?i/2+r:i+1-r;a.push(`<tr>${Mg(e,t.header.get(String(r)),`left`)}<td class="num">${r}</td><td class="num">${o}</td>${Mg(e,t.header.get(String(o)),`right`)}</tr>`)}return t.usb===`bottom`&&a.push(o),`<h2>Physical pins</h2>${r}<p>As on the board: pin 1 top left, ${n?`numbered down the left side, then down the right`:`numbered down the left side and back up the right`}.${t.usb?` The USB connector is at the ${t.usb}.`:``}</p><div class="scroll"><table class="header"><tbody>${a.join(``)}</tbody></table></div>`}let a=n.map(n=>`<tr><td class="num">${Eg(n)}</td>${Mg(e,t.header.get(n),`left`)}</tr>`);return`<h2>Physical pins</h2>${r}${t.usb?`<p>The USB connector is at the ${t.usb===`top`?`pin 1`:`last pin`} end.</p>`:``}<table class="header"><thead><tr><th>Pin</th><th>Connected to</th></tr></thead><tbody>${a.join(``)}</tbody></table>`}function Pg(e){if(!e.spi)return``;let t=[];for(let[n,r]of[...e.spi.buses].sort((e,t)=>e[0]-t[0])){let e=`Any pins`;r.pins?e=[`sck`,`mosi`,`miso`].filter(e=>r.pins?.[e]).map(e=>`${e.toUpperCase()}: ${qc(r.pins[e])}`).join(`<br>`):r.fastPins&&(e=`Any pins. Fastest on ${[`sck`,`mosi`,`miso`].filter(e=>r.fastPins?.[e]!==void 0).map(e=>`${e.toUpperCase()} ${r.fastPins[e]}`).join(`, `)}`),t.push(`<tr><td>${n}</td><td>${e}</td></tr>`)}let n=[];return e.spi.maxHz&&n.push(`Up to ${Ig(e.spi.maxHz)}`),e.spi.otherPinsMaxHz&&n.push(`up to ${Ig(e.spi.otherPinsMaxHz)} on other pins`),`<h2>SPI</h2>`+(n.length?`<p>${n.join(`, `)}.</p>`:``)+`<table><thead><tr><th>Bus</th><th>Pins</th></tr></thead><tbody>${t.join(``)}</tbody></table>`}function Fg(e){if(!e.i2c)return``;let t=[];for(let[n,r]of[...e.i2c.buses].sort((e,t)=>e[0]-t[0])){let e=r.pins?[`sda`,`scl`].filter(e=>r.pins?.[e]).map(e=>`${e.toUpperCase()}: ${qc(r.pins[e])}`).join(`<br>`):`Any pins`;t.push(`<tr><td>${n}</td><td>${e}</td></tr>`)}return`<h2>I2C</h2><table><thead><tr><th>Bus</th><th>Pins</th></tr></thead><tbody>${t.join(``)}</tbody></table>`}function Ig(e){return e>=1e6?`${+(e/1e6).toFixed(1)} MHz`:`${+(e/1e3).toFixed(1)} kHz`}var Lg=`
:root { --bg: #ffffff; --fg: #1d2328; --muted: #5d6870; --line: #d9dee2; --head: #f2f4f6;
  --reserved: #fbe3e1; --avoid: #fff3d6; --limited: #e8f1fb; --accent: #2f6f9f;
  --power: #e04a3f; --power-fg: #ffffff; --ground: #3a4148; --ground-fg: #ffffff; --other: #f4c7c3; color-scheme: light; }
@media (prefers-color-scheme: dark) { :root { --bg: #16191c; --fg: #e3e7ea; --muted: #9aa5ad; --line: #30363b;
  --head: #1f2327; --reserved: #4a2320; --avoid: #45391a; --limited: #1c3146; --accent: #7fb3dc;
  --power: #c9372d; --power-fg: #ffffff; --ground: #5a636b; --ground-fg: #ffffff; --other: #5c2e2a; color-scheme: dark; } }
body { background: var(--bg); color: var(--fg); margin: 0; padding: 24px 16px 48px;
  font: 15px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
main { max-width: 760px; margin: 0 auto; }
h1 { font-size: 1.6rem; margin: 0 0 4px; text-wrap: balance; }
h2 { font-size: 1.1rem; margin: 28px 0 8px; }
.sub { color: var(--muted); margin: 0 0 16px; }
.notes p { margin: 0 0 8px; }
table { border-collapse: collapse; width: 100%; font-variant-numeric: tabular-nums; }
th, td { text-align: left; vertical-align: top; padding: 6px 10px; border-bottom: 1px solid var(--line); }
th { background: var(--head); font-weight: 600; }
td.gpio { font-weight: 600; white-space: nowrap; }
tr.reserved td { background: var(--reserved); }
tr.avoid td { background: var(--avoid); }
tr.limited td { background: var(--limited); }
.scroll { overflow-x: auto; }
table.header td { white-space: nowrap; }
table.header td.num { width: 2.5em; text-align: center; font-weight: 600; background: var(--head); }
table.header td.right { text-align: left; }
table.header td.left { text-align: right; }
table.header td.usb { border: 2px solid var(--accent); letter-spacing: 0.1em; }
td.power { background: var(--power); color: var(--power-fg); font-weight: 600; }
td.ground { background: var(--ground); color: var(--ground-fg); font-weight: 600; }
td.other { background: var(--other); }
td.reserved { background: var(--reserved); }
td.avoid { background: var(--avoid); }
td.limited { background: var(--limited); }
.key { color: var(--muted); font-size: 0.9rem; margin: 6px 0 0; }
.notice { background: var(--avoid); padding: 12px 16px; border-radius: 6px; margin: 0 0 16px; }
.notice p { margin: 0 0 8px; }
pre { overflow-x: auto; background: var(--head); padding: 10px 12px; border-radius: 4px; margin: 0 0 8px; }
code { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 0.92em; }
footer { margin-top: 32px; color: var(--muted); font-size: 0.9rem; }
@media print { body { padding: 0; } }
`;function Rg(e,t){return`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${Eg(e)}</title><style>${Lg}</style></head><body><main>${t}</main></body></html>`}function zg(e,t){return`<pre><code>${Eg(JSON.stringify({name:e,processor:t,match:[e],pins:{LED:2}},null,2))}</code></pre>`}function Bg(e,t,n){let{boardPart:r}=Cg(e),i=r.toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/^-+|-+$/g,``)||`my-board`;return`<div class="notice"><p><strong>Your board isn't in Thingstudio's list.</strong> It reports <code>${Eg(e)}</code>. Thingstudio knows its processor, so the pins below are the ${Eg(t.name)}'s. Pins the board wires to something, such as its LED, aren't shown.</p><p>To add them, save a file like this as <code>~/.thingstudio/boards/${Eg(i)}.json</code>, with your board's real pins, then click Pins… again:</p>`+zg(r,t.id)+`<p>See <a href="${Eg(n.docsUrl)}#adding-a-board">Adding a board</a>.</p></div>`}function Vg(e,t){let{board:n,processor:r}=e,i=n?n.name:`${r.name} (any board)`,a=[`Processor: ${Eg(r.name)}`];n&&a.push(n.wifi===!0?`WiFi: yes`:n.wifi===!1?`WiFi: no`:`WiFi: not stated`),a.push(`Native code: <code>${Eg(r.nativeArch)}</code>${r.nativeArchConfirmed?``:` (unverified)`}`);let o=[n?.notes,r.notes].filter(e=>!!e&&e.trim()!==``),s=o.length?`<div class="notes">${o.map(e=>`<p>${Eg(e)}</p>`).join(``)}</div>`:``,c=!!n&&n.header.size>0,l=Ag(e),u=e=>{let t=l.get(e);return t?`pin ${t.join(`, `)}`:`not on the header`},d=``;if(n&&n.pins.size>0){let t=[...n.pins].sort((e,t)=>Dg(e[1],t[1])||e[0].localeCompare(t[0])).map(([t,n])=>{let r=Og(e,n),i=r.kind===`free`?``:`${r.status}. ${r.why}`.trim();return`<tr><td>${Eg(t)}</td><td class="gpio">${Eg(hc(n))}</td>`+(c?`<td>${Eg(u(n))}</td>`:``)+`<td>${Eg(i)}</td></tr>`});d=`<h2>Named pins</h2><p>Pins wired to something on this board. Pin fields in the editor take the pin's name or number.</p><table><thead><tr><th>Name</th><th>Pin</th>${c?`<th>Header</th>`:``}<th>Notes</th></tr></thead><tbody>${t.join(``)}</tbody></table>`}let f=[...new Set([...e.gpio,...e.reserved.keys()])].sort(Dg).map(t=>{let n=Og(e,t),r=e.pinLabels.get(t)??[],i=typeof t==`number`?String(t):t;return`<tr class="${n.kind}"><td class="gpio">${Eg(i)}</td><td>${Eg(r.join(`, `))}</td>`+(c?`<td>${Eg(l.has(t)?l.get(t).join(`, `):``)}</td>`:``)+`<td>${Eg(n.status)}</td><td>${Eg(n.why)}</td></tr>`}),p=`<h2>All pins</h2><div class="scroll"><table><thead><tr><th>Pin</th><th>Name</th>${c?`<th>Header pin</th>`:``}<th>Status</th><th>Why</th></tr></thead><tbody>${f.join(``)}</tbody></table></div><p class="key">Reserved pins stop the compile. Pins to avoid work, but the compile warns. Blue rows have limits.</p>`,m=[n?`<code>~/.thingstudio/boards/${Eg(n.id)}.json</code>`:null,`<code>~/.thingstudio/processors/${Eg(r.id)}.json</code>`].filter(Boolean).join(` and `),h=!n&&t.unlistedBoard?Bg(t.unlistedBoard,r,t):``;return Rg(`${i} pins`,`<h1>${Eg(i)}</h1><p class="sub">${a.join(` · `)}</p>`+h+s+d+Ng(e)+p+Pg(r)+Fg(r)+`<footer><p>From ${m}. Edit ${n?`them`:`it`} to correct this page. See <a href="${Eg(t.docsUrl)}">Boards and processors</a>.</p><p>${Eg(t.generated)}</p></footer>`)}var Hg={"editor.transfer":{illegal:{"*":{to:`same`}},initial:`idle`,states:[`idle`,`sending`,`committing`],transitions:[{do:`sendPiece`,from:[`idle`],on:`start`,to:`sending`},{do:`sendNext`,from:[`sending`],if:`morePieces`,on:`pieceOk`,to:`sending`},{do:`sendCommit`,from:[`sending`],on:`pieceOk`,to:`committing`},{do:`resend`,from:[`sending`,`committing`],if:`canRetry`,on:`garbled`,to:`same`},{do:`fail`,from:[`sending`,`committing`],on:`garbled`,to:`idle`},{do:`resend`,from:[`sending`],if:`canRetry`,on:`timeout`,to:`sending`},{do:`fail`,from:[`sending`],on:`timeout`,to:`idle`},{do:`fail`,from:[`sending`],on:`pieceRefused`,to:`idle`},{do:`finishRestarted`,from:[`sending`,`committing`],on:`restart`,to:`idle`},{do:`finishOk`,from:[`committing`],on:`commitOk`,to:`idle`},{do:`finishRefused`,from:[`committing`],on:`commitRefused`,to:`idle`},{do:`finishNoAnswer`,from:[`committing`],on:`timeout`,to:`idle`},{do:`note`,from:[`idle`,`sending`,`committing`],on:`staleAck`,to:`same`},{do:`note`,from:[`idle`,`sending`,`committing`],on:`earlyMemoryError`,to:`same`},{do:`abort`,from:[`sending`,`committing`],on:`lost`,to:`idle`},{from:[`idle`],on:`lost`,to:`same`},{do:`note`,from:[`idle`],on:`garbled`,to:`same`}]}},Ug=class{name;guards;actions;onIllegal;#e;#t;state;constructor(e,t,n,r){this.name=e,this.guards=t,this.actions=n,this.onIllegal=r;let i=Hg[e];this.#e=i.transitions,this.#t=i.illegal,this.state=i.initial;let a=new Set;for(let e of this.#e)e.if&&!(e.if in t)&&a.add(e.if),e.do&&!(e.do in n)&&a.add(e.do);for(let e of Object.values(this.#t))e.do&&!(e.do in n)&&a.add(e.do);if(a.size>0)throw Error(`${e}: the table needs ${[...a].sort().join(`, `)}, not implemented here`)}fire(e,t,n=``){let r=this.#e.find(n=>n.on===e&&n.from.includes(this.state)&&(!n.if||this.guards[n.if](t)));if(!r){this.onIllegal({machine:this.name,state:this.state,event:e,detail:n});let r=this.#t[e]??this.#t[`*`]??{};return r.do&&this.actions[r.do](t),r.to&&r.to!==`same`&&(this.state=r.to),!1}return r.do&&this.actions[r.do](t),r.to!==`same`&&(this.state=r.to),!0}},Wg={pieceTimeoutMs:1e4,pieceRetries:2,commitTimeoutMs:3e4},Gg=5120;function Kg(e,t=Gg){let n=[];for(let r=0;r<Math.max(e.length,1);r+=t)n.push({type:`FLOW_PUT`,offset:r,total:e.length,data:e.subarray(r,r+t)});return n}function qg(e,t){return e.type===`FLOW_PUT`?t.type===`FLOW_ACK`&&t.offset===e.offset:t.type===`DEP_ACK`&&t.name===e.name&&t.file===e.file&&t.offset===e.offset}function Jg(e){return e.type===`FLOW_PUT`?`flow byte ${e.offset}`:e.type===`DEP_PUT`?`${e.name} (${e.file} byte ${e.offset})`:e.type===`FLOW_COMMIT`?`the flow's commit`:`${e.name}'s commit`}var Yg=class{#e;#t;#n;#r;#i;#a=null;#o=null;#s=0;#c=0;#l=null;#u=null;#d=!1;#f=null;#p=null;#m=``;constructor(e,t={}){this.#e=e,this.#t=t.timing??Wg,this.#n=t.isRestartHello??(()=>!0),this.#r=t.onEvent??(()=>{}),this.#i=new Ug(`editor.transfer`,{morePieces:()=>this.#s<this.#a.pieces.length-1,canRetry:()=>this.#c<this.#t.pieceRetries},{sendPiece:()=>this.#_(0),sendNext:()=>this.#_(this.#s+1),sendCommit:()=>this.#_(-1),resend:e=>this.#v(e),fail:e=>this.#b(e),finishRestarted:e=>this.#x({kind:`restarted`,hello:e.message}),finishOk:e=>this.#x(e.message.type===`DEPLOY_ACK`?{kind:`deployed`,ack:e.message}:{kind:`installed`,result:e.message}),finishRefused:e=>{let t=e.message;this.#x(t.type===`DEPLOY_ERROR`?{kind:`refused`,code:t.code,message:t.message}:{kind:`refused`,code:t.code??`Unknown`,message:t.error??`${t.name} not installed`})},finishNoAnswer:()=>this.#x({kind:`no-answer`,timeoutMs:this.#t.commitTimeoutMs}),abort:()=>this.#S(),note:()=>{}},e=>this.#r({kind:`illegal`,move:e}))}get state(){return this.#i.state}deploy(e,t,n=Gg){return this.#h({pieces:Kg(e,n),commit:{type:`FLOW_COMMIT`,total:e.length,...t}})}install(e,t){return this.#h({pieces:e,commit:t})}receive(e){let t=this.#g(e);t!==null&&(this.#d=t===`garbled`,this.#i.fire(t,{event:t,message:e},`${e.type} ${JSON.stringify(e,(e,t)=>t instanceof Uint8Array?`<${t.length} bytes>`:t)}`))}connectionLost(e){this.#m=e,this.#i.fire(`lost`,{event:`lost`,message:null})}#h(e){return this.#i.state===`idle`?new Promise((t,n)=>{this.#a=e,this.#f=t,this.#p=n,this.#i.fire(`start`,{event:`start`,message:null})}):Promise.reject(Error(`a transfer is already under way`))}#g(e){let t=this.#i.state,n=this.#a;switch(e.type){case`HELLO`:return t!==`idle`&&this.#n(e)?`restart`:null;case`FLOW_ACK`:case`DEP_ACK`:{if(e.type===`FLOW_ACK`&&!e.ok&&e.code===`Garbled`)return`garbled`;let r=t===`sending`&&n?n.pieces[this.#s]:void 0;return r&&qg(r,e)?e.ok?`pieceOk`:`pieceRefused`:[...n?t===`committing`?n.pieces:n.pieces.slice(0,this.#s):[],...this.#o?.pieces??[]].some(t=>qg(t,e))?`staleAck`:`strayAck`}case`DEPLOY_ACK`:case`DEPLOY_ERROR`:return e.type===`DEPLOY_ERROR`&&e.code===`MemoryError`&&this.#d?`earlyMemoryError`:t===`committing`&&n?.commit.type===`FLOW_COMMIT`?e.type===`DEPLOY_ACK`?`commitOk`:`commitRefused`:`strayResult`;case`DEP_RESULT`:return t===`committing`&&n?.commit.type===`DEP_COMMIT`&&e.name===n.commit.name?e.ok?`commitOk`:`commitRefused`:`strayResult`;default:return null}}#_(e){let t=this.#a;this.#c=0,e>=0&&(this.#s=e),this.#y(e>=0?t.pieces[e]:t.commit)}#v(e){this.#c+=1;let t=e.event===`garbled`?e.message:null;this.#r({kind:`resend`,line:this.#l,reason:t?`garbled`:`timeout`,detail:t?.error??null,attempt:this.#c}),this.#y(this.#l)}#y(e){this.#l=e,this.#C();let t=e.type===`FLOW_COMMIT`||e.type===`DEP_COMMIT`?this.#t.commitTimeoutMs:this.#t.pieceTimeoutMs;this.#u=setTimeout(()=>{this.#u=null,this.#i.fire(`timeout`,{event:`timeout`,message:null})},t),this.#e.send(e).catch(e=>this.connectionLost(e instanceof Error?e.message:String(e)))}#b(e){let t=this.#l,n,r;if(e.event===`timeout`)n=`Timeout`,r=`no reply to ${Jg(t)} after ${this.#t.pieceRetries+1} tries`;else{let i=e.message;n=i.code??`BadPiece`,r=i.error??`the board refused ${Jg(t)}`}this.#x({kind:`pieces-failed`,failure:{code:n,message:r,line:t}})}#x(e){this.#C();let t=this.#f;this.#o=this.#a,this.#a=null,this.#f=this.#p=null,t?.(e)}#S(){this.#C();let e=this.#p;this.#o=this.#a,this.#a=null,this.#f=this.#p=null,e?.(Error(this.#m||`the connection closed`))}#C(){this.#u!==null&&clearTimeout(this.#u),this.#u=null}};function Xg(e){let t=[];return e.version&&t.push(`v${e.version}`),e.commit&&t.push(e.commit+(e.dirty?`+`:``)),t.length>0?t.join(` · `):`dev build`}function Zg(e){let t=e.commit?`, commit ${e.commit}${e.dirty?` with uncommitted changes`:``}`:`, commit unknown`;return`Editor ${e.version??`(version unknown)`}${t}, built ${e.builtAt}`}function Qg(e,t,n,r,i,a,o){try{var s=e[a](o),c=s.value}catch(e){n(e);return}s.done?t(c):Promise.resolve(c).then(r,i)}function G(e){return function(){var t=this,n=arguments;return new Promise(function(r,i){var a=e.apply(t,n);function o(e){Qg(a,r,i,o,s,`next`,e)}function s(e){Qg(a,r,i,o,s,`throw`,e)}o(void 0)})}}function K(e,t){if(!(e instanceof t))throw TypeError(`Cannot call a class as a function`)}function $g(e){"@babel/helpers - typeof";return $g=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},$g(e)}function e_(e,t){if($g(e)!=`object`||!e)return e;var n;if(typeof Symbol<`u`&&(n=e[Symbol.toPrimitive])!==void 0){var r=n.call(e,t||`default`);if($g(r)!=`object`)return r;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(t===`string`?String:Number)(e)}function t_(e){var t=e_(e,`string`);return $g(t)==`symbol`?t:t+``}function n_(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,`value`in r&&(r.writable=!0),Object.defineProperty(e,t_(r.key),r)}}function q(e,t,n){return t&&n_(e.prototype,t),n&&n_(e,n),Object.defineProperty(e,"prototype",{writable:!1}),e}function r_(e){if(e===void 0)throw ReferenceError(`this hasn't been initialised - super() hasn't been called`);return e}function i_(e,t){if(t&&($g(t)==`object`||typeof t==`function`))return t;if(t!==void 0)throw TypeError(`Derived constructors may only return object or undefined`);return r_(e)}function a_(e){return a_=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(e){return e.__proto__||Object.getPrototypeOf(e)},a_(e)}function o_(e,t){return o_=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(e,t){return e.__proto__=t,e},o_(e,t)}function s_(e,t){if(typeof t!=`function`&&t!==null)throw TypeError(`Super expression must either be null or a function`);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),Object.defineProperty(e,"prototype",{writable:!1}),t&&o_(e,t)}function J(e,t,n){return(t=t_(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var c_=o(((e,t)=>{function n(e,t){this.v=e,this.k=t}t.exports=n,t.exports.__esModule=!0,t.exports.default=t.exports})),l_=o(((e,t)=>{function n(e,r,i,a){var o=Object.defineProperty;try{o({},``,{})}catch{o=0}t.exports=n=function(e,t,r,i){function a(t,r){n(e,t,function(e){return this._invoke(t,r,e)})}t?o?o(e,t,{value:r,enumerable:!i,configurable:!i,writable:!i}):e[t]=r:(a(`next`,0),a(`throw`,1),a(`return`,2))},t.exports.__esModule=!0,t.exports.default=t.exports,n(e,r,i,a)}t.exports=n,t.exports.__esModule=!0,t.exports.default=t.exports})),u_=o(((e,t)=>{var n=l_();function r(){var e,i,a=typeof Symbol==`function`?Symbol:{},o=a.iterator||`@@iterator`,s=a.toStringTag||`@@toStringTag`;function c(t,r,a,o){var s=r&&r.prototype instanceof u?r:u,c=Object.create(s.prototype);return n(c,`_invoke`,function(t,n,r){var a,o,s,c=0,u=r||[],d=!1,f={p:0,n:0,v:e,a:p,f:p.bind(e,4),d:function(t,n){return a=t,o=0,s=e,f.n=n,l}};function p(t,n){for(o=t,s=n,i=0;!d&&c&&!r&&i<u.length;i++){var r,a=u[i],p=f.p,m=a[2];t>3?(r=m===n)&&(s=a[(o=a[4])?5:(o=3,3)],a[4]=a[5]=e):a[0]<=p&&((r=t<2&&p<a[1])?(o=0,f.v=n,f.n=a[1]):p<m&&(r=t<3||a[0]>n||n>m)&&(a[4]=t,a[5]=n,f.n=m,o=0))}if(r||t>1)return l;throw d=!0,n}return function(r,u,m){if(c>1)throw TypeError(`Generator is already running`);for(d&&u===1&&p(u,m),o=u,s=m;(i=o<2?e:s)||!d;){a||(o?o<3?(o>1&&(f.n=-1),p(o,s)):f.n=s:f.v=s);try{if(c=2,a){if(o||(r=`next`),i=a[r]){if(!(i=i.call(a,s)))throw TypeError(`iterator result is not an object`);if(!i.done)return i;s=i.value,o<2&&(o=0)}else o===1&&(i=a.return)&&i.call(a),o<2&&(s=TypeError(`The iterator does not provide a '`+r+`' method`),o=1);a=e}else if((i=(d=f.n<0)?s:t.call(n,f))!==l)break}catch(t){a=e,o=1,s=t}finally{c=1}}return{value:i,done:d}}}(t,a,o),!0),c}var l={};function u(){}function d(){}function f(){}i=Object.getPrototypeOf;var p=[][o]?i(i([][o]())):(n(i={},o,function(){return this}),i),m=f.prototype=u.prototype=Object.create(p);function h(e){return Object.setPrototypeOf?Object.setPrototypeOf(e,f):(e.__proto__=f,n(e,s,`GeneratorFunction`)),e.prototype=Object.create(m),e}return d.prototype=f,n(m,`constructor`,f),n(f,`constructor`,d),d.displayName=`GeneratorFunction`,n(f,s,`GeneratorFunction`),n(m),n(m,s,`Generator`),n(m,o,function(){return this}),n(m,`toString`,function(){return`[object Generator]`}),(t.exports=r=function(){return{w:c,m:h}},t.exports.__esModule=!0,t.exports.default=t.exports)()}t.exports=r,t.exports.__esModule=!0,t.exports.default=t.exports})),d_=o(((e,t)=>{var n=c_(),r=l_();function i(e,t){function a(r,i,o,s){try{var c=e[r](i),l=c.value;return l instanceof n?t.resolve(l.v).then(function(e){a(`next`,e,o,s)},function(e){a(`throw`,e,o,s)}):t.resolve(l).then(function(e){c.value=e,o(c)},function(e){return a(`throw`,e,o,s)})}catch(e){s(e)}}var o;this.next||(r(i.prototype),r(i.prototype,typeof Symbol==`function`&&Symbol.asyncIterator||`@asyncIterator`,function(){return this})),r(this,`_invoke`,function(e,n,r){function i(){return new t(function(t,n){a(e,r,t,n)})}return o=o?o.then(i,i):i()},!0)}t.exports=i,t.exports.__esModule=!0,t.exports.default=t.exports})),f_=o(((e,t)=>{var n=u_(),r=d_();function i(e,t,i,a,o){return new r(n().w(e,t,i,a),o||Promise)}t.exports=i,t.exports.__esModule=!0,t.exports.default=t.exports})),p_=o(((e,t)=>{var n=f_();function r(e,t,r,i,a){var o=n(e,t,r,i,a);return o.next().then(function(e){return e.done?e.value:o.next()})}t.exports=r,t.exports.__esModule=!0,t.exports.default=t.exports})),m_=o(((e,t)=>{function n(e){var t=Object(e),n=[];for(var r in t)n.unshift(r);return function e(){for(;n.length;)if((r=n.pop())in t)return e.value=r,e.done=!1,e;return e.done=!0,e}}t.exports=n,t.exports.__esModule=!0,t.exports.default=t.exports})),h_=o(((e,t)=>{function n(e){"@babel/helpers - typeof";return t.exports=n=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},t.exports.__esModule=!0,t.exports.default=t.exports,n(e)}t.exports=n,t.exports.__esModule=!0,t.exports.default=t.exports})),g_=o(((e,t)=>{var n=h_().default;function r(e){if(e!=null){var t=e[typeof Symbol==`function`&&Symbol.iterator||`@@iterator`],r=0;if(t)return t.call(e);if(typeof e.next==`function`)return e;if(!isNaN(e.length))return{next:function(){return e&&r>=e.length&&(e=void 0),{value:e&&e[r++],done:!e}}}}throw TypeError(n(e)+` is not iterable`)}t.exports=r,t.exports.__esModule=!0,t.exports.default=t.exports})),__=o(((e,t)=>{var n=c_(),r=u_(),i=p_(),a=f_(),o=d_(),s=m_(),c=g_();function l(){var e=r(),u=e.m(l),d=(Object.getPrototypeOf?Object.getPrototypeOf(u):u.__proto__).constructor;function f(e){var t=typeof e==`function`&&e.constructor;return!!t&&(t===d||(t.displayName||t.name)===`GeneratorFunction`)}var p={throw:1,return:2,break:3,continue:3};function m(e){var t,n;return function(r){t||(t={stop:function(){return n(r.a,2)},catch:function(){return r.v},abrupt:function(e,t){return n(r.a,p[e],t)},delegateYield:function(e,i,a){return t.resultName=i,n(r.d,c(e),a)},finish:function(e){return n(r.f,e)}},n=function(e,n,i){r.p=t.prev,r.n=t.next;try{return e(n,i)}finally{t.next=r.n}}),t.resultName&&(t[t.resultName]=r.v,t.resultName=void 0),t.sent=r.v,t.next=r.n;try{return e.call(this,t)}finally{r.p=t.prev,r.n=t.next}}}return(t.exports=l=function(){return{wrap:function(t,n,r,i){return e.w(m(t),n,r,i&&i.reverse())},isGeneratorFunction:f,mark:e.m,awrap:function(e,t){return new n(e,t)},AsyncIterator:o,async:function(e,t,n,r,o){return(f(t)?a:i)(m(e),t,n,r,o)},keys:s,values:c}},t.exports.__esModule=!0,t.exports.default=t.exports)()}t.exports=l,t.exports.__esModule=!0,t.exports.default=t.exports})),Y=c(o(((e,t)=>{var n=__()();t.exports=n;try{regeneratorRuntime=n}catch{typeof globalThis==`object`?globalThis.regeneratorRuntime=n:Function(`r`,`regeneratorRuntime = r`)(n)}}))());function v_(e,t){var n=typeof Symbol<`u`&&e[Symbol.iterator]||e[`@@iterator`];if(!n){if(Array.isArray(e)||(n=y_(e))||t&&e&&typeof e.length==`number`){n&&(e=n);var r=0,i=function(){};return{s:i,n:function(){return r>=e.length?{done:!0}:{done:!1,value:e[r++]}},e:function(e){throw e},f:i}}throw TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var a,o=!0,s=!1;return{s:function(){n=n.call(e)},n:function(){var e=n.next();return o=e.done,e},e:function(e){s=!0,a=e},f:function(){try{o||n.return==null||n.return()}finally{if(s)throw a}}}}function y_(e,t){if(e){if(typeof e==`string`)return b_(e,t);var n={}.toString.call(e).slice(8,-1);return n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`?Array.from(e):n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?b_(e,t):void 0}}function b_(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function x_(){return{debug:function(e){}}}var S_=function(){function e(){K(this,e),J(this,`pipes`,[])}return q(e,[{key:`addPipe`,value:function(e){this.pipes.push(e)}},{key:`emit`,value:function(){var e=G(Y.default.mark(function e(t){var n,r,i,a;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:n=t,r=v_(this.pipes),e.prev=2,r.s();case 4:if((i=r.n()).done){e.next=13;break}return a=i.value,e.next=8,a(n);case 8:if(n=e.sent,n!==void 0){e.next=11;break}return e.abrupt(`return`);case 11:e.next=4;break;case 13:e.next=18;break;case 15:e.prev=15,e.t0=e.catch(2),r.e(e.t0);case 18:return e.prev=18,r.f(),e.finish(18);case 21:return e.abrupt(`return`,n);case 22:case`end`:return e.stop()}},e,this,[[2,15,18,21]])}));function t(t){return e.apply(this,arguments)}return t}()}])}(),C_=function(){function e(t){K(this,e),J(this,`signal`,new S_),this.name=t}return q(e,[{key:`addPipe`,value:function(e){this.signal.addPipe(e)}},{key:`use`,value:function(t){if(!(t instanceof e))throw Error(`cannot use non-Scope instance`);return t.setParent(this),this.addPipe(function(e){return t.signal.emit(e)}),x_()}},{key:`setParent`,value:function(e){this.parent=e}},{key:`emit`,value:function(e){return this.signal.emit(e)}},{key:`hasParent`,value:function(){return!!this.parent}},{key:`parentScope`,value:function(e){if(!this.parent)throw Error(`cannot find parent`);if(e&&this.parent instanceof e)return this.parent;if(e)throw Error(`actual parent is not instance of type`);return this.parent}}])}();function w_(e,t){var n=typeof Symbol<`u`&&e[Symbol.iterator]||e[`@@iterator`];if(!n){if(Array.isArray(e)||(n=T_(e))||t&&e&&typeof e.length==`number`){n&&(e=n);var r=0,i=function(){};return{s:i,n:function(){return r>=e.length?{done:!0}:{done:!1,value:e[r++]}},e:function(e){throw e},f:i}}throw TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var a,o=!0,s=!1;return{s:function(){n=n.call(e)},n:function(){var e=n.next();return o=e.done,e},e:function(e){s=!0,a=e},f:function(){try{o||n.return==null||n.return()}finally{if(s)throw a}}}}function T_(e,t){if(e){if(typeof e==`string`)return E_(e,t);var n={}.toString.call(e).slice(8,-1);return n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`?Array.from(e):n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?E_(e,t):void 0}}function E_(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function D_(e,t,n){return t=a_(t),i_(e,O_()?Reflect.construct(t,n||[],a_(e).constructor):t.apply(e,n))}function O_(){try{var e=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(O_=function(){return!!e})()}var k_=function(e){function t(){var e;return K(this,t),e=D_(this,t,[`NodeEditor`]),J(e,`nodes`,[]),J(e,`connections`,[]),e}return s_(t,e),q(t,[{key:`getNode`,value:function(e){return this.nodes.find(function(t){return t.id===e})}},{key:`getNodes`,value:function(){return this.nodes.slice()}},{key:`getConnections`,value:function(){return this.connections.slice()}},{key:`getConnection`,value:function(e){return this.connections.find(function(t){return t.id===e})}},{key:`addNode`,value:function(){var e=G(Y.default.mark(function e(t){return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(!this.getNode(t.id)){e.next=2;break}throw Error(`node has already been added`);case 2:return e.next=4,this.emit({type:`nodecreate`,data:t});case 4:if(e.sent){e.next=6;break}return e.abrupt(`return`,!1);case 6:return this.nodes.push(t),e.next=9,this.emit({type:`nodecreated`,data:t});case 9:return e.abrupt(`return`,!0);case 10:case`end`:return e.stop()}},e,this)}));function t(t){return e.apply(this,arguments)}return t}()},{key:`addConnection`,value:function(){var e=G(Y.default.mark(function e(t){return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(!this.getConnection(t.id)){e.next=2;break}throw Error(`connection has already been added`);case 2:return e.next=4,this.emit({type:`connectioncreate`,data:t});case 4:if(e.sent){e.next=6;break}return e.abrupt(`return`,!1);case 6:return this.connections.push(t),e.next=9,this.emit({type:`connectioncreated`,data:t});case 9:return e.abrupt(`return`,!0);case 10:case`end`:return e.stop()}},e,this)}));function t(t){return e.apply(this,arguments)}return t}()},{key:`removeNode`,value:function(){var e=G(Y.default.mark(function e(t){var n,r;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(n=this.nodes.find(function(e){return e.id===t}),n){e.next=3;break}throw Error(`cannot find node`);case 3:return e.next=5,this.emit({type:`noderemove`,data:n});case 5:if(e.sent){e.next=7;break}return e.abrupt(`return`,!1);case 7:return r=this.nodes.indexOf(n),this.nodes.splice(r,1),e.next=11,this.emit({type:`noderemoved`,data:n});case 11:return e.abrupt(`return`,!0);case 12:case`end`:return e.stop()}},e,this)}));function t(t){return e.apply(this,arguments)}return t}()},{key:`removeConnection`,value:function(){var e=G(Y.default.mark(function e(t){var n,r;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(n=this.connections.find(function(e){return e.id===t}),n){e.next=3;break}throw Error(`cannot find connection`);case 3:return e.next=5,this.emit({type:`connectionremove`,data:n});case 5:if(e.sent){e.next=7;break}return e.abrupt(`return`,!1);case 7:return r=this.connections.indexOf(n),this.connections.splice(r,1),e.next=11,this.emit({type:`connectionremoved`,data:n});case 11:return e.abrupt(`return`,!0);case 12:case`end`:return e.stop()}},e,this)}));function t(t){return e.apply(this,arguments)}return t}()},{key:`clear`,value:function(){var e=G(Y.default.mark(function e(){var t,n,r,i,a,o;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,this.emit({type:`clear`});case 2:if(e.sent){e.next=6;break}return e.next=5,this.emit({type:`clearcancelled`});case 5:return e.abrupt(`return`,!1);case 6:t=w_(this.connections.slice()),e.prev=7,t.s();case 9:if((n=t.n()).done){e.next=15;break}return r=n.value,e.next=13,this.removeConnection(r.id);case 13:e.next=9;break;case 15:e.next=20;break;case 17:e.prev=17,e.t0=e.catch(7),t.e(e.t0);case 20:return e.prev=20,t.f(),e.finish(20);case 23:i=w_(this.nodes.slice()),e.prev=24,i.s();case 26:if((a=i.n()).done){e.next=32;break}return o=a.value,e.next=30,this.removeNode(o.id);case 30:e.next=26;break;case 32:e.next=37;break;case 34:e.prev=34,e.t1=e.catch(24),i.e(e.t1);case 37:return e.prev=37,i.f(),e.finish(37);case 40:return e.next=42,this.emit({type:`cleared`});case 42:return e.abrupt(`return`,!0);case 43:case`end`:return e.stop()}},e,this,[[7,17,20,23],[24,34,37,40]])}));function t(){return e.apply(this,arguments)}return t}()}])}(C_),A_=globalThis.crypto;function j_(){if(`randomBytes`in A_)return A_.randomBytes(8).toString(`hex`);var e=A_.getRandomValues(new Uint8Array(8));return Array.from(e).map(function(e){return e.toString(16).padStart(2,`0`)}).join(``)}function M_(e,t,n){return t=a_(t),i_(e,N_()?Reflect.construct(t,n||[],a_(e).constructor):t.apply(e,n))}function N_(){try{var e=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(N_=function(){return!!e})()}var P_=q(function e(t){K(this,e),this.name=t}),F_=q(function e(t,n,r){K(this,e),this.socket=t,this.label=n,this.multipleConnections=r,this.id=j_()}),I_=function(e){function t(e,n,r){var i;return K(this,t),i=M_(this,t,[e,n,r]),J(i,`control`,null),J(i,`showControl`,!0),i.socket=e,i.label=n,i.multipleConnections=r,i}return s_(t,e),q(t,[{key:`addControl`,value:function(e){if(this.control)throw Error(`control already added for this input`);this.control=e}},{key:`removeControl`,value:function(){this.control=null}}])}(F_),L_=function(e){function t(e,n,r){return K(this,t),M_(this,t,[e,n,r!==!1])}return s_(t,e),q(t)}(F_),R_=q(function e(){K(this,e),this.id=j_()}),z_=Object.freeze({__proto__:null,Socket:P_,Port:F_,Input:I_,Output:L_,Control:R_,InputControl:function(e){function t(e,n){var r;return K(this,t),r=M_(this,t),r.type=e,r.options=n,r.id=j_(),r.readonly=n?.readonly??!1,n?.initial!==void 0&&(r.value=n.initial),r}return s_(t,e),q(t,[{key:`setValue`,value:function(e){var t;this.value=e,(t=this.options)!=null&&t.change&&this.options.change(e)}}])}(R_),Node:function(){function e(t){K(this,e),J(this,`inputs`,{}),J(this,`outputs`,{}),J(this,`controls`,{}),this.label=t,this.id=j_()}return q(e,[{key:`hasInput`,value:function(e){return Object.prototype.hasOwnProperty.call(this.inputs,e)}},{key:`addInput`,value:function(e,t){if(this.hasInput(e))throw Error(`input with key '${String(e)}' already added`);Object.defineProperty(this.inputs,e,{value:t,enumerable:!0,configurable:!0})}},{key:`removeInput`,value:function(e){delete this.inputs[e]}},{key:`hasOutput`,value:function(e){return Object.prototype.hasOwnProperty.call(this.outputs,e)}},{key:`addOutput`,value:function(e,t){if(this.hasOutput(e))throw Error(`output with key '${String(e)}' already added`);Object.defineProperty(this.outputs,e,{value:t,enumerable:!0,configurable:!0})}},{key:`removeOutput`,value:function(e){delete this.outputs[e]}},{key:`hasControl`,value:function(e){return Object.prototype.hasOwnProperty.call(this.controls,e)}},{key:`addControl`,value:function(e,t){if(this.hasControl(e))throw Error(`control with key '${String(e)}' already added`);Object.defineProperty(this.controls,e,{value:t,enumerable:!0,configurable:!0})}},{key:`removeControl`,value:function(e){delete this.controls[e]}}])}(),Connection:q(function e(t,n,r,i){if(K(this,e),this.sourceOutput=n,this.targetInput=i,!t.outputs[n])throw Error(`source node doesn't have output with a key ${String(n)}`);if(!r.inputs[i])throw Error(`target node doesn't have input with a key ${String(i)}`);this.id=j_(),this.source=t.id,this.target=r.id})});function B_(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function V_(e){if(Array.isArray(e))return B_(e)}function H_(e){if(typeof Symbol<`u`&&e[Symbol.iterator]!=null||e[`@@iterator`]!=null)return Array.from(e)}function U_(e,t){if(e){if(typeof e==`string`)return B_(e,t);var n={}.toString.call(e).slice(8,-1);return n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`?Array.from(e):n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?B_(e,t):void 0}}function W_(){throw TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function G_(e){return V_(e)||H_(e)||U_(e)||W_()}var K_=function(){function e(t){K(this,e),this.reordered=t,this.holder=document.createElement(`div`),this.holder.style.transformOrigin=`0 0`}return q(e,[{key:`getPointerFrom`,value:function(e){var t=this.holder.getBoundingClientRect(),n=t.left,r=t.top;return{x:e.clientX-n,y:e.clientY-r}}},{key:`add`,value:function(e){this.holder.appendChild(e)}},{key:`reorder`,value:function(){var e=G(Y.default.mark(function e(t,n){return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(this.holder.contains(t)){e.next=2;break}throw Error(`content doesn't have 'target' for reordering`);case 2:if(n===null||this.holder.contains(n)){e.next=4;break}throw Error(`content doesn't have 'next' for reordering`);case 4:return this.holder.insertBefore(t,n),e.next=7,this.reordered(t);case 7:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`remove`,value:function(e){this.holder.contains(e)&&this.holder.removeChild(e)}}])}();function q_(e,t){var n=function(e){t.move(e)},r=function(e){window.removeEventListener(`pointermove`,n),window.removeEventListener(`pointerup`,r),window.removeEventListener(`pointercancel`,r),t.up(e)},i=function(e){window.addEventListener(`pointermove`,n),window.addEventListener(`pointerup`,r),window.addEventListener(`pointercancel`,r),t.down(e)};return e.addEventListener(`pointerdown`,i),{destroy:function(){e.removeEventListener(`pointerdown`,i),window.removeEventListener(`pointermove`,n),window.removeEventListener(`pointerup`,r),window.removeEventListener(`pointercancel`,r)}}}var J_=function(e){return e.length===0?0:Math.min.apply(Math,G_(e))},Y_=function(e){return e.length===0?0:Math.max.apply(Math,G_(e))};function X_(e){var t=J_(e.map(function(e){return e.position.x})),n=J_(e.map(function(e){return e.position.y})),r=Y_(e.map(function(e){return e.position.x+e.width})),i=Y_(e.map(function(e){return e.position.y+e.height}));return{left:t,right:r,top:n,bottom:i,width:Math.abs(t-r),height:Math.abs(n-i),center:{x:(t+r)/2,y:(n+i)/2}}}function Z_(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function Q_(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Z_(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Z_(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}var $_=function(){function e(t){var n=this;K(this,e),J(this,`down`,function(e){n.guards.down(e)&&(e.stopPropagation(),n.pointerStart={x:e.pageX,y:e.pageY},n.startPosition=Q_({},n.config.getCurrentPosition()),n.events.start(e))}),J(this,`move`,function(e){if(n.pointerStart&&n.startPosition&&n.guards.move(e)){e.preventDefault();var t={x:e.pageX-n.pointerStart.x,y:e.pageY-n.pointerStart.y},r=n.config.getZoom(),i=n.startPosition.x+t.x/r,a=n.startPosition.y+t.y/r;n.events.translate(i,a,e)}}),J(this,`up`,function(e){n.pointerStart&&(delete n.pointerStart,n.events.drag(e))}),this.guards=t||{down:function(e){return e.pointerType!==`mouse`||e.button===0},move:function(){return!0}}}return q(e,[{key:`initialize`,value:function(e,t,n){this.config=t,this.events=n,e.style.touchAction=`none`,this.pointerListener=q_(e,{down:this.down,move:this.move,up:this.up})}},{key:`destroy`,value:function(){this.pointerListener.destroy()}}])}(),ev=8,tv=24,nv=1,rv=2;function iv(e,t){return t===nv?e*ev:t===rv?e*tv:e}function av(e,t){if(e===0)return 0;var n=t/ev,r=-e*n;return Math.sign(r)*Math.min(t,Math.abs(r))}var ov=function(){function e(t){var n=this;K(this,e),J(this,`previous`,null),J(this,`pointers`,[]),J(this,`wheel`,function(e){e.preventDefault();var t=av(iv(e.deltaY,e.deltaMode),n.intensity);if(t!==0){var r=n.element.getBoundingClientRect(),i=r.left,a=r.top,o=(i-e.clientX)*t,s=(a-e.clientY)*t;n.onzoom(t,o,s,`wheel`)}}),J(this,`down`,function(e){n.pointers.push(e)}),J(this,`move`,function(e){if(n.pointers=n.pointers.map(function(t){return t.pointerId===e.pointerId?e:t}),n.isTranslating()){var t=n.element.getBoundingClientRect(),r=t.left,i=t.top,a=n.getTouches(),o=a.cx,s=a.cy,c=a.distance;if(n.previous!==null&&n.previous.distance>0){var l=c/n.previous.distance-1,u=(r-o)*l,d=(i-s)*l;n.onzoom(l,u-(n.previous.cx-o),d-(n.previous.cy-s),`touch`)}n.previous={cx:o,cy:s,distance:c}}}),J(this,`contextmenu`,function(){n.pointers=[]}),J(this,`up`,function(e){n.previous=null,n.pointers=n.pointers.filter(function(t){return t.pointerId!==e.pointerId})}),J(this,`dblclick`,function(e){e.preventDefault();var t=n.element.getBoundingClientRect(),r=t.left,i=t.top,a=4*n.intensity,o=(r-e.clientX)*a,s=(i-e.clientY)*a;n.onzoom(a,o,s,`dblclick`)}),this.intensity=t}return q(e,[{key:`initialize`,value:function(e,t,n){this.container=e,this.element=t,this.onzoom=n,this.container.addEventListener(`wheel`,this.wheel),this.container.addEventListener(`pointerdown`,this.down),this.container.addEventListener(`dblclick`,this.dblclick),window.addEventListener(`pointermove`,this.move),window.addEventListener(`pointerup`,this.up),window.addEventListener(`pointercancel`,this.up),window.addEventListener(`contextmenu`,this.contextmenu)}},{key:`getTouches`,value:function(){var e={touches:this.pointers},t=[e.touches[0].clientX,e.touches[0].clientY],n=t[0],r=t[1],i=[e.touches[1].clientX,e.touches[1].clientY],a=i[0],o=i[1],s=Math.sqrt((n-a)**2+(r-o)**2);return{cx:(n+a)/2,cy:(r+o)/2,distance:s}}},{key:`isTranslating`,value:function(){return this.pointers.length>=2}},{key:`destroy`,value:function(){this.container.removeEventListener(`wheel`,this.wheel),this.container.removeEventListener(`pointerdown`,this.down),this.container.removeEventListener(`dblclick`,this.dblclick),window.removeEventListener(`pointermove`,this.move),window.removeEventListener(`pointerup`,this.up),window.removeEventListener(`pointercancel`,this.up),window.removeEventListener(`contextmenu`,this.contextmenu)}}])}(),sv=function(){function e(t,n,r){var i=this;K(this,e),J(this,`transform`,{k:1,x:0,y:0}),J(this,`pointer`,{x:0,y:0}),J(this,`zoomHandler`,null),J(this,`dragHandler`,null),J(this,`pointerdown`,function(e){i.setPointerFrom(e),i.events.pointerDown(i.pointer,e)}),J(this,`pointermove`,function(e){i.setPointerFrom(e),i.events.pointerMove(i.pointer,e)}),J(this,`pointerup`,function(e){i.setPointerFrom(e),i.events.pointerUp(i.pointer,e)}),J(this,`resize`,function(e){i.events.resize(e)}),J(this,`onTranslate`,function(e,t){var n;(n=i.zoomHandler)!=null&&n.isTranslating()||i.translate(e,t)}),J(this,`onZoom`,function(e,t,n,r){i.zoom(i.transform.k*(1+e),t,n,r),i.update()}),this.container=t,this.events=n,this.guards=r,this.content=new K_(function(e){return i.events.reordered(e)}),this.content.holder.style.transformOrigin=`0 0`,this.setZoomHandler(new ov(.1)),this.setDragHandler(new $_),this.container.addEventListener(`pointerdown`,this.pointerdown),this.container.addEventListener(`pointermove`,this.pointermove),window.addEventListener(`pointerup`,this.pointerup),window.addEventListener(`resize`,this.resize),t.appendChild(this.content.holder),this.update()}return q(e,[{key:`update`,value:function(){var e=this.transform,t=e.x,n=e.y,r=e.k;this.content.holder.style.transform=`translate(${t}px, ${n}px) scale(${r})`}},{key:`setDragHandler`,value:function(e){var t=this;this.dragHandler&&this.dragHandler.destroy(),this.dragHandler=e,this.dragHandler&&this.dragHandler.initialize(this.container,{getCurrentPosition:function(){return t.transform},getZoom:function(){return 1}},{start:function(){return null},translate:this.onTranslate,drag:function(){return null}})}},{key:`setZoomHandler`,value:function(e){this.zoomHandler&&this.zoomHandler.destroy(),this.zoomHandler=e,this.zoomHandler&&this.zoomHandler.initialize(this.container,this.content.holder,this.onZoom)}},{key:`setPointerFrom`,value:function(e){var t=this.content.getPointerFrom(e),n=t.x,r=t.y,i=this.transform.k;this.pointer={x:n/i,y:r/i}}},{key:`translate`,value:function(){var e=G(Y.default.mark(function e(t,n){var r,i;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return r={x:t,y:n},e.next=3,this.guards.translate({previous:this.transform,position:r});case 3:if(i=e.sent,i){e.next=6;break}return e.abrupt(`return`,!1);case 6:return this.transform.x=i.data.position.x,this.transform.y=i.data.position.y,this.update(),e.next=11,this.events.translated(i.data);case 11:return e.abrupt(`return`,!0);case 12:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`zoom`,value:function(){var e=G(Y.default.mark(function e(t){var n,r,i,a,o,s,c=arguments;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return n=c.length>1&&c[1]!==void 0?c[1]:0,r=c.length>2&&c[2]!==void 0?c[2]:0,i=c.length>3?c[3]:void 0,a=this.transform.k,e.next=6,this.guards.zoom({previous:this.transform,zoom:t,source:i});case 6:if(o=e.sent,o){e.next=9;break}return e.abrupt(`return`,!0);case 9:return s=(a-o.data.zoom)/(a-t||1),this.transform.k=o.data.zoom||1,this.transform.x+=n*s,this.transform.y+=r*s,this.update(),e.next=16,this.events.zoomed(o.data);case 16:return e.abrupt(`return`,!1);case 17:case`end`:return e.stop()}},e,this)}));function t(t){return e.apply(this,arguments)}return t}()},{key:`destroy`,value:function(){this.container.removeEventListener(`pointerdown`,this.pointerdown),this.container.removeEventListener(`pointermove`,this.pointermove),window.removeEventListener(`pointerup`,this.pointerup),window.removeEventListener(`resize`,this.resize),this.dragHandler&&this.dragHandler.destroy(),this.zoomHandler&&this.zoomHandler.destroy(),this.content.holder.innerHTML=``}}])}();function cv(e,t,n){return t=a_(t),i_(e,lv()?Reflect.construct(t,n||[],a_(e).constructor):t.apply(e,n))}function lv(){try{var e=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(lv=function(){return!!e})()}var uv=function(e){function t(){return K(this,t),cv(this,t,arguments)}return s_(t,e),q(t)}(C_),dv=q(function e(t){K(this,e),this.element=document.createElement(`div`),this.element.style.position=`absolute`,this.element.style.left=`0`,this.element.style.top=`0`,this.element.addEventListener(`contextmenu`,function(e){t.contextmenu(e)})}),fv=function(){function e(){K(this,e),J(this,`views`,new WeakMap),J(this,`viewsElements`,new Map)}return q(e,[{key:`set`,value:function(e){var t=e.element,n=e.type,r=e.payload;r!=null&&r.id&&(this.views.set(t,e),this.viewsElements.set(`${n}_${r.id}`,t))}},{key:`get`,value:function(e,t){var n=this.viewsElements.get(`${e}_${t}`);return n&&this.views.get(n)}},{key:`delete`,value:function(e){var t,n=this.views.get(e);n&&(t=n.payload)!=null&&t.id&&(this.views.delete(e),this.viewsElements.delete(`${n.type}_${n.payload.id}`))}}])}();function pv(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function mv(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?pv(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):pv(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}var hv=function(){function e(t,n,r){var i=this;K(this,e),J(this,`translate`,function(){var e=G(Y.default.mark(function e(t,n){var r,a;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return r=mv({},i.position),e.next=3,i.guards.translate({previous:r,position:{x:t,y:n}});case 3:if(a=e.sent,a){e.next=6;break}return e.abrupt(`return`,!1);case 6:return i.position=mv({},a.data.position),i.element.style.transform=`translate(${i.position.x}px, ${i.position.y}px)`,e.next=10,i.events.translated({position:i.position,previous:r});case 10:return e.abrupt(`return`,!0);case 11:case`end`:return e.stop()}},e)}));return function(t,n){return e.apply(this,arguments)}}()),J(this,`resize`,function(){var e=G(Y.default.mark(function e(t,n){var r,a;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return r={width:t,height:n},e.next=3,i.guards.resize({size:r});case 3:if(e.sent){e.next=5;break}return e.abrupt(`return`,!1);case 5:if(a=i.element.querySelector(`*:not(span):not([fragment])`),a&&a instanceof HTMLElement){e.next=8;break}return e.abrupt(`return`,!1);case 8:return a.style.width=`${t}px`,a.style.height=`${n}px`,e.next=12,i.events.resized({size:r});case 12:return e.abrupt(`return`,!0);case 13:case`end`:return e.stop()}},e)}));return function(t,n){return e.apply(this,arguments)}}()),this.getZoom=t,this.events=n,this.guards=r,this.element=document.createElement(`div`),this.element.style.position=`absolute`,this.position={x:0,y:0},this.translate(0,0),this.element.addEventListener(`contextmenu`,function(e){i.events.contextmenu(e)}),this.dragHandler=new $_,this.dragHandler.initialize(this.element,{getCurrentPosition:function(){return i.position},getZoom:function(){return i.getZoom()}},{start:this.events.picked,translate:this.translate,drag:this.events.dragged})}return q(e,[{key:`destroy`,value:function(){this.dragHandler.destroy()}}])}();function gv(e,t){return e.map(function(e){return{view:t.get(e.id),node:e}}).filter(function(e){return e.view}).map(function(e){var t=e.view,n=e.node,r=n.width,i=n.height;return r!==void 0&&i!==void 0?{position:t.position,width:r,height:i}:{position:t.position,width:t.element.clientWidth,height:t.element.clientHeight}})}function _v(e,t){var n=e.parentScope(k_);return X_(gv(t.map(function(e){return $g(e)===`object`?e:n.getNode(e)}),e.nodeViews))}function vv(e){var t=e;t.addPipe(function(e){if(!e||$g(e)!==`object`||!(`type`in e))return e;if(e.type===`nodepicked`){var n=t.nodeViews.get(e.data.id),r=t.area.content;n&&r.reorder(n.element,null)}if(e.type===`connectioncreated`){var i=t.connectionViews.get(e.data.id),a=t.area.content;i&&a.reorder(i.element,a.holder.firstChild)}return e})}var yv=0,bv=1;function xv(e){var t=e,n=bv,r=function(e){var n=t.nodeViews.get(e);n&&(n.element.style.zIndex=String(bv))},i=function(e){var r=t.nodeViews.get(e);r&&(n+=1,r.element.style.zIndex=String(n))},a=function(e){var n=t.connectionViews.get(e);n&&(n.element.style.zIndex=String(yv))};t.addPipe(function(e){return!e||$g(e)!==`object`||!(`type`in e)||(e.type===`nodecreated`&&r(e.data.id),e.type===`nodepicked`&&i(e.data.id),e.type===`connectioncreated`&&a(e.data.id)),e})}function Sv(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function Cv(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Sv(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Sv(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function wv(e,t){var n=t!=null&&t.scaling?t.scaling===!0?{min:.1,max:1}:t.scaling:!1,r=t!=null&&t.translation?t.translation===!0?{left:0,top:0,right:1e3,bottom:1e3}:t.translation:!1;function i(e){if(!n)throw Error(`scaling param isnt defined`);var t=typeof n==`function`?n():n,r=t.min,i=t.max;return e<r?r:e>i?i:e}function a(e){if(!r)throw Error(`translation param isnt defined`);var t=Cv({},e),n=typeof r==`function`?r():r,i=n.left,a=n.top,o=n.right,s=n.bottom;return t.x<i&&(t.x=i),t.x>o&&(t.x=o),t.y<a&&(t.y=a),t.y>s&&(t.y=s),t}e.addPipe(function(t){if(!t||$g(t)!==`object`||!(`type`in t))return t;if(n&&t.type===`zoom`)return Cv(Cv({},t),{},{data:Cv(Cv({},t.data),{},{zoom:i(t.data.zoom)})});if(r&&t.type===`zoomed`){var o=a(e.area.transform);e.area.translate(o.x,o.y)}return r&&t.type===`translate`?Cv(Cv({},t),{},{data:Cv(Cv({},t.data),{},{position:a(t.data.position)})}):t})}function Tv(){var e=!1;function t(t){(t.key===`Control`||t.key===`Meta`)&&(e=!0)}function n(t){(t.key===`Control`||t.key===`Meta`)&&(e=!1)}return document.addEventListener(`keydown`,t),document.addEventListener(`keyup`,n),{active:function(){return e},destroy:function(){document.removeEventListener(`keydown`,t),document.removeEventListener(`keyup`,n)}}}var Ev=function(){function e(){K(this,e),J(this,`entities`,new Map),J(this,`pickId`,null)}return q(e,[{key:`isSelected`,value:function(e){return this.entities.has(`${e.label}_${e.id}`)}},{key:`add`,value:function(){var e=G(Y.default.mark(function e(t,n){var r;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(r=`${t.label}_${t.id}`,n){e.next=4;break}return e.next=4,this.unselect(Array.from(this.entities.values()).filter(function(e){return e.label!==t.label||e.id!==t.id}));case 4:this.entities.set(r,t);case 5:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`remove`,value:function(){var e=G(Y.default.mark(function e(t){var n,r;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(n=`${t.label}_${t.id}`,r=this.entities.get(n),!r){e.next=6;break}return this.entities.delete(n),e.next=6,r.unselect();case 6:case`end`:return e.stop()}},e,this)}));function t(t){return e.apply(this,arguments)}return t}()},{key:`unselect`,value:function(){var e=G(Y.default.mark(function e(t){var n=this;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,Promise.all(Array.from(t).map(function(e){return n.remove(e)}));case 2:case`end`:return e.stop()}},e)}));function t(t){return e.apply(this,arguments)}return t}()},{key:`unselectAll`,value:function(){var e=G(Y.default.mark(function e(){return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,this.unselect(this.entities.values());case 2:case`end`:return e.stop()}},e,this)}));function t(){return e.apply(this,arguments)}return t}()},{key:`translate`,value:function(){var e=G(Y.default.mark(function e(t,n){var r=this;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,Promise.all(Array.from(this.entities.values()).map(function(e){return!r.isPicked(e)&&e.translate(t,n)}));case 2:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`pick`,value:function(e){this.pickId=`${e.label}_${e.id}`}},{key:`release`,value:function(){this.pickId=null}},{key:`isPicked`,value:function(e){return this.pickId===`${e.label}_${e.id}`}}])}();function Dv(){return new Ev}function Ov(e,t,n){var r=null,i=e,a=function(){return r||=i.parentScope(k_)},o=0;function s(e){e.selected||(e.selected=!0,i.update(`node`,e.id))}function c(e){e.selected&&(e.selected=!1,i.update(`node`,e.id))}function l(e,t){return u.apply(this,arguments)}function u(){return u=G(Y.default.mark(function e(n,r){var o;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(o=a().getNode(n),o){e.next=3;break}return e.abrupt(`return`);case 3:return e.next=5,t.add({label:`node`,id:o.id,translate:function(e,t){return G(Y.default.mark(function n(){var r,a;return Y.default.wrap(function(n){for(;;)switch(n.prev=n.next){case 0:if(r=i.nodeViews.get(o.id),a=r?.position,!a){n.next=5;break}return n.next=5,r.translate(a.x+e,a.y+t);case 5:case`end`:return n.stop()}},n)}))()},unselect:function(){c(o)}},r);case 5:s(o);case 6:case`end`:return e.stop()}},e)})),u.apply(this,arguments)}function d(e){return f.apply(this,arguments)}function f(){return f=G(Y.default.mark(function e(n){return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,t.remove({id:n,label:`node`});case 2:case`end`:return e.stop()}},e)})),f.apply(this,arguments)}return i.addPipe(function(){var e=G(Y.default.mark(function e(r){var i,a,s,c,u,d,f,p;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(r&&$g(r)===`object`&&`type`in r){e.next=2;break}return e.abrupt(`return`,r);case 2:if(r.type!==`nodepicked`){e.next=11;break}return i=r.data.id,a=n.accumulating.active(),t.pick({id:i,label:`node`}),o=null,e.next=9,l(i,a);case 9:e.next=33;break;case 11:if(r.type!==`nodetranslated`){e.next=20;break}if(s=r.data,c=s.id,u=s.position,d=s.previous,f=u.x-d.x,p=u.y-d.y,!t.isPicked({id:c,label:`node`})){e.next=18;break}return e.next=18,t.translate(f,p);case 18:e.next=33;break;case 20:if(r.type!==`pointerdown`){e.next=24;break}o=0,e.next=33;break;case 24:if(r.type!==`pointermove`){e.next=28;break}o!==null&&o++,e.next=33;break;case 28:if(r.type!==`pointerup`){e.next=33;break}if(!(o!==null&&o<4)){e.next=32;break}return e.next=32,t.unselectAll();case 32:o=null;case 33:return e.abrupt(`return`,r);case 34:case`end`:return e.stop()}},e)}));return function(t){return e.apply(this,arguments)}}()),{select:l,unselect:d}}function kv(e,t){var n=null,r=function(){return n||=e.parentScope(k_)};function i(n,i){var a=r().getNode(n);if(a){var o=a.inputs[i];if(!o)throw Error(`cannot find input`);var s=o.showControl,c=!!r().getConnections().find(function(e){return e.target===n&&e.targetInput===i});o.showControl=t?t({hasAnyConnection:c,input:o}):!c,o.showControl!==s&&e.update(`node`,a.id)}}e.addPipe(function(e){return(e.type===`connectioncreated`||e.type===`connectionremoved`)&&i(e.data.target,e.data.targetInput),e})}function Av(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function jv(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Av(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Av(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function Mv(e,t){var n=e,r=t?.size===void 0?16:t.size,i=t?.dynamic===void 0||t.dynamic;function a(e){return Math.round(e/r)*r}n.addPipe(function(e){if(!e||$g(e)!==`object`||!(`type`in e))return e;if(i&&e.type===`nodetranslate`){var t=e.data.position,r=a(t.x),o=a(t.y);return jv(jv({},e),{},{data:jv(jv({},e.data),{},{position:{x:r,y:o}})})}if(!i&&e.type===`nodedragged`){var s=n.nodeViews.get(e.data.id);if(s){var c=s.position,l=c.x,u=c.y;s.translate(a(l),a(u))}}return e})}function Nv(e,t,n){return Pv.apply(this,arguments)}function Pv(){return Pv=G(Y.default.mark(function e(t,n,r){var i,a,o,s,c,l,u,d,f,p,m,h,g;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return i=r||{},a=i.scale,o=a===void 0?.9:a,s=t.parentScope(k_),c=n.map(function(e){return $g(e)===`object`?e:s.getNode(e)}),l=gv(c,t.nodeViews),u=X_(l),d=[t.container.clientWidth,t.container.clientHeight],f=d[0],p=d[1],m=f/u.width,h=p/u.height,g=Math.min(h*o,m*o,1),t.area.transform.x=f/2-u.center.x*g,t.area.transform.y=p/2-u.center.y*g,e.next=12,t.area.zoom(g,0,0);case 12:case`end`:return e.stop()}},e)})),Pv.apply(this,arguments)}var Fv=Object.freeze({__proto__:null,getBoundingBox:_v,simpleNodesOrder:vv,zIndexNodesOrder:xv,restrictor:wv,accumulateOnCtrl:Tv,selectableNodes:Ov,Selector:Ev,selector:Dv,showInputControl:kv,snapGrid:Mv,zoomAt:Nv});function Iv(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function Lv(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Iv(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Iv(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function Rv(e,t,n){return t=a_(t),i_(e,zv()?Reflect.construct(t,n||[],a_(e).constructor):t.apply(e,n))}function zv(){try{var e=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(zv=function(){return!!e})()}var Bv=function(e){function t(e){var n;return K(this,t),n=Rv(this,t,[`area`]),J(n,`nodeViews`,new Map),J(n,`connectionViews`,new Map),J(n,`elements`,new fv),J(n,`onContextMenu`,function(e){n.emit({type:`contextmenu`,data:{event:e,context:`root`}})}),n.container=e,e.style.overflow=`hidden`,e.addEventListener(`contextmenu`,n.onContextMenu),n.addPipe(function(e){return!e||!($g(e)===`object`&&`type`in e)||(e.type===`nodecreated`&&n.addNodeView(e.data),e.type===`noderemoved`&&n.removeNodeView(e.data.id),e.type===`connectioncreated`&&n.addConnectionView(e.data),e.type===`connectionremoved`&&n.removeConnectionView(e.data.id),e.type===`render`&&n.elements.set(e.data),e.type===`unmount`&&n.elements.delete(e.data.element)),e}),n.area=new sv(e,{zoomed:function(e){return n.emit({type:`zoomed`,data:e})},pointerDown:function(e,t){n.emit({type:`pointerdown`,data:{position:e,event:t}})},pointerMove:function(e,t){n.emit({type:`pointermove`,data:{position:e,event:t}})},pointerUp:function(e,t){n.emit({type:`pointerup`,data:{position:e,event:t}})},resize:function(e){n.emit({type:`resized`,data:{event:e}})},translated:function(e){return n.emit({type:`translated`,data:e})},reordered:function(e){return n.emit({type:`reordered`,data:{element:e}})}},{translate:function(e){return n.emit({type:`translate`,data:e})},zoom:function(e){return n.emit({type:`zoom`,data:e})}}),n}return s_(t,e),q(t,[{key:`addNodeView`,value:function(e){var t=this,n=e.id,r=new hv(function(){return t.area.transform.k},{picked:function(){t.emit({type:`nodepicked`,data:{id:n}})},translated:function(e){return t.emit({type:`nodetranslated`,data:Lv({id:n},e)})},dragged:function(){t.emit({type:`nodedragged`,data:e})},contextmenu:function(n){t.emit({type:`contextmenu`,data:{event:n,context:e}})},resized:function(n){var r=n.size;return t.emit({type:`noderesized`,data:{id:e.id,size:r}})}},{translate:function(e){return t.emit({type:`nodetranslate`,data:Lv({id:n},e)})},resize:function(n){var r=n.size;return t.emit({type:`noderesize`,data:{id:e.id,size:r}})}});return this.nodeViews.set(n,r),this.area.content.add(r.element),this.emit({type:`render`,data:{element:r.element,type:`node`,payload:e}}),r}},{key:`removeNodeView`,value:function(e){var t=this.nodeViews.get(e);t&&(this.emit({type:`unmount`,data:{element:t.element}}),this.nodeViews.delete(e),this.area.content.remove(t.element))}},{key:`addConnectionView`,value:function(e){var t=this,n=new dv({contextmenu:function(n){t.emit({type:`contextmenu`,data:{event:n,context:e}})}});return this.connectionViews.set(e.id,n),this.area.content.add(n.element),this.emit({type:`render`,data:{element:n.element,type:`connection`,payload:e}}),n}},{key:`removeConnectionView`,value:function(e){var t=this.connectionViews.get(e);t&&(this.emit({type:`unmount`,data:{element:t.element}}),this.connectionViews.delete(e),this.area.content.remove(t.element))}},{key:`update`,value:function(){var e=G(Y.default.mark(function e(t,n){var r;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(r=this.elements.get(t,n),!r){e.next=4;break}return e.next=4,this.emit({type:`render`,data:r});case 4:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`resize`,value:function(){var e=G(Y.default.mark(function e(t,n,r){var i;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(i=this.nodeViews.get(t),!i){e.next=5;break}return e.next=4,i.resize(n,r);case 4:return e.abrupt(`return`,e.sent);case 5:case`end`:return e.stop()}},e,this)}));function t(t,n,r){return e.apply(this,arguments)}return t}()},{key:`translate`,value:function(){var e=G(Y.default.mark(function e(t,n){var r,i,a;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(r=n.x,i=n.y,a=this.nodeViews.get(t),!a){e.next=6;break}return e.next=5,a.translate(r,i);case 5:return e.abrupt(`return`,e.sent);case 6:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`destroy`,value:function(){var e=this;this.container.removeEventListener(`contextmenu`,this.onContextMenu),Array.from(this.connectionViews.keys()).forEach(function(t){e.removeConnectionView(t)}),Array.from(this.nodeViews.keys()).forEach(function(t){e.removeNodeView(t)}),this.area.destroy()}}])}(uv);function Vv(e,t){for(;!{}.hasOwnProperty.call(e,t)&&(e=a_(e))!==null;);return e}function Hv(){return Hv=typeof Reflect<`u`&&Reflect.get?Reflect.get.bind():function(e,t,n){var r=Vv(e,t);if(r){var i=Object.getOwnPropertyDescriptor(r,t);return i.get?i.get.call(arguments.length<3?e:n):i.value}},Hv.apply(null,arguments)}function Uv(e){if(Array.isArray(e))return e}function Wv(e,t){var n=e==null?null:typeof Symbol<`u`&&e[Symbol.iterator]||e[`@@iterator`];if(n!=null){var r,i,a,o,s=[],c=!0,l=!1;try{if(a=(n=n.call(e)).next,t===0){if(Object(n)!==n)return;c=!1}else for(;!(c=(r=a.call(n)).done)&&(s.push(r.value),s.length!==t);c=!0);}catch(e){l=!0,i=e}finally{try{if(!c&&n.return!=null&&(o=n.return(),Object(o)!==o))return}finally{if(l)throw i}}return s}}function Gv(){throw TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function Kv(e,t){return Uv(e)||Wv(e,t)||U_(e,t)||Gv()}function qv(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function Jv(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?qv(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):qv(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function Yv(e){var t=null,n=null;function r(e){n&&e.removeConnectionView(n),t=null,n=null}function i(e){r(e),n=`pseudo_${j_()}`}return{isMounted:function(){return!!n},mount:i,render:function(r,i,a){var o=i.x,s=i.y,c=a.side===`output`,l={x:o+(c?-3:3),y:s};if(!n)throw Error(`pseudo connection id wasn't generated`);var u=Jv(c?{id:n,source:a.nodeId,sourceOutput:a.key,target:``,targetInput:``}:{id:n,target:a.nodeId,targetInput:a.key,source:``,sourceOutput:``},e??{});t||=r.addConnectionView(u).element,t&&r.emit({type:`render`,data:Jv({element:t,type:`connection`,payload:u},c?{end:l}:{start:l})})},unmount:r}}function Xv(e,t){var n=typeof Symbol<`u`&&e[Symbol.iterator]||e[`@@iterator`];if(!n){if(Array.isArray(e)||(n=Zv(e))||t&&e&&typeof e.length==`number`){n&&(e=n);var r=0,i=function(){};return{s:i,n:function(){return r>=e.length?{done:!0}:{done:!1,value:e[r++]}},e:function(e){throw e},f:i}}throw TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var a,o=!0,s=!1;return{s:function(){n=n.call(e)},n:function(){var e=n.next();return o=e.done,e},e:function(e){s=!0,a=e},f:function(){try{o||n.return==null||n.return()}finally{if(s)throw a}}}}function Zv(e,t){if(e){if(typeof e==`string`)return Qv(e,t);var n={}.toString.call(e).slice(8,-1);return n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`?Array.from(e):n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?Qv(e,t):void 0}}function Qv(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function $v(e,t){var n=Xv(t),r;try{for(n.s();!(r=n.n()).done;){var i=r.value,a=e.get(i);if(a)return a}}catch(e){n.e(e)}finally{n.f()}}function ey(e,t){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:document,r=n.elementsFromPoint(e,t),i=r[0]?.shadowRoot;return i&&i!==n&&r.unshift.apply(r,G_(ey(e,t,i))),r}var ty=function(){function e(){K(this,e)}return q(e,[{key:`setContext`,value:function(e){this.context=e}}])}();function ny(e,t){var n=e.side===`output`&&t.side===`input`,r=e.side===`input`&&t.side===`output`,i=Kv(n?[e,t]:r?[t,e]:[],2),a=i[0],o=i[1];if(a&&o)return[a,o]}function ry(e,t){return!!ny(e,t)}function iy(e,t,n){var r=Kv(ny(e,t)||[null,null],2),i=r[0],a=r[1];if(i&&a)return n.editor.addConnection({id:j_(),source:i.nodeId,sourceOutput:i.key,target:a.nodeId,targetInput:a.key}),!0}function ay(e,t){var n=t.getNode(e.nodeId);if(!n)throw Error(`cannot find node`);return(e.side===`input`?n.inputs:n.outputs)[e.key]}function oy(e,t){var n=e.nodeId,r=e.side,i=e.key;return t.getConnections().filter(function(e){if(r===`input`)return e.target===n&&e.targetInput===i;if(r===`output`)return e.source===n&&e.sourceOutput===i})}function sy(e,t){var n=e.map(function(e){return ay(e,t)?.multipleConnections?[]:oy(e,t)}).flat();return{commit:function(){Array.from(new Set(n.map(function(e){return e.id}))).forEach(function(e){t.removeConnection(e)})}}}function cy(e,t,n){return t=a_(t),i_(e,ly()?Reflect.construct(t,n||[],a_(e).constructor):t.apply(e,n))}function ly(){try{var e=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(ly=function(){return!!e})()}var uy=function(e){function t(e,n){var r;return K(this,t),r=cy(this,t),r.initial=e,r.params=n,r}return s_(t,e),q(t,[{key:`pick`,value:function(){var e=G(Y.default.mark(function e(t,n){var r,i;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:r=t.socket,this.params.canMakeConnection(this.initial,r)&&(sy([this.initial,r],n.editor).commit(),i=this.params.makeConnection(this.initial,r,n),this.drop(n,i?r:null,i));case 2:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`drop`,value:function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null,n=arguments.length>2&&arguments[2]!==void 0&&arguments[2];this.initial&&e.scope.emit({type:`connectiondrop`,data:{initial:this.initial,socket:t,created:n}}),this.context.switchTo(new fy(this.params))}}])}(ty),dy=function(e){function t(e,n,r){var i;K(this,t),i=cy(this,t),i.connection=e,i.params=n;var a=Array.from(r.socketsCache.values()).find(function(e){return e.nodeId===i.connection.source&&e.side===`output`&&e.key===i.connection.sourceOutput});if(!a)throw Error(`cannot find output socket`);return i.outputSocket=a,i}return s_(t,e),q(t,[{key:`init`,value:function(){var e=G(Y.default.mark(function e(t){var n=this;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:t.scope.emit({type:`connectionpick`,data:{socket:this.outputSocket}}).then(function(e){e?(t.editor.removeConnection(n.connection.id),n.initial=n.outputSocket):n.drop(t)});case 1:case`end`:return e.stop()}},e,this)}));function t(t){return e.apply(this,arguments)}return t}()},{key:`pick`,value:function(){var e=G(Y.default.mark(function e(t,n){var r,i,a,o,s,c;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:r=t.socket,i=t.event,this.initial&&(r.side!==`input`||this.connection.target!==r.nodeId||this.connection.targetInput!==r.key)?this.params.canMakeConnection(this.initial,r)&&(sy([this.initial,r],n.editor).commit(),a=this.params.makeConnection(this.initial,r,n),o=a?r:null,this.drop(n,o,a)):i===`down`&&this.initial&&(sy([this.initial,r],n.editor).commit(),s=this.params.makeConnection(this.initial,r,n),c=s?null:r,this.drop(n,c,s));case 2:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`drop`,value:function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null,n=arguments.length>2&&arguments[2]!==void 0&&arguments[2];this.initial&&e.scope.emit({type:`connectiondrop`,data:{initial:this.initial,socket:t,created:n}}),this.context.switchTo(new fy(this.params))}}])}(ty),fy=function(e){function t(e){var n;return K(this,t),n=cy(this,t),n.params=e,n}return s_(t,e),q(t,[{key:`pick`,value:function(){var e=G(Y.default.mark(function e(t,n){var r,i,a,o;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(r=t.socket,i=t.event,i===`down`){e.next=3;break}return e.abrupt(`return`);case 3:if(r.side!==`input`||(a=n.editor.getConnections().find(function(e){return e.target===r.nodeId&&e.targetInput===r.key}),!a)){e.next=11;break}return o=new dy(a,this.params,n),e.next=9,o.init(n);case 9:return this.context.switchTo(o),e.abrupt(`return`);case 11:return e.next=13,n.scope.emit({type:`connectionpick`,data:{socket:r}});case 13:if(!e.sent){e.next=17;break}this.context.switchTo(new uy(r,this.params)),e.next=18;break;case 17:this.drop(n);case 18:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`drop`,value:function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null,n=arguments.length>2&&arguments[2]!==void 0&&arguments[2];this.initial&&e.scope.emit({type:`connectiondrop`,data:{initial:this.initial,socket:t,created:n}}),delete this.initial}}])}(ty),py=function(){function e(t){K(this,e);var n=t?.canMakeConnection||ry,r=t?.makeConnection||iy;this.switchTo(new fy({canMakeConnection:n,makeConnection:r}))}return q(e,[{key:`pick`,value:function(){var e=G(Y.default.mark(function e(t,n){return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,this.currentState.pick(t,n);case 2:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`getPickedSocket`,value:function(){return this.currentState.initial}},{key:`switchTo`,value:function(e){e.setContext(this),this.currentState=e}},{key:`drop`,value:function(e){this.currentState.drop(e)}}])}();function my(){return function(){return new py}}var hy=Object.freeze({__proto__:null,classic:Object.freeze({__proto__:null,setup:my})});function gy(e,t){var n=typeof Symbol<`u`&&e[Symbol.iterator]||e[`@@iterator`];if(!n){if(Array.isArray(e)||(n=_y(e))||t&&e&&typeof e.length==`number`){n&&(e=n);var r=0,i=function(){};return{s:i,n:function(){return r>=e.length?{done:!0}:{done:!1,value:e[r++]}},e:function(e){throw e},f:i}}throw TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var a,o=!0,s=!1;return{s:function(){n=n.call(e)},n:function(){var e=n.next();return o=e.done,e},e:function(e){s=!0,a=e},f:function(){try{o||n.return==null||n.return()}finally{if(s)throw a}}}}function _y(e,t){if(e){if(typeof e==`string`)return vy(e,t);var n={}.toString.call(e).slice(8,-1);return n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`?Array.from(e):n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?vy(e,t):void 0}}function vy(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function yy(e,t,n){return t=a_(t),i_(e,by()?Reflect.construct(t,n||[],a_(e).constructor):t.apply(e,n))}function by(){try{var e=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(by=function(){return!!e})()}function xy(e,t,n,r){var i=Hv(a_(1&r?e.prototype:e),t,n);return 2&r&&typeof i==`function`?function(e){return i.apply(n,e)}:i}var Sy=function(e){function t(){var e;return K(this,t),e=yy(this,t,[`connection`]),J(e,`presets`,[]),J(e,`currentFlow`,null),J(e,`preudoconnection`,Yv({isPseudo:!0})),J(e,`socketsCache`,new Map),e}return s_(t,e),q(t,[{key:`addPreset`,value:function(e){this.presets.push(e)}},{key:`findPreset`,value:function(e){var t=gy(this.presets),n;try{for(t.s();!(n=t.n()).done;){var r=n.value,i=r(e);if(i)return i}}catch(e){t.e(e)}finally{t.f()}return null}},{key:`update`,value:function(){if(this.currentFlow){var e=this.currentFlow.getPickedSocket();e&&this.preudoconnection.render(this.areaPlugin,this.areaPlugin.area.pointer,e)}}},{key:`drop`,value:function(){var e={editor:this.editor,scope:this,socketsCache:this.socketsCache};this.currentFlow&&=(this.currentFlow.drop(e),this.preudoconnection.unmount(this.areaPlugin),null)}},{key:`pick`,value:function(){var e=G(Y.default.mark(function e(t,n){var r,i,a;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(r={editor:this.editor,scope:this,socketsCache:this.socketsCache},i=ey(t.clientX,t.clientY),a=$v(this.socketsCache,i),!a){e.next=13;break}if(t.preventDefault(),t.stopPropagation(),this.currentFlow=this.currentFlow||this.findPreset(a),!this.currentFlow){e.next=11;break}return e.next=10,this.currentFlow.pick({socket:a,event:n},r);case 10:this.preudoconnection.mount(this.areaPlugin);case 11:e.next=14;break;case 13:this.currentFlow&&this.currentFlow.drop(r);case 14:this.currentFlow&&!this.currentFlow.getPickedSocket()&&(this.preudoconnection.unmount(this.areaPlugin),this.currentFlow=null),this.update();case 16:case`end`:return e.stop()}},e,this)}));function t(t,n){return e.apply(this,arguments)}return t}()},{key:`setParent`,value:function(e){var n=this;xy(t,`setParent`,this,3)([e]),this.areaPlugin=this.parentScope(uv),this.editor=this.areaPlugin.parentScope(k_);var r=function(e){n.pick(e,`down`)};this.addPipe(function(e){if(!e||$g(e)!==`object`||!(`type`in e))return e;if(e.type===`pointermove`)n.update();else if(e.type===`pointerup`)n.pick(e.data.event,`up`);else if(e.type===`render`){if(e.data.type===`socket`){var t=e.data.element;t.addEventListener(`pointerdown`,r),n.socketsCache.set(t,e.data)}}else if(e.type===`unmount`){var i=e.data.element;i.removeEventListener(`pointerdown`,r),n.socketsCache.delete(i)}return e})}}])}(C_);function Cy(e,t){var n=Kv(e,2),r=n[0],i=r.x,a=r.y,o=n[1],s=o.x,c=o.y,l=Math.abs(a-c);return`M ${i} ${a} C ${i+Math.max(l/2,Math.abs(s-i))*t} ${a} ${s-Math.max(l/2,Math.abs(s-i))*t} ${c} ${s} ${c}`}function wy(e,t,n){var r=Kv(e,2),i=r[0],a=i.x,o=i.y,s=r[1],c=s.x,l=s.y,u=l>o?1:-1,d=n+Math.abs(a-c)/(n/2),f=(a+c)/2,p=o-u*d,m=(l-o)*t;return`
        M ${a} ${o}
        C ${a+d} ${o}
        ${a+d} ${p-m}
        ${f} ${p}
        C ${c-d} ${p+m}
        ${c-d} ${l}
        ${c} ${l}
    `}function Ty(e,t){return Ey.apply(this,arguments)}function Ey(){return Ey=G(Y.default.mark(function e(t,n){var r,i,a,o,s;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(t.offsetParent){e.next=5;break}return e.next=3,new Promise(function(e){return setTimeout(e,0)});case 3:e.next=0;break;case 5:if(r=t.offsetLeft,i=t.offsetTop,a=t.offsetParent,a){e.next=10;break}throw Error(`child has null offsetParent`);case 10:for(;a!==null&&a!==n;)r+=a.offsetLeft+a.clientLeft,i+=a.offsetTop+a.clientTop,a=a.offsetParent;return o=t.offsetWidth,s=t.offsetHeight,e.abrupt(`return`,{x:r+o/2,y:i+s/2});case 14:case`end`:return e.stop()}},e)})),Ey.apply(this,arguments)}var Dy=function(){function e(){K(this,e),J(this,`listeners`,new Set)}return q(e,[{key:`emit`,value:function(e){this.listeners.forEach(function(t){t(e)})}},{key:`listen`,value:function(e){var t=this;return this.listeners.add(e),function(){t.listeners.delete(e)}}}])}(),Oy=function(){function e(){K(this,e),J(this,`elements`,new Map)}return q(e,[{key:`getPosition`,value:function(e){var t=Array.from(this.elements.values()).flat().filter(function(t){return t.side===e.side&&t.nodeId===e.nodeId&&t.key===e.key});return t.length>1&&console.warn(`Found more than one element for socket with same key and side. Probably it was not unmounted correctly`,e),t.pop()?.position??null}},{key:`add`,value:function(e){var t=this.elements.get(e.element);this.elements.set(e.element,t?[].concat(G_(t.filter(function(t){return t.nodeId!==e.nodeId||t.key!==e.key||t.side!==e.side})),[e]):[e])}},{key:`remove`,value:function(e){this.elements.delete(e)}},{key:`snapshot`,value:function(){return Array.from(this.elements.values()).flat()}}])}(),ky=function(){function e(){K(this,e),J(this,`sockets`,new Oy),J(this,`emitter`,new Dy),J(this,`area`,null)}return q(e,[{key:`attach`,value:function(e){var t=this;this.area||e.hasParent()&&(this.area=e.parentScope(uv),this.area.addPipe(function(){var e=G(Y.default.mark(function e(n){var r,i,a,o,s,c,l,u,d,f,p;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(n.type!==`rendered`||n.data.type!==`socket`){e.next=8;break}return r=n.data,i=r.nodeId,a=r.key,o=r.side,s=r.element,e.next=4,t.calculatePosition(i,o,a,s);case 4:c=e.sent,c&&(t.sockets.add({nodeId:i,key:a,side:o,element:s,position:c}),t.emitter.emit({nodeId:i,key:a,side:o})),e.next=24;break;case 8:if(n.type!==`unmount`){e.next=12;break}t.sockets.remove(n.data.element),e.next=24;break;case 12:if(n.type!==`nodetranslated`){e.next=16;break}t.emitter.emit({nodeId:n.data.id}),e.next=24;break;case 16:if(n.type!==`noderesized`){e.next=23;break}return l=n.data.id,e.next=20,Promise.all(t.sockets.snapshot().filter(function(e){return e.nodeId===n.data.id&&e.side===`output`}).map(function(){var e=G(Y.default.mark(function e(n){var r,i,a,o;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return r=n.side,i=n.key,a=n.element,e.next=3,t.calculatePosition(l,r,i,a);case 3:o=e.sent,o&&(n.position=o);case 5:case`end`:return e.stop()}},e)}));return function(t){return e.apply(this,arguments)}}()));case 20:t.emitter.emit({nodeId:l}),e.next=24;break;case 23:n.type===`render`&&n.data.type===`connection`&&(u=n.data.payload,d=u.source,f=u.target,p=d||f,t.emitter.emit({nodeId:p}));case 24:return e.abrupt(`return`,n);case 25:case`end`:return e.stop()}},e)}));return function(t){return e.apply(this,arguments)}}()))}},{key:`listen`,value:function(e,t,n,r){var i=this,a=this.emitter.listen(function(a){if(a.nodeId===e&&(!a.key||a.side===t)&&(!a.side||a.key===n)){var o=i.sockets.getPosition({side:t,nodeId:e,key:n});if(!o)return;var s=o.x,c=o.y,l=i.area?.nodeViews.get(e);l&&r({x:s+l.position.x,y:c+l.position.y})}});return this.sockets.snapshot().forEach(function(t){t.nodeId===e&&i.emitter.emit(t)}),a}}])}();function Ay(e,t,n){return t=a_(t),i_(e,jy()?Reflect.construct(t,n||[],a_(e).constructor):t.apply(e,n))}function jy(){try{var e=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(jy=function(){return!!e})()}var My=function(e){function t(e){var n;return K(this,t),n=Ay(this,t),n.props=e,n}return s_(t,e),q(t,[{key:`calculatePosition`,value:function(){var e=G(Y.default.mark(function e(t,n,r,i){var a,o,s;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(o=this.area?.nodeViews.get(t),o!=null&&o.element){e.next=3;break}return e.abrupt(`return`,null);case 3:return e.next=5,Ty(i,o.element);case 5:if(s=e.sent,!((a=this.props)!=null&&a.offset)){e.next=8;break}return e.abrupt(`return`,this.props.offset(s,t,n,r));case 8:return e.abrupt(`return`,{x:s.x+12*(n===`input`?-1:1),y:s.y});case 9:case`end`:return e.stop()}},e,this)}));function t(t,n,r,i){return e.apply(this,arguments)}return t}()}])}(ky);function Ny(e){return new My(e)}function Py(e){if(!e||typeof window>`u`)return;let t=document.createElement(`style`);return t.setAttribute(`type`,`text/css`),t.innerHTML=e,document.head.appendChild(t),e}function Fy(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function Iy(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Fy(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Fy(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function Ly(e,t,n,r,i){var a=O(sn(n)),o={render:function(){return Xa(t,Iy(Iy({},a.value),{},{seed:Math.random()}))},mounted:function(){r()},updated:function(){r()}},s=i!=null&&i.setup?i.setup(o):fs(o);return s.mount(e),{app:s,payload:a}}function Ry(e,t){e.payload.value=sn(Iy(Iy({},e.payload.value),t))}function zy(e){e.app.unmount()}function By(e){var t=new Map;return{get:function(e){return t.get(e)},mount:function(n,r,i,a){var o=Ly(n,r,i,a,e);return t.set(n,o),o},update:function(e,t){Ry(e,t)},unmount:function(e){var n=t.get(e);n&&(zy(n),t.delete(e))}}}var Vy={"data-testid":`connection`},Hy=[`d`];function Uy(e,t,n,r,i,a){return M(),N(`svg`,Vy,[P(`path`,{d:n.path},null,8,Hy)])}Py(`/*! https://github.com/retejs/connection-plugin/commit/206ca0fd7fb82801ac45a0f7180ae05dff9ed901 */
svg[data-v-fee8858e] {
  overflow: visible !important;
  position: absolute;
  pointer-events: none;
  width: 9999px;
  height: 9999px;
}
svg[data-v-fee8858e] path[data-v-fee8858e] {
  fill: none;
  stroke-width: 5px;
  stroke: steelblue;
  pointer-events: auto;
}`);var Wy=(e,t)=>{let n=e.__vccOpts||e;for(let[e,r]of t)n[e]=r;return n},Gy=Wy({props:[`data`,`start`,`end`,`path`]},[[`render`,Uy],[`__scopeId`,`data-v-fee8858e`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/classic/components/Connection.vue`]]);function Ky(e,t,n,r,i,a){return M(),ma(Br(n.component),{data:n.data,start:a.startPosition,end:a.endPosition,path:i.observedPath},null,8,[`data`,`start`,`end`,`path`])}var qy=Wy({props:[`component`,`data`,`start`,`end`,`path`],data(){return{observedStart:{x:0,y:0},observedEnd:{x:0,y:0},observedPath:``,onDestroy:null}},computed:{startPosition(){return this.start&&`x`in this.start?this.start:this.observedStart},endPosition(){return this.end&&`x`in this.end?this.end:this.observedEnd}},watch:{startPosition(){this.fetchPath()},endPosition(){this.fetchPath()}},methods:{async fetchPath(){this.startPosition&&this.endPosition&&(this.observedPath=await this.path(this.startPosition,this.endPosition))}},created(){let e=typeof this.start==`function`&&this.start(e=>{this.observedStart=e}),t=typeof this.end==`function`&&this.end(e=>{this.observedEnd=e});this.onDestroy=()=>{e&&e(),t&&t()}},destroyed(){this.onDestroy&&this.onDestroy()}},[[`render`,Ky],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/classic/components/ConnectionWrapper.vue`]]),Jy=[`type`,`value`,`readonly`];function Yy(e,t,n,r,i,a){return M(),N(`input`,{type:n.data.type,value:n.data.value,readonly:n.data.readonly,onInput:t[0]||=(...e)=>a.change&&a.change(...e),onPointerdown:t[1]||=os(()=>{},[`stop`])},null,40,Jy)}Py(`input[data-v-a4adbbb3] {
  width: 100%;
  border-radius: 30px;
  background-color: white;
  color: black;
  padding: 2px 6px;
  border: 1px solid #999;
  font-size: 110%;
  box-sizing: border-box;
}`);var Xy=Wy({props:[`data`],methods:{change(e){let t=this.data.type===`number`?+e.target.value:e.target.value;this.data.setValue(t)}}},[[`render`,Yy],[`__scopeId`,`data-v-a4adbbb3`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/classic/components/Control.vue`]]);function Zy(e,t,n,r,i,a){return M(),N(`div`,Da(e.$props,{ref:`element`}),null,16)}var Qy=Wy({props:[`data`,`emit`],mounted(){this.emit({type:`render`,data:{...this.data,element:this.$refs.element}})},beforeDestroy(){this.emit({type:`unmount`,data:{element:this.$refs.element}})},beforeUnmount(){this.emit({type:`unmount`,data:{element:this.$refs.element}})}},[[`render`,Zy],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/Ref.vue`]]),$y={class:`title`,"data-testid":`title`},eb=[`data-testid`],tb={class:`output-title`,"data-testid":`output-title`},nb=[`data-testid`];function rb(e,t,n,r,i,a){let o=Rr(`Ref`);return M(),N(`div`,{class:De([`node`,{selected:n.data.selected}]),style:Se(a.nodeStyles()),"data-testid":`node`},[P(`div`,$y,E(n.data.label),1),F(` Outputs`),(M(!0),N(j,null,A(a.outputs(),([e,t])=>(M(),N(`div`,{class:`output`,key:`output`+e+n.seed,"data-testid":`output-`+e},[P(`div`,tb,E(t.label),1),ya(o,{class:`output-socket`,data:{type:`socket`,side:`output`,key:e,nodeId:n.data.id,payload:t.socket},emit:n.emit,"data-testid":`output-socket`},null,8,[`data`,`emit`])],8,eb))),128)),F(` Controls`),(M(!0),N(j,null,A(a.controls(),([e,t])=>(M(),ma(o,{class:`control`,key:`control`+e+n.seed,"data-testid":`control-`+e,emit:n.emit,data:{type:`control`,payload:t}},null,8,[`data-testid`,`emit`,`data`]))),128)),F(` Inputs`),(M(!0),N(j,null,A(a.inputs(),([e,t])=>(M(),N(`div`,{class:`input`,key:`input`+e+n.seed,"data-testid":`input-`+e},[ya(o,{class:`input-socket`,data:{type:`socket`,side:`input`,key:e,nodeId:n.data.id,payload:t.socket},emit:n.emit,"data-testid":`input-socket`},null,8,[`data`,`emit`]),k(P(`div`,{class:`input-title`,"data-testid":`input-title`},E(t.label),513),[[uo,!t.control||!t.showControl]]),k(ya(o,{class:`input-control`,emit:n.emit,data:{type:`control`,payload:t.control},"data-testid":`input-control`},null,8,[`emit`,`data`]),[[uo,t.control&&t.showControl]])],8,nb))),128))],6)}Py(`.node[data-v-cc6bc301] {
  background: rgba(110, 136, 255, 0.8);
  border: 2px solid #4e58bf;
  border-radius: 10px;
  cursor: pointer;
  box-sizing: border-box;
  width: 180px;
  height: auto;
  padding-bottom: 6px;
  position: relative;
  user-select: none;
  line-height: initial;
  font-family: Arial;
}
.node[data-v-cc6bc301][data-v-cc6bc301]:hover {
  background: rgba(130, 153, 255, 0.8);
}
.node[data-v-cc6bc301].selected[data-v-cc6bc301] {
  background: #ffd92c;
  border-color: #e3c000;
}
.node[data-v-cc6bc301] .title[data-v-cc6bc301] {
  color: white;
  font-family: sans-serif;
  font-size: 18px;
  padding: 8px;
}
.node[data-v-cc6bc301] .output[data-v-cc6bc301] {
  text-align: right;
}
.node[data-v-cc6bc301] .input[data-v-cc6bc301] {
  text-align: left;
}
.node[data-v-cc6bc301] .output-socket[data-v-cc6bc301] {
  text-align: right;
  margin-right: -18px;
  display: inline-block;
}
.node[data-v-cc6bc301] .input-socket[data-v-cc6bc301] {
  text-align: left;
  margin-left: -18px;
  display: inline-block;
}
.node[data-v-cc6bc301] .input-title[data-v-cc6bc301],
.node[data-v-cc6bc301] .output-title[data-v-cc6bc301] {
  vertical-align: middle;
  color: white;
  display: inline-block;
  font-family: sans-serif;
  font-size: 14px;
  margin: 6px;
  line-height: 24px;
}
.node[data-v-cc6bc301] .input-control[data-v-cc6bc301] {
  z-index: 1;
  width: calc(100% - 36px);
  vertical-align: middle;
  display: inline-block;
}
.node[data-v-cc6bc301] .control[data-v-cc6bc301] {
  padding: 6px 18px;
}`);function ib(e){return e.sort((e,t)=>(e[1]&&e[1].index||0)-(t[1]&&t[1].index||0)),e}var ab=Wy({props:[`data`,`emit`,`seed`],methods:{nodeStyles(){return{width:Number.isFinite(this.data.width)?`${this.data.width}px`:``,height:Number.isFinite(this.data.height)?`${this.data.height}px`:``}},inputs(){return ib(Object.entries(this.data.inputs))},controls(){return ib(Object.entries(this.data.controls))},outputs(){return ib(Object.entries(this.data.outputs))}},components:{Ref:Qy}},[[`render`,rb],[`__scopeId`,`data-v-cc6bc301`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/classic/components/Node.vue`]]),ob=[`title`];function sb(e,t,n,r,i,a){return M(),N(`div`,{class:`socket`,title:n.data.name},null,8,ob)}Py(`.socket[data-v-4a0a4b7f] {
  display: inline-block;
  cursor: pointer;
  border: 1px solid white;
  border-radius: 12px;
  width: 24px;
  height: 24px;
  margin: 6px;
  vertical-align: middle;
  background: #96b38a;
  z-index: 2;
  box-sizing: border-box;
}
.socket[data-v-4a0a4b7f][data-v-4a0a4b7f]:hover {
  border-width: 4px;
}
.socket[data-v-4a0a4b7f].multiple[data-v-4a0a4b7f] {
  border-color: yellow;
}
.socket[data-v-4a0a4b7f].output[data-v-4a0a4b7f] {
  margin-right: -12px;
}
.socket[data-v-4a0a4b7f].input[data-v-4a0a4b7f] {
  margin-left: -12px;
}`);var cb=Wy({props:[`data`]},[[`render`,sb],[`__scopeId`,`data-v-4a0a4b7f`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/classic/components/Socket.vue`]]);function lb(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function ub(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?lb(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):lb(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function db(e){var t=e?.socketPositionWatcher===void 0?Ny():e.socketPositionWatcher,n=e?.customize??{},r=n.node,i=n.connection,a=n.socket,o=n.control;return{attach:function(e){t.attach(e)},update:function(e,t){var n=e.data.payload,r=t.parentScope();if(!r)throw Error(`parent`);var i=r.emit.bind(r);if(e.data.type===`node`)return{data:n,emit:i};if(e.data.type===`connection`){var a=e.data,o=a.start,s=a.end;return ub(ub({data:n},o?{start:o}:{}),s?{end:s}:{})}return{data:n}},render:function(e,n){var s=n.parentScope(),c=s.emit.bind(s);if(e.data.type===`node`){var l=r?r(e.data):ab;return l&&{component:l,props:{data:e.data.payload,emit:c}}}if(e.data.type===`connection`){var u=i?i(e.data):Gy,d=e.data.payload,f=d.source,p=d.target,m=d.sourceOutput,h=d.targetInput;return u&&{component:qy,props:{data:e.data.payload,component:u,start:e.data.start??function(e){return t.listen(f,`output`,m,e)},end:e.data.end??function(e){return t.listen(p,`input`,h,e)},path:function(){var e=G(Y.default.mark(function e(t,r){var i,a,o,s,c;return Y.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.emit({type:`connectionpath`,data:{payload:d,points:[t,r]}});case 2:if(i=e.sent,i){e.next=5;break}return e.abrupt(`return`,``);case 5:if(a=i.data,o=a.path,s=a.points,c=.3,o||s.length===2){e.next=9;break}throw Error(`cannot render connection with a custom number of points`);case 9:if(o){e.next=11;break}return e.abrupt(`return`,d.isLoop?wy(s,c,120):Cy(s,c));case 11:return e.abrupt(`return`,o);case 12:case`end`:return e.stop()}},e)}));function t(t,n){return e.apply(this,arguments)}return t}()}}}if(e.data.type===`socket`){var g=e.data.payload;return{component:a?a(e.data):cb,props:{data:g}}}if(e.data.type===`control`){var _=e.data.payload;if(o){var v=o(e.data);return v&&{component:v,props:{data:_}}}return e.data.payload instanceof z_.InputControl?{component:Xy,props:{data:_}}:null}}}}var fb=Object.freeze({__proto__:null,setup:db,Connection:Gy,Control:Xy,Node:ab,Socket:cb}),pb={class:`block`};function mb(e,t){return M(),N(`div`,pb,[Ur(e.$slots,`default`,{},void 0,!0)])}Py(`.block[data-v-e9c17765] {
  color: #fff;
  padding: 4px;
  border-bottom: 1px solid rgba(69, 103, 255, 0.8);
  background-color: rgba(110, 136, 255, 0.8);
  cursor: pointer;
  box-sizing: border-box;
  width: 100%;
  position: relative;
}
.block[data-v-e9c17765][data-v-e9c17765]:first-child {
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
}
.block[data-v-e9c17765][data-v-e9c17765]:last-child {
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
}
.block[data-v-e9c17765][data-v-e9c17765]:hover {
  background-color: rgba(130, 153, 255, 0.8);
}`);var hb=Wy({},[[`render`,mb],[`__scopeId`,`data-v-e9c17765`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/context-menu/components/Block.vue`]]),gb=[`value`];function _b(e,t,n,r,i,a){return M(),N(`input`,{class:`search`,value:n.text,onInput:t[0]||=t=>e.$emit(`change`,t.target.value),"data-testid":`context-menu-search-input`},null,40,gb)}Py(`.search[data-v-3253b3e6] {
  color: white;
  padding: 1px 8px;
  border: 1px solid white;
  border-radius: 10px;
  font-size: 16px;
  font-family: serif;
  width: 100%;
  box-sizing: border-box;
  background: transparent;
}`);var vb=Wy({props:[`text`]},[[`render`,_b],[`__scopeId`,`data-v-3253b3e6`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/context-menu/components/Search.vue`]]);function yb(e,t){return{timeout:null,cancel:function(){this.timeout&&=(window.clearTimeout(this.timeout),null)},call:function(){this.timeout=window.setTimeout(function(){t()},e)}}}var bb={key:0,class:`subitems`};function xb(e,t,n,r,i,a){let o=Rr(`Item`,!0),s=Rr(`Block`);return M(),ma(s,{class:De([`block`,{hasSubitems:n.subitems}]),"data-testid":`context-menu-item`},{default:Xn(()=>[P(`div`,{class:`content`,onClick:t[1]||=os(t=>{e.$emit(`select`,t),e.$emit(`hide`)},[`stop`]),onWheel:t[2]||=os(()=>{},[`stop`]),onPointerover:t[3]||=e=>{i.hide.cancel(),i.visibleSubitems=!0},onPointerleave:t[4]||=e=>i.hide.call(),onPointerdown:t[5]||=os(()=>{},[`stop`])},[Ur(e.$slots,`default`,{},void 0,!0),n.subitems&&i.visibleSubitems?(M(),N(`div`,bb,[(M(!0),N(j,null,A(n.subitems,r=>(M(),ma(o,{key:r.key,onSelect:e=>r.handler(e),delay:n.delay,onHide:t[0]||=t=>e.$emit(`hide`),subitems:r.subitems},{default:Xn(()=>[Ca(E(r.label),1)]),_:2},1032,[`onSelect`,`delay`,`subitems`]))),128))])):F(`v-if`,!0)],32)]),_:3},8,[`class`])}Py(`@charset "UTF-8";
.block[data-v-fc3b2bca] {
  padding: 0;
}

.content[data-v-fc3b2bca] {
  padding: 4px;
}

.hasSubitems[data-v-fc3b2bca][data-v-fc3b2bca]:after {
  content: "►";
  position: absolute;
  opacity: 0.6;
  right: 5px;
  top: 5px;
}

.subitems[data-v-fc3b2bca] {
  position: absolute;
  top: 0;
  left: 100%;
  width: 120px;
}`);var Sb=Wy({name:`Item`,props:[`subitems`,`delay`],data(){return{visibleSubitems:!1,hide:yb(this.delay,this.hideSubitems)}},methods:{hideSubitems(){this.visibleSubitems=!1}},components:{Block:hb}},[[`render`,xb],[`__scopeId`,`data-v-fc3b2bca`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/context-menu/components/Item.vue`]]);function Cb(e,t,n,r,i,a){let o=Rr(`Search`),s=Rr(`Block`),c=Rr(`Item`);return M(),N(`div`,{class:`menu`,onMouseover:t[2]||=e=>i.hide.cancel(),onMouseleave:t[3]||=e=>i.hide.call(),"data-testid":`context-menu`,"rete-context-menu":``},[n.searchBar?(M(),ma(s,{key:0},{default:Xn(()=>[ya(o,{text:i.filter,onChange:t[0]||=e=>i.filter=e},null,8,[`text`])]),_:1})):F(`v-if`,!0),(M(!0),N(j,null,A(a.getItems(),e=>(M(),ma(c,{key:e.key,onSelect:t=>e.handler(t),delay:n.delay,onHide:t[1]||=e=>n.onHide(),subitems:e.subitems},{default:Xn(()=>[Ca(E(e.label),1)]),_:2},1032,[`onSelect`,`delay`,`subitems`]))),128))],32)}Py(`.menu[data-v-2571168d] {
  padding: 10px;
  width: 120px;
  margin-top: -20px;
  margin-left: -60px;
}`);var wb=Wy({props:[`items`,`delay`,`searchBar`,`onHide`,`seed`],data(){return{filter:``,hide:yb(this.delay,this.onHide)}},methods:{getItems(){let e=new RegExp(this.filter,`i`);return this.items.filter(t=>t.label.match(e))}},unmounted(){this.hide&&this.hide.cancel()},components:{Block:hb,Search:vb,Item:Sb}},[[`render`,Cb],[`__scopeId`,`data-v-2571168d`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/context-menu/components/Menu.vue`]]);function Tb(e){var t=e?.delay===void 0?1e3:e.delay;return{update:function(e){if(e.data.type===`contextmenu`)return{items:e.data.items,delay:t,searchBar:e.data.searchBar,onHide:e.data.onHide}},render:function(e){if(e.data.type===`contextmenu`)return{component:wb,props:{items:e.data.items,delay:t,searchBar:e.data.searchBar,onHide:e.data.onHide}}}}}var Eb=Object.freeze({__proto__:null,setup:Tb});function Db(e){return`${e}px`}function Ob(e,t,n,r,i,a){return M(),N(`div`,{class:`mini-node`,style:Se(a.styles),"data-testid":`minimap-node`},null,4)}Py(`.mini-node[data-v-2d96711d] {
  position: absolute;
  background: rgba(110, 136, 255, 0.8);
  border: 1px solid rgba(192, 206, 212, 0.6);
}`);var kb=Wy({props:[`left`,`top`,`width`,`height`],computed:{styles(){return{left:Db(this.left),top:Db(this.top),width:Db(this.width),height:Db(this.height)}}}},[[`render`,Ob],[`__scopeId`,`data-v-2d96711d`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/minimap/MiniNode.vue`]]);function Ab(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function jb(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Ab(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Ab(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function Mb(e,t){return{start:function(n){var r=jb({},t(n));function i(n){var i=jb({},t(n)),a=i.x-r.x,o=i.y-r.y;r=i,e(a,o)}function a(){window.removeEventListener(`pointermove`,i),window.removeEventListener(`pointerup`,a),window.removeEventListener(`pointercancel`,a)}window.addEventListener(`pointermove`,i),window.addEventListener(`pointerup`,a),window.addEventListener(`pointercancel`,a)}}}function Nb(e,t,n,r,i,a){return M(),N(`div`,{class:`mini-viewport`,onPointerdown:t[0]||=os(e=>i.drag.start(e),[`stop`]),style:Se(a.styles),"data-testid":`minimap-viewport`},null,36)}Py(`.mini-viewport[data-v-ed5fcf61] {
  position: absolute;
  background: rgba(255, 251, 128, 0.32);
  border: 1px solid #ffe52b;
}`);var Pb=Wy({props:[`left`,`top`,`width`,`height`,`containerWidth`,`translate`],data(){return{drag:Mb(this.onDrag,e=>({x:e.pageX,y:e.pageY}))}},methods:{scale(e){return e*this.containerWidth},invert(e){return e/this.containerWidth},onDrag(e,t){this.translate(this.invert(-e),this.invert(-t))}},computed:{styles(){return{left:Db(this.scale(this.left)),top:Db(this.scale(this.top)),width:Db(this.scale(this.width)),height:Db(this.scale(this.height))}}}},[[`render`,Nb],[`__scopeId`,`data-v-ed5fcf61`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/minimap/MiniViewport.vue`]]);function Fb(e,t,n,r,i,a){let o=Rr(`MiniNode`),s=Rr(`MiniViewport`);return M(),N(`div`,{class:`minimap`,ref:`container`,style:Se({width:a.px(n.size*n.ratio),height:a.px(n.size)}),onPointerdown:t[0]||=os(()=>{},[`stop`,`prevent`]),onDblclick:t[1]||=os(e=>a.dblclick(e),[`stop`,`prevent`]),"data-testid":`minimap`},[(M(!0),N(j,null,A(n.nodes,(e,t)=>(M(),ma(o,{key:[t,e.left].join(`_`),left:a.scale(e.left),top:a.scale(e.top),width:a.scale(e.width),height:a.scale(e.height)},null,8,[`left`,`top`,`width`,`height`]))),128)),ya(s,{left:n.viewport.left,top:n.viewport.top,width:n.viewport.width,height:n.viewport.height,containerWidth:e.$refs.container&&e.$refs.container.clientWidth,translate:n.translate},null,8,[`left`,`top`,`width`,`height`,`containerWidth`,`translate`])],36)}Py(`.minimap[data-v-403730b0] {
  position: absolute;
  right: 24px;
  bottom: 24px;
  background: rgba(229, 234, 239, 0.65);
  padding: 20px;
  overflow: hidden;
  border: 1px solid #b1b7ff;
  border-radius: 8px;
  box-sizing: border-box;
}`);var Ib=Wy({props:{size:Number,ratio:Number,nodes:Array,viewport:Object,translate:Function,point:Function,seed:Number},methods:{dblclick(e){if(!this.$refs.container)return;let t=this.$refs.container.getBoundingClientRect(),n=(e.clientX-t.left)/(this.size*this.ratio),r=(e.clientY-t.top)/(this.size*this.ratio);this.point(n,r)},px:Db,scale(e){return this.$refs.container?e*this.$refs.container.clientWidth:0}},components:{MiniNode:kb,MiniViewport:Pb}},[[`render`,Fb],[`__scopeId`,`data-v-403730b0`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/minimap/Minimap.vue`]]);function Lb(e){return{update:function(t){if(t.data.type===`minimap`)return{nodes:t.data.nodes,size:e?.size??200,ratio:t.data.ratio,viewport:t.data.viewport,translate:t.data.translate,point:t.data.point}},render:function(t){if(t.data.type===`minimap`)return{component:Ib,props:{nodes:t.data.nodes,size:e?.size??200,ratio:t.data.ratio,viewport:t.data.viewport,translate:t.data.translate,point:t.data.point}}}}}var Rb=Object.freeze({__proto__:null,setup:Lb});function zb(e,t,n,r,i,a){return M(),N(`div`,{class:De([`pin`,{selected:n.selected}]),onPointerdown:t[0]||=os(t=>{i.drag.start(t),e.$emit(`down`)},[`stop`,`prevent`]),onContextmenu:t[1]||=os(t=>e.$emit(`menu`),[`stop`,`prevent`]),style:Se(a.style),"data-testid":`pin`},null,38)}Py(`.pin[data-v-42b064e9] {
  width: 20px;
  height: 20px;
  box-sizing: border-box;
  background: steelblue;
  border: 2px solid white;
  border-radius: 20px;
}
.pin[data-v-42b064e9].selected[data-v-42b064e9] {
  background: #ffd92c;
}`);var Bb=20,Vb=Wy({props:[`position`,`selected`,`getPointer`],data(){return{drag:Mb(this.onDrag,this.getPointer)}},computed:{style(){let{x:e,y:t}=this.position;return{position:`absolute`,top:`${t-Bb/2}px`,left:`${e-Bb/2}px`}}},methods:{onDrag(e,t){this.$emit(`translate`,{dx:e,dy:t})}}},[[`render`,zb],[`__scopeId`,`data-v-42b064e9`],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/reroute/Pin.vue`]]),Hb={class:`pins`};function Ub(e,t,n,r,i,a){let o=Rr(`Pin`);return M(),N(`div`,Hb,[(M(!0),N(j,null,A(n.pins,e=>(M(),ma(o,{key:e.id,position:e.position,selected:e.selected,getPointer:n.getPointer,onMenu:t=>n.menu(e.id),onTranslate:t=>n.translate(e.id,t.dx,t.dy),onDown:t=>n.down(e.id)},null,8,[`position`,`selected`,`getPointer`,`onMenu`,`onTranslate`,`onDown`]))),128))])}var Wb=Wy({props:[`pins`,`menu`,`translate`,`down`,`seed`,`getPointer`],components:{Pin:Vb}},[[`render`,Ub],[`__file`,`/home/runner/work/vue-plugin/vue-plugin/src/presets/reroute/Pins.vue`]]);function Gb(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function Kb(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Gb(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Gb(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function qb(e){var t=function(){return{menu:e?.contextMenu??function(){return null},translate:e?.translate??function(){return null},down:e?.pointerdown??function(){return null}}};return{update:function(e){if(e.data.type===`reroute-pins`)return Kb(Kb({},t()),{},{pins:e.data.data.pins})},render:function(e,n){if(e.data.type===`reroute-pins`){var r=n.parentScope(uv);return{component:Wb,props:Kb(Kb({},t()),{},{getPointer:function(){return r.area.pointer},pins:e.data.data.pins})}}}}}var Jb=Object.freeze({__proto__:null,classic:fb,contextMenu:Eb,minimap:Rb,reroute:Object.freeze({__proto__:null,setup:qb})});function Yb(e,t){var n=typeof Symbol<`u`&&e[Symbol.iterator]||e[`@@iterator`];if(!n){if(Array.isArray(e)||(n=Xb(e))||t&&e&&typeof e.length==`number`){n&&(e=n);var r=0,i=function(){};return{s:i,n:function(){return r>=e.length?{done:!0}:{done:!1,value:e[r++]}},e:function(e){throw e},f:i}}throw TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var a,o=!0,s=!1;return{s:function(){n=n.call(e)},n:function(){var e=n.next();return o=e.done,e},e:function(e){s=!0,a=e},f:function(){try{o||n.return==null||n.return()}finally{if(s)throw a}}}}function Xb(e,t){if(e){if(typeof e==`string`)return Zb(e,t);var n={}.toString.call(e).slice(8,-1);return n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`?Array.from(e):n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?Zb(e,t):void 0}}function Zb(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function Qb(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function $b(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Qb(Object(n),!0).forEach(function(t){J(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Qb(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function ex(e,t,n){return t=a_(t),i_(e,tx()?Reflect.construct(t,n||[],a_(e).constructor):t.apply(e,n))}function tx(){try{var e=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(tx=function(){return!!e})()}function nx(e,t,n,r){var i=Hv(a_(1&r?e.prototype:e),t,n);return 2&r&&typeof i==`function`?function(e){return i.apply(n,e)}:i}var rx=function(e){function t(e){var n;return K(this,t),n=ex(this,t,[`vue-render`]),J(n,`presets`,[]),J(n,`owners`,new WeakMap),n.renderer=By(e),n.addPipe(function(e){if(!e||$g(e)!==`object`||!(`type`in e))return e;if(e.type===`unmount`)n.unmount(e.data.element);else if(e.type===`render`){if(`filled`in e.data&&e.data.filled)return e;if(n.mount(e.data.element,e))return $b($b({},e),{},{data:$b($b({},e.data),{},{filled:!0})})}return e}),n}return s_(t,e),q(t,[{key:`setParent`,value:function(e){var n=this;nx(t,`setParent`,this,3)([e]),this.presets.forEach(function(e){e.attach&&e.attach(n)})}},{key:`unmount`,value:function(e){this.owners.delete(e),this.renderer.unmount(e)}},{key:`mount`,value:function(e,t){var n=this,r=this.renderer.get(e),i=this.parentScope();if(r)return this.presets.forEach(function(i){if(n.owners.get(e)===i){var a=i.update(t,n);a&&n.renderer.update(r,a)}}),!0;var a=Yb(this.presets),o;try{for(a.s();!(o=a.n()).done;){var s=o.value,c=s.render(t,this);if(c)return this.renderer.mount(e,c.component,c.props,function(){return i.emit({type:`rendered`,data:t.data})}),this.owners.set(e,s),!0}}catch(e){a.e(e)}finally{a.f()}}},{key:`addPreset`,value:function(e){var t=e;t.attach&&t.attach(this),this.presets.push(t)}}])}(C_);function ix(e,t){let n=e.getNode(t.source),r=e.getNode(t.target),i=n&&n.outputs[t.sourceOutput],a=r&&r.inputs[t.targetInput];return{source:i?.socket,target:a?.socket}}function ax(e,t){let{source:n,target:r}=ix(e,t);return!!n&&!!r&&r.isCompatibleWith(n)}function ox(e,t){e.addPipe(n=>{if(n.type===`connectioncreate`&&!ax(e,n.data))t?.(n.data);else return n})}var sx=100;function cx(e){let t=e.trim().toLowerCase().replace(/[^a-z0-9_-]+/g,`-`).replace(/-+/g,`-`).replace(/^-+|-+$/g,``);return(t===``?`untitled`:t).slice(0,sx)}function lx(e,t){let n=ux[e];if(!n)return t;let r=new Set(n.fields.map(e=>e.name)),i={};for(let[e,n]of Object.entries(t))r.has(e)&&(i[e]=n);return i}var ux={"thingstudio/config/wifi":{type:`thingstudio/config/wifi`,label:`WiFi`,singleton:!0,fields:[{name:`credentialName`,label:`saved network`,kind:`credential`,credentialType:`wifi`},{name:`security`,label:`security`,kind:`select`,options:[{value:`password`,label:`Password (WPA/WPA2/WPA3)`},{value:`open`,label:`Open (no password)`},{value:`unmanaged`,label:`Unmanaged (device connects itself, e.g. captive portal)`}]},{name:`allowReprovisioning`,label:`Allow reprovisioning on connect failure`,kind:`boolean`,help:`Off by default: the device only opens its setup AP on first run. Turning this on lets it reopen that AP any time WiFi drops, not just once -- only do this on a trusted, physically-controlled network. Anyone in radio range while WiFi is down could otherwise connect to the AP and redirect this device to a different network.`}],defaults:{credentialName:``,security:`password`,allowReprovisioning:!1},summarize:e=>typeof e.credentialName==`string`?e.credentialName:``},"thingstudio/config/i2c-bus":{type:`thingstudio/config/i2c-bus`,label:`I2C bus`,keyField:`bus`,fields:[{name:`bus`,label:`bus`,kind:`number`},{name:`scl`,label:`scl pin`,kind:`pin`},{name:`sda`,label:`sda pin`,kind:`pin`},{name:`freq`,label:`frequency (Hz)`,kind:`number`,help:`100000 suits most sensors; 400000 for displays that can take it.`}],defaults:{bus:0,scl:null,sda:null,freq:1e5},summarize:e=>{let t=e.scl!==null&&e.scl!==void 0&&e.sda!==null&&e.sda!==void 0?`SCL ${String(e.scl)}, SDA ${String(e.sda)}`:`pins not set`;return`bus ${String(e.bus??0)}: ${t}`}},"thingstudio/config/ble":{type:`thingstudio/config/ble`,label:`BLE`,singleton:!0,fields:[{name:`name`,label:`name`,kind:`text`,help:`What other devices show when they find the board, up to 26 bytes. Shorter leaves more room in an advertisement.`}],defaults:{name:`thingstudio`},summarize:e=>String(e.name??``)},"thingstudio/config/ble-peer":{type:`thingstudio/config/ble-peer`,label:`BLE peer`,fields:[{name:`addr`,label:`address`,kind:`text`,help:`aa:bb:cc:dd:ee:ff. Leave blank to find the device by its name instead.`},{name:`namePrefix`,label:`name starts with`,kind:`text`,help:`Used when there's no address. Phones change their address; most sensors don't.`},{name:`timeoutMs`,label:`timeout (ms)`,kind:`number`,help:`How long finding and connecting may each take before it tries again.`}],defaults:{addr:``,namePrefix:``,timeoutMs:1e4},summarize:e=>String(e.addr||e.namePrefix||``)},"thingstudio/config/touch-panel":{type:`thingstudio/config/touch-panel`,label:`Touch panel`,presetType:`touch_panel`,fields:[{name:`controller`,label:`controller`,kind:`select`,options:[{value:`ft6336u`,label:`FT6336U (Freenove ESP32 displays)`}],help:`Other controllers (GT911, CST820) aren't supported yet.`},{name:`i2cConfigId`,label:`I2C bus`,kind:`configRef`,configType:`thingstudio/config/i2c-bus`},{name:`address`,label:`address`,kind:`text`,help:`7-bit, e.g. 0x38.`},{name:`rstPin`,label:`reset pin`,kind:`pin`,help:`Blank if the panel has none.`},{name:`pollMs`,label:`poll every (ms)`,kind:`number`},{name:`width`,label:`panel width`,kind:`number`},{name:`height`,label:`panel height`,kind:`number`,help:`The panel's own size. If the display is rotated, tick swap/flip until a touch lands where you pressed.`},{name:`swapXY`,label:`swap x and y`,kind:`boolean`},{name:`flipX`,label:`flip x`,kind:`boolean`},{name:`flipY`,label:`flip y`,kind:`boolean`}],defaults:{controller:`ft6336u`,i2cConfigId:``,address:`0x38`,rstPin:``,pollMs:20,width:320,height:480,swapXY:!1,flipX:!1,flipY:!1},summarize:e=>`${String(e.controller??`ft6336u`).toUpperCase()} ${String(e.width??`?`)}x${String(e.height??`?`)}`},"thingstudio/config/gui-theme":{type:`thingstudio/config/gui-theme`,label:`GUI theme`,presetType:`gui_theme`,fields:[{name:`preset`,label:`starting point`,kind:`select`,options:Rs(),help:`Choosing a starting point replaces the colours below; editing one makes the theme custom.`},...Is.map(e=>({name:e,label:Ls[e],kind:`colour`}))],defaults:{preset:`dark-slate`,bg:4258,card:8484,fg:65535,muted:35953,track:16904,accent:16113,on_accent:2113,ok:15974,warn:64608,alarm:63488},summarize:e=>`${String(e.preset||`custom`)} theme`},"thingstudio/config/mqtt-broker":{type:`thingstudio/config/mqtt-broker`,label:`MQTT Broker`,singleton:!0,fields:[{name:`credentialName`,label:`saved broker`,kind:`credential`,credentialType:`mqtt-broker`}],defaults:{credentialName:``},summarize:e=>typeof e.credentialName==`string`?e.credentialName:``}},dx=O(null),fx=O(null),px=O(null),mx=O(0);function hx(){mx.value++}var gx=O(null),_x=O(null),vx=O(new Map),yx=O(0);function bx(){yx.value++}function xx(e){return[...vx.value.values()].filter(t=>t.type===e)}function Sx(e){return vx.value.get(e)}function Cx(e,t){if(ux[e]?.singleton){let n=xx(e)[0];if(n)return n.properties=n.properties.credentialName===t.credentialName?{...n.properties,...t}:{...t},wx(n.id),bx(),n.id}let n=ux[e]?.keyField;if(n!==void 0){let r=xx(e).find(e=>Number(e.properties[n])===Number(t[n]));if(r)return r.properties={...r.properties,...t},bx(),r.id}let r=crypto.randomUUID();return vx.value.set(r,{id:r,type:e,properties:t}),bx(),r}function wx(e){let t=vx.value.get(e);if(!t)return;let n=!1;for(let r of xx(t.type))r.id!==e&&(vx.value.delete(r.id),n=!0);n&&bx()}function Tx(e,t){let n=new Set(xx(e).map(e=>Number(e.properties[t]))),r=0;for(;n.has(r);)r++;return r}function Ex(e,t){let n=vx.value.get(e);if(!n)throw Error(`store.ts: updateConfig() called with unknown config id "${e}"`);n.properties={...n.properties,...t},bx()}function Dx(e){vx.value=new Map(e.map(e=>[e.id,e])),bx()}function Ox(){Dx([])}var kx=dn(null),Ax=`untitled flow`,jx=`pane-1`,Mx=`Flow 01`,X=class extends Error{};function Nx(e,t){return e<t?-1:+(e>t)}function Px(e,t,n=[],r=Ax,i=[{id:jx,name:Mx}],a={},o=``){let s=[...e].sort((e,t)=>Nx(e.id,t.id)),c=[...t].sort((e,t)=>Nx(e[0],t[0])||e[1]-t[1]||Nx(e[2],t[2])||e[3]-t[3]),l=[...n].sort((e,t)=>Nx(e.id,t.id)),u={},d={};for(let e of s)u[e.id]=e.size?{pos:e.pos,size:e.size}:{pos:e.pos},d[e.id]=e.paneId;return{formatVersion:1,flowName:r,nodes:s.map(e=>({id:e.id,type:e.type,properties:e.properties})),edges:c,layout:u,configs:l.map(e=>({id:e.id,type:e.type,properties:e.properties})),panes:i,paneOf:d,...Object.keys(a).length>0?{screens:Object.fromEntries(Object.keys(a).sort(Nx).map(e=>[e,a[e]]))}:{},...o.trim()===``?{}:{notes:o}}}function Fx(e){return JSON.stringify(e,null,2)+`
`}function Ix(e){let t;try{t=JSON.parse(e)}catch(e){throw new X(`not valid JSON: ${e instanceof Error?e.message:String(e)}`)}if(typeof t!=`object`||!t)throw new X(`flow file must be a JSON object`);let n=t;if(n.formatVersion!==1)throw new X(`unsupported flow file formatVersion ${JSON.stringify(n.formatVersion)} (expected 1)`);if(n.flowName!==void 0&&typeof n.flowName!=`string`)throw new X(`"flowName" must be a string`);let r=typeof n.flowName==`string`?n.flowName:Ax;if(!Array.isArray(n.nodes))throw new X(`"nodes" must be an array`);if(!Array.isArray(n.edges))throw new X(`"edges" must be an array`);if(typeof n.layout!=`object`||n.layout===null)throw new X(`"layout" must be an object`);if(n.configs!==void 0&&!Array.isArray(n.configs))throw new X(`"configs" must be an array`);if(n.panes!==void 0&&!Array.isArray(n.panes))throw new X(`"panes" must be an array`);if(n.paneOf!==void 0&&(typeof n.paneOf!=`object`||n.paneOf===null))throw new X(`"paneOf" must be an object`);let i=n.nodes.map((e,t)=>{if(typeof e!=`object`||!e)throw new X(`nodes[${t}] must be an object`);let n=e;if(typeof n.id!=`string`)throw new X(`nodes[${t}].id must be a string`);if(typeof n.type!=`string`)throw new X(`nodes[${t}].type must be a string`);if(typeof n.properties!=`object`||n.properties===null)throw new X(`nodes[${t}].properties must be an object`);return{id:n.id,type:n.type,properties:n.properties}}),a=n.edges.map((e,t)=>{if(!Array.isArray(e)||e.length!==4||typeof e[0]!=`string`||typeof e[1]!=`number`||typeof e[2]!=`string`||typeof e[3]!=`number`)throw new X(`edges[${t}] must be a 4-element array [originId: string, originSlot: number, targetId: string, targetSlot: number]`);return e}),o=n.layout,s={};for(let e of Object.keys(o)){let t=o[e];if(typeof t!=`object`||!t)throw new X(`layout["${e}"] must be an object`);let n=t;if(!Array.isArray(n.pos)||n.pos.length!==2||n.pos.some(e=>typeof e!=`number`))throw new X(`layout["${e}"].pos must be a 2-element numeric array`);let r={pos:n.pos};if(n.size!==void 0){if(!Array.isArray(n.size)||n.size.length!==2||n.size.some(e=>typeof e!=`number`))throw new X(`layout["${e}"].size must be a 2-element numeric array`);r.size=n.size}s[e]=r}let c=(Array.isArray(n.configs)?n.configs:[]).map((e,t)=>{if(typeof e!=`object`||!e)throw new X(`configs[${t}] must be an object`);let n=e;if(typeof n.id!=`string`)throw new X(`configs[${t}].id must be a string`);if(typeof n.type!=`string`)throw new X(`configs[${t}].type must be a string`);if(typeof n.properties!=`object`||n.properties===null)throw new X(`configs[${t}].properties must be an object`);return{id:n.id,type:n.type,properties:n.properties}}),l=(Array.isArray(n.panes)?n.panes:[{id:jx,name:Mx}]).map((e,t)=>{if(typeof e!=`object`||!e)throw new X(`panes[${t}] must be an object`);let n=e;if(typeof n.id!=`string`)throw new X(`panes[${t}].id must be a string`);if(typeof n.name!=`string`)throw new X(`panes[${t}].name must be a string`);return{id:n.id,name:n.name}});if(l.length===0)throw new X(`"panes" must have at least one entry`);let u=n.paneOf??{},d={};for(let e of Object.keys(u)){let t=u[e];if(typeof t!=`string`)throw new X(`paneOf["${e}"] must be a string`);d[e]=t}let f;if(n.screens!==void 0){if(typeof n.screens!=`object`||n.screens===null||Array.isArray(n.screens))throw new X(`"screens" must be an object`);for(let[e,t]of Object.entries(n.screens))if(typeof t!=`object`||!t||!Array.isArray(t.pages))throw new X(`screens["${e}"] must be an object with a "pages" array`);f=n.screens}if(n.notes!==void 0&&typeof n.notes!=`string`)throw new X(`"notes" must be a string`);let p=typeof n.notes==`string`&&n.notes.trim()!==``?n.notes:void 0;return{formatVersion:n.formatVersion,flowName:r,nodes:i,edges:a,layout:s,configs:c,panes:l,paneOf:d,...f?{screens:f}:{},...p===void 0?{}:{notes:p}}}var Lx=O([{id:jx,name:Mx}]),Rx=O(jx),zx=O(new Map),Bx=O(0);function Vx(){Bx.value++}var Hx=2;function Ux(){return`Flow ${String(Hx++).padStart(2,`0`)}`}function Wx(){let e=crypto.randomUUID();return Lx.value=[...Lx.value,{id:e,name:Ux()}],e}function Gx(e,t){let n=Lx.value.find(t=>t.id===e);if(!n)throw Error(`panes-store.ts: renamePane() called with unknown pane id "${e}"`);n.name=t,Lx.value=[...Lx.value]}function Kx(e){e!==Rx.value&&(Rx.value=e,dx.value=null,fx.value=null,px.value?.())}function qx(e){zx.value.set(e,Rx.value),Vx()}function Jx(e){zx.value.delete(e)&&Vx()}function Yx(e){return zx.value.get(e)??Lx.value[0].id}function Xx(e){return Yx(e)===Rx.value}function Zx(e,t,n){Lx.value=e,Rx.value=e[0].id;let r=new Map;for(let i of n)r.set(i,t[i]??e[0].id);zx.value=r,Vx();let i=1;for(let t of e){let e=/^Flow (\d+)$/.exec(t.name);e&&(i=Math.max(i,Number(e[1])))}Hx=i+1}function Qx(){Lx.value=[{id:jx,name:Mx}],Rx.value=jx,zx.value=new Map,Vx(),Hx=2}function $x(e){return[...zx.value.entries()].filter(([,t])=>t===e).map(([e])=>e)}function eS(e){return Lx.value.length<=1||Lx.value.findIndex(t=>t.id===e)===-1?!1:(Lx.value=Lx.value.filter(t=>t.id!==e),Rx.value===e&&Kx(Lx.value[0].id),!0)}var tS=dn({});function nS(e){tS.value=e}function rS(e,t){let n=tS.value[e]??{pages:[]},r=t(n);r!==n&&(tS.value={...tS.value,[e]:r},hx())}function iS(e){let t={};for(let[n,r]of Object.entries(tS.value))e.has(n)||(t[n]=xf(r,e));tS.value=t,hx()}var aS=()=>[];function oS(e){aS=e}function sS(){return aS()}var cS=class extends z_.Socket{constructor(){super(`bool`)}isCompatibleWith(){return!0}},lS=class e extends z_.Socket{constructor(){super(`number`)}isCompatibleWith(t){return t instanceof e||t instanceof uS||t instanceof dS}},uS=class e extends z_.Socket{constructor(){super(`int`)}isCompatibleWith(t){return t instanceof e||t instanceof dS}},dS=class e extends z_.Socket{constructor(){super(`string`)}isCompatibleWith(t){return t instanceof e}},fS=class e extends z_.Socket{constructor(){super(`bytes`)}isCompatibleWith(t){return t instanceof e||t instanceof pS}},pS=class extends z_.Socket{constructor(){super(`any`)}isCompatibleWith(){return!0}};function mS(e){switch(e){case`bool`:return new cS;case`number`:return new lS;case`int`:return new uS;case`string`:return new dS;case`bytes`:return new fS;case`any`:return new pS}}var hS=34;function gS(e,t,n){let r=e?.find(e=>e.name===t);if(!r)throw Error(`nodes.ts: no port definition named "${t}" -- node-library ports declaration is out of sync with this file`);return mS(hs(r,n))}var _S=class extends z_.Node{width;height;kind;nodeType;descriptor;highlighted=!1;status=null;statusText=null;properties;constructor(e){super(e.title??e.label??e.paletteId??e.type),this.descriptor=e,this.width=e.width??100,this.height=(e.ports?.outputs?.length??0)>1?54:hS,this.kind=e.paletteId??`custom`,this.nodeType=e.type,this.properties=Object.fromEntries((e.properties??[]).filter(e=>e.name!==void 0).map(e=>[e.name,e.default]));for(let t of e.ports?.inputs??[])this.addInput(t.name,new z_.Input(gS(e.ports?.inputs,t.name,this.properties),t.name,!0));let t=e.dynamicOutputs;if(t){let e=vs(t,this.properties);for(let t=0;t<e;t++)this.addDynamicOutputAt(t);this.setDynamicOutputHeight(e)}else for(let t of e.ports?.outputs??[])this.addOutput(t.name,new z_.Output(gS(e.ports?.outputs,t.name,this.properties),t.name))}addDynamicOutputAt(e){let t=this.descriptor.dynamicOutputs,n=this.descriptor.ports?.outputs?.[0];if(!n)throw Error(`nodes.ts: dynamic-output node "${this.descriptor.type}" has no ports.outputs template`);this.addOutput(`${t.namePrefix}${e}`,new z_.Output(gS(this.descriptor.ports?.outputs,n.name,this.properties),String(e+1)))}removeDynamicOutputAt(e){this.removeOutput(`${this.descriptor.dynamicOutputs.namePrefix}${e}`)}setDynamicOutputHeight(e){this.height=hS+Math.max(0,e-1)*this.descriptor.dynamicOutputs.rowHeightPx}retypeOutputs(){for(let e of this.descriptor.ports?.outputs??[]){let t=this.outputs[e.name];t&&(t.socket=gS(this.descriptor.ports?.outputs,e.name,this.properties))}}};function Z(e){return class extends _S{constructor(){super(e)}}}var vS=class extends Z(js){},yS=class extends Z(ic){},bS=class extends Z(tc){},xS=class extends Z(Ju){},SS=class extends Z(Nu){},CS=class extends Z(od){},wS=class extends Z(Pu){},TS=class extends Z(id){},ES=class extends Z(cd){},DS=class extends Z(fc){},OS=class extends Z(gu){},kS=class extends Z(uc){},AS=class extends Z(gd){},jS=class extends Z(Td){},MS=class extends Z(Id){},NS=class extends Z(zd){},PS=class extends Z(Hd){},FS=class extends Z(Gd){},IS=class extends Z(Jd){},LS=class extends Z(Zd){},RS=class extends Z(tf){},zS=class extends Z(af){},BS=class extends Z(pd){},VS=class extends Z(ud){},HS=class extends Z(Vu){},US=class extends Z(Ru){},WS=class extends Z(Wu){},GS=class extends Z(Qu){},KS=class extends Z(td){},qS=class extends Z(Xu){},JS=class extends Z(vu){},YS=class extends Z(bu){},XS=class extends Z(Su){},ZS=class extends Z(Tu){},QS=class extends Z(Du){},$S=class extends Z(oc){},eC=class extends Z(cc){},tC=class extends Z(Sd){},nC=class extends Z(yd){},rC=class extends Z(Ys){},iC=class extends Z(Ns){},aC=class extends Z(Jf){},oC=class extends Z(Xf){},sC=class extends Z(Zf){},cC=class extends Z(Qf){},lC=class extends Z($f){},uC=class extends Z(ep){},dC=class extends Z(tp){},fC=class extends Z(np){},pC=class extends Z(rp){},mC=class extends _S{width=128;constructor(e){super(e)}},hC={inject:()=>new xS,startup:()=>new CS,function:()=>new SS,debug:()=>new vS,gpio_out:()=>new wS,pwm_out:()=>new TS,timer:()=>new ES,interrupt:()=>new qS,eswitch:()=>new JS,ebutton:()=>new YS,adc:()=>new XS,encoder:()=>new ZS,neopixel:()=>new QS,display_spi:()=>new rC,display_i2c:()=>new iC,wifi_status:()=>new tC,wifi_gate:()=>new nC,udp_send:()=>new BS,udp_receive:()=>new VS,http_request:()=>new HS,http_in:()=>new US,http_response:()=>new WS,mqtt_publish:()=>new GS,mqtt_subscribe:()=>new KS,delay:()=>new yS,change:()=>new bS,filter:()=>new $S,bme280:()=>new kS,touch_i2c:()=>new DS,i2c:()=>new OS,gui_screen:()=>new aC,gui_label:()=>new oC,gui_readout:()=>new sC,gui_bar:()=>new cC,gui_trend:()=>new lC,journal:()=>new eC,ntp:()=>new AS,ble_scan:()=>new jS,ble_advertise:()=>new MS,ble_characteristic_in:()=>new NS,ble_characteristic_out:()=>new PS,ble_uart_in:()=>new FS,ble_uart_out:()=>new IS,ble_read:()=>new LS,ble_write:()=>new RS,ble_notify:()=>new zS,gui_led:()=>new uC,gui_button:()=>new dC,gui_navigator:()=>new fC,gui_modal:()=>new pC},gC=[`general`,`network`,`hardware`,`GUI`],_C={},vC={color:`#555`,bgcolor:`#2b2b2b`,icon:`?`,label:`?`,group:`general`,priority:1e3},yC=`application/x-thingstudio-node-kind`,bC=`application/x-thingstudio-custom-node-type`,xC=null;function SC(){if(!xC){xC=new Map;for(let e of sp().values())e.paletteId&&xC.set(e.paletteId,e)}return xC}function CC(e){return SC().get(e)}function wC(e){let t=CC(e);return t&&t.label!==void 0&&t.group!==void 0&&t.priority!==void 0?{color:t.color??vC.color,bgcolor:t.bgcolor??vC.bgcolor,icon:t.icon??vC.icon,label:t.label,group:t.group,priority:t.priority,...t.hidden?{hidden:!0}:{}}:_C[e]??vC}var TC=[`title`],EC={class:`ts-label`,"data-testid":`title`},DC={class:`ts-status-text`},OC=`#e05555`,kC=`#5a1f1f`,AC=10,jC=pr({__name:`ThingstudioNode`,props:{data:{},emit:{type:Function},seed:{}},setup(e){let t=e,n=I(()=>(Bx.value,!Xx(t.data.id))),r=I(()=>{let e=wC(t.data.kind),n=t.data.descriptor;return n?{...e,color:n.color??e.color,bgcolor:n.bgcolor??e.bgcolor,icon:n.icon??e.icon,label:n.label??e.label}:e}),i=I(()=>r.value.icon),a=I(()=>{mx.value;let e=t.data.properties?.label;return typeof e==`string`&&e.trim()?e.trim():t.data.label}),o=I(()=>t.data instanceof xS);function s(e){o.value&&(e.stopPropagation(),_x.value?.(t.data))}let c=I(()=>({width:Number.isFinite(t.data.width)?`${t.data.width}px`:``,height:Number.isFinite(t.data.height)?`${t.data.height}px`:``,outlineColor:t.data.highlighted?OC:t.data.selected?`#ff8f0e`:r.value.color,background:t.data.highlighted?kC:r.value.bgcolor})),l={connected:`connected`,connecting:`connecting`,disconnected:`disconnected`,error:`error`},u=I(()=>{t.seed;let e=t.data.status;return e==null?null:{text:t.data.statusText??e,dotClass:l[e]}}),d=I(()=>({top:`${(Number.isFinite(t.data.height)?t.data.height:34)+3}px`,left:`0`,width:Number.isFinite(t.data.width)?`${t.data.width}px`:``}));function f(e){return[...e].sort(([,e],[,t])=>(e?.index??0)-(t?.index??0))}let p=I(()=>(t.seed,f(Object.entries(t.data.inputs)))),m=I(()=>(t.seed,f(Object.entries(t.data.outputs))));function h(e,n){let r=Number.isFinite(t.data.height)?t.data.height:34;return{top:`${(n<=1?.5:(e+1)/(n+1))*r-AC/2}px`}}return(t,r)=>(M(),N(j,null,[P(`div`,{class:De([`ts-node`,[`kind-${e.data.kind}`,{selected:e.data.selected,highlighted:e.data.highlighted,"ts-pane-hidden":n.value}]]),style:Se(c.value)},[P(`div`,{class:De([`ts-icon`,{"ts-icon-fire":o.value}]),title:o.value?`fire this inject node`:void 0,onPointerdown:s},E(i.value),43,TC),P(`div`,EC,E(a.value),1),(M(!0),N(j,null,A(p.value,(t,n)=>(M(),ma(mn(Qy),{key:`input`+t[0],class:`ts-port in`,style:Se(h(n,p.value.length)),data:{type:`socket`,side:`input`,key:t[0],nodeId:e.data.id,payload:t[1].socket},emit:e.emit,"data-testid":`input-socket`},null,8,[`style`,`data`,`emit`]))),128)),(M(!0),N(j,null,A(m.value,(t,n)=>(M(),ma(mn(Qy),{key:`output`+t[0],class:`ts-port out`,style:Se(h(n,m.value.length)),data:{type:`socket`,side:`output`,key:t[0],nodeId:e.data.id,payload:t[1].socket},emit:e.emit,"data-testid":`output-socket`},null,8,[`style`,`data`,`emit`]))),128))],6),u.value&&!n.value?(M(),N(`div`,{key:0,class:`ts-status`,style:Se(d.value)},[P(`span`,{class:De([`ts-status-dot`,u.value.dotClass])},null,2),P(`span`,DC,E(u.value.text),1)],4)):F(``,!0)],64))}}),MC=(e,t)=>{let n=e.__vccOpts||e;for(let[e,r]of t)n[e]=r;return n},NC=MC(jC,[[`__scopeId`,`data-v-0e1972ea`]]),PC={class:`ts-socket-dot`},FC=MC(pr({__name:`ThingstudioSocket`,props:{data:{}},setup(e){return(e,t)=>(M(),N(`div`,PC))}}),[[`__scopeId`,`data-v-b4dc3bf3`]]),IC={key:0,"data-testid":`connection`},LC=[`d`],RC=MC(pr({__name:`ThingstudioConnection`,props:{data:{},path:{}},setup(e){let t=e,n=I(()=>fx.value?.id===t.data.id),r=I(()=>(Bx.value,!Xx(t.data.source)));function i(){fx.value=t.data,dx.value=null,px.value?.()}return(t,a)=>r.value?F(``,!0):(M(),N(`svg`,IC,[P(`path`,{d:e.path,class:De({"ts-wire-selected":n.value}),onPointerdown:os(i,[`stop`])},null,42,LC)]))}}),[[`__scopeId`,`data-v-605617c1`]]);async function zC(e){let t=new k_,n=new Bv(e),r=new Sy,i=new rx;i.addPreset(Jb.classic.setup({customize:{node:()=>NC,socket:()=>FC,connection:()=>RC}})),r.addPreset(hy.classic.setup()),t.use(n),n.use(r),n.use(i),ox(t,e=>{console.warn(`[thingstudio] rejected incompatible connection`,e)}),n.addPipe(e=>(e.type===`nodepicked`&&(dx.value=t.getNode(e.data.id)??null,fx.value=null),e)),e.addEventListener(`pointerdown`,t=>{t.target===e&&(dx.value=null,fx.value=null)});let a=Fv.selector(),o=Fv.selectableNodes(n,a,{accumulating:Fv.accumulateOnCtrl()});px.value=()=>{a.unselectAll()},Fv.simpleNodesOrder(n),gx.value=async(e,r)=>{let i=e.descriptor.dynamicOutputs;if(!i)return;let a=Math.max(i.min,Math.min(i.max,Math.round(r)||i.min)),o=Object.keys(e.outputs).length;if(a!==o){if(a>o)for(let t=o;t<a;t++)e.addDynamicOutputAt(t);else for(let n=a;n<o;n++){let r=`${i.namePrefix}${n}`;for(let n of[...t.getConnections()])n.source===e.id&&n.sourceOutput===r&&await t.removeConnection(n.id);e.removeDynamicOutputAt(n)}e.properties[i.property]=a,e.setDynamicOutputHeight(a),await n.update(`node`,e.id)}};function s(e){let t=n.container.clientWidth,r=n.container.clientHeight;if(t===0||r===0)return!1;let i=Fv.getBoundingBox(n,[e]),{x:a,y:o,k:s}=n.area.transform,c=i.left*s+a,l=i.top*s+o,u=i.right*s+a,d=i.bottom*s+o;return c>=40&&l>=40&&u<=t-40&&d<=r-40}return{editor:t,area:n,addNode:async(e,r)=>(await t.addNode(e),await n.translate(e.id,r),e),connectNodes:(e,n,r,i)=>t.addConnection(new z_.Connection(e,n,r,i)),fitView:()=>Fv.zoomAt(n,t.getNodes()),focusNode:e=>s(e)?Promise.resolve():Fv.zoomAt(n,[e]),selectNode:async e=>{dx.value=e,fx.value=null,await o.select(e.id,!1)},clear:async()=>{for(let e of[...t.getConnections()])await t.removeConnection(e.id);for(let e of[...t.getNodes()])await t.removeNode(e.id),Jx(e.id);dx.value=null,fx.value=null,hx()},deleteSelected:async()=>{let e=new Set(t.getNodes().filter(e=>e.selected).map(e=>e.id));if(e.size>0){for(let n of[...t.getConnections()])(e.has(n.source)||e.has(n.target))&&await t.removeConnection(n.id);for(let n of e)await t.removeNode(n),Jx(n);dx.value&&e.has(dx.value.id)&&(dx.value=null),iS(e),hx()}else if(fx.value){let e=fx.value.id;t.getConnections().some(t=>t.id===e)&&await t.removeConnection(e),fx.value=null}},deletePane:async e=>{let n=new Set($x(e));if(n.size>0){for(let e of[...t.getConnections()])(n.has(e.source)||n.has(e.target))&&await t.removeConnection(e.id);for(let e of n)await t.removeNode(e),Jx(e);dx.value&&n.has(dx.value.id)&&(dx.value=null),iS(n),hx()}return eS(e)}}}function BC(e,t){let n=e.indexOf(t);if(n===-1)throw Error(`graph-adapter: socket key "${t}" not found among [${e.join(`, `)}]`);return n}function VC(e,t=[]){let n={nodes:e.getNodes().map(e=>{let t=e;return{id:t.id,type:t.nodeType,properties:t.properties}}),links:e.getConnections().map((t,n)=>{let r=e.getNode(t.source),i=e.getNode(t.target);if(!r||!i)throw Error(`graph-adapter: connection ${t.id} references a missing node`);let a=BC(Object.keys(r.outputs),t.sourceOutput),o=BC(Object.keys(i.inputs),t.targetInput),s=r.outputs[t.sourceOutput]?.socket.name??`any`;return[n+1,t.source,a,t.target,o,s]})};return t.length>0&&(n.configs=t),n}var HC=O(new Map),UC=O(0),WC=new Map;function GC(){return[...HC.value.values()]}function KC(e){return HC.value.get(e)}function qC(){return GC().map(e=>{let t=pu(e.descriptor,e.pythonSource);return e.compileHook!==void 0&&(t.compileHook=e.compileHook),t})}function JC(e){let t=WC.get(e);return t?`custom node type "${e}" didn't load -- ${t.file}: ${t.message}`:e.startsWith(`thingstudio/`)?`unknown node type "${e}"`:`no custom node package defines type "${e}" -- add its two files to ~/.thingstudio/custom-nodes/, then click Reload custom nodes`}var YC=`thingstudio.paletteFolds`,XC=`general`;function ZC(e,t){return Object.prototype.hasOwnProperty.call(e,t)?e[t]===!0:t!==XC}function QC(e,t){return{...e,[t]:!ZC(e,t)}}function $C(e){if(!e)return{};try{let t=JSON.parse(e);if(!t||typeof t!=`object`||Array.isArray(t))return{};let n={};for(let[e,r]of Object.entries(t))typeof r==`boolean`&&(n[e]=r);return n}catch{return{}}}var ew={class:`palette-header`},tw={key:0,class:`palette-header-label`},nw=[`title`],rw=[`aria-expanded`,`title`,`onClick`],iw={class:`palette-chevron`},aw={key:0,class:`palette-count`},ow=[`disabled`,`title`,`draggable`,`onClick`,`onDragstart`],sw={class:`palette-label`},cw={key:0,class:`hint`},lw=MC(pr({__name:`PaletteSidebar`,emits:[`add`,`addCustom`,`reloadCustomNodes`],setup(e,{emit:t}){let n=t,r=sp();function i(e){let t=kx.value;return t?(e??[]).filter(e=>!t.capabilities.has(e)):[]}let a=O(!1),o=O(``);function s(){try{return $C(localStorage.getItem(YC))}catch{return{}}}let c=O(s());function l(e){return o.value.trim()===``&&ZC(c.value,e)}function u(e){if(o.value.trim()===``){c.value=QC(c.value,e);try{localStorage.setItem(YC,JSON.stringify(c.value))}catch{}}}let d=I(()=>{UC.value;let e=o.value.trim().toLowerCase(),t=[...new Set([...Object.keys(_C),...SC().keys()])].map(e=>({kind:e,style:wC(e)})).filter(({style:e})=>!e.hidden).filter(({style:t})=>t.label.toLowerCase().includes(e)).map(({kind:e,style:t})=>({key:e,origin:`builtin`,value:e,label:t.label,color:t.color,bgcolor:t.bgcolor,icon:t.icon,group:t.group,priority:t.priority,unmet:i(r.get(`thingstudio/${e}`)?.requires?.capabilities)})),n=[...HC.value.values()].filter(e=>!e.descriptor.hidden).map(e=>({key:e.descriptor.type,origin:`custom`,value:e.descriptor.type,label:e.descriptor.label,color:e.descriptor.color??vC.color,bgcolor:e.descriptor.bgcolor??vC.bgcolor,icon:e.descriptor.icon??`◆`,group:e.descriptor.group??vC.group,priority:e.descriptor.priority??vC.priority,unmet:i(e.descriptor.requires?.capabilities)})).filter(t=>t.label.toLowerCase().includes(e));return[...t,...n]}),f=I(()=>{let e=d.value,t=[...gC];for(let n of e)t.includes(n.group)||t.push(n.group);return t.map(t=>({name:t,rows:e.filter(e=>e.group===t).sort((e,t)=>e.priority-t.priority)})).filter(e=>e.rows.length>0)});function p(e){e.unmet.length>0||(e.origin===`builtin`?n(`add`,e.value):n(`addCustom`,e.value))}function m(e,t){t.unmet.length>0||(e.dataTransfer?.setData(t.origin===`builtin`?yC:bC,t.value),e.dataTransfer&&(e.dataTransfer.effectAllowed=`copy`))}return(e,t)=>(M(),N(`div`,{class:De([`palette-sidebar`,{"is-collapsed":a.value}])},[P(`div`,ew,[a.value?F(``,!0):(M(),N(`span`,tw,`Palette`)),P(`button`,{class:`palette-collapse-toggle`,title:a.value?`Expand palette`:`Collapse palette`,onClick:t[0]||=e=>a.value=!a.value},E(a.value?`»`:`«`),9,nw)]),a.value?F(``,!0):(M(),N(j,{key:0},[k(P(`input`,{"onUpdate:modelValue":t[1]||=e=>o.value=e,class:`palette-filter`,type:`text`,placeholder:`filter nodes`},null,512),[[Ko,o.value]]),(M(!0),N(j,null,A(f.value,e=>(M(),N(j,{key:e.name},[P(`button`,{class:`palette-category`,"aria-expanded":!l(e.name),title:l(e.name)?`Show the ${e.name} nodes`:`Hide the ${e.name} nodes`,onClick:t=>u(e.name)},[P(`span`,iw,E(l(e.name)?`▸`:`▾`),1),P(`span`,null,E(e.name),1),l(e.name)?(M(),N(`span`,aw,E(e.rows.length),1)):F(``,!0)],8,rw),(M(!0),N(j,null,A(l(e.name)?[]:e.rows,e=>(M(),N(`button`,{key:e.key,class:De([`palette-row`,{"is-unmet":e.unmet.length>0}]),style:Se({borderColor:e.color}),disabled:e.unmet.length>0,title:e.unmet.length?`Needs ${e.unmet.join(`, `)}, which this board doesn't have`:void 0,draggable:e.unmet.length===0,onClick:t=>p(e),onDragstart:t=>m(t,e)},[P(`span`,{class:`palette-icon`,style:Se({background:e.bgcolor})},E(e.icon),5),P(`span`,sw,E(e.label),1)],46,ow))),128))],64))),128)),f.value.length===0?(M(),N(`p`,cw,`No nodes match "`+E(o.value)+`".`,1)):F(``,!0),mn(!0)?F(``,!0):(M(),N(`button`,{key:1,class:`palette-row load-custom-row`,title:`Read the custom node folder again, after you change a file there`,onClick:t[2]||=e=>n(`reloadCustomNodes`)},[...t[3]||=[P(`span`,{class:`palette-icon`},`⟳`,-1),P(`span`,{class:`palette-label`},`Reload custom nodes`,-1)]]))],64))],2))}}),[[`__scopeId`,`data-v-e6ee531b`]]),uw=`button, a, select`;function dw(e){return Array.from(e.querySelectorAll(uw)).filter(e=>!e.hidden&&!e.disabled&&e.closest(`[hidden]`)===null)}function fw(e=document){let t=Array.from(e.querySelectorAll(`.menu`)).map(e=>({menu:e,button:e.querySelector(`:scope > .menu-button`),list:e.querySelector(`:scope > .menu-list`)})).filter(e=>!!e.button&&!!e.list);function n(e,t=!1){e.list.hidden||(e.list.hidden=!0,e.button.setAttribute(`aria-expanded`,`false`),t&&e.button.focus())}function r(e){for(let r of t)r!==e&&n(r)}function i(e,t=!1){r(e),e.list.hidden=!1,e.button.setAttribute(`aria-expanded`,`true`),t&&dw(e.list)[0]?.focus()}for(let e of t)e.button.addEventListener(`click`,()=>e.list.hidden?i(e):n(e)),e.button.addEventListener(`keydown`,t=>{t.key===`ArrowDown`&&(t.preventDefault(),i(e,!0))}),e.list.addEventListener(`keydown`,t=>{if(t.key===`Escape`){t.preventDefault(),n(e,!0);return}if(t.key!==`ArrowDown`&&t.key!==`ArrowUp`||t.target.tagName===`SELECT`)return;t.preventDefault();let r=dw(e.list),i=r.indexOf(document.activeElement);r[t.key===`ArrowDown`?(i+1)%r.length:(i-1+r.length)%r.length]?.focus()}),e.list.addEventListener(`click`,t=>{let r=t.target.closest(`button, a`);r&&e.list.contains(r)&&n(e)});document.addEventListener(`click`,e=>{let n=e.target?.closest?.(`.menu`);r(t.find(e=>e.menu===n))}),document.addEventListener(`keydown`,e=>{e.key===`Escape`&&r()})}var pw={wifi:{type:`wifi`,label:`WiFi credential`,namePlaceholder:`e.g. home-wifi`,fields:[{name:`ssid`,label:`SSID`,kind:`text`},{name:`password`,label:`password`,kind:`password`}],defaults:{ssid:``,password:``}},"mqtt-broker":{type:`mqtt-broker`,label:`MQTT broker credential`,namePlaceholder:`e.g. home-broker`,fields:[{name:`broker`,label:`host`,kind:`text`,placeholder:`e.g. 192.168.1.20 or broker.local`},{name:`port`,label:`port`,kind:`number`},{name:`username`,label:`username`,kind:`text`,placeholder:`optional`},{name:`password`,label:`password`,kind:`password`,placeholder:`optional`}],defaults:{broker:``,port:1883,username:``,password:``}}},mw=`Demo: nothing is saved or sent. Use made-up values.`,hw=class extends Error{},gw=new Map,_w=(e,t,n)=>`${e}\u0000${t}\u0000${n}`,vw=(e,t)=>{let n=`${e}\u0000${t}\u0000`;return[...gw.keys()].filter(e=>e.startsWith(n)).map(e=>e.slice(n.length)).sort()};function yw(e,t,n){let r=gw.get(_w(e,t,n));if(!r)throw new hw(`no ${t} ${e} called "${n}" in this demo yet`);return{...r}}async function bw(e,t,n,r){gw.set(_w(e,t,n),{...r})}async function xw(e){return vw(`credential`,e)}async function Sw(e,t){return yw(`credential`,e,t)}async function Cw(e,t,n){return bw(`credential`,e,t,n)}async function ww(e){return vw(`preset`,e).map(e=>({name:e,valid:!0,error:null}))}async function Tw(e,t){return yw(`preset`,e,t)}async function Ew(e,t,n){return bw(`preset`,e,t,n)}function Dw(e){return e instanceof hw||!1}function Ow(e){return e instanceof Error?e.message:String(e)}var kw={class:`pin-field`},Aw={class:`pin-name`},jw=[`value`],Mw={key:0,value:``},Nw=[`value`],Pw=[`value`],Fw=[`min`,`max`,`value`],Iw=[`value`],Lw=[`title`],Rw=MC(pr({__name:`PinField`,props:{modelValue:{},label:{},optional:{type:Boolean}},emits:[`update:modelValue`,`touch`],setup(e,{emit:t}){let n=e,r=t;function i(e){return typeof e==`number`?Number.isInteger(e):typeof e==`string`&&e.trim()!==``}let a=I(()=>i(n.modelValue)?typeof n.modelValue==`string`?n.modelValue.trim():n.modelValue:null),o=I(()=>{let e=kx.value;return e?[...e.gpio].sort((e,t)=>typeof e==`number`&&typeof t==`number`?e-t:typeof e==`number`?-1:typeof t==`number`?1:e.localeCompare(t)):[]}),s=I(()=>kx.value?o.value.some(e=>typeof e==`string`)?`named`:`numeric`:`plain`),c=I(()=>{let e=kx.value;if(!e)return 48;let t=[...e.gpio].filter(e=>typeof e==`number`);return t.length?Math.max(...t):48});function l(e){return JSON.stringify(e)}function u(e){if(e===``)return null;try{let t=JSON.parse(e);return i(t)?t:null}catch{return null}}let d=I(()=>a.value===null?``:l(a.value)),f=I(()=>{let e=a.value;return s.value!==`named`||e===null||o.value.some(t=>t===e)?null:l(e)}),p=I(()=>`${String(a.value)} (not on this board)`);function m(e){let t=kx.value,n=typeof e==`number`?`GPIO ${e}`:e,r=t.pinLabels.get(e);return r&&r.length?`${n} · ${r.join(`, `)}`:n}function h(e){let t=kx.value;if(!t||e===null||typeof e==`number`&&e<0)return null;if(!t.gpio.has(e))return{text:`not on this board`,title:`${t.label} has no ${typeof e==`number`?`GPIO ${e}`:`pin ${e}`}`,bad:!0};let n=t.reserved.get(e);if(n!==void 0)return{text:`reserved`,title:n,bad:!0};let r=t.pinLabels.get(e)?.join(`, `),i=t.avoid.get(e);return i===void 0?t.inputOnly.has(e)?{text:r?`${r} · input only`:`input only`,title:`${typeof e==`number`?`GPIO ${e}`:`pin ${e}`} is input-only on ${t.label}`,bad:!1}:r?{text:r,title:`${t.board?.name??t.label}: ${r}`,bad:!1}:null:{text:r?`${r} · avoid`:`avoid`,title:i,bad:!1}}let g=I(()=>h(a.value)),_=I(()=>typeof a.value==`number`?a.value:null),v=I(()=>a.value===null?``:String(a.value));function y(e){r(`update:modelValue`,e),r(`touch`)}function b(e){y(u(e.target.value))}function x(e){let t=e.target.valueAsNumber;y(Number.isFinite(t)?Math.round(t):null)}function S(e){let t=e.target.value.trim();t===``?y(n.optional?null:t):/^\d+$/.test(t)?y(Number(t)):(Sc(t),y(t))}return(t,n)=>(M(),N(`label`,kw,[P(`span`,Aw,E(e.label),1),s.value===`named`?(M(),N(`select`,{key:0,value:d.value,onChange:b},[e.optional?(M(),N(`option`,Mw,`— not wired —`)):F(``,!0),f.value===null?F(``,!0):(M(),N(`option`,{key:1,value:f.value},E(p.value),9,Nw)),(M(!0),N(j,null,A(o.value,e=>(M(),N(`option`,{key:l(e),value:l(e)},E(m(e)),9,Pw))),128))],40,jw)):s.value===`numeric`?(M(),N(`input`,{key:1,type:`number`,min:e.optional?-1:0,max:c.value,value:_.value,onInput:x},null,40,Fw)):(M(),N(`input`,{key:2,type:`text`,value:v.value,placeholder:`5 or X1`,onInput:S},null,40,Iw)),g.value?(M(),N(`span`,{key:3,class:De([`pin-hint`,{bad:g.value.bad}]),title:g.value.title},E(g.value.text),11,Lw)):F(``,!0)]))}}),[[`__scopeId`,`data-v-38388d98`]]),zw={class:`preset-ref-field`},Bw={class:`ref-line`},Vw={class:`ref-name`},Hw={class:`preset-ref-row`},Uw=[`value`,`disabled`],Ww={value:``,disabled:``},Gw=[`value`,`disabled`],Kw=[`disabled`],qw={key:0,class:`preset-error`},Jw={key:1,class:`preset-error`},Yw={key:2,class:`preset-save-panel`},Xw={class:`field-row`},Zw={key:0,class:`preset-error`},Qw={class:`preset-save-actions`},$w=[`disabled`],eT=MC(pr({__name:`PresetRefField`,props:{presetType:{},properties:{},label:{}},emits:[`applied`],setup(e,{emit:t}){function n(e){return Object.fromEntries(Object.entries(e).filter(([e])=>!e.endsWith(`ConfigId`)))}let r=e,i=t,a=I(()=>r.label??`preset`),o=O([]),s=O(!1),c=O(null),l=O(``),u=I(()=>{let e=o.value.filter(e=>!e.valid);if(e.length===0)return null;let t=e.map(e=>e.name).join(`, `);return`${e.length===1?`1 saved preset is`:`${e.length} saved presets are`} invalid and can't be loaded: ${t} -- fix the JSON by hand in ~/.thingstudio/presets/${r.presetType}/`});async function d(){s.value=!0,c.value=null;try{o.value=await ww(r.presetType)}catch(e){c.value=Ow(e)}finally{s.value=!1}}d(),nr(()=>r.presetType,d);async function f(e){if(e){c.value=null;try{let t=await Tw(r.presetType,e);Object.assign(r.properties,n(t)),l.value=e,i(`applied`)}catch(e){c.value=Ow(e)}}}let p=O(!1),m=O(``),h=O(null),g=O(!1);function _(){h.value=null,m.value=l.value,p.value=!0}async function v(){let e=m.value.trim();if(!e)h.value=`name is required`;else{g.value=!0,h.value=null;try{await Ew(r.presetType,e,n(r.properties)),await d(),l.value=e,p.value=!1}catch(e){h.value=Ow(e)}finally{g.value=!1}}}return(e,t)=>(M(),N(`div`,zw,[P(`label`,Bw,[P(`span`,Vw,E(a.value),1),P(`div`,Hw,[P(`select`,{value:l.value,onChange:t[0]||=e=>f(e.target.value),disabled:s.value},[P(`option`,Ww,E(s.value?`loading...`:`load preset...`),1),(M(!0),N(j,null,A(o.value,e=>(M(),N(`option`,{key:e.name,value:e.name,disabled:!e.valid},E(e.name)+E(e.valid?``:` (invalid)`),9,Gw))),128))],40,Uw),P(`button`,{type:`button`,class:`icon-btn`,title:`save current values as a preset`,onClick:_},`💾`),P(`button`,{type:`button`,class:`icon-btn`,title:`refresh`,disabled:s.value,onClick:d},`↻`,8,Kw)])]),c.value?(M(),N(`p`,qw,E(c.value),1)):F(``,!0),u.value?(M(),N(`p`,Jw,E(u.value),1)):F(``,!0),p.value?(M(),N(`div`,Yw,[P(`label`,Xw,[t[3]||=P(`span`,{class:`field-label`},`name`,-1),k(P(`input`,{"onUpdate:modelValue":t[1]||=e=>m.value=e,placeholder:`e.g. cyd`},null,512),[[Ko,m.value]])]),h.value?(M(),N(`p`,Zw,E(h.value),1)):F(``,!0),P(`div`,Qw,[P(`button`,{type:`button`,disabled:g.value,onClick:v},E(g.value?`saving...`:`Save`),9,$w),P(`button`,{type:`button`,onClick:t[2]||=e=>p.value=!1},`Cancel`)])])):F(``,!0)]))}}),[[`__scopeId`,`data-v-54be37ef`]]),tT={class:`config-ref-field`},nT={class:`ref-line`},rT={class:`ref-name`},iT={class:`config-ref-row`},aT=[`value`],oT=[`selected`],sT=[`value`],cT=[`disabled`],lT={key:0,class:`config-edit-panel`},uT={class:`config-edit-header`},dT={key:0,class:`config-edit-name`},fT={key:0,class:`field-note`},pT={key:1,class:`field-note`},mT={class:`field-label`},hT=[`type`,`placeholder`,`disabled`,`onUpdate:modelValue`],gT={class:`field-row`},_T={class:`field-label`},vT=[`onUpdate:modelValue`],yT=[`value`],bT=[`onUpdate:modelValue`],xT=[`type`,`onUpdate:modelValue`],ST={key:0,class:`field-help`},CT={key:1,class:`field-note demo-note`},wT={key:2,class:`field-note`},TT={key:3,class:`field-error`},ET={class:`config-edit-actions`},DT=[`disabled`],OT={key:1,class:`config-edit-panel`},kT={class:`config-edit-header`},AT={key:2,class:`field-row`},jT={class:`field-label`},MT=[`onUpdate:modelValue`,`onChange`],NT=[`value`],PT=[`onUpdate:modelValue`],FT=[`type`,`onUpdate:modelValue`],IT={key:3,class:`field-help`},LT={key:2,class:`config-edit-panel`},RT={class:`config-edit-header`},zT={key:0,class:`field-note demo-note`},BT={key:1,class:`field-note`},VT={class:`field-row`},HT=[`placeholder`],UT={class:`field-label`},WT=[`type`,`placeholder`,`onUpdate:modelValue`],GT={class:`field-row`},KT={class:`field-label`},qT=[`onUpdate:modelValue`,`onChange`],JT=[`value`],YT=[`onUpdate:modelValue`],XT=[`type`,`onUpdate:modelValue`],ZT={key:0,class:`field-help`},QT={key:2,class:`field-error`},$T={class:`config-edit-actions`},eE=[`disabled`],tE=`credential:`,nE=`__unmanaged__`,rE=`unmanaged`,iE=MC(pr({__name:`ConfigRefField`,props:{configType:{},modelValue:{},label:{}},emits:[`update:modelValue`],setup(e,{emit:t}){let n=e,r=t,i=I(()=>{let e=ux[n.configType];if(!e)throw Error(`ConfigRefField: no config-types.ts entry for "${n.configType}"`);return e}),a=I(()=>n.label??i.value.label),o=O([]);async function s(){let e=w.value;if(!e?.credentialType)o.value=[];else try{o.value=await xw(e.credentialType)}catch{o.value=[]}}Or(s);let c=I(()=>te.value.find(e=>e.kind===`select`&&e.options?.some(e=>e.value===rE))),l=I(()=>{yx.value;let e=w.value,t=xx(n.configType),r=t.map(e=>({id:e.id,summary:i.value.summarize(e.properties)||`(unnamed ${i.value.label} #${e.id.slice(0,6)})`}));if(!e)return r;let a=new Set(t.map(t=>t.properties[e.name]).filter(e=>typeof e==`string`&&e!==``)),s=o.value.filter(e=>!a.has(e)).map(e=>({id:`${tE}${e}`,summary:e})),l=c.value,u=l&&t.some(t=>!t.properties[e.name]&&t.properties[l.name]===rE),d=l&&!u?[{id:nE,summary:l.options.find(e=>e.value===rE).label}]:[];return[...r,...s,...d]}),u=I(()=>{if(yx.value,i.value.singleton){let e=xx(n.configType);return e.length===1?e[0].id:void 0}return n.modelValue}),d=I(()=>{yx.value;let e=u.value;return e?vx.value.get(e)??null:null});function f(e){if(e){if(e===nE){let e=w.value,t=c.value;if(!e||!t)return;let a=xx(n.configType).find(n=>!n.properties[e.name]&&n.properties[t.name]===rE)?.id??Cx(n.configType,{...i.value.defaults,[e.name]:``,[t.name]:rE});i.value.singleton&&wx(a),r(`update:modelValue`,a)}else if(e.startsWith(tE)){let t=e.slice(11),a=w.value;if(!a)return;let o=xx(n.configType).find(e=>e.properties[a.name]===t),s=o?o.id:Cx(n.configType,{...i.value.defaults,[a.name]:t});i.value.singleton&&wx(s),r(`update:modelValue`,s)}else i.value.singleton&&wx(e),r(`update:modelValue`,e)}}let p=O(null),m=Qt({}),h=O(``),g=Qt({}),_=O(!1),v=O(!1),y=O(null),b=O(!1);function x(e){let t=Sx(e);if(!t)return;p.value=e;for(let e of Object.keys(m))delete m[e];Object.assign(m,i.value.defaults,t.properties);let n=w.value;n?.credentialType&&S(n.credentialType,String(t.properties[n.name]??``))}async function S(e,t){y.value=null,v.value=!1,h.value=t;for(let e of Object.keys(g))delete g[e];if(Object.assign(g,pw[e]?.defaults??{}),t){_.value=!0;try{Object.assign(g,await Sw(e,t))}catch(e){Dw(e)?v.value=!0:y.value=Ow(e)}finally{_.value=!1}}}async function ee(){let e=p.value,t=w.value;if(e&&t?.credentialType){b.value=!0,y.value=null;try{let n=h.value;n&&await Cw(t.credentialType,n,{...g});let r={};for(let e of te.value)r[e.name]=m[e.name];Ex(e,n?{...r,...g}:r),p.value=null,s()}catch(e){y.value=Ow(e)}finally{b.value=!1}}}function C(e,t){i.value.type===`thingstudio/config/gui-theme`&&e.name===`preset`&&zs(t,`preset`,String(t.preset??``))}let w=I(()=>i.value.fields.find(e=>e.kind===`credential`)),te=I(()=>i.value.fields.filter(e=>e.kind!==`credential`)),T=I(()=>{let e=w.value;return e?.credentialType?pw[e.credentialType]??null:null}),ne=O(!1),re=O(``),ie=Qt({}),ae=Qt({}),oe=O(null),se=O(!1);function ce(){if(w.value){oe.value=null,re.value=``;for(let e of Object.keys(ie))delete ie[e];Object.assign(ie,T.value?.defaults??{});for(let e of Object.keys(ae))delete ae[e];for(let e of te.value)ae[e.name]=i.value.defaults[e.name];ne.value=!0}else{let e=i.value.keyField,t=e?{[e]:Tx(n.configType,e)}:{},a=Cx(n.configType,{...i.value.defaults,...t});r(`update:modelValue`,a),x(a)}}async function le(){let e=w.value;if(!e?.credentialType)return;let t=re.value.trim();if(!t)oe.value=`name is required`;else{se.value=!0,oe.value=null;try{await Cw(e.credentialType,t,{...ie});let a=Cx(n.configType,{...i.value.defaults,...ae,[e.name]:t});r(`update:modelValue`,a),ne.value=!1,s()}catch(e){oe.value=Ow(e)}finally{se.value=!1}}}function ue(){ne.value=!1}nr(m,()=>{p.value&&!w.value&&Ex(p.value,{...m})},{deep:!0});function de(){p.value=null}return nr(()=>u.value,e=>{p.value&&e!==p.value&&(p.value=null)}),(e,t)=>{let n=Rr(`ConfigRefField`,!0);return M(),N(`div`,tT,[P(`label`,nT,[P(`span`,rT,E(a.value),1),P(`div`,iT,[P(`select`,{value:u.value??``,onChange:t[0]||=e=>f(e.target.value)},[P(`option`,{value:``,selected:!u.value},`unassigned`,8,oT),(M(!0),N(j,null,A(l.value,e=>(M(),N(`option`,{key:e.id,value:e.id},E(e.summary),9,sT))),128))],40,aT),P(`button`,{type:`button`,class:`icon-btn`,title:`edit`,disabled:!d.value,onClick:t[1]||=e=>x(d.value.id)},`✎`,8,cT),P(`button`,{type:`button`,class:`icon-btn`,title:`add new`,onClick:ce},`+`)])]),p.value&&w.value?(M(),N(`div`,lT,[P(`div`,uT,[Ca(` edit `+E(i.value.label),1),h.value?(M(),N(`span`,dT,` "`+E(h.value)+`"`,1)):F(``,!0)]),h.value?(M(),N(j,{key:0},[_.value?(M(),N(`p`,fT,`loading...`)):v.value?(M(),N(`p`,pT,` No saved `+E(i.value.label)+` called "`+E(h.value)+`" `+E(mn(!0)?`in this demo`:`on this computer`)+`. Fill it in and save to create it. `,1)):F(``,!0),(M(!0),N(j,null,A(T.value?.fields??[],e=>(M(),N(`label`,{key:e.name,class:`field-row`},[P(`span`,mT,E(e.label),1),k(P(`input`,{type:e.kind===`password`?`password`:e.kind===`number`?`number`:`text`,placeholder:e.placeholder,disabled:_.value,"onUpdate:modelValue":t=>g[e.name]=t},null,8,hT),[[ts,g[e.name]]])]))),128))],64)):F(``,!0),(M(!0),N(j,null,A(te.value,e=>(M(),N(j,{key:e.name},[P(`label`,gT,[P(`span`,_T,E(e.label),1),e.kind===`select`?k((M(),N(`select`,{key:0,"onUpdate:modelValue":t=>m[e.name]=t},[(M(!0),N(j,null,A(e.options,e=>(M(),N(`option`,{key:e.value,value:e.value},E(e.label),9,yT))),128))],8,vT)),[[Xo,m[e.name]]]):e.kind===`boolean`?k((M(),N(`input`,{key:1,type:`checkbox`,"onUpdate:modelValue":t=>m[e.name]=t},null,8,bT)),[[qo,m[e.name]]]):k((M(),N(`input`,{key:2,type:e.kind===`number`?`number`:`text`,"onUpdate:modelValue":t=>m[e.name]=t},null,8,xT)),[[ts,m[e.name]]])]),e.help?(M(),N(`p`,ST,E(e.help),1)):F(``,!0)],64))),128)),h.value&&mn(!0)?(M(),N(`p`,CT,E(mn(mw)),1)):h.value?(M(),N(`p`,wT,` Saved on this computer, not in the flow. Every flow that uses "`+E(h.value)+`" gets the change. `,1)):F(``,!0),y.value?(M(),N(`p`,TT,E(y.value),1)):F(``,!0),P(`div`,ET,[P(`button`,{type:`button`,disabled:b.value||_.value,onClick:ee},E(b.value?`saving...`:`Save`),9,DT),P(`button`,{type:`button`,onClick:de},`Cancel`)])])):p.value?(M(),N(`div`,OT,[P(`div`,kT,`edit `+E(i.value.label),1),i.value.presetType?(M(),ma(eT,{key:p.value,"preset-type":i.value.presetType,properties:m},null,8,[`preset-type`,`properties`])):F(``,!0),(M(!0),N(j,null,A(i.value.fields,e=>(M(),N(j,{key:e.name},[e.kind===`configRef`?(M(),ma(n,{key:0,"config-type":e.configType,"model-value":m[e.name]||void 0,label:e.label,"onUpdate:modelValue":t=>{m[e.name]=t}},null,8,[`config-type`,`model-value`,`label`,`onUpdate:modelValue`])):e.kind===`pin`?(M(),ma(Rw,{key:1,label:e.label,optional:!0,"model-value":m[e.name],"onUpdate:modelValue":t=>{m[e.name]=t}},null,8,[`label`,`model-value`,`onUpdate:modelValue`])):(M(),N(`label`,AT,[P(`span`,jT,E(e.label),1),e.kind===`select`?k((M(),N(`select`,{key:0,"onUpdate:modelValue":t=>m[e.name]=t,onChange:t=>C(e,m)},[(M(!0),N(j,null,A(e.options,e=>(M(),N(`option`,{key:e.value,value:e.value},E(e.label),9,NT))),128))],40,MT)),[[Xo,m[e.name]]]):e.kind===`boolean`?k((M(),N(`input`,{key:1,type:`checkbox`,"onUpdate:modelValue":t=>m[e.name]=t},null,8,PT)),[[qo,m[e.name]]]):k((M(),N(`input`,{key:2,type:e.kind===`password`?`password`:e.kind===`number`?`number`:`text`,"onUpdate:modelValue":t=>m[e.name]=t},null,8,FT)),[[ts,m[e.name]]])])),e.help?(M(),N(`p`,IT,E(e.help),1)):F(``,!0)],64))),128)),P(`div`,{class:`config-edit-actions`},[P(`button`,{type:`button`,onClick:de},`Cancel`)])])):F(``,!0),ne.value?(M(),N(`div`,LT,[P(`div`,RT,`new `+E(i.value.label),1),T.value&&mn(!0)?(M(),N(`p`,zT,E(mn(mw)),1)):T.value?(M(),N(`p`,BT,`Saved on this computer, not in the flow.`)):F(``,!0),P(`label`,VT,[t[3]||=P(`span`,{class:`field-label`},`name`,-1),k(P(`input`,{"onUpdate:modelValue":t[2]||=e=>re.value=e,placeholder:T.value?.namePlaceholder??`e.g. home`},null,8,HT),[[Ko,re.value]])]),(M(!0),N(j,null,A(T.value?.fields??[],e=>(M(),N(`label`,{key:e.name,class:`field-row`},[P(`span`,UT,E(e.label),1),k(P(`input`,{type:e.kind===`password`?`password`:e.kind===`number`?`number`:`text`,placeholder:e.placeholder,"onUpdate:modelValue":t=>ie[e.name]=t},null,8,WT),[[ts,ie[e.name]]])]))),128)),(M(!0),N(j,null,A(te.value,e=>(M(),N(j,{key:e.name},[P(`label`,GT,[P(`span`,KT,E(e.label),1),e.kind===`select`?k((M(),N(`select`,{key:0,"onUpdate:modelValue":t=>ae[e.name]=t,onChange:t=>C(e,ae)},[(M(!0),N(j,null,A(e.options,e=>(M(),N(`option`,{key:e.value,value:e.value},E(e.label),9,JT))),128))],40,qT)),[[Xo,ae[e.name]]]):e.kind===`boolean`?k((M(),N(`input`,{key:1,type:`checkbox`,"onUpdate:modelValue":t=>ae[e.name]=t},null,8,YT)),[[qo,ae[e.name]]]):k((M(),N(`input`,{key:2,type:e.kind===`password`?`password`:e.kind===`number`?`number`:`text`,"onUpdate:modelValue":t=>ae[e.name]=t},null,8,XT)),[[ts,ae[e.name]]])]),e.help?(M(),N(`p`,ZT,E(e.help),1)):F(``,!0)],64))),128)),oe.value?(M(),N(`p`,QT,E(oe.value),1)):F(``,!0),P(`div`,$T,[P(`button`,{type:`button`,disabled:se.value,onClick:le},E(se.value?`saving...`:`Save`),9,eE),P(`button`,{type:`button`,onClick:ue},`Cancel`)])])):F(``,!0)])}}}),[[`__scopeId`,`data-v-d016e4fc`]]),aE={class:`credential-ref-field`},oE={class:`ref-line`},sE={class:`ref-name`},cE={class:`credential-ref-row`},lE=[`value`,`disabled`],uE={value:``,disabled:``},dE=[`value`],fE=[`disabled`],pE={key:0,class:`credential-note`},mE={key:1,class:`credential-error`},hE={key:2,class:`credential-edit-panel`},gE={class:`credential-edit-header`},_E={key:0,class:`field-row`},vE={class:`field-label`},yE=[`type`,`onUpdate:modelValue`],bE={key:1,class:`credential-error`},xE={class:`credential-edit-actions`},SE=[`disabled`],CE=MC(pr({__name:`CredentialRefField`,props:{credentialType:{},modelValue:{},label:{}},emits:[`update:modelValue`],setup(e,{emit:t}){let n=e,r=t,i=I(()=>{let e=pw[n.credentialType];if(!e)throw Error(`CredentialRefField: no credential-types.ts entry for "${n.credentialType}"`);return e}),a=I(()=>n.label??i.value.label),o=O([]),s=O(!1),c=O(null);async function l(){s.value=!0,c.value=null;try{o.value=await xw(n.credentialType)}catch(e){c.value=Ow(e)}finally{s.value=!1}}l(),nr(()=>n.credentialType,l);function u(e){e&&r(`update:modelValue`,e)}let d=O(!1),f=O(!1),p=O(``),m=O(``),h=Qt({}),g=O(null),_=O(!1);async function v(e){if(e){g.value=null,f.value=!1,p.value=e,d.value=!0;for(let e of Object.keys(h))delete h[e];Object.assign(h,i.value.defaults);try{let t=await Sw(n.credentialType,e);Object.assign(h,t)}catch(e){g.value=Ow(e)}}}function y(){g.value=null,f.value=!0,p.value=``,m.value=``;for(let e of Object.keys(h))delete h[e];Object.assign(h,i.value.defaults),d.value=!0}async function b(){let e=f.value?m.value.trim():p.value;if(!e)g.value=`name is required`;else{_.value=!0,g.value=null;try{await Cw(n.credentialType,e,{...h}),await l(),r(`update:modelValue`,e),d.value=!1}catch(e){g.value=Ow(e)}finally{_.value=!1}}}function x(){d.value=!1}return nr(()=>n.modelValue,e=>{d.value&&!f.value&&e!==p.value&&(d.value=!1)}),(t,n)=>(M(),N(`div`,aE,[P(`label`,oE,[P(`span`,sE,E(a.value),1),P(`div`,cE,[P(`select`,{value:e.modelValue??``,onChange:n[0]||=e=>u(e.target.value),disabled:s.value},[P(`option`,uE,E(s.value?`loading...`:`select ${i.value.label}...`),1),(M(!0),N(j,null,A(o.value,e=>(M(),N(`option`,{key:e,value:e},E(e),9,dE))),128))],40,lE),P(`button`,{type:`button`,class:`icon-btn`,title:`edit`,disabled:!e.modelValue,onClick:n[1]||=t=>v(e.modelValue)},`✎`,8,fE),P(`button`,{type:`button`,class:`icon-btn`,title:`add new`,onClick:y},`+`)])]),mn(!0)?(M(),N(`p`,pE,E(mn(mw)),1)):F(``,!0),c.value?(M(),N(`p`,mE,E(c.value),1)):F(``,!0),d.value?(M(),N(`div`,hE,[P(`div`,gE,E(f.value?`new ${i.value.label}`:`editing "${p.value}"`),1),f.value?(M(),N(`label`,_E,[n[3]||=P(`span`,{class:`field-label`},`name`,-1),k(P(`input`,{"onUpdate:modelValue":n[2]||=e=>m.value=e,placeholder:`e.g. home-wifi`},null,512),[[Ko,m.value]])])):F(``,!0),(M(!0),N(j,null,A(i.value.fields,e=>(M(),N(`label`,{key:e.name,class:`field-row`},[P(`span`,vE,E(e.label),1),k(P(`input`,{type:e.kind===`password`?`password`:e.kind===`number`?`number`:`text`,"onUpdate:modelValue":t=>h[e.name]=t},null,8,yE),[[ts,h[e.name]]])]))),128)),g.value?(M(),N(`p`,bE,E(g.value),1)):F(``,!0),P(`div`,xE,[P(`button`,{type:`button`,disabled:_.value,onClick:b},E(_.value?`saving...`:`Save`),9,SE),P(`button`,{type:`button`,onClick:x},`Cancel`)])])):F(``,!0)]))}}),[[`__scopeId`,`data-v-5218ba4c`]]);function wE(e){let t=Math.min(65535,Math.max(0,Math.round(Number(e)||0))),n=t>>11&31,r=t>>5&63,i=t&31;return`#`+[n<<3|n>>2,r<<2|r>>4,i<<3|i>>2].map(e=>e.toString(16).padStart(2,`0`)).join(``)}function TE(e){let t=/^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/.exec(e.trim());if(!t)throw Error(`"${e}" is not a #rrggbb color`);let n=parseInt(t[1],16),r=parseInt(t[2],16),i=parseInt(t[3],16);return n>>3<<11|r>>2<<5|i>>3}function EE(e){return`0x`+(Math.round(Number(e)||0)&65535).toString(16).padStart(4,`0`)}var DE={key:0,class:`palette-field`},OE={class:`palette-head`},kE={class:`swatches`},AE=[`title`],jE={class:`idx`},ME=[`value`,`onInput`],NE=MC(pr({__name:`PaletteField`,props:{properties:{}},emits:[`changed`],setup(e,{emit:t}){let n=e,r=t,i=I(()=>{let e=n.properties.frameFormat;return e===`gs4`||e===`gs2`||e===`mono`?Js[e]:0}),a=I(()=>{let e=n.properties.palette;return Array.isArray(e)&&e.length===16?e.map(e=>Number(e)):[...qs]});function o(e,t){let i=[...a.value];i[e]=TE(t),n.properties.palette=i,r(`changed`)}function s(){n.properties.palette=[...qs],r(`changed`)}return(e,t)=>i.value>0?(M(),N(`div`,DE,[P(`div`,OE,[P(`span`,null,`palette (`+E(i.value)+` of 16 used)`,1),P(`button`,{type:`button`,class:`reset`,title:`Restore the built-in 16-color palette`,onClick:s},`reset`)]),P(`div`,kE,[(M(!0),N(j,null,A(i.value,e=>(M(),N(`label`,{key:e,class:`swatch`,title:`index ${e-1}: ${mn(EE)(a.value[e-1])}`},[P(`span`,jE,E(e-1),1),P(`input`,{type:`color`,value:mn(wE)(a.value[e-1]),onInput:t=>o(e-1,t.target.value)},null,40,ME)],8,AE))),128))])])):F(``,!0)}}),[[`__scopeId`,`data-v-b1dd80c8`]]),PE={class:`prop-row`},FE={class:`prop-name`},IE={class:`color-field`},LE=[`value`,`title`],RE=[`value`],zE=MC(pr({__name:`ColorField`,props:{label:{},modelValue:{}},emits:[`update:modelValue`],setup(e,{emit:t}){let n=e,r=t,i=I(()=>{let e=Number(n.modelValue);return Number.isFinite(e)?Math.min(65535,Math.max(0,Math.round(e))):0});function a(e){try{r(`update:modelValue`,TE(e))}catch{}}return(t,n)=>(M(),N(`label`,PE,[P(`span`,FE,E(e.label),1),P(`span`,IE,[P(`input`,{type:`color`,value:mn(wE)(i.value),title:`${mn(wE)(i.value)} (0x${i.value.toString(16).padStart(4,`0`)})`,onInput:n[0]||=e=>a(e.target.value)},null,40,LE),P(`input`,{class:`hex`,type:`text`,spellcheck:`false`,value:mn(wE)(i.value),onChange:n[1]||=e=>a(e.target.value)},null,40,RE)])]))}}),[[`__scopeId`,`data-v-6151258d`]]),BE={class:`outline`},VE={key:0,class:`hint`},HE={class:`target-head`},UE={key:0,class:`dim`},WE={class:`btns`},GE=[`disabled`,`onClick`],KE=[`onClick`],qE=[`onClick`],JE={class:`addrow`},YE=[`disabled`],XE={class:`target-head`},ZE={class:`btns`},QE=[`onClick`],$E={key:0,class:`addrow`},eD=[`value`],tD=MC(pr({__name:`ScreenOutline`,props:{screenId:{}},setup(e){let t=e,n=I(()=>tS.value[t.screenId]??{pages:[]}),r=O(``),i=O(``);function a(e){let r=e(n.value);r!==n.value&&(rS(t.screenId,r),hx())}function o(){let e=r.value.trim();e&&(a(t=>gf(t,e)),r.value=``)}function s(){let e=i.value;e&&(a(t=>yf(t,e)),i.value=``)}let c=I(()=>sS());function l(e){return c.value.find(t=>t.id===e)?.name??e.slice(0,6)}function u(e){let t=new Set(e.filter(e=>!e.card&&e.node).map(e=>e.node));return c.value.filter(e=>e.kind===`widget`&&!t.has(e.id))}let d=I(()=>{let e=new Set((n.value.modals??[]).map(e=>e.node));return c.value.filter(t=>t.kind===`modal`&&!e.has(t.id))});function f(e){a(t=>{switch(e.op){case`up`:return pf(t,e.target,e.index,-1);case`down`:return pf(t,e.target,e.index,1);case`remove`:return ff(t,e.target,e.index);case`props`:return mf(t,e.target,e.index,e.props??{})}})}function p(e){a(t=>df(t,e.target,e.element))}let m=pr({props:{elements:{type:Array,required:!0},target:{type:Object,required:!0},names:{type:Function,required:!0},unplaced:{type:Array,required:!0}},emits:[`op`,`add`],setup(e,{emit:t}){let n=O({});return()=>Xa(`div`,{class:`rows`},e.elements.map((t,n)=>({index:n,element:t,canUp:n>0,canDown:n<e.elements.length-1,label:t.card?`panel`:t.kind===`text`?`“${t.text??``}”`:t.kind===`pagedots`?`page dots`:e.names(t.node??``)})).map(r=>{let i=r.element,a=(n,a,o,s)=>Xa(`label`,{class:`f`},[n,Xa(`input`,{class:`mini`,style:{width:`${o}px`},value:i[a]??``,onChange:n=>{let i=n.target.value.trim();t(`op`,{op:`props`,target:e.target,index:r.index,props:{[a]:s?i===``?void 0:Number(i):i}})}})]),o=[a(`row`,`row`,34,!0),a(`col`,`col`,34,!0),a(`rows`,`rowSpan`,34,!0),a(`cols`,`colSpan`,34,!0)];o.push(Xa(`label`,{class:`f`,title:`draw a card behind these cells`},[`panel`,Xa(`input`,{type:`checkbox`,checked:i.card===!0,onChange:n=>t(`op`,{op:`props`,target:e.target,index:r.index,props:{card:n.target.checked?!0:void 0}})})])),i.kind===`text`&&(o.push(a(`text`,`text`,110,!1)),o.push(Xa(`label`,{class:`f`},[`align`,Xa(`select`,{class:`mini`,onChange:n=>t(`op`,{op:`props`,target:e.target,index:r.index,props:{align:n.target.value||void 0}})},[`left`,`center`,`right`].map(e=>Xa(`option`,{value:e,selected:(i.align??`left`)===e},e)))])));let s=(n,i,a,o)=>Xa(`button`,{title:i,disabled:!a,onClick:()=>t(`op`,{op:o,target:e.target,index:r.index})},n);return Xa(`div`,{class:`rowwrap`},[Xa(`div`,{class:`row`},[Xa(`span`,{class:`lbl`},r.label),Xa(`span`,{class:`btns`},[(()=>{let n=n=>t(`add`,{target:e.target,element:n}),r={"@text":()=>({kind:`text`,text:`Text`,row:0,col:0}),"@dots":()=>({kind:`pagedots`,row:0,col:0,colSpan:2,align:`center`}),"@panel":()=>({card:!0,row:0,col:0,rowSpan:1,colSpan:2})};return Xa(`select`,{class:`addsel`,title:`add to this page`,value:``,onChange:e=>{let t=e.target,i=t.value;t.value=``,i&&n(i.startsWith(`@`)?r[i]():{kind:`widget`,node:i,row:0,col:0})}},[Xa(`option`,{value:``},`+ add…`),...e.unplaced.length?[Xa(`optgroup`,{label:`widgets`},e.unplaced.map(e=>Xa(`option`,{value:e.id},e.name)))]:[],Xa(`optgroup`,{label:`other`},[Xa(`option`,{value:`@text`},`text`),Xa(`option`,{value:`@dots`},`page dots`),Xa(`option`,{value:`@panel`},`panel`)])])})(),Xa(`button`,{title:`placement`,class:n.value[r.index]?`on`:``,onClick:()=>n.value={...n.value,[r.index]:!n.value[r.index]}},`⚙`),s(`↑`,`earlier in the list`,r.canUp,`up`),s(`↓`,`later in the list`,r.canDown,`down`),s(`✕`,`remove`,!0,`remove`)])]),n.value[r.index]?Xa(`div`,{class:`extras`,style:{paddingLeft:`8px`}},o):null])}))}});return(e,t)=>(M(),N(`div`,BE,[t[4]||=P(`h4`,null,`Pages`,-1),n.value.pages.length?F(``,!0):(M(),N(`p`,VE,`No pages yet. Add one below.`)),(M(!0),N(j,null,A(n.value.pages,(e,t)=>(M(),N(`div`,{key:e.name,class:`target`},[P(`div`,HE,[P(`strong`,null,E(e.name),1),e.parent?(M(),N(`span`,UE,` (inside `+E(e.parent)+`)`,1)):F(``,!0),P(`span`,WE,[e.parent?F(``,!0):(M(),N(`button`,{key:0,disabled:t===0,title:`earlier in the page order`,onClick:t=>a(t=>mn(vf)(t,e.name,-1))},`↑`,8,GE)),e.parent?F(``,!0):(M(),N(`button`,{key:1,title:`later in the page order`,onClick:t=>a(t=>mn(vf)(t,e.name,1))},`↓`,8,KE)),P(`button`,{title:`remove this page`,onClick:t=>a(t=>mn(_f)(t,e.name))},`✕`,8,qE)])]),ya(mn(m),{elements:e.elements,target:{page:e.name},names:l,unplaced:u(e.elements),onOp:f,onAdd:p},null,8,[`elements`,`target`,`unplaced`])]))),128)),P(`div`,JE,[k(P(`input`,{"onUpdate:modelValue":t[0]||=e=>r.value=e,placeholder:`new page name`,onKeyup:cs(o,[`enter`])},null,544),[[Ko,r.value]]),P(`button`,{disabled:!r.value.trim(),onClick:o},`add page`,8,YE)]),n.value.modals?.length||d.value.length?(M(),N(j,{key:1},[t[3]||=P(`h4`,null,`Modals`,-1),(M(!0),N(j,null,A(n.value.modals??[],e=>(M(),N(`div`,{key:e.node,class:`target`},[P(`div`,XE,[P(`strong`,null,E(l(e.node)),1),P(`span`,ZE,[P(`button`,{title:`remove this modal's layout`,onClick:t=>a(t=>mn(bf)(t,e.node))},`✕`,8,QE)])]),ya(mn(m),{elements:e.elements,target:{modal:e.node},names:l,unplaced:u(e.elements),onOp:f,onAdd:p},null,8,[`elements`,`target`,`unplaced`])]))),128)),d.value.length?(M(),N(`div`,$E,[k(P(`select`,{"onUpdate:modelValue":t[1]||=e=>i.value=e,onChange:s},[t[2]||=P(`option`,{value:``},`lay out a modal…`,-1),(M(!0),N(j,null,A(d.value,e=>(M(),N(`option`,{key:e.id,value:e.id},E(e.name),9,eD))),128))],544),[[Xo,i.value]])])):F(``,!0)],64)):F(``,!0),t[5]||=P(`p`,{class:`hint`},[Ca(`Rows and columns are cells of the screen's grid (0-based); spans default to 1. Tick `),P(`em`,null,`panel`),Ca(` to draw a card behind the cells.`)],-1)]))}}),[[`__scopeId`,`data-v-c4ed54ec`]]),nD={class:`node-id`},rD={class:`prop-row`},iD=[`placeholder`],aD={key:1,class:`hint`},oD={key:5,class:`prop-row`},sD={class:`prop-name`},cD=[`onUpdate:modelValue`,`onChange`],lD={key:6,class:`hint`},uD={class:`prop-name`},dD=[`onUpdate:modelValue`,`onChange`],fD=[`value`],pD=[`rows`,`placeholder`,`onUpdate:modelValue`,`onInput`],mD=[`min`,`max`,`step`,`placeholder`,`onUpdate:modelValue`,`onInput`],hD=[`placeholder`,`onUpdate:modelValue`,`onInput`],gD=[`placeholder`,`onUpdate:modelValue`,`onInput`],_D={key:9,class:`hint`},vD={key:3,class:`hint`},yD=MC(pr({__name:`PropertyPanel`,setup(e){let t=I(()=>(mx.value,dx.value)),n=I(()=>t.value?.descriptor??null),r=I(()=>t.value instanceof mC),i=I(()=>t.value?.properties??{}),a=I(()=>{let e=t.value?.properties?.label;return typeof e==`string`&&e.trim()?e.trim():t.value?.label??``}),o=I(()=>{if(!t.value)return vC;let e=wC(t.value.kind),r=n.value;return r?{color:r.color??e.color,bgcolor:r.bgcolor??e.bgcolor,icon:r.icon??e.icon,label:r.label??e.label,group:r.group??e.group,priority:r.priority??e.priority}:e});function s(){hx()}function c(e,n){t.value&&(t.value.properties[e]=n,s())}function l(e){return e.name?i.value[e.name]:void 0}function u(e,t){e.name?c(e.name,t):s()}function d(e){return gs(e.placeholderWhen,e.placeholder,i.value)}function f(e){n.value?.dynamicOutputs?.property===e.name&&p(Number(i.value[e.name])),e.name===`themePreset`&&t.value?.type===`thingstudio/gui_screen`&&zs(i.value,`themePreset`,String(i.value.themePreset??``)),e.retype&&t.value?.retypeOutputs?.(),s()}function p(e){t.value&&Number.isFinite(e)&&gx.value?.(t.value,e)}return(e,p)=>(M(),N(`div`,{class:De([`property-panel`,{"is-collapsed":!t.value}])},[p[2]||=P(`div`,{class:`panel-eyebrow`},`Properties`,-1),t.value?(M(),N(j,{key:0},[P(`h3`,null,[P(`span`,{class:`kind-dot`,style:Se({background:o.value.color})},null,4),Ca(` `+E(a.value)+` `,1),P(`span`,nD,`#`+E(t.value.id.slice(0,6)),1)]),P(`label`,rD,[p[1]||=P(`span`,{class:`prop-name`,title:`The title on the canvas`},`flow label`,-1),k(P(`input`,{type:`text`,"onUpdate:modelValue":p[0]||=e=>t.value.properties.label=e,placeholder:t.value.label,onInput:s},null,40,iD),[[Ko,t.value.properties.label]])]),n.value?(M(),N(j,{key:0},[n.value.presetType?(M(),ma(eT,{key:t.value.id,"preset-type":n.value.presetType,properties:i.value,onApplied:s},null,8,[`preset-type`,`properties`])):F(``,!0),n.value.description?(M(),N(`p`,aD,E(n.value.description),1)):F(``,!0),(M(!0),N(j,null,A((n.value.properties??[]).filter(e=>!e.hidden),e=>(M(),N(j,{key:e.name??e.label},[!e.visibleWhen||mn(_s)(e.visibleWhen,i.value)?(M(),N(j,{key:0},[e.kind===`pin`?(M(),ma(Rw,{key:0,label:e.label,optional:e.optional,"model-value":i.value[e.name],"onUpdate:modelValue":t=>c(e.name,t)},null,8,[`label`,`optional`,`model-value`,`onUpdate:modelValue`])):e.kind===`colour`?(M(),ma(zE,{key:1,label:e.label,"model-value":l(e),"onUpdate:modelValue":t=>u(e,t)},null,8,[`label`,`model-value`,`onUpdate:modelValue`])):e.kind===`palette`?(M(),ma(NE,{key:2,properties:i.value,onChanged:s},null,8,[`properties`])):e.kind===`configRef`?(M(),ma(iE,{key:3,"config-type":e.configType,label:e.label,"model-value":l(e)||void 0,"onUpdate:modelValue":t=>u(e,t)},null,8,[`config-type`,`label`,`model-value`,`onUpdate:modelValue`])):e.kind===`credential`?(M(),ma(CE,{key:4,"credential-type":e.credentialType,label:e.label,"model-value":l(e)||void 0,"onUpdate:modelValue":t=>u(e,t)},null,8,[`credential-type`,`label`,`model-value`,`onUpdate:modelValue`])):e.kind===`boolean`?(M(),N(`label`,oD,[P(`span`,sD,E(e.label),1),k(P(`input`,{type:`checkbox`,class:`prop-check`,"onUpdate:modelValue":t=>i.value[e.name]=t,onChange:t=>f(e)},null,40,cD),[[qo,i.value[e.name]]])])):e.kind===`target`?(M(),N(`p`,lD,E(e.label)+` — the board/processor this flow targets, resolved when the flow is compiled.`,1)):e.kind===`nodeId`?(M(),N(j,{key:7},[],64)):(M(),N(`label`,{key:8,class:De(e.kind===`textarea`?`prop-stacked`:`prop-row`)},[P(`span`,uD,E(e.label),1),e.kind===`select`?k((M(),N(`select`,{key:0,"onUpdate:modelValue":t=>i.value[e.name]=t,onChange:t=>f(e)},[(M(!0),N(j,null,A(e.options,e=>(M(),N(`option`,{key:e.value,value:e.value},E(e.label),9,fD))),128))],40,dD)),[[Xo,i.value[e.name]]]):e.kind===`textarea`?k((M(),N(`textarea`,{key:1,rows:e.rows??4,placeholder:d(e),spellcheck:`false`,"onUpdate:modelValue":t=>i.value[e.name]=t,onInput:t=>f(e)},null,40,pD)),[[Ko,i.value[e.name]]]):e.kind===`number`?k((M(),N(`input`,{key:2,type:`number`,min:e.min,max:e.max,step:e.step,placeholder:d(e),"onUpdate:modelValue":t=>i.value[e.name]=t,onInput:t=>f(e)},null,40,mD)),[[Ko,i.value[e.name],void 0,{number:!0}]]):e.kind===`password`?k((M(),N(`input`,{key:3,type:`password`,placeholder:d(e),"onUpdate:modelValue":t=>i.value[e.name]=t,onInput:t=>f(e)},null,40,hD)),[[Ko,i.value[e.name]]]):k((M(),N(`input`,{key:4,type:`text`,placeholder:d(e),"onUpdate:modelValue":t=>i.value[e.name]=t,onInput:t=>f(e)},null,40,gD)),[[Ko,i.value[e.name]]])],2)),e.help?(M(),N(`p`,_D,E(e.help),1)):F(``,!0)],64)):F(``,!0)],64))),128)),n.value.screenOutline?(M(),ma(tD,{key:2,"screen-id":t.value.id},null,8,[`screen-id`])):F(``,!0),r.value?(M(),N(`p`,vD,`Custom node (`+E(n.value.type)+`) -- loaded this session only; reload its package after a page refresh.`,1)):F(``,!0)],64)):F(``,!0)],64)):F(``,!0)],2))}}),[[`__scopeId`,`data-v-dfcfdf9a`]]),bD={id:`pane-tabs`},xD=[`onClick`,`onDblclick`],SD=[`onKeydown`,`onBlur`],CD={key:1,class:`pane-label`,title:`Double-click to rename`},wD=[`onClick`],TD=MC(pr({__name:`PaneTabs`,emits:[`deletePane`],setup(e,{emit:t}){let n=t;function r(e){Kx(e)}function i(){Kx(Wx())}let a=O(null),o=O(``),s=O(null);async function c(e){a.value=e.id,o.value=e.name,await In();let t=Array.isArray(s.value)?s.value[0]:s.value;t?.focus(),t?.select()}function l(e){if(a.value!==e)return;let t=o.value.trim();t!==``&&Gx(e,t),a.value=null}function u(e){if(Lx.value.length<=1)return;let t=$x(e.id).length,r=t===1?`node`:`nodes`,i=t>0?`Delete pane "${e.name}" and its ${t} ${r}? This cannot be undone.`:`Delete pane "${e.name}"?`;window.confirm(i)&&n(`deletePane`,e.id)}return(e,t)=>(M(),N(`div`,bD,[(M(!0),N(j,null,A(mn(Lx),e=>(M(),N(`div`,{key:e.id,class:De([`pane-tab`,{active:e.id===mn(Rx)}]),onClick:t=>r(e.id),onDblclick:t=>c(e)},[a.value===e.id?k((M(),N(`input`,{key:0,ref_for:!0,ref_key:`renameInputRef`,ref:s,"onUpdate:modelValue":t[0]||=e=>o.value=e,class:`pane-rename-input`,onClick:t[1]||=os(()=>{},[`stop`]),onDblclick:t[2]||=os(()=>{},[`stop`]),onKeydown:[cs(t=>l(e.id),[`enter`]),t[3]||=cs(e=>a.value=null,[`escape`])],onBlur:t=>l(e.id)},null,40,SD)),[[Ko,o.value]]):(M(),N(`span`,CD,E(e.name),1)),P(`button`,{class:`pane-close`,title:`Remove this pane (and its nodes)`,onClick:os(t=>u(e),[`stop`])},`×`,8,wD)],42,xD))),128)),P(`button`,{id:`pane-add`,title:`Add a new pane`,onClick:i},`+`)]))}}),[[`__scopeId`,`data-v-10187bae`]]),ED=[{description:`Thingstudio flow`,accept:{"application/json":[`.json`]}}],DD=class extends Error{constructor(e){super(`no permission to use ${e}`),this.name=`FilePermissionError`}};async function OD(e,t){if(e.queryPermission&&e.requestPermission&&await e.queryPermission({mode:t})!==`granted`&&await e.requestPermission({mode:t})!==`granted`)throw new DD(e.name)}async function kD(e,t){await OD(e,`readwrite`);let n=await e.createWritable();return await n.write(t),await n.close(),{handle:e,lastModified:(await e.getFile()).lastModified}}async function AD(e){try{return(await e.getFile()).lastModified}catch{return null}}function jD(e,t,n){let r=URL.createObjectURL(new Blob([e],{type:n})),i=document.createElement(`a`);i.href=r,i.download=t,i.click(),setTimeout(()=>URL.revokeObjectURL(r),1e3)}async function MD(e,t,n={}){let r=window;if(r.showSaveFilePicker&&n.picker!==!1){let n;try{n=await r.showSaveFilePicker({suggestedName:t,types:ED})}catch(e){if(e instanceof Error&&e.name===`AbortError`)return null;throw e}return kD(n,e)}return jD(e,t,`application/json`),`downloaded`}async function ND(e={}){let t=window;if(t.showOpenFilePicker&&e.picker!==!1){let e;try{e=await t.showOpenFilePicker({types:ED})}catch(e){if(e instanceof Error&&e.name===`AbortError`)return null;throw e}let n=e[0],r=await n.getFile();return{text:await r.text(),ref:{handle:n,lastModified:r.lastModified}}}return new Promise(e=>{let t=document.createElement(`input`);t.type=`file`,t.accept=`.json,.flow.json,application/json`,t.addEventListener(`change`,()=>{let n=t.files?.[0];n?n.text().then(t=>e({text:t,ref:null})):e(null)}),t.click()})}async function PD(e,t){if(e===t)return!0;if(e.isSameEntry)try{return await e.isSameEntry(t)}catch{return!1}return!1}async function FD(e,t,n=8){let r=[];for(let n of e)await PD(n.handle,t.handle)||r.push(n);return[t,...r].slice(0,n)}var ID=`thingstudio-editor`,LD=`recent-files`,RD=`list`;function zD(){return new Promise((e,t)=>{let n=indexedDB.open(ID,1);n.onupgradeneeded=()=>n.result.createObjectStore(LD),n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error)})}async function BD(e){try{let t=await zD();return await new Promise((n,r)=>{let i=t.transaction(LD,`readwrite`);i.objectStore(LD).put([...e],RD),i.oncomplete=()=>n(),i.onerror=()=>r(i.error)}),!0}catch{return!1}}var VD=[{label:`Blink an LED`,text:`{
  "formatVersion": 1,
  "flowName": "blink",
  "nodes": [
    {
      "id": "b1ink0timer00001",
      "type": "thingstudio/timer",
      "properties": { "intervalMs": 500 }
    },
    {
      "id": "b1ink0onoff00002",
      "type": "thingstudio/function",
      "properties": {
        "code": "msg['payload'] = msg['payload'] % 2\\nreturn msg",
        "outputCount": 1
      }
    },
    {
      "id": "b1ink0gpio000003",
      "type": "thingstudio/gpio_out",
      "properties": { "pin": 15 }
    }
  ],
  "edges": [
    ["b1ink0timer00001", 0, "b1ink0onoff00002", 0],
    ["b1ink0onoff00002", 0, "b1ink0gpio000003", 0]
  ],
  "layout": {
    "b1ink0timer00001": { "pos": [80, 200] },
    "b1ink0onoff00002": { "pos": [320, 200] },
    "b1ink0gpio000003": { "pos": [560, 200] }
  },
  "configs": []
}
`},{label:`Two more blinks`,text:`{
  "formatVersion": 1,
  "flowName": "two more blinks",
  "nodes": [
    {
      "id": "pinset0timer00001",
      "type": "thingstudio/timer",
      "properties": {
        "intervalMs": 500
      }
    },
    {
      "id": "pinset0func00002",
      "type": "thingstudio/function",
      "properties": {
        "code": "import machine\\nmsg['payload'] = 0 if machine.Pin(15).value() else 1\\nreturn msg",
        "outputCount": 1
      }
    },
    {
      "id": "pinset0gpio00003",
      "type": "thingstudio/gpio_out",
      "properties": {
        "pin": 15
      }
    }
  ],
  "edges": [
    [
      "pinset0timer00001",
      0,
      "pinset0func00002",
      0
    ],
    [
      "pinset0func00002",
      0,
      "pinset0gpio00003",
      0
    ]
  ],
  "layout": {
    "pinset0timer00001": {
      "pos": [
        80,
        80
      ]
    },
    "pinset0func00002": {
      "pos": [
        300,
        80
      ]
    },
    "pinset0gpio00003": {
      "pos": [
        520,
        80
      ]
    }
  },
  "configs": []
}
`},{label:`Web Blink: an LED from your browser`,text:`{
  "formatVersion": 1,
  "flowName": "http-blink",
  "nodes": [
    {
      "id": "httpbl0wifistat01",
      "type": "thingstudio/wifi_status",
      "properties": {
        "pollMs": 5000,
        "wifiConfigId": "httpb0wifi0000001"
      }
    },
    {
      "id": "httpbl0debug00002",
      "type": "thingstudio/debug",
      "properties": {}
    },
    {
      "id": "httpbl0httpin00005",
      "type": "thingstudio/http_in",
      "properties": {
        "port": 9999,
        "path": "/toggle",
        "method": "GET",
        "responseTimeoutMs": 10000,
        "wifiConfigId": "httpb0wifi0000001"
      }
    },
    {
      "id": "httpbl0funct00006",
      "type": "thingstudio/function",
      "properties": {
        "code": "on = not context.get('on', False)\\ncontext.set('on', on)\\nmsg['payload'] = on\\nreply = dict(msg)\\nreply['payload'] = 'LED ' + ('on' if on else 'off')\\nreturn [msg, reply]",
        "outputCount": 2
      }
    },
    {
      "id": "httpbl0gpio00007",
      "type": "thingstudio/gpio_out",
      "properties": { "pin": 15 }
    },
    {
      "id": "httpbl0respon00008",
      "type": "thingstudio/http_response",
      "properties": {}
    }
  ],
  "edges": [
    ["httpbl0wifistat01", 0, "httpbl0debug00002", 0],
    ["httpbl0httpin00005", 0, "httpbl0funct00006", 0],
    ["httpbl0funct00006", 0, "httpbl0gpio00007", 0],
    ["httpbl0funct00006", 1, "httpbl0respon00008", 0]
  ],
  "layout": {
    "httpbl0wifistat01": { "pos": [80, 140] },
    "httpbl0debug00002": { "pos": [300, 140] },
    "httpbl0httpin00005": { "pos": [80, 240] },
    "httpbl0funct00006": { "pos": [300, 240] },
    "httpbl0gpio00007": { "pos": [520, 240] },
    "httpbl0respon00008": { "pos": [520, 310] }
  },
  "configs": [
    {
      "id": "httpb0wifi0000001",
      "type": "thingstudio/config/wifi",
      "properties": {
        "credentialName": "",
        "security": "password"
      }
    }
  ]
}
`},{label:`Blink from anywhere (MQTT)`,text:`{
  "formatVersion": 1,
  "flowName": "blink from anywhere",
  "nodes": [
    {
      "id": "1",
      "type": "thingstudio/inject",
      "properties": {
        "payloadType": "string",
        "payloadValue": "pressed",
        "repeat": "manual"
      }
    },
    {
      "id": "2",
      "type": "thingstudio/mqtt_publish",
      "properties": {
        "topic": "thingstudio/change-this-number/button",
        "retain": false,
        "qos": 0,
        "brokerConfigId": "8e47a2b3-1c9d-4e60-b5f2-6a3d9c0e7b24",
        "wifiConfigId": "3c1d5f10-6b2e-4f7a-9a41-0d2b7e5c8a11"
      }
    },
    {
      "id": "3",
      "type": "thingstudio/mqtt_subscribe",
      "properties": {
        "topic": "thingstudio/change-this-number/led",
        "qos": 0,
        "brokerConfigId": "8e47a2b3-1c9d-4e60-b5f2-6a3d9c0e7b24",
        "wifiConfigId": "3c1d5f10-6b2e-4f7a-9a41-0d2b7e5c8a11"
      }
    },
    {
      "id": "4",
      "type": "thingstudio/function",
      "properties": {
        "code": "msg['payload'] = str(msg['payload']).lower() in ('on', '1', 'true')\\nreturn msg",
        "outputCount": 1
      }
    },
    {
      "id": "5",
      "type": "thingstudio/gpio_out",
      "properties": {
        "pin": 15
      }
    },
    {
      "id": "6",
      "type": "thingstudio/debug",
      "properties": {}
    }
  ],
  "edges": [
    [
      "1",
      0,
      "2",
      0
    ],
    [
      "3",
      0,
      "4",
      0
    ],
    [
      "4",
      0,
      "5",
      0
    ],
    [
      "3",
      0,
      "6",
      0
    ]
  ],
  "layout": {
    "1": {
      "pos": [
        60,
        60
      ],
      "size": [
        96,
        34
      ]
    },
    "2": {
      "pos": [
        280,
        60
      ],
      "size": [
        128,
        34
      ]
    },
    "3": {
      "pos": [
        60,
        160
      ],
      "size": [
        132,
        34
      ]
    },
    "4": {
      "pos": [
        280,
        160
      ],
      "size": [
        96,
        34
      ]
    },
    "5": {
      "pos": [
        500,
        160
      ],
      "size": [
        96,
        34
      ]
    },
    "6": {
      "pos": [
        280,
        230
      ],
      "size": [
        84,
        34
      ]
    }
  },
  "configs": [
    {
      "id": "3c1d5f10-6b2e-4f7a-9a41-0d2b7e5c8a11",
      "type": "thingstudio/config/wifi",
      "properties": {
        "credentialName": "",
        "security": "password"
      }
    },
    {
      "id": "8e47a2b3-1c9d-4e60-b5f2-6a3d9c0e7b24",
      "type": "thingstudio/config/mqtt-broker",
      "properties": {
        "credentialName": ""
      }
    }
  ]
}
`},{label:`Sensor dashboard on a touchscreen`,text:`{
  "formatVersion": 1,
  "flowName": "gui-headliner-sensor-freenove-s3-4in",
  "nodes": [
    {
      "id": "n01-sensor",
      "type": "thingstudio/bme280",
      "properties": {
        "i2cConfigId": "cfg-i2c",
        "address": 118,
        "intervalMs": 5000
      }
    },
    {
      "id": "n02-split",
      "type": "thingstudio/function",
      "properties": {
        "code": "# One BME280 reading in; one value out each way. A BMP280 has no humidity, so that output stays quiet.\\np = msg['payload']\\nt = {'topic': 'temperature', 'payload': p['temperature']}\\nh = None\\nif p['humidity'] is not None:\\n    h = {'topic': 'humidity', 'payload': p['humidity']}\\npr = {'topic': 'pressure', 'payload': p['pressure']}\\nok = {'topic': 'sensor', 'payload': True}\\nreturn [t, h, pr, pr, ok]\\n",
        "outputCount": 5
      }
    },
    {
      "id": "n03-temp",
      "type": "thingstudio/gui_readout",
      "properties": {
        "name": "Temperature",
        "units": "°C",
        "decimals": 1,
        "lo": -20,
        "hi": 50,
        "staleAfter": 15
      }
    },
    {
      "id": "n04-hum",
      "type": "thingstudio/gui_readout",
      "properties": {
        "name": "Humidity",
        "units": "%",
        "decimals": 0,
        "lo": 0,
        "hi": 100,
        "staleAfter": 15
      }
    },
    {
      "id": "n05-press",
      "type": "thingstudio/gui_readout",
      "properties": {
        "name": "Pressure",
        "units": "hPa",
        "decimals": 0,
        "lo": 900,
        "hi": 1100,
        "staleAfter": 15
      }
    },
    {
      "id": "n06-pbar",
      "type": "thingstudio/gui_trend",
      "properties": {
        "name": "Pressure trend",
        "lo": 970,
        "hi": 1050,
        "columns": 60,
        "colWidth": 3,
        "height": 120,
        "staleAfter": 30
      }
    },
    {
      "id": "n07-alive",
      "type": "thingstudio/gui_led",
      "properties": {
        "name": "Sensor",
        "staleAfter": 15
      }
    },
    {
      "id": "n08-tick",
      "type": "thingstudio/timer",
      "properties": {
        "intervalMs": 8000
      }
    },
    {
      "id": "n09-next",
      "type": "thingstudio/function",
      "properties": {
        "code": "msg['payload'] = 'next'\\nreturn msg\\n",
        "outputCount": 1
      }
    },
    {
      "id": "n10-nav",
      "type": "thingstudio/gui_navigator",
      "properties": {
        "name": "nav",
        "screen": ""
      }
    },
    {
      "id": "n11-navdbg",
      "type": "thingstudio/debug",
      "properties": {
        "fullMessage": false
      }
    },
    {
      "id": "n12-screen",
      "type": "thingstudio/gui_screen",
      "properties": {
        "name": "tft",
        "minInterval": 200,
        "wrap": true,
        "touchPanelConfigId": "cfg-touch",
        "gridColumns": 12,
        "gridRows": 0
      }
    },
    {
      "id": "n13-display",
      "type": "thingstudio/display_spi",
      "properties": {
        "controller": "st7796",
        "frameFormat": "rgb565",
        "spiBus": 1,
        "baudrate": 40000000,
        "sck": 12,
        "mosi": 11,
        "dc": 46,
        "cs": 10,
        "reset": -1,
        "backlight": 45,
        "width": 320,
        "height": 480,
        "rotation": 1,
        "xstart": -1,
        "ystart": -1,
        "colorOrder": "bgr",
        "invertColors": true,
        "dataLatchOrder": true,
        "orientation": "90"
      }
    },
    {
      "id": "n20-tj1",
      "type": "thingstudio/journal",
      "properties": {
        "rows": 156,
        "stepSeconds": 10,
        "steps": 6,
        "xff": 0.5
      }
    },
    {
      "id": "n21-tj2",
      "type": "thingstudio/journal",
      "properties": {
        "rows": 156,
        "stepSeconds": 0,
        "steps": 0,
        "xff": 0.5
      }
    },
    {
      "id": "n22-ttrend1",
      "type": "thingstudio/gui_trend",
      "properties": {
        "name": "Temperature, minutes",
        "lo": 15,
        "hi": 30,
        "columns": 60,
        "colWidth": 3,
        "height": 52,
        "staleAfter": 30
      }
    },
    {
      "id": "n23-ttrend2",
      "type": "thingstudio/gui_trend",
      "properties": {
        "name": "Temperature, hours",
        "lo": 15,
        "hi": 30,
        "columns": 60,
        "colWidth": 3,
        "height": 52,
        "staleAfter": 0
      }
    },
    {
      "id": "n24-pj",
      "type": "thingstudio/journal",
      "properties": {
        "rows": 156,
        "stepSeconds": 60,
        "steps": 0,
        "xff": 0.5
      }
    },
    {
      "id": "n30-pub-t",
      "type": "thingstudio/mqtt_publish",
      "properties": {
        "topic": "thingstudio/headliner/temperature",
        "retain": false,
        "qos": 0,
        "brokerConfigId": "cfg-mqtt"
      }
    },
    {
      "id": "n31-pub-h",
      "type": "thingstudio/mqtt_publish",
      "properties": {
        "topic": "thingstudio/headliner/humidity",
        "retain": false,
        "qos": 0,
        "brokerConfigId": "cfg-mqtt"
      }
    },
    {
      "id": "n32-pub-p",
      "type": "thingstudio/mqtt_publish",
      "properties": {
        "topic": "thingstudio/headliner/pressure",
        "retain": false,
        "qos": 0,
        "brokerConfigId": "cfg-mqtt"
      }
    },
    {
      "id": "n41-ctick",
      "type": "thingstudio/timer",
      "properties": {
        "intervalMs": 1000
      }
    },
    {
      "id": "n40-ntp-time",
      "type": "thingstudio/ntp",
      "properties": {
        "server": "pool.ntp.org",
        "utcOffset": 0,
        "dst": "eu",
        "format": "time"
      }
    },
    {
      "id": "n44-ntp-date",
      "type": "thingstudio/ntp",
      "properties": {
        "server": "pool.ntp.org",
        "utcOffset": 0,
        "dst": "eu",
        "format": "date"
      }
    },
    {
      "id": "n42-ctime",
      "type": "thingstudio/gui_label",
      "properties": {
        "name": "Time",
        "maxChars": 5,
        "staleAfter": 0,
        "font": "font_seg764"
      }
    },
    {
      "id": "n43-cdate",
      "type": "thingstudio/gui_label",
      "properties": {
        "name": "Date",
        "maxChars": 10,
        "staleAfter": 0
      }
    }
  ],
  "edges": [
    [
      "n01-sensor",
      0,
      "n02-split",
      0
    ],
    [
      "n02-split",
      0,
      "n03-temp",
      0
    ],
    [
      "n02-split",
      1,
      "n04-hum",
      0
    ],
    [
      "n02-split",
      2,
      "n05-press",
      0
    ],
    [
      "n02-split",
      4,
      "n07-alive",
      0
    ],
    [
      "n08-tick",
      0,
      "n09-next",
      0
    ],
    [
      "n09-next",
      0,
      "n10-nav",
      0
    ],
    [
      "n10-nav",
      0,
      "n11-navdbg",
      0
    ],
    [
      "n12-screen",
      0,
      "n13-display",
      0
    ],
    [
      "n02-split",
      0,
      "n20-tj1",
      0
    ],
    [
      "n20-tj1",
      0,
      "n22-ttrend1",
      0
    ],
    [
      "n20-tj1",
      1,
      "n21-tj2",
      0
    ],
    [
      "n21-tj2",
      0,
      "n23-ttrend2",
      0
    ],
    [
      "n02-split",
      3,
      "n24-pj",
      0
    ],
    [
      "n24-pj",
      0,
      "n06-pbar",
      0
    ],
    [
      "n02-split",
      0,
      "n30-pub-t",
      0
    ],
    [
      "n02-split",
      1,
      "n31-pub-h",
      0
    ],
    [
      "n02-split",
      2,
      "n32-pub-p",
      0
    ],
    [
      "n41-ctick",
      0,
      "n40-ntp-time",
      0
    ],
    [
      "n41-ctick",
      0,
      "n44-ntp-date",
      0
    ],
    [
      "n40-ntp-time",
      0,
      "n42-ctime",
      0
    ],
    [
      "n44-ntp-date",
      0,
      "n43-cdate",
      0
    ]
  ],
  "layout": {
    "n01-sensor": {
      "pos": [
        60,
        200
      ]
    },
    "n02-split": {
      "pos": [
        280,
        200
      ]
    },
    "n20-tj1": {
      "pos": [
        520,
        40
      ]
    },
    "n22-ttrend1": {
      "pos": [
        760,
        40
      ]
    },
    "n21-tj2": {
      "pos": [
        760,
        120
      ]
    },
    "n23-ttrend2": {
      "pos": [
        980,
        120
      ]
    },
    "n03-temp": {
      "pos": [
        520,
        220
      ]
    },
    "n04-hum": {
      "pos": [
        520,
        290
      ]
    },
    "n07-alive": {
      "pos": [
        520,
        360
      ]
    },
    "n05-press": {
      "pos": [
        520,
        430
      ]
    },
    "n24-pj": {
      "pos": [
        520,
        510
      ]
    },
    "n06-pbar": {
      "pos": [
        760,
        510
      ]
    },
    "n08-tick": {
      "pos": [
        60,
        640
      ]
    },
    "n09-next": {
      "pos": [
        280,
        640
      ]
    },
    "n10-nav": {
      "pos": [
        520,
        640
      ]
    },
    "n11-navdbg": {
      "pos": [
        760,
        640
      ]
    },
    "n12-screen": {
      "pos": [
        1000,
        300
      ]
    },
    "n13-display": {
      "pos": [
        1220,
        300
      ]
    },
    "n30-pub-t": {
      "pos": [
        760,
        200
      ]
    },
    "n31-pub-h": {
      "pos": [
        760,
        270
      ]
    },
    "n32-pub-p": {
      "pos": [
        760,
        340
      ]
    },
    "n41-ctick": {
      "pos": [
        60,
        780
      ]
    },
    "n40-ntp-time": {
      "pos": [
        280,
        780
      ]
    },
    "n44-ntp-date": {
      "pos": [
        280,
        850
      ]
    },
    "n42-ctime": {
      "pos": [
        520,
        780
      ]
    },
    "n43-cdate": {
      "pos": [
        520,
        850
      ]
    }
  },
  "configs": [
    {
      "id": "cfg-i2c",
      "type": "thingstudio/config/i2c-bus",
      "properties": {
        "bus": 0,
        "scl": 15,
        "sda": 16,
        "freq": 100000
      }
    },
    {
      "id": "cfg-touch",
      "type": "thingstudio/config/touch-panel",
      "properties": {
        "controller": "ft6336u",
        "i2cConfigId": "cfg-i2c",
        "address": "0x38",
        "rstPin": "",
        "pollMs": 20,
        "width": 320,
        "height": 480,
        "swapXY": false,
        "flipX": false,
        "flipY": false
      }
    },
    {
      "id": "cfg-wifi",
      "type": "thingstudio/config/wifi",
      "properties": {
        "credentialName": "mihome",
        "security": "password",
        "allowReprovisioning": false
      }
    },
    {
      "id": "cfg-mqtt",
      "type": "thingstudio/config/mqtt-broker",
      "properties": {
        "credentialName": "verdi-mqtt-broker"
      }
    }
  ],
  "panes": [
    {
      "id": "pane-1",
      "name": "Flow 1"
    }
  ],
  "paneOf": {
    "n01-sensor": "pane-1",
    "n02-split": "pane-1",
    "n03-temp": "pane-1",
    "n04-hum": "pane-1",
    "n05-press": "pane-1",
    "n06-pbar": "pane-1",
    "n07-alive": "pane-1",
    "n08-tick": "pane-1",
    "n09-next": "pane-1",
    "n10-nav": "pane-1",
    "n11-navdbg": "pane-1",
    "n12-screen": "pane-1",
    "n13-display": "pane-1",
    "n41-ctick": "pane-1",
    "n40-ntp-time": "pane-1",
    "n44-ntp-date": "pane-1",
    "n42-ctime": "pane-1",
    "n43-cdate": "pane-1"
  },
  "screens": {
    "n12-screen": {
      "pages": [
        {
          "name": "climate",
          "elements": [
            {
              "kind": "text",
              "text": "Living room",
              "row": 0,
              "col": 0,
              "rowSpan": 1,
              "colSpan": 3
            },
            {
              "kind": "widget",
              "node": "n07-alive",
              "row": 0,
              "col": 3,
              "rowSpan": 1,
              "colSpan": 9
            },
            {
              "kind": "text",
              "text": "Temperature",
              "row": 2,
              "col": 0,
              "rowSpan": 1,
              "colSpan": 5
            },
            {
              "kind": "widget",
              "node": "n03-temp",
              "row": 3,
              "col": 0,
              "rowSpan": 1,
              "colSpan": 5
            },
            {
              "kind": "text",
              "text": "Humidity",
              "row": 2,
              "col": 5,
              "rowSpan": 1,
              "colSpan": 4
            },
            {
              "kind": "widget",
              "node": "n04-hum",
              "row": 3,
              "col": 5,
              "rowSpan": 1,
              "colSpan": 4
            },
            {
              "kind": "text",
              "text": "Last 26 minutes",
              "row": 4,
              "col": 0,
              "rowSpan": 1,
              "colSpan": 12
            },
            {
              "kind": "widget",
              "node": "n22-ttrend1",
              "row": 5,
              "col": 0,
              "rowSpan": 1,
              "colSpan": 12
            },
            {
              "kind": "text",
              "text": "Last 2.6 hours",
              "row": 6,
              "col": 0,
              "rowSpan": 1,
              "colSpan": 12
            },
            {
              "kind": "widget",
              "node": "n23-ttrend2",
              "row": 7,
              "col": 0,
              "rowSpan": 1,
              "colSpan": 12
            },
            {
              "kind": "pagedots",
              "row": 2,
              "col": 9,
              "rowSpan": 1,
              "colSpan": 1
            }
          ]
        },
        {
          "name": "pressure",
          "elements": [
            {
              "kind": "text",
              "text": "Pressure",
              "row": 0,
              "col": 0,
              "rowSpan": 1,
              "colSpan": 12
            },
            {
              "kind": "widget",
              "node": "n05-press",
              "row": 1,
              "col": 3,
              "rowSpan": 1,
              "colSpan": 5
            },
            {
              "kind": "widget",
              "node": "n06-pbar",
              "row": 2,
              "col": 0,
              "rowSpan": 3,
              "colSpan": 12
            },
            {
              "kind": "text",
              "text": "Last 2.6 hours, 970 to 1050 hPa",
              "row": 6,
              "col": 0,
              "rowSpan": 1,
              "colSpan": 12
            },
            {
              "kind": "pagedots",
              "row": 7,
              "col": 6,
              "rowSpan": 1,
              "colSpan": 1
            }
          ]
        },
        {
          "name": "clock",
          "elements": [
            {
              "kind": "text",
              "text": "Clock",
              "row": 0,
              "col": 0,
              "rowSpan": 1,
              "colSpan": 12
            },
            {
              "kind": "widget",
              "node": "n42-ctime",
              "row": 2,
              "col": 3,
              "rowSpan": 2,
              "colSpan": 6
            },
            {
              "kind": "widget",
              "node": "n43-cdate",
              "row": 4,
              "col": 3,
              "rowSpan": 1,
              "colSpan": 6
            },
            {
              "kind": "pagedots",
              "row": 7,
              "col": 6,
              "rowSpan": 1,
              "colSpan": 1
            }
          ]
        }
      ]
    }
  },
  "notes": "Climate on the Freenove FNK0104S: a BME280 on the touch panel's I2C bus (SCL 15, SDA 16, address 0x76) shows temperature, humidity and pressure in landscape (the display's orientation is 90).\\n\\nReadings come every 5 seconds. Two journals keep the temperature, as in RRDtool: one row per 10 seconds for the last 26 minutes, and its per-minute roll-up (average, with min and max) for the last 2.6 hours. Each bar is the average and the thin line its min to max. Pressure keeps a row a minute. The trend range is fixed (15 to 30 C, 970 to 1050 hPa): change it in the trend's properties. A reading that stops arriving dims the numbers after 15 seconds and the Sensor light goes grey. The pages change by themselves every 8 seconds. The third page is a clock in seven-segment digits: two ntp nodes, one sending the time and one the date, get it over WiFi (UK / EU summer time applied automatically, UTC offset 0: set both ntp nodes' offset for other zones). It shows -- until WiFi is up and the first sync works.\\n\\nEach reading is also published over MQTT to thingstudio/headliner/temperature, /humidity and /pressure on your broker (the WiFi and broker settings are the ones named mihome and verdi-mqtt-broker: change them in the flow's settings to your own).\\n\\nWire the sensor to 3V3, GND, SCL 15 and SDA 16. Set the screen's width and height to the panel's own size (320x480) when you turn the display."
}
`,board:`board:freenove-s3-4in`}],HD={wifi:{name:`demo-wifi`,values:{ssid:`demo-network`,password:`made-up-password`}},"mqtt-broker":{name:`demo-broker`,values:{broker:`broker.example.com`,port:1883,username:``,password:``}}},UD={"thingstudio/config/wifi":`wifi`,"thingstudio/config/mqtt-broker":`mqtt-broker`};async function WD(e){let t;try{t=JSON.parse(e)}catch{return e}for(let e of Array.isArray(t.configs)?t.configs:[]){let t=typeof e?.type==`string`?UD[e.type]:void 0;if(!t)continue;let n=e.properties??={};if(t===`wifi`&&n.security===`unmanaged`)continue;let r=typeof n.credentialName==`string`&&n.credentialName?n.credentialName:HD[t].name;n.credentialName=r,await Cw(t,r,HD[t].values)}return JSON.stringify(t)}var GD=e=>document.getElementById(e);async function KD(e){GD(`demo-version`).textContent=e.versionLabel;async function t(t){try{await e.openFlowText(await WD(t.text)),e.chooseBoard(t.board??`auto`)}catch(n){e.log(`[demo] couldn't open "${t.label}": ${n instanceof Error?n.message:String(n)}`,`err`)}}let n=GD(`examplesMenuList`);for(let e of VD){let r=document.createElement(`button`);r.setAttribute(`role`,`menuitem`),r.textContent=e.label,r.addEventListener(`click`,()=>void t(e)),n.appendChild(r)}GD(`btnCompile`).addEventListener(`click`,async()=>{let t=GD(`btnCompile`);t.disabled=!0;try{await e.compile()}finally{t.disabled=!1}let n=GD(`previewPanel`);n.open=!0,n.scrollIntoView({block:`nearest`})}),e.log(`[demo] No board here: Compile shows the Python a board would run. Examples ▾ has more flows.`,``);let r=VD[0];r&&await t(r)}var Q=e=>document.getElementById(e);function qD(){let e=Q(`flowNameInput`).value.trim();return e===``?Ax:e}var JD=Q(`rete-canvas`),YD=await zC(JD),XD=YD.editor,ZD=YD.area,QD=0;function $D(){let e=QD%3,t=Math.floor(QD/3);return QD++,{x:80+e*220,y:80+t*160}}async function eO(e,t){let n=hC[e]();return await YD.addNode(n,t??$D()),qx(n.id),n}async function tO(e,t){let n=KC(e);if(!n)return $(`[${JC(e)}]`,`err`),null;let r=new mC(n.descriptor);return await YD.addNode(r,t??$D()),qx(r.id),r}Q(`clear-canvas`).addEventListener(`click`,async()=>{await YD.clear(),QD=0,Ox(),Qx(),nS({}),Q(`flowNotes`).value=``,Q(`flowNameInput`).value=``,cO=null,fO()}),document.addEventListener(`keydown`,e=>{if(e.key!==`Delete`&&e.key!==`Backspace`)return;let t=document.activeElement,n=t?.tagName;n===`INPUT`||n===`TEXTAREA`||n===`SELECT`||t?.isContentEditable||(e.preventDefault(),YD.deleteSelected())}),fw(),fs(lw,{onAdd:e=>{eO(e)},onAddCustom:e=>{tO(e)},onReloadCustomNodes:()=>{}}).mount(Q(`palette-mount`)),fs(yD).mount(Q(`property-panel-mount`)),fs(TD,{onDeletePane:e=>{YD.deletePane(e)}}).mount(Q(`pane-tabs-mount`)),JD.addEventListener(`dragover`,e=>e.preventDefault()),JD.addEventListener(`drop`,e=>{e.preventDefault();let t=JD.getBoundingClientRect(),{x:n,y:r,k:i}=ZD.area.transform,a=(e.clientX-t.left-n)/i,o=(e.clientY-t.top-r)/i,s=e.dataTransfer?.getData(bC);if(s){tO(s,{x:a,y:o});return}let c=e.dataTransfer?.getData(yC);c&&eO(c,{x:a,y:o})});function nO(){return{nodes:XD.getNodes().map(e=>{let t=ZD.nodeViews.get(e.id),n=t?[t.position.x,t.position.y]:[0,0];return{id:e.id,type:e.nodeType,properties:e.properties,pos:n,size:[e.width,e.height],paneId:Yx(e.id)}}),edges:XD.getConnections().map(e=>{let t=XD.getNode(e.source),n=XD.getNode(e.target),r=BC(Object.keys(t.outputs),e.sourceOutput),i=BC(Object.keys(n.inputs),e.targetInput);return[e.source,r,e.target,i]})}}function rO(){return[...vx.value.values()].map(e=>({id:e.id,type:e.type,properties:lx(e.type,e.properties)}))}var iO=new Map,aO=new Set;async function oO(e=!1){let t={"thingstudio/config/wifi":`wifi`,"thingstudio/config/mqtt-broker":`mqtt-broker`};for(let n of[...vx.value.values()]){let r=t[n.type];if(!r)continue;let i=typeof n.properties.credentialName==`string`?n.properties.credentialName:``;if(i&&!(e&&iO.get(n.id)===i))try{let e=await Sw(r,i);Ex(n.id,e),iO.set(n.id,i)}catch{{let e=`${r}:${i}`;aO.has(e)||(aO.add(e),$(`[demo] ${r} "${i}" has no values here. Open its config in the node's panel to fill in made-up ones.`,``));continue}}}}async function sO(e){await YD.clear(),QD=0;let t=ks(e.nodes,e.configs);if(t.dropped.length>0){e={...e,nodes:t.nodes,configs:t.configs};let n=e=>typeof e.properties.credentialName==`string`&&e.properties.credentialName?`"${e.properties.credentialName}"`:`#${e.id.slice(0,6)}`,r=t.configs.find(e=>e.type===Ds);$(`[load] one WiFi network per flow now: kept ${r?n(r):`?`}, removed ${t.dropped.map(n).join(`, `)}. Save to keep this.`,``)}let n=Ul(e.nodes,e.configs,()=>crypto.randomUUID());if(n.moved>0){e={...e,nodes:n.nodes,configs:n.configs},$(`[load] I2C pins moved to a shared "I2C bus" setting (${n.moved} node(s)). Save to keep this.`,``);for(let e of n.notes)$(`[load] ${e}`,`err`)}Dx(e.configs.map(e=>({id:e.id,type:e.type,properties:e.properties}))),nS(e.screens??{}),Q(`flowNotes`).value=e.notes??``,Q(`notesPanel`).open=(e.notes??``).trim()!==``,await oO();let r=new Set,i=new Map;for(let t of e.nodes){let n=KC(t.type),a;if(n)a=new mC(n.descriptor);else{let e=hC[t.type.replace(/^thingstudio\//,``)];if(!e){r.add(t.id),$(`[load: skipped node ${t.id}: ${JC(t.type)}]`,`err`);continue}a=e()}a.id=t.id,Object.assign(a.properties,t.properties),a.retypeOutputs();let o=a.descriptor.dynamicOutputs;if(o){let e=vs(o,a.properties),t=Object.keys(a.outputs).length;for(let n=t;n<e;n++)a.addDynamicOutputAt(n);for(let n=e;n<t;n++)a.removeDynamicOutputAt(n);a.properties[o.property]=e,a.setDynamicOutputHeight(e)}let s=e.layout[t.id],c=s?{x:s.pos[0],y:s.pos[1]}:{x:0,y:0};await YD.addNode(a,c),i.set(t.id,a)}for(let[t,n,a,o]of e.edges){if(r.has(t)||r.has(a))continue;let e=i.get(t),s=i.get(a);if(!e||!s){$(`[load: skipped edge from missing node ${e?a:t}]`,`err`);continue}let c=Object.keys(e.outputs)[n],l=Object.keys(s.inputs)[o];c!==void 0&&l!==void 0&&await YD.connectNodes(e,c,s,l)||$(`[load: failed to connect node ${t} slot ${n} -> node ${a} slot ${o}]`,`err`)}Zx(e.panes,e.paneOf,[...i.keys()]),QD=e.nodes.length}var cO=null,lO=[];function uO(){let{nodes:e,edges:t}=nO();return Fx(Px(e,t,rO(),qD(),Lx.value,tS.value,Q(`flowNotes`).value))}function dO(){return`${cx(qD())}.flow.json`}function fO(){let e=Q(`flowFileName`);e.hidden=cO===null,e.textContent=cO?cO.handle.name:``,e.title=cO?`Save writes to ${cO.handle.name}. File → Save As… saves somewhere else.`:``}async function pO(e){cO=e,fO(),lO=await FD(lO,{handle:e.handle,name:e.handle.name,flowName:qD(),at:Date.now()}),await BD(lO),mO()}function mO(){let e=Q(`fileMenuList`);for(let t of Array.from(e.querySelectorAll(`.recent-item`)))t.remove();let t=Q(`btnClearRecent`);Q(`recentSep`).hidden=!0,Q(`recentHeading`).hidden=!0,Q(`recentHeading`).textContent=lO.length>0?`Open recent`:`No recent files`,t.hidden=!0}function hO(e,t){let n=t??`the file`;return e instanceof DD?`${e.message}. Allow it when the browser asks, or use Save As.`:e instanceof X?`invalid flow file: ${e.message}`:e instanceof Error&&e.name===`NotFoundError`?`${n} has moved or been deleted. Use Save As.`:e instanceof Error&&e.name===`NotAllowedError`?`no permission to use ${n}. Allow it when the browser asks, or use Save As.`:e instanceof Error?e.message:String(e)}async function gO(){try{let e=await MD(uO(),dO(),{picker:!1});if(e===null)return;if(e===`downloaded`){$(`[flow saved -- downloaded]`,`ok`);return}await pO(e),$(`[flow saved to ${e.handle.name}]`,`ok`)}catch(e){$(`[save failed] ${hO(e,null)}`,`err`)}}async function _O(){if(!cO)return gO();let e=cO;try{let t=await AD(e.handle);if(t!==null&&t!==e.lastModified&&!window.confirm(`${e.handle.name} has changed on disk since you opened or last saved it. Overwrite it?`)){$(`[save cancelled] ${e.handle.name} was left as it is on disk. Use Save As to keep both.`,``);return}await pO(await kD(e.handle,uO())),$(`[flow saved to ${e.handle.name}]`,`ok`)}catch(t){$(`[save failed] ${hO(t,e.handle.name)}`,`err`)}}async function vO(e,t){let n=Ix(e);await sO(n),Q(`flowNameInput`).value=n.flowName===`untitled flow`?``:n.flowName,cO=null,t?await pO(t):fO(),$(`[flow loaded -- ${n.nodes.length} node(s)${t?` from ${t.handle.name}`:``}]`,`ok`),RO()}async function yO(){try{let e=await ND({picker:!1});if(e===null)return;await vO(e.text,e.ref)}catch(e){$(`[load failed] ${hO(e,null)}`,`err`)}}Q(`btnSaveFlow`).addEventListener(`click`,()=>void _O()),Q(`btnSaveFlowAs`).addEventListener(`click`,()=>void gO()),Q(`btnOpenFlow`).addEventListener(`click`,()=>void yO()),Q(`btnClearRecent`).addEventListener(`click`,async()=>{lO=[],await BD(lO),mO()});var bO=/Mac|iPhone|iPad/.test(navigator.platform);for(let e of Array.from(document.querySelectorAll(`.menu-key`))){let t=e.dataset.key??``;e.textContent=bO?`${e.dataset.shift?`⇧`:``}⌘${t}`:`Ctrl+${e.dataset.shift?`Shift+`:``}${t}`}document.addEventListener(`keydown`,e=>{if(!(bO?e.metaKey:e.ctrlKey)||e.altKey)return;let t=e.key.toLowerCase();t===`s`?(e.preventDefault(),e.shiftKey?gO():_O()):t===`o`&&!e.shiftKey&&(e.preventDefault(),yO())}),fO(),mO();var xO=Q(`console`),SO=`normal`;try{SO=Kh(localStorage.getItem(`thingstudio.consoleLevel`),localStorage.getItem(`thingstudio.consoleVerbose`))}catch{}function $(e,t,n){let r=document.createElement(`div`),i=Gh(e,t);r.dataset.level=i,r.hidden=!Rh(i,SO);let a=new Date;r.innerHTML=`<span class="t">[${a.toLocaleTimeString(void 0,{hour12:!1})+`.`+String(a.getMilliseconds()).padStart(3,`0`)}] </span><span class="${t??``}"></span>`;let o=r.querySelector(`span:last-child`);o.textContent=e,n!==void 0&&(o.classList.add(`node-link`),o.setAttribute(`title`,`click to locate this node on the canvas`),o.addEventListener(`click`,()=>TO(n)));let s=xO.scrollHeight-xO.scrollTop-xO.clientHeight<24;xO.appendChild(r),s&&(xO.scrollTop=xO.scrollHeight)}var CO=`https://docs.thingstudio.net/`;function wO(e){return`${CO}${e.path}`}function TO(e){let t=XD.getNode(e);t?(Kx(Yx(e)),In().then(()=>{YD.selectNode(t),YD.focusNode(t)})):$(`[locate: node ${e} not found on the canvas -- removed since, or from a different flow]`,`err`)}Q(`btnClear`).addEventListener(`click`,()=>xO.innerHTML=``);var EO=null;async function DO(e){let t=window,n=Date.now()+e;for(;!t.__thingstudioCreateMpyCross;){if(Date.now()>n)throw Error(`mpy-cross loader (public/vendor/mpy-cross/load.mjs) never populated window.__thingstudioCreateMpyCross -- check the browser console for a script-load error`);await new Promise(e=>setTimeout(e,20))}return t.__thingstudioCreateMpyCross}var OO=[],kO=(async()=>{EO=await(await DO(1e4))({print:e=>$(`[mpy-cross] `+e,``),printErr:e=>{OO.push(e),$(`[mpy-cross] `+e,`err`)}}),$(`[mpy-cross WASM ready]`,`ok`)})().catch(e=>{$(`[mpy-cross load error] ${e instanceof Error?e.message:String(e)}`,`err`)});function AO(e,t){if(!EO)throw Error(`mpy-cross not ready yet`);OO=[],EO.FS.writeFile(`/in.py`,e);try{EO.FS.unlink(`/out.mpy`)}catch{}let n=EO.callMain([...t?[`-march=`+t]:[],`-o`,`/out.mpy`,`/in.py`]);if(n!==0)throw Error(`mpy-cross exited ${n} (see console log above for stderr)`);return EO.FS.readFile(`/out.mpy`)}var jO=sp(),MO=new URL(`vendor/micropython-wasi/micropython-wasi.wasm`,document.baseURI).href,NO=Cp({createWorker:wp(),wasmUrl:MO}),PO=[],FO=[];oS(()=>XD.getNodes().flatMap(e=>{let t=e.nodeType??``;if(!t.startsWith(`thingstudio/gui_`))return[];let n=e.properties,r=typeof n?.label==`string`&&n.label.trim()?n.label:n?.name;return[{id:e.id,type:t,name:typeof r==`string`&&r.trim()?r.trim():`${t.replace(`thingstudio/`,``)} ${e.id.slice(0,6)}`}]}));async function IO(){let e={...VC(XD,[...vx.value.values()]),screens:tS.value},t=hu(jO,qC());for(let n of e.nodes)if(!t.has(n.type))throw Error(`${JC(n.type)} (node ${n.id})`);let n=await bp(e,t,NO,{target:kx.value,redactConfig:e=>lx(e.type,e.properties)}),{source:r,nodeLineRanges:i,warnings:a}=xs(e,t,{target:kx.value,hookResults:n.results,hookWarnings:n.warnings});return PO=i,FO=a,As(e),r}var LO=xp(()=>BO());function RO(){return LO.latest()}function zO(){return LO.now()}async function BO(){try{let e=await IO();return Q(`source-preview`).textContent=FO.length===0?e:`${e}\n\n${FO.map(e=>`# WARNING: ${e}`).join(`
`)}\n`,{source:e}}catch(e){let t=e instanceof Error?e.message:String(e);return Q(`source-preview`).textContent=`COMPILE ERROR: `+t,{error:t}}}function VO(){for(let e of XD.getNodes())e.highlighted&&(e.highlighted=!1,ZD.update(`node`,e.id))}function HO(e){let t=XD.getNode(e);return t?(t.highlighted=!0,ZD.update(`node`,t.id),t):null}function UO(e){let t=e.match(/line (\d+)/);if(!t)return;let n=Number(t[1]),r=PO.find(e=>n>=e.startLine&&n<=e.endLine);if(!r)return;let i=HO(r.nodeId);i&&$(`[compile error attributed to node ${r.nodeId} (${i.nodeType}), source line ${n}]`,`err`,r.nodeId)}var WO=!1,GO=!1,KO=!1;function qO(){Q(`btnDeploy`).disabled=!ZO.isConnected||WO||KO}XD.addPipe(e=>((e.type===`nodecreated`||e.type===`noderemoved`||e.type===`connectioncreated`||e.type===`connectionremoved`||e.type===`cleared`)&&(WO=!1,qO(),RO()),e)),nr(mx,()=>{WO=!1,qO(),RO()}),nr(yx,async()=>{await oO(!0),WO=!1,qO(),RO()}),RO();var JO={major:15,minor:0,patch:0},YO=`${Zg({version:`0.12.1`,commit:`27cfbd64`,dirty:!1,builtAt:`2026-11-08 13:54 UTC`})}; expects board runtime ${JO.major}.x`;{let e=Q(`editor-version`);e.textContent=Xg({version:`0.12.1`,commit:`27cfbd64`,dirty:!1,builtAt:`2026-11-08 13:54 UTC`}),e.title=YO,console.info(`[thingstudio] ${YO}`)}var XO=null,ZO={isConnected:!1,disconnect:async()=>{},send:async()=>{throw Error(`the demo has no board`)}};_x.value=e=>{ZO.isConnected?($(`[inject: firing node ${e.id}]`,``),ZO.send({type:`TRIGGER`,nodeId:e.id}).catch(e=>{$(`[inject: trigger send failed] ${e instanceof Error?e.message:String(e)}`,`err`)})):$(`[demo] ▶ fires an inject on a connected board. The demo has no board.`,``)};function QO(){let e=Q(`nativeArchSelect`).value;if(e===`auto`){let e=kx.value?.processor;return e?{arch:e.nativeArch,confirmed:e.nativeArchConfirmed,manual:!1}:{...Jh(``),manual:!1}}return{arch:e,confirmed:!0,manual:!0}}for(let e of qh){let t=document.createElement(`option`);t.value=e.value,t.textContent=e.label,Q(`nativeArchSelect`).appendChild(t)}var $O=Kc(yg,[]);function ek(){let e=Q(`boardSelect`),t=e.value||`auto`;e.replaceChildren();let n=(e,t,n,r=!1)=>{let i=document.createElement(`option`);i.value=t,i.textContent=n,i.disabled=r,e.appendChild(i)};n(e,`auto`,`Board: Auto`);let r=(e,t)=>e.name.localeCompare(t.name),i=document.createElement(`optgroup`);i.label=`Boards`;for(let e of[...$O.boards.values()].sort(r))n(i,`board:${e.id}`,e.name);let a=document.createElement(`optgroup`);a.label=`Processor only`;for(let e of[...$O.processors.values()].sort(r))n(a,`processor:${e.id}`,`${e.name} (any board)`);if(e.append(i,a),$O.problems.length>0){let t=document.createElement(`optgroup`);t.label=`Invalid files (see console)`;for(let e of $O.problems)n(t,``,`${e.source}`,!0);e.appendChild(t)}e.value=t,e.value!==t&&n(e,t,`${t} (no longer defined)`),e.value=t}function tk(){let e=Q(`boardSelect`),t=e.value||`auto`,n=Tg($O,t,XO);kx.value=n.target;let r=e.querySelector(`option[value="auto"]`);r&&(r.textContent=t===`auto`&&n.target?`Auto: ${n.target.board?.name??`${n.target.processor.name} (any board)`}`:`Board: Auto`),e.title=n.note;let i=Q(`btnBoardPins`);return i.disabled=!n.target&&!0,i.title=n.target?`Show ${n.target.label}'s pins: which are free, reserved or wired to something, and why. Opens in a new tab.`:`Pick a board in the Board menu, or connect one, to see its pins.`,nk(),RO(),n}function nk(){let e=Q(`nativeArchSelect`),t=e.querySelector(`option[value="auto"]`);if(!t)return;if(e.value!==`auto`){t.textContent=`Arch: Auto`;return}let n=QO();t.textContent=kx.value===null?`Arch: Auto`:`Arch: ${n.arch}${n.confirmed?``:` (unverified)`}`}Q(`nativeArchSelect`).addEventListener(`change`,nk);var rk=300;function ik(e){return Math.round(Math.max(rk,Math.min(e,window.innerWidth-400)))}function ak(e){let t=Q(`sidebar`);e===null?t.style.removeProperty(`--sidebar-width`):t.style.setProperty(`--sidebar-width`,`${ik(e)}px`)}{let e=null;try{e=localStorage.getItem(`thingstudio.sidebarWidth`)}catch{}e!==null&&Number.isFinite(Number(e))&&ak(Number(e));let t=Q(`sidebar-resizer`);t.addEventListener(`pointerdown`,e=>{e.preventDefault(),t.setPointerCapture(e.pointerId),t.classList.add(`dragging`);let n=e.clientX,r=Q(`sidebar`).getBoundingClientRect().width,i=e=>ak(r+(n-e.clientX)),a=()=>{t.removeEventListener(`pointermove`,i),t.removeEventListener(`pointerup`,a),t.removeEventListener(`pointercancel`,a),t.classList.remove(`dragging`);try{localStorage.setItem(`thingstudio.sidebarWidth`,String(Math.round(Q(`sidebar`).getBoundingClientRect().width)))}catch{}};t.addEventListener(`pointermove`,i),t.addEventListener(`pointerup`,a),t.addEventListener(`pointercancel`,a)}),t.addEventListener(`dblclick`,()=>{ak(null);try{localStorage.removeItem(`thingstudio.sidebarWidth`)}catch{}})}Q(`btnBoardPins`).addEventListener(`click`,async()=>{let e=window.open(``,`thingstudio-pins`);if(!e){$(`[board] The browser blocked the pins page from opening. Allow pop-ups for this page, then try again.`,`err`);return}let t=Tg($O,Q(`boardSelect`).value||`auto`,XO),n={generated:`Thingstudio's built-in definition, ${new Date().toLocaleString()}.`,docsUrl:`${CO}boards/`,unlistedBoard:t.how===`detected`&&!t.target?.board?XO:null},r;if(t.target)r=Vg(t.target,n);else{e.close(),$(`[board] Pick a board in the Board menu, or connect one, to see its pins.`,``);return}e.location.href=URL.createObjectURL(new Blob([r],{type:`text/html`})),e.focus()});function ok(e){$(`[board] ${e.note}`,e.target?`ok`:``),e.mismatch&&$(`[board] ${e.mismatch}`,`err`)}ek(),Q(`boardSelect`).addEventListener(`change`,()=>{ok(tk()),WO=!1,qO()});function sk(){let e=Q(`btnBoardSettings`),t=ZO.isConnected&&!1,n=lk()?.connectedOverNetwork??!1;e.hidden=!t,e.disabled=!t||n||GO,e.title=n?`Board settings can only be changed over USB.`:`The board's network name and WiFi password. Changes are made over USB.`}{let e=Q(`consoleLevel`);e.value=SO,e.addEventListener(`change`,()=>{let t=e.value;SO=Lh.includes(t)?t:`normal`;try{localStorage.setItem(`thingstudio.consoleLevel`,SO)}catch{}xO.querySelectorAll(`[data-level]`).forEach(e=>{e.hidden=!Rh(e.dataset.level,SO)}),xO.scrollTop=xO.scrollHeight})}Q(`btnDocs`).addEventListener(`click`,()=>{window.open(wO({label:`Docs`,path:``}),`_blank`,`noopener`)}),Q(`btnDocsGettingStarted`).addEventListener(`click`,()=>{window.open(wO({label:`Getting started`,path:`getting-started/`}),`_blank`,`noopener`)}),Q(`btnAbout`).addEventListener(`click`,async()=>{let e=[];e.push(`Thingstudio online demo: no board, no backend`),e.push(Zg({version:`0.12.1`,commit:`27cfbd64`,dirty:!1,builtAt:`2026-11-08 13:54 UTC`}));let t=JO;e.push(`Editor expects board runtime ${t.major}.x (built for ${t.major}.${t.minor}.${t.patch})`),e.push(`No board connected`),e.push(`Browser: ${navigator.userAgent}`),Q(`aboutVersions`).replaceChildren(...e.flatMap((e,t)=>t?[document.createElement(`br`),document.createTextNode(e)]:[document.createTextNode(e)])),Q(`aboutDialog`).showModal()}),new Yg({send:e=>ZO.send(e)},{timing:Wg,isRestartHello:()=>!0,onEvent:e=>{if(e.kind===`illegal`){let t=e.move;$(`[protocol] illegal: ${t.event} while ${t.state} (${t.detail})`,`err`);return}let t=e.line,n=t.type===`FLOW_PUT`||t.type===`FLOW_COMMIT`?`deploy`:`libraries`,r=t.type===`FLOW_PUT`?`flow byte ${t.offset}`:t.type===`DEP_PUT`?`${t.file} byte ${t.offset}`:`the commit`;$(`[${n}] ${e.reason===`garbled`?`board couldn't read ${r}${e.detail?` (${e.detail})`:``}`:`no reply to ${r}`}, resending (${e.attempt}/${Wg.pieceRetries})`,`err`)}});function ck(){let e=ZO.isConnected;Q(`cmdInput`).disabled=!e,Q(`btnSendCmd`).disabled=!e,Q(`btnStopToPrompt`).disabled=!e,Q(`btnRestartSoft`).disabled=!e||KO,Q(`btnRestartHard`).disabled=!e||KO,Q(`btnClearSettings`).disabled=!e||GO,Q(`btnStopToPrompt`).hidden=GO,Q(`btnResume`).hidden=!0,Q(`cmdInput`).placeholder=`Python command, e.g. gc.mem_free()`,qO(),sk()}ck();function lk(){return null}async function uk(){let e=await zO();if(`error`in e){$(`[download] The flow doesn't compile, so there's no Python yet. ${e.error}`,`err`);return}let t=`${cx(qD())}.py`;jD(e.source,t,`text/x-python`),$(`[download] ${t}`,`ok`)}Q(`btnDownloadPython`).addEventListener(`click`,()=>void uk());async function dk(){VO(),await oO();let e=await zO();if(`error`in e){$(`[compile error] ${e.error}`,`err`);return}for(let e of FO)$(`[compile warning] ${e}`,``);await kO;let t=QO(),n;try{n=AO(e.source,t.arch)}catch(e){$(`[mpy-cross error] ${e instanceof Error?e.message:String(e)}`,`err`),UO(OO.join(`
`));return}let r=e.source.split(`
`).length;$(`[compiled] ${r} lines of Python, ${n.length} bytes of bytecode for ${t.arch}. The Python is under Compiled source.`,`ok`)}KD({openFlowText:async e=>{await vO(e,null),await YD.fitView()},chooseBoard:e=>{Q(`boardSelect`).value=e,ok(tk())},compile:dk,log:$,versionLabel:Xg({version:`0.12.1`,commit:`27cfbd64`,dirty:!1,builtAt:`2026-11-08 13:54 UTC`})});